


function MM_openBrWindow(theURL,winName,features) {
	return window.open(theURL,winName,features);
}