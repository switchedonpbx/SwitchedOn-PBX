-- MySQL dump 10.13  Distrib 5.1.56, for debian-linux-gnu (i486)
--
-- Host: localhost    Database: TikiWiki_63
-- ------------------------------------------------------
-- Server version	5.1.56-0.dotdeb.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `messu_archive`
--

DROP TABLE IF EXISTS `messu_archive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messu_archive` (
  `msgId` int(14) NOT NULL AUTO_INCREMENT,
  `user` varchar(40) NOT NULL DEFAULT '',
  `user_from` varchar(40) NOT NULL DEFAULT '',
  `user_to` text,
  `user_cc` text,
  `user_bcc` text,
  `subject` varchar(255) DEFAULT NULL,
  `body` text,
  `hash` varchar(32) DEFAULT NULL,
  `replyto_hash` varchar(32) DEFAULT NULL,
  `date` int(14) DEFAULT NULL,
  `isRead` char(1) DEFAULT NULL,
  `isReplied` char(1) DEFAULT NULL,
  `isFlagged` char(1) DEFAULT NULL,
  `priority` int(2) DEFAULT NULL,
  PRIMARY KEY (`msgId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messu_archive`
--

LOCK TABLES `messu_archive` WRITE;
/*!40000 ALTER TABLE `messu_archive` DISABLE KEYS */;
/*!40000 ALTER TABLE `messu_archive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messu_messages`
--

DROP TABLE IF EXISTS `messu_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messu_messages` (
  `msgId` int(14) NOT NULL AUTO_INCREMENT,
  `user` varchar(200) NOT NULL DEFAULT '',
  `user_from` varchar(200) NOT NULL DEFAULT '',
  `user_to` text,
  `user_cc` text,
  `user_bcc` text,
  `subject` varchar(255) DEFAULT NULL,
  `body` text,
  `hash` varchar(32) DEFAULT NULL,
  `replyto_hash` varchar(32) DEFAULT NULL,
  `date` int(14) DEFAULT NULL,
  `isRead` char(1) DEFAULT NULL,
  `isReplied` char(1) DEFAULT NULL,
  `isFlagged` char(1) DEFAULT NULL,
  `priority` int(2) DEFAULT NULL,
  PRIMARY KEY (`msgId`),
  KEY `userIsRead` (`user`,`isRead`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messu_messages`
--

LOCK TABLES `messu_messages` WRITE;
/*!40000 ALTER TABLE `messu_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messu_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messu_sent`
--

DROP TABLE IF EXISTS `messu_sent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messu_sent` (
  `msgId` int(14) NOT NULL AUTO_INCREMENT,
  `user` varchar(40) NOT NULL DEFAULT '',
  `user_from` varchar(40) NOT NULL DEFAULT '',
  `user_to` text,
  `user_cc` text,
  `user_bcc` text,
  `subject` varchar(255) DEFAULT NULL,
  `body` text,
  `hash` varchar(32) DEFAULT NULL,
  `replyto_hash` varchar(32) DEFAULT NULL,
  `date` int(14) DEFAULT NULL,
  `isRead` char(1) DEFAULT NULL,
  `isReplied` char(1) DEFAULT NULL,
  `isFlagged` char(1) DEFAULT NULL,
  `priority` int(2) DEFAULT NULL,
  PRIMARY KEY (`msgId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messu_sent`
--

LOCK TABLES `messu_sent` WRITE;
/*!40000 ALTER TABLE `messu_sent` DISABLE KEYS */;
/*!40000 ALTER TABLE `messu_sent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metrics_assigned`
--

DROP TABLE IF EXISTS `metrics_assigned`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `metrics_assigned` (
  `assigned_id` int(11) NOT NULL AUTO_INCREMENT,
  `metric_id` int(11) NOT NULL,
  `tab_id` int(11) NOT NULL,
  PRIMARY KEY (`assigned_id`),
  KEY `metric_id` (`metric_id`),
  KEY `tab_id` (`tab_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metrics_assigned`
--

LOCK TABLES `metrics_assigned` WRITE;
/*!40000 ALTER TABLE `metrics_assigned` DISABLE KEYS */;
/*!40000 ALTER TABLE `metrics_assigned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metrics_metric`
--

DROP TABLE IF EXISTS `metrics_metric`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `metrics_metric` (
  `metric_id` int(11) NOT NULL AUTO_INCREMENT,
  `metric_name` varchar(255) NOT NULL,
  `metric_range` varchar(1) NOT NULL DEFAULT '+' COMMENT 'values: + (daily), @ (monthly&weekly), - (weekly)',
  `metric_datatype` varchar(1) NOT NULL DEFAULT 'i' COMMENT 'values: i(nteger), %(percentage), f(loat), L(ist)',
  `metric_lastupdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `metric_query` text,
  `metric_dsn` varchar(200) NOT NULL DEFAULT 'local',
  PRIMARY KEY (`metric_id`),
  UNIQUE KEY `metric_name` (`metric_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metrics_metric`
--

LOCK TABLES `metrics_metric` WRITE;
/*!40000 ALTER TABLE `metrics_metric` DISABLE KEYS */;
/*!40000 ALTER TABLE `metrics_metric` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metrics_tab`
--

DROP TABLE IF EXISTS `metrics_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `metrics_tab` (
  `tab_id` int(11) NOT NULL AUTO_INCREMENT,
  `tab_name` varchar(255) NOT NULL,
  `tab_order` int(11) NOT NULL DEFAULT '0',
  `tab_content` longtext NOT NULL,
  PRIMARY KEY (`tab_id`),
  UNIQUE KEY `tab_name` (`tab_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metrics_tab`
--

LOCK TABLES `metrics_tab` WRITE;
/*!40000 ALTER TABLE `metrics_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `metrics_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `sesskey` char(32) NOT NULL,
  `expiry` int(11) unsigned NOT NULL,
  `expireref` varchar(64) DEFAULT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`sesskey`),
  KEY `expiry` (`expiry`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_actionlog`
--

DROP TABLE IF EXISTS `tiki_actionlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_actionlog` (
  `actionId` int(8) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) NOT NULL DEFAULT '',
  `lastModif` int(14) DEFAULT NULL,
  `object` varchar(255) DEFAULT NULL,
  `objectType` varchar(32) NOT NULL DEFAULT '',
  `user` varchar(200) DEFAULT '',
  `ip` varchar(39) DEFAULT NULL,
  `comment` varchar(200) DEFAULT NULL,
  `categId` int(12) NOT NULL DEFAULT '0',
  `client` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`actionId`),
  KEY `lastModif` (`lastModif`),
  KEY `object` (`object`(100),`objectType`,`action`(100))
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_actionlog`
--

LOCK TABLES `tiki_actionlog` WRITE;
/*!40000 ALTER TABLE `tiki_actionlog` DISABLE KEYS */;
INSERT INTO `tiki_actionlog` VALUES (1,'system',1305469938,'system','system','admin','192.168.161.28','erased all cache content',0,'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.2.17) Gecko/20110422 Linux Mint/10 (Julia) Firefox/3.6.17'),(2,'login',1305469938,'system','system','admin','192.168.161.28','logged out',0,'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.2.17) Gecko/20110422 Linux Mint/10 (Julia) Firefox/3.6.17'),(3,'login',1305469959,'system','system','admin','192.168.161.28','logged from change_password',0,'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.2.17) Gecko/20110422 Linux Mint/10 (Julia) Firefox/3.6.17'),(4,'Created',1305469961,'HomePage','wiki page','admin','192.168.161.28','add=3630',0,NULL);
/*!40000 ALTER TABLE `tiki_actionlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_actionlog_conf`
--

DROP TABLE IF EXISTS `tiki_actionlog_conf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_actionlog_conf` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(32) NOT NULL DEFAULT '',
  `objectType` varchar(32) NOT NULL DEFAULT '',
  `status` char(1) DEFAULT '',
  PRIMARY KEY (`action`,`objectType`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_actionlog_conf`
--

LOCK TABLES `tiki_actionlog_conf` WRITE;
/*!40000 ALTER TABLE `tiki_actionlog_conf` DISABLE KEYS */;
INSERT INTO `tiki_actionlog_conf` VALUES (1,'Created','wiki page','y'),(2,'Updated','wiki page','y'),(3,'Removed','wiki page','y'),(4,'Viewed','wiki page','n'),(5,'Viewed','forum','n'),(6,'Posted','forum','n'),(7,'Replied','forum','n'),(8,'Updated','forum','n'),(9,'Viewed','file gallery','n'),(10,'Viewed','image gallery','n'),(11,'Uploaded','file gallery','n'),(12,'Uploaded','image gallery','n'),(13,'%','category','n'),(14,'login','system','y'),(15,'Posted','message','n'),(16,'Replied','message','n'),(17,'Viewed','message','n'),(18,'Removed version','wiki page','n'),(19,'Removed last version','wiki page','n'),(20,'Rollback','wiki page','n'),(21,'Removed','forum','n'),(22,'Downloaded','file gallery','n'),(23,'Posted','comment','n'),(24,'Replied','comment','n'),(25,'Updated','comment','n'),(26,'Removed','comment','n'),(27,'Renamed','wiki page','n'),(28,'Created','sheet','n'),(29,'Updated','sheet','n'),(30,'Removed','sheet','n'),(31,'Viewed','sheet','n'),(32,'Viewed','blog','n'),(33,'Posted','blog','n'),(34,'Updated','blog','n'),(35,'Removed','blog','n'),(36,'Removed','file','n'),(37,'Viewed','article','n'),(38,'%','system','y'),(39,'feature','system','y'),(40,'Updated','trackeritem','n'),(41,'Created','trackeritem','n'),(42,'Viewed','trackeritem','n');
/*!40000 ALTER TABLE `tiki_actionlog_conf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_actionlog_params`
--

DROP TABLE IF EXISTS `tiki_actionlog_params`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_actionlog_params` (
  `actionId` int(8) NOT NULL,
  `name` varchar(40) NOT NULL,
  `value` text,
  KEY `actionId` (`actionId`),
  KEY `nameValue` (`name`,`value`(200))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_actionlog_params`
--

LOCK TABLES `tiki_actionlog_params` WRITE;
/*!40000 ALTER TABLE `tiki_actionlog_params` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_actionlog_params` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_article_types`
--

DROP TABLE IF EXISTS `tiki_article_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_article_types` (
  `type` varchar(50) NOT NULL,
  `use_ratings` varchar(1) DEFAULT NULL,
  `show_pre_publ` varchar(1) DEFAULT NULL,
  `show_post_expire` varchar(1) DEFAULT 'y',
  `heading_only` varchar(1) DEFAULT NULL,
  `allow_comments` varchar(1) DEFAULT 'y',
  `show_image` varchar(1) DEFAULT 'y',
  `show_avatar` varchar(1) DEFAULT NULL,
  `show_author` varchar(1) DEFAULT 'y',
  `show_pubdate` varchar(1) DEFAULT 'y',
  `show_expdate` varchar(1) DEFAULT NULL,
  `show_reads` varchar(1) DEFAULT 'y',
  `show_size` varchar(1) DEFAULT 'n',
  `show_topline` varchar(1) DEFAULT 'n',
  `show_subtitle` varchar(1) DEFAULT 'n',
  `show_linkto` varchar(1) DEFAULT 'n',
  `show_image_caption` varchar(1) DEFAULT 'n',
  `show_lang` varchar(1) DEFAULT 'n',
  `creator_edit` varchar(1) DEFAULT NULL,
  `comment_can_rate_article` char(1) DEFAULT NULL,
  PRIMARY KEY (`type`),
  KEY `show_pre_publ` (`show_pre_publ`),
  KEY `show_post_expire` (`show_post_expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_article_types`
--

LOCK TABLES `tiki_article_types` WRITE;
/*!40000 ALTER TABLE `tiki_article_types` DISABLE KEYS */;
INSERT INTO `tiki_article_types` VALUES ('Article',NULL,NULL,'y',NULL,'y','y',NULL,'y','y',NULL,'y','n','n','n','n','n','n',NULL,NULL),('Review','y',NULL,'y',NULL,'y','y',NULL,'y','y',NULL,'y','n','n','n','n','n','n',NULL,NULL),('Event',NULL,NULL,'n',NULL,'y','y',NULL,'y','y',NULL,'y','n','n','n','n','n','n',NULL,NULL),('Classified',NULL,NULL,'n','y','n','y',NULL,'y','y',NULL,'y','n','n','n','n','n','n',NULL,NULL);
/*!40000 ALTER TABLE `tiki_article_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_articles`
--

DROP TABLE IF EXISTS `tiki_articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_articles` (
  `articleId` int(8) NOT NULL AUTO_INCREMENT,
  `topline` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `linkto` varchar(255) DEFAULT NULL,
  `lang` varchar(16) DEFAULT NULL,
  `state` char(1) DEFAULT 's',
  `authorName` varchar(60) DEFAULT NULL,
  `topicId` int(14) DEFAULT NULL,
  `topicName` varchar(40) DEFAULT NULL,
  `size` int(12) DEFAULT NULL,
  `useImage` char(1) DEFAULT NULL,
  `image_name` varchar(80) DEFAULT NULL,
  `image_caption` text,
  `image_type` varchar(80) DEFAULT NULL,
  `image_size` int(14) DEFAULT NULL,
  `image_x` int(4) DEFAULT NULL,
  `image_y` int(4) DEFAULT NULL,
  `list_image_x` int(4) DEFAULT NULL,
  `image_data` longblob,
  `publishDate` int(14) DEFAULT NULL,
  `expireDate` int(14) DEFAULT NULL,
  `created` int(14) DEFAULT NULL,
  `heading` text,
  `body` text,
  `hash` varchar(32) DEFAULT NULL,
  `author` varchar(200) DEFAULT NULL,
  `nbreads` int(14) DEFAULT NULL,
  `votes` int(8) DEFAULT NULL,
  `points` int(14) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `rating` decimal(3,2) DEFAULT NULL,
  `isfloat` char(1) DEFAULT NULL,
  `ispublished` char(1) NOT NULL DEFAULT 'y',
  PRIMARY KEY (`articleId`),
  KEY `title` (`title`),
  KEY `heading` (`heading`(255)),
  KEY `body` (`body`(255)),
  KEY `nbreads` (`nbreads`),
  KEY `author` (`author`(32)),
  KEY `topicId` (`topicId`),
  KEY `publishDate` (`publishDate`),
  KEY `expireDate` (`expireDate`),
  KEY `type` (`type`),
  FULLTEXT KEY `ft` (`title`,`heading`,`body`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_articles`
--

LOCK TABLES `tiki_articles` WRITE;
/*!40000 ALTER TABLE `tiki_articles` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_auth_tokens`
--

DROP TABLE IF EXISTS `tiki_auth_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_auth_tokens` (
  `tokenId` int(11) NOT NULL AUTO_INCREMENT,
  `creation` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `timeout` int(11) NOT NULL DEFAULT '0',
  `hits` int(11) NOT NULL DEFAULT '1',
  `token` char(32) DEFAULT NULL,
  `entry` varchar(50) DEFAULT NULL,
  `parameters` varchar(255) DEFAULT NULL,
  `groups` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`tokenId`),
  KEY `tiki_auth_tokens_token` (`token`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_auth_tokens`
--

LOCK TABLES `tiki_auth_tokens` WRITE;
/*!40000 ALTER TABLE `tiki_auth_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_auth_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_banners`
--

DROP TABLE IF EXISTS `tiki_banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_banners` (
  `bannerId` int(12) NOT NULL AUTO_INCREMENT,
  `client` varchar(200) NOT NULL DEFAULT '',
  `url` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `alt` varchar(250) DEFAULT NULL,
  `which` varchar(50) DEFAULT NULL,
  `imageData` longblob,
  `imageType` varchar(200) DEFAULT NULL,
  `imageName` varchar(100) DEFAULT NULL,
  `HTMLData` text,
  `fixedURLData` varchar(255) DEFAULT NULL,
  `textData` text,
  `fromDate` int(14) DEFAULT NULL,
  `toDate` int(14) DEFAULT NULL,
  `useDates` char(1) DEFAULT NULL,
  `mon` char(1) DEFAULT NULL,
  `tue` char(1) DEFAULT NULL,
  `wed` char(1) DEFAULT NULL,
  `thu` char(1) DEFAULT NULL,
  `fri` char(1) DEFAULT NULL,
  `sat` char(1) DEFAULT NULL,
  `sun` char(1) DEFAULT NULL,
  `hourFrom` varchar(4) DEFAULT NULL,
  `hourTo` varchar(4) DEFAULT NULL,
  `created` int(14) DEFAULT NULL,
  `maxImpressions` int(8) DEFAULT NULL,
  `impressions` int(8) DEFAULT NULL,
  `maxUserImpressions` int(8) DEFAULT '-1',
  `maxClicks` int(8) DEFAULT NULL,
  `clicks` int(8) DEFAULT NULL,
  `zone` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`bannerId`),
  KEY `ban1` (`zone`,`useDates`,`impressions`,`maxImpressions`,`hourFrom`,`hourTo`,`fromDate`,`toDate`,`mon`,`tue`,`wed`,`thu`,`fri`,`sat`,`sun`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_banners`
--

LOCK TABLES `tiki_banners` WRITE;
/*!40000 ALTER TABLE `tiki_banners` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_banning`
--

DROP TABLE IF EXISTS `tiki_banning`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_banning` (
  `banId` int(12) NOT NULL AUTO_INCREMENT,
  `mode` enum('user','ip') DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `ip1` char(3) DEFAULT NULL,
  `ip2` char(3) DEFAULT NULL,
  `ip3` char(3) DEFAULT NULL,
  `ip4` char(3) DEFAULT NULL,
  `user` varchar(200) DEFAULT '',
  `date_from` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_to` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `use_dates` char(1) DEFAULT NULL,
  `created` int(14) DEFAULT NULL,
  `message` text,
  PRIMARY KEY (`banId`),
  KEY `ban` (`use_dates`,`date_from`,`date_to`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_banning`
--

LOCK TABLES `tiki_banning` WRITE;
/*!40000 ALTER TABLE `tiki_banning` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_banning` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_banning_sections`
--

DROP TABLE IF EXISTS `tiki_banning_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_banning_sections` (
  `banId` int(12) NOT NULL DEFAULT '0',
  `section` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`banId`,`section`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_banning_sections`
--

LOCK TABLES `tiki_banning_sections` WRITE;
/*!40000 ALTER TABLE `tiki_banning_sections` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_banning_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_blog_activity`
--

DROP TABLE IF EXISTS `tiki_blog_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_blog_activity` (
  `blogId` int(8) NOT NULL DEFAULT '0',
  `day` int(14) NOT NULL DEFAULT '0',
  `posts` int(8) DEFAULT NULL,
  PRIMARY KEY (`blogId`,`day`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_blog_activity`
--

LOCK TABLES `tiki_blog_activity` WRITE;
/*!40000 ALTER TABLE `tiki_blog_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_blog_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_blog_posts`
--

DROP TABLE IF EXISTS `tiki_blog_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_blog_posts` (
  `postId` int(8) NOT NULL AUTO_INCREMENT,
  `blogId` int(8) NOT NULL DEFAULT '0',
  `data` text,
  `data_size` int(11) unsigned NOT NULL DEFAULT '0',
  `excerpt` text,
  `created` int(14) DEFAULT NULL,
  `user` varchar(200) DEFAULT '',
  `trackbacks_to` text,
  `trackbacks_from` text,
  `title` varchar(255) DEFAULT NULL,
  `priv` varchar(1) DEFAULT NULL,
  `wysiwyg` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`postId`),
  KEY `data` (`data`(255)),
  KEY `blogId` (`blogId`),
  KEY `created` (`created`),
  FULLTEXT KEY `ft` (`data`,`title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_blog_posts`
--

LOCK TABLES `tiki_blog_posts` WRITE;
/*!40000 ALTER TABLE `tiki_blog_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_blog_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_blog_posts_images`
--

DROP TABLE IF EXISTS `tiki_blog_posts_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_blog_posts_images` (
  `imgId` int(14) NOT NULL AUTO_INCREMENT,
  `postId` int(14) NOT NULL DEFAULT '0',
  `filename` varchar(80) DEFAULT NULL,
  `filetype` varchar(80) DEFAULT NULL,
  `filesize` int(14) DEFAULT NULL,
  `data` longblob,
  PRIMARY KEY (`imgId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_blog_posts_images`
--

LOCK TABLES `tiki_blog_posts_images` WRITE;
/*!40000 ALTER TABLE `tiki_blog_posts_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_blog_posts_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_blogs`
--

DROP TABLE IF EXISTS `tiki_blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_blogs` (
  `blogId` int(8) NOT NULL AUTO_INCREMENT,
  `created` int(14) DEFAULT NULL,
  `lastModif` int(14) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `description` text,
  `user` varchar(200) DEFAULT '',
  `public` char(1) DEFAULT NULL,
  `posts` int(8) DEFAULT NULL,
  `maxPosts` int(8) DEFAULT NULL,
  `hits` int(8) DEFAULT NULL,
  `activity` decimal(4,2) DEFAULT NULL,
  `heading` text,
  `post_heading` text,
  `use_find` char(1) DEFAULT NULL,
  `use_title` char(1) DEFAULT 'y',
  `use_title_in_post` char(1) DEFAULT 'y',
  `use_description` char(1) DEFAULT 'y',
  `use_breadcrumbs` char(1) DEFAULT 'n',
  `use_author` char(1) DEFAULT NULL,
  `use_excerpt` char(1) DEFAULT NULL,
  `add_date` char(1) DEFAULT NULL,
  `add_poster` char(1) DEFAULT NULL,
  `allow_comments` char(1) DEFAULT NULL,
  `show_avatar` char(1) DEFAULT NULL,
  `always_owner` char(1) DEFAULT NULL,
  `show_related` char(1) DEFAULT NULL,
  `related_max` int(4) DEFAULT '5',
  PRIMARY KEY (`blogId`),
  KEY `title` (`title`),
  KEY `description` (`description`(255)),
  KEY `hits` (`hits`),
  FULLTEXT KEY `ft` (`title`,`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_blogs`
--

LOCK TABLES `tiki_blogs` WRITE;
/*!40000 ALTER TABLE `tiki_blogs` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_blogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_calendar_categories`
--

DROP TABLE IF EXISTS `tiki_calendar_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_calendar_categories` (
  `calcatId` int(11) NOT NULL AUTO_INCREMENT,
  `calendarId` int(14) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`calcatId`),
  UNIQUE KEY `catname` (`calendarId`,`name`(16))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_calendar_categories`
--

LOCK TABLES `tiki_calendar_categories` WRITE;
/*!40000 ALTER TABLE `tiki_calendar_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_calendar_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_calendar_items`
--

DROP TABLE IF EXISTS `tiki_calendar_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_calendar_items` (
  `calitemId` int(14) NOT NULL AUTO_INCREMENT,
  `calendarId` int(14) NOT NULL DEFAULT '0',
  `start` int(14) NOT NULL DEFAULT '0',
  `end` int(14) NOT NULL DEFAULT '0',
  `locationId` int(14) DEFAULT NULL,
  `categoryId` int(14) DEFAULT NULL,
  `nlId` int(12) NOT NULL DEFAULT '0',
  `priority` enum('0','1','2','3','4','5','6','7','8','9') DEFAULT '0',
  `status` enum('0','1','2') NOT NULL DEFAULT '0',
  `url` varchar(255) DEFAULT NULL,
  `lang` char(16) NOT NULL DEFAULT 'en',
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `recurrenceId` int(14) DEFAULT NULL,
  `changed` tinyint(1) DEFAULT '0',
  `user` varchar(200) DEFAULT '',
  `created` int(14) NOT NULL DEFAULT '0',
  `lastmodif` int(14) NOT NULL DEFAULT '0',
  `allday` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`calitemId`),
  KEY `calendarId` (`calendarId`),
  KEY `fk_calitems_recurrence` (`recurrenceId`),
  FULLTEXT KEY `ft` (`name`,`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_calendar_items`
--

LOCK TABLES `tiki_calendar_items` WRITE;
/*!40000 ALTER TABLE `tiki_calendar_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_calendar_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_calendar_locations`
--

DROP TABLE IF EXISTS `tiki_calendar_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_calendar_locations` (
  `callocId` int(14) NOT NULL AUTO_INCREMENT,
  `calendarId` int(14) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` blob,
  PRIMARY KEY (`callocId`),
  UNIQUE KEY `locname` (`calendarId`,`name`(16))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_calendar_locations`
--

LOCK TABLES `tiki_calendar_locations` WRITE;
/*!40000 ALTER TABLE `tiki_calendar_locations` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_calendar_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_calendar_options`
--

DROP TABLE IF EXISTS `tiki_calendar_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_calendar_options` (
  `calendarId` int(14) NOT NULL DEFAULT '0',
  `optionName` varchar(120) NOT NULL DEFAULT '',
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`calendarId`,`optionName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_calendar_options`
--

LOCK TABLES `tiki_calendar_options` WRITE;
/*!40000 ALTER TABLE `tiki_calendar_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_calendar_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_calendar_recurrence`
--

DROP TABLE IF EXISTS `tiki_calendar_recurrence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_calendar_recurrence` (
  `recurrenceId` int(14) NOT NULL AUTO_INCREMENT,
  `calendarId` int(14) NOT NULL DEFAULT '0',
  `start` int(4) NOT NULL DEFAULT '0',
  `end` int(4) NOT NULL DEFAULT '2359',
  `allday` tinyint(1) NOT NULL DEFAULT '0',
  `locationId` int(14) DEFAULT NULL,
  `categoryId` int(14) DEFAULT NULL,
  `nlId` int(12) NOT NULL DEFAULT '0',
  `priority` enum('1','2','3','4','5','6','7','8','9') NOT NULL DEFAULT '1',
  `status` enum('0','1','2') NOT NULL DEFAULT '0',
  `url` varchar(255) DEFAULT NULL,
  `lang` char(16) NOT NULL DEFAULT 'en',
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` blob,
  `weekly` tinyint(1) DEFAULT '0',
  `weekday` tinyint(1) DEFAULT NULL,
  `monthly` tinyint(1) DEFAULT '0',
  `dayOfMonth` int(2) DEFAULT NULL,
  `yearly` tinyint(1) DEFAULT '0',
  `dateOfYear` int(4) DEFAULT NULL,
  `nbRecurrences` int(8) DEFAULT NULL,
  `startPeriod` int(14) DEFAULT NULL,
  `endPeriod` int(14) DEFAULT NULL,
  `user` varchar(200) DEFAULT '',
  `created` int(14) NOT NULL DEFAULT '0',
  `lastmodif` int(14) NOT NULL DEFAULT '0',
  PRIMARY KEY (`recurrenceId`),
  KEY `calendarId` (`calendarId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_calendar_recurrence`
--

LOCK TABLES `tiki_calendar_recurrence` WRITE;
/*!40000 ALTER TABLE `tiki_calendar_recurrence` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_calendar_recurrence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_calendar_roles`
--

DROP TABLE IF EXISTS `tiki_calendar_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_calendar_roles` (
  `calitemId` int(14) NOT NULL DEFAULT '0',
  `username` varchar(200) NOT NULL DEFAULT '',
  `role` enum('0','1','2','3','6') NOT NULL DEFAULT '0',
  PRIMARY KEY (`calitemId`,`username`(16),`role`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_calendar_roles`
--

LOCK TABLES `tiki_calendar_roles` WRITE;
/*!40000 ALTER TABLE `tiki_calendar_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_calendar_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_calendars`
--

DROP TABLE IF EXISTS `tiki_calendars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_calendars` (
  `calendarId` int(14) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL DEFAULT '',
  `description` varchar(255) DEFAULT NULL,
  `user` varchar(200) NOT NULL DEFAULT '',
  `customlocations` enum('n','y') NOT NULL DEFAULT 'n',
  `customcategories` enum('n','y') NOT NULL DEFAULT 'n',
  `customlanguages` enum('n','y') NOT NULL DEFAULT 'n',
  `custompriorities` enum('n','y') NOT NULL DEFAULT 'n',
  `customparticipants` enum('n','y') NOT NULL DEFAULT 'n',
  `customsubscription` enum('n','y') NOT NULL DEFAULT 'n',
  `customstatus` enum('n','y') NOT NULL DEFAULT 'y',
  `created` int(14) NOT NULL DEFAULT '0',
  `lastmodif` int(14) NOT NULL DEFAULT '0',
  `personal` enum('n','y') NOT NULL DEFAULT 'n',
  PRIMARY KEY (`calendarId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_calendars`
--

LOCK TABLES `tiki_calendars` WRITE;
/*!40000 ALTER TABLE `tiki_calendars` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_calendars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_categories`
--

DROP TABLE IF EXISTS `tiki_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_categories` (
  `categId` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `parentId` int(12) DEFAULT NULL,
  `hits` int(8) DEFAULT NULL,
  `rootCategId` int(12) DEFAULT NULL,
  PRIMARY KEY (`categId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_categories`
--

LOCK TABLES `tiki_categories` WRITE;
/*!40000 ALTER TABLE `tiki_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_categorized_objects`
--

DROP TABLE IF EXISTS `tiki_categorized_objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_categorized_objects` (
  `catObjectId` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`catObjectId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_categorized_objects`
--

LOCK TABLES `tiki_categorized_objects` WRITE;
/*!40000 ALTER TABLE `tiki_categorized_objects` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_categorized_objects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_category_objects`
--

DROP TABLE IF EXISTS `tiki_category_objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_category_objects` (
  `catObjectId` int(12) NOT NULL DEFAULT '0',
  `categId` int(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`catObjectId`,`categId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_category_objects`
--

LOCK TABLES `tiki_category_objects` WRITE;
/*!40000 ALTER TABLE `tiki_category_objects` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_category_objects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_category_sites`
--

DROP TABLE IF EXISTS `tiki_category_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_category_sites` (
  `categId` int(10) NOT NULL DEFAULT '0',
  `siteId` int(14) NOT NULL DEFAULT '0',
  PRIMARY KEY (`categId`,`siteId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_category_sites`
--

LOCK TABLES `tiki_category_sites` WRITE;
/*!40000 ALTER TABLE `tiki_category_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_category_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_chat_channels`
--

DROP TABLE IF EXISTS `tiki_chat_channels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_chat_channels` (
  `channelId` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `max_users` int(8) DEFAULT NULL,
  `mode` char(1) DEFAULT NULL,
  `moderator` varchar(200) DEFAULT NULL,
  `active` char(1) DEFAULT NULL,
  `refresh` int(6) DEFAULT NULL,
  PRIMARY KEY (`channelId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_chat_channels`
--

LOCK TABLES `tiki_chat_channels` WRITE;
/*!40000 ALTER TABLE `tiki_chat_channels` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_chat_channels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_chat_messages`
--

DROP TABLE IF EXISTS `tiki_chat_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_chat_messages` (
  `messageId` int(8) NOT NULL AUTO_INCREMENT,
  `channelId` int(8) NOT NULL DEFAULT '0',
  `data` varchar(255) DEFAULT NULL,
  `poster` varchar(200) NOT NULL DEFAULT 'anonymous',
  `timestamp` int(14) DEFAULT NULL,
  PRIMARY KEY (`messageId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_chat_messages`
--

LOCK TABLES `tiki_chat_messages` WRITE;
/*!40000 ALTER TABLE `tiki_chat_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_chat_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_chat_users`
--

DROP TABLE IF EXISTS `tiki_chat_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_chat_users` (
  `nickname` varchar(200) NOT NULL DEFAULT '',
  `channelId` int(8) NOT NULL DEFAULT '0',
  `timestamp` int(14) DEFAULT NULL,
  PRIMARY KEY (`nickname`,`channelId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_chat_users`
--

LOCK TABLES `tiki_chat_users` WRITE;
/*!40000 ALTER TABLE `tiki_chat_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_chat_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_comments`
--

DROP TABLE IF EXISTS `tiki_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_comments` (
  `threadId` int(14) NOT NULL AUTO_INCREMENT,
  `object` varchar(255) NOT NULL DEFAULT '',
  `objectType` varchar(32) NOT NULL DEFAULT '',
  `parentId` int(14) DEFAULT NULL,
  `userName` varchar(200) DEFAULT '',
  `commentDate` int(14) DEFAULT NULL,
  `hits` int(8) DEFAULT NULL,
  `type` char(1) DEFAULT NULL,
  `points` decimal(8,2) DEFAULT NULL,
  `votes` int(8) DEFAULT NULL,
  `average` decimal(8,4) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `data` text,
  `hash` varchar(32) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `website` varchar(200) DEFAULT NULL,
  `user_ip` varchar(15) DEFAULT NULL,
  `summary` varchar(240) DEFAULT NULL,
  `smiley` varchar(80) DEFAULT NULL,
  `message_id` varchar(128) DEFAULT NULL,
  `in_reply_to` varchar(128) DEFAULT NULL,
  `comment_rating` tinyint(2) DEFAULT NULL,
  `archived` char(1) DEFAULT NULL,
  `approved` char(1) NOT NULL DEFAULT 'y',
  `locked` char(1) NOT NULL DEFAULT 'n',
  PRIMARY KEY (`threadId`),
  UNIQUE KEY `no_repeats` (`parentId`,`userName`(40),`title`(100),`commentDate`,`message_id`(40),`in_reply_to`(40)),
  KEY `title` (`title`),
  KEY `data` (`data`(255)),
  KEY `hits` (`hits`),
  KEY `tc_pi` (`parentId`),
  KEY `objectType` (`object`,`objectType`),
  KEY `commentDate` (`commentDate`),
  KEY `threaded` (`message_id`,`in_reply_to`,`parentId`),
  FULLTEXT KEY `ft` (`title`,`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_comments`
--

LOCK TABLES `tiki_comments` WRITE;
/*!40000 ALTER TABLE `tiki_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_content`
--

DROP TABLE IF EXISTS `tiki_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_content` (
  `contentId` int(8) NOT NULL AUTO_INCREMENT,
  `description` text,
  `contentLabel` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`contentId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_content`
--

LOCK TABLES `tiki_content` WRITE;
/*!40000 ALTER TABLE `tiki_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_content_templates`
--

DROP TABLE IF EXISTS `tiki_content_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_content_templates` (
  `templateId` int(10) NOT NULL AUTO_INCREMENT,
  `template_type` varchar(20) NOT NULL DEFAULT 'static',
  `content` longblob,
  `name` varchar(200) DEFAULT NULL,
  `created` int(14) DEFAULT NULL,
  PRIMARY KEY (`templateId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_content_templates`
--

LOCK TABLES `tiki_content_templates` WRITE;
/*!40000 ALTER TABLE `tiki_content_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_content_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_content_templates_sections`
--

DROP TABLE IF EXISTS `tiki_content_templates_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_content_templates_sections` (
  `templateId` int(10) NOT NULL DEFAULT '0',
  `section` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`templateId`,`section`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_content_templates_sections`
--

LOCK TABLES `tiki_content_templates_sections` WRITE;
/*!40000 ALTER TABLE `tiki_content_templates_sections` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_content_templates_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_contributions`
--

DROP TABLE IF EXISTS `tiki_contributions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_contributions` (
  `contributionId` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`contributionId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_contributions`
--

LOCK TABLES `tiki_contributions` WRITE;
/*!40000 ALTER TABLE `tiki_contributions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_contributions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_contributions_assigned`
--

DROP TABLE IF EXISTS `tiki_contributions_assigned`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_contributions_assigned` (
  `contributionId` int(12) NOT NULL,
  `objectId` int(12) NOT NULL,
  PRIMARY KEY (`objectId`,`contributionId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_contributions_assigned`
--

LOCK TABLES `tiki_contributions_assigned` WRITE;
/*!40000 ALTER TABLE `tiki_contributions_assigned` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_contributions_assigned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_cookies`
--

DROP TABLE IF EXISTS `tiki_cookies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_cookies` (
  `cookieId` int(10) NOT NULL AUTO_INCREMENT,
  `cookie` text,
  PRIMARY KEY (`cookieId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_cookies`
--

LOCK TABLES `tiki_cookies` WRITE;
/*!40000 ALTER TABLE `tiki_cookies` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_cookies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_copyrights`
--

DROP TABLE IF EXISTS `tiki_copyrights`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_copyrights` (
  `copyrightId` int(12) NOT NULL AUTO_INCREMENT,
  `page` varchar(200) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `authors` varchar(200) DEFAULT NULL,
  `copyright_order` int(11) DEFAULT NULL,
  `userName` varchar(200) DEFAULT '',
  PRIMARY KEY (`copyrightId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_copyrights`
--

LOCK TABLES `tiki_copyrights` WRITE;
/*!40000 ALTER TABLE `tiki_copyrights` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_copyrights` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_credits`
--

DROP TABLE IF EXISTS `tiki_credits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_credits` (
  `creditId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userId` int(8) NOT NULL,
  `credit_type` varchar(25) NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expiration_date` timestamp NULL DEFAULT NULL,
  `total_amount` float NOT NULL DEFAULT '0',
  `used_amount` float NOT NULL DEFAULT '0',
  `product_id` int(8) DEFAULT NULL,
  PRIMARY KEY (`creditId`),
  KEY `userId` (`userId`,`credit_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_credits`
--

LOCK TABLES `tiki_credits` WRITE;
/*!40000 ALTER TABLE `tiki_credits` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_credits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_credits_types`
--

DROP TABLE IF EXISTS `tiki_credits_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_credits_types` (
  `credit_type` varchar(25) NOT NULL,
  `display_text` varchar(50) DEFAULT NULL,
  `unit_text` varchar(25) DEFAULT NULL,
  `is_static_level` char(1) DEFAULT 'n',
  `scaling_divisor` float NOT NULL DEFAULT '1',
  PRIMARY KEY (`credit_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_credits_types`
--

LOCK TABLES `tiki_credits_types` WRITE;
/*!40000 ALTER TABLE `tiki_credits_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_credits_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_credits_usage`
--

DROP TABLE IF EXISTS `tiki_credits_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_credits_usage` (
  `usageId` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `usage_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `credit_type` varchar(25) NOT NULL,
  `used_amount` float NOT NULL DEFAULT '0',
  `product_id` int(8) DEFAULT NULL,
  PRIMARY KEY (`usageId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_credits_usage`
--

LOCK TABLES `tiki_credits_usage` WRITE;
/*!40000 ALTER TABLE `tiki_credits_usage` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_credits_usage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_directory_categories`
--

DROP TABLE IF EXISTS `tiki_directory_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_directory_categories` (
  `categId` int(10) NOT NULL AUTO_INCREMENT,
  `parent` int(10) DEFAULT NULL,
  `name` varchar(240) DEFAULT NULL,
  `description` text,
  `childrenType` char(1) DEFAULT NULL,
  `sites` int(10) DEFAULT NULL,
  `viewableChildren` int(4) DEFAULT NULL,
  `allowSites` char(1) DEFAULT NULL,
  `showCount` char(1) DEFAULT NULL,
  `editorGroup` varchar(200) DEFAULT NULL,
  `hits` int(12) DEFAULT NULL,
  PRIMARY KEY (`categId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_directory_categories`
--

LOCK TABLES `tiki_directory_categories` WRITE;
/*!40000 ALTER TABLE `tiki_directory_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_directory_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_directory_search`
--

DROP TABLE IF EXISTS `tiki_directory_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_directory_search` (
  `term` varchar(250) NOT NULL DEFAULT '',
  `hits` int(14) DEFAULT NULL,
  PRIMARY KEY (`term`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_directory_search`
--

LOCK TABLES `tiki_directory_search` WRITE;
/*!40000 ALTER TABLE `tiki_directory_search` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_directory_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_directory_sites`
--

DROP TABLE IF EXISTS `tiki_directory_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_directory_sites` (
  `siteId` int(14) NOT NULL AUTO_INCREMENT,
  `name` varchar(240) DEFAULT NULL,
  `description` text,
  `url` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `hits` int(12) DEFAULT NULL,
  `isValid` char(1) DEFAULT NULL,
  `created` int(14) DEFAULT NULL,
  `lastModif` int(14) DEFAULT NULL,
  `cache` longblob,
  `cache_timestamp` int(14) DEFAULT NULL,
  PRIMARY KEY (`siteId`),
  KEY `isValid` (`isValid`),
  KEY `url` (`url`),
  FULLTEXT KEY `ft` (`name`,`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_directory_sites`
--

LOCK TABLES `tiki_directory_sites` WRITE;
/*!40000 ALTER TABLE `tiki_directory_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_directory_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_discount`
--

DROP TABLE IF EXISTS `tiki_discount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_discount` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `max` int(11) DEFAULT NULL,
  `comment` text,
  PRIMARY KEY (`id`),
  KEY `code` (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_discount`
--

LOCK TABLES `tiki_discount` WRITE;
/*!40000 ALTER TABLE `tiki_discount` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_discount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_download`
--

DROP TABLE IF EXISTS `tiki_download`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_download` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object` varchar(255) NOT NULL DEFAULT '',
  `userId` int(8) NOT NULL DEFAULT '0',
  `type` varchar(20) NOT NULL DEFAULT '',
  `date` int(14) NOT NULL DEFAULT '0',
  `IP` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `object` (`object`,`userId`,`type`),
  KEY `userId` (`userId`),
  KEY `type` (`type`),
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_download`
--

LOCK TABLES `tiki_download` WRITE;
/*!40000 ALTER TABLE `tiki_download` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_download` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_dsn`
--

DROP TABLE IF EXISTS `tiki_dsn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_dsn` (
  `dsnId` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `dsn` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`dsnId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_dsn`
--

LOCK TABLES `tiki_dsn` WRITE;
/*!40000 ALTER TABLE `tiki_dsn` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_dsn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_dynamic_variables`
--

DROP TABLE IF EXISTS `tiki_dynamic_variables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_dynamic_variables` (
  `name` varchar(40) NOT NULL,
  `data` text,
  `lang` varchar(16) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_dynamic_variables`
--

LOCK TABLES `tiki_dynamic_variables` WRITE;
/*!40000 ALTER TABLE `tiki_dynamic_variables` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_dynamic_variables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_extwiki`
--

DROP TABLE IF EXISTS `tiki_extwiki`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_extwiki` (
  `extwikiId` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `extwiki` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`extwikiId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_extwiki`
--

LOCK TABLES `tiki_extwiki` WRITE;
/*!40000 ALTER TABLE `tiki_extwiki` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_extwiki` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_faq_questions`
--

DROP TABLE IF EXISTS `tiki_faq_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_faq_questions` (
  `questionId` int(10) NOT NULL AUTO_INCREMENT,
  `faqId` int(10) DEFAULT NULL,
  `position` int(4) DEFAULT NULL,
  `question` text,
  `answer` text,
  `created` int(14) DEFAULT NULL,
  PRIMARY KEY (`questionId`),
  KEY `faqId` (`faqId`),
  KEY `question` (`question`(255)),
  KEY `answer` (`answer`(255)),
  KEY `created` (`created`),
  FULLTEXT KEY `ft` (`question`,`answer`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_faq_questions`
--

LOCK TABLES `tiki_faq_questions` WRITE;
/*!40000 ALTER TABLE `tiki_faq_questions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_faq_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_faqs`
--

DROP TABLE IF EXISTS `tiki_faqs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_faqs` (
  `faqId` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) DEFAULT NULL,
  `description` text,
  `created` int(14) DEFAULT NULL,
  `questions` int(5) DEFAULT NULL,
  `hits` int(8) DEFAULT NULL,
  `canSuggest` char(1) DEFAULT NULL,
  PRIMARY KEY (`faqId`),
  KEY `title` (`title`),
  KEY `description` (`description`(255)),
  KEY `hits` (`hits`),
  FULLTEXT KEY `ft` (`title`,`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_faqs`
--

LOCK TABLES `tiki_faqs` WRITE;
/*!40000 ALTER TABLE `tiki_faqs` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_faqs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_feature`
--

DROP TABLE IF EXISTS `tiki_feature`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_feature` (
  `feature_id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `feature_name` varchar(150) NOT NULL,
  `parent_id` mediumint(9) NOT NULL,
  `status` varchar(12) NOT NULL DEFAULT 'active',
  `setting_name` varchar(50) DEFAULT NULL,
  `feature_type` varchar(30) NOT NULL DEFAULT 'feature',
  `template` varchar(50) DEFAULT NULL,
  `permission` varchar(50) DEFAULT NULL,
  `ordinal` mediumint(9) NOT NULL DEFAULT '1',
  `depends_on` mediumint(9) DEFAULT NULL,
  `keyword` varchar(30) DEFAULT NULL,
  `tip` text,
  `feature_count` mediumint(9) NOT NULL DEFAULT '0',
  `feature_path` varchar(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`feature_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_feature`
--

LOCK TABLES `tiki_feature` WRITE;
/*!40000 ALTER TABLE `tiki_feature` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_feature` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_featured_links`
--

DROP TABLE IF EXISTS `tiki_featured_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_featured_links` (
  `url` varchar(200) NOT NULL DEFAULT '',
  `title` varchar(200) DEFAULT NULL,
  `description` text,
  `hits` int(8) DEFAULT NULL,
  `position` int(6) DEFAULT NULL,
  `type` char(1) DEFAULT NULL,
  PRIMARY KEY (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_featured_links`
--

LOCK TABLES `tiki_featured_links` WRITE;
/*!40000 ALTER TABLE `tiki_featured_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_featured_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_file_backlinks`
--

DROP TABLE IF EXISTS `tiki_file_backlinks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_file_backlinks` (
  `fileId` int(14) NOT NULL,
  `objectId` int(12) NOT NULL,
  KEY `objectId` (`objectId`),
  KEY `fileId` (`fileId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_file_backlinks`
--

LOCK TABLES `tiki_file_backlinks` WRITE;
/*!40000 ALTER TABLE `tiki_file_backlinks` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_file_backlinks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_file_galleries`
--

DROP TABLE IF EXISTS `tiki_file_galleries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_file_galleries` (
  `galleryId` int(14) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL DEFAULT '',
  `type` varchar(20) NOT NULL DEFAULT 'default',
  `description` text,
  `created` int(14) DEFAULT NULL,
  `visible` char(1) DEFAULT NULL,
  `lastModif` int(14) DEFAULT NULL,
  `user` varchar(200) DEFAULT '',
  `hits` int(14) DEFAULT NULL,
  `votes` int(8) DEFAULT NULL,
  `points` decimal(8,2) DEFAULT NULL,
  `maxRows` int(10) DEFAULT NULL,
  `public` char(1) DEFAULT NULL,
  `show_id` char(1) DEFAULT NULL,
  `show_icon` char(1) DEFAULT NULL,
  `show_name` char(1) DEFAULT NULL,
  `show_size` char(1) DEFAULT NULL,
  `show_description` char(1) DEFAULT NULL,
  `max_desc` int(8) DEFAULT NULL,
  `show_created` char(1) DEFAULT NULL,
  `show_hits` char(1) DEFAULT NULL,
  `show_lastDownload` char(1) DEFAULT NULL,
  `parentId` int(14) NOT NULL DEFAULT '-1',
  `lockable` char(1) DEFAULT 'n',
  `show_lockedby` char(1) DEFAULT NULL,
  `archives` int(4) DEFAULT '0',
  `sort_mode` char(20) DEFAULT NULL,
  `show_modified` char(1) DEFAULT NULL,
  `show_author` char(1) DEFAULT NULL,
  `show_creator` char(1) DEFAULT NULL,
  `subgal_conf` varchar(200) DEFAULT NULL,
  `show_last_user` char(1) DEFAULT NULL,
  `show_comment` char(1) DEFAULT NULL,
  `show_files` char(1) DEFAULT NULL,
  `show_explorer` char(1) DEFAULT NULL,
  `show_path` char(1) DEFAULT NULL,
  `show_slideshow` char(1) DEFAULT NULL,
  `default_view` varchar(20) DEFAULT NULL,
  `quota` int(8) DEFAULT '0',
  `size` int(14) DEFAULT NULL,
  `wiki_syntax` varchar(200) DEFAULT NULL,
  `backlinkPerms` char(1) DEFAULT 'n',
  `show_backlinks` char(1) DEFAULT NULL,
  `image_max_size_x` int(8) NOT NULL DEFAULT '0',
  `image_max_size_y` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`galleryId`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_file_galleries`
--

LOCK TABLES `tiki_file_galleries` WRITE;
/*!40000 ALTER TABLE `tiki_file_galleries` DISABLE KEYS */;
INSERT INTO `tiki_file_galleries` VALUES (1,'File Galleries','system','',NULL,'y',NULL,'admin',NULL,NULL,NULL,NULL,'y',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,-1,'n',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,'n',NULL,0,0);
/*!40000 ALTER TABLE `tiki_file_galleries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_file_handlers`
--

DROP TABLE IF EXISTS `tiki_file_handlers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_file_handlers` (
  `mime_type` varchar(64) DEFAULT NULL,
  `cmd` varchar(238) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_file_handlers`
--

LOCK TABLES `tiki_file_handlers` WRITE;
/*!40000 ALTER TABLE `tiki_file_handlers` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_file_handlers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_files`
--

DROP TABLE IF EXISTS `tiki_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_files` (
  `fileId` int(14) NOT NULL AUTO_INCREMENT,
  `galleryId` int(14) NOT NULL DEFAULT '0',
  `name` varchar(200) NOT NULL DEFAULT '',
  `description` text,
  `created` int(14) DEFAULT NULL,
  `filename` varchar(80) DEFAULT NULL,
  `filesize` int(14) DEFAULT NULL,
  `filetype` varchar(250) DEFAULT NULL,
  `data` longblob,
  `user` varchar(200) DEFAULT '',
  `author` varchar(40) DEFAULT NULL,
  `hits` int(14) DEFAULT NULL,
  `lastDownload` int(14) DEFAULT NULL,
  `votes` int(8) DEFAULT NULL,
  `points` decimal(8,2) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `reference_url` varchar(250) DEFAULT NULL,
  `is_reference` char(1) DEFAULT NULL,
  `hash` varchar(32) DEFAULT NULL,
  `search_data` longtext,
  `lastModif` int(14) DEFAULT NULL,
  `lastModifUser` varchar(200) DEFAULT NULL,
  `lockedby` varchar(200) DEFAULT '',
  `comment` varchar(200) DEFAULT NULL,
  `archiveId` int(14) DEFAULT '0',
  `deleteAfter` int(14) DEFAULT NULL,
  PRIMARY KEY (`fileId`),
  KEY `name` (`name`),
  KEY `description` (`description`(255)),
  KEY `created` (`created`),
  KEY `archiveId` (`archiveId`),
  KEY `galleryId` (`galleryId`),
  KEY `hits` (`hits`),
  FULLTEXT KEY `ft` (`name`,`description`,`search_data`,`filename`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_files`
--

LOCK TABLES `tiki_files` WRITE;
/*!40000 ALTER TABLE `tiki_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_forum_attachments`
--

DROP TABLE IF EXISTS `tiki_forum_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_forum_attachments` (
  `attId` int(14) NOT NULL AUTO_INCREMENT,
  `threadId` int(14) NOT NULL DEFAULT '0',
  `qId` int(14) NOT NULL DEFAULT '0',
  `forumId` int(14) DEFAULT NULL,
  `filename` varchar(250) DEFAULT NULL,
  `filetype` varchar(250) DEFAULT NULL,
  `filesize` int(12) DEFAULT NULL,
  `data` longblob,
  `dir` varchar(200) DEFAULT NULL,
  `created` int(14) DEFAULT NULL,
  `path` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`attId`),
  KEY `threadId` (`threadId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_forum_attachments`
--

LOCK TABLES `tiki_forum_attachments` WRITE;
/*!40000 ALTER TABLE `tiki_forum_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_forum_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_forum_reads`
--

DROP TABLE IF EXISTS `tiki_forum_reads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_forum_reads` (
  `user` varchar(200) NOT NULL DEFAULT '',
  `threadId` int(14) NOT NULL DEFAULT '0',
  `forumId` int(14) DEFAULT NULL,
  `timestamp` int(14) DEFAULT NULL,
  PRIMARY KEY (`user`,`threadId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_forum_reads`
--

LOCK TABLES `tiki_forum_reads` WRITE;
/*!40000 ALTER TABLE `tiki_forum_reads` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_forum_reads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_forums`
--

DROP TABLE IF EXISTS `tiki_forums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_forums` (
  `forumId` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `created` int(14) DEFAULT NULL,
  `lastPost` int(14) DEFAULT NULL,
  `threads` int(8) DEFAULT NULL,
  `comments` int(8) DEFAULT NULL,
  `controlFlood` char(1) DEFAULT NULL,
  `floodInterval` int(8) DEFAULT NULL,
  `moderator` varchar(200) DEFAULT NULL,
  `hits` int(8) DEFAULT NULL,
  `mail` varchar(200) DEFAULT NULL,
  `useMail` char(1) DEFAULT NULL,
  `section` varchar(200) DEFAULT NULL,
  `usePruneUnreplied` char(1) DEFAULT NULL,
  `pruneUnrepliedAge` int(8) DEFAULT NULL,
  `usePruneOld` char(1) DEFAULT NULL,
  `pruneMaxAge` int(8) DEFAULT NULL,
  `topicsPerPage` int(6) DEFAULT NULL,
  `topicOrdering` varchar(100) DEFAULT NULL,
  `threadOrdering` varchar(100) DEFAULT NULL,
  `att` varchar(80) DEFAULT NULL,
  `att_store` varchar(4) DEFAULT NULL,
  `att_store_dir` varchar(250) DEFAULT NULL,
  `att_max_size` int(12) DEFAULT NULL,
  `att_list_nb` char(1) DEFAULT NULL,
  `ui_level` char(1) DEFAULT NULL,
  `forum_password` varchar(32) DEFAULT NULL,
  `forum_use_password` char(1) DEFAULT NULL,
  `moderator_group` varchar(200) DEFAULT NULL,
  `approval_type` varchar(20) DEFAULT NULL,
  `outbound_address` varchar(250) DEFAULT NULL,
  `outbound_mails_for_inbound_mails` char(1) DEFAULT NULL,
  `outbound_mails_reply_link` char(1) DEFAULT NULL,
  `outbound_from` varchar(250) DEFAULT NULL,
  `inbound_pop_server` varchar(250) DEFAULT NULL,
  `inbound_pop_port` int(4) DEFAULT NULL,
  `inbound_pop_user` varchar(200) DEFAULT NULL,
  `inbound_pop_password` varchar(80) DEFAULT NULL,
  `topic_smileys` char(1) DEFAULT NULL,
  `ui_avatar` char(1) DEFAULT NULL,
  `ui_flag` char(1) DEFAULT NULL,
  `ui_posts` char(1) DEFAULT NULL,
  `ui_email` char(1) DEFAULT NULL,
  `ui_online` char(1) DEFAULT NULL,
  `topic_summary` char(1) DEFAULT NULL,
  `show_description` char(1) DEFAULT NULL,
  `topics_list_replies` char(1) DEFAULT NULL,
  `topics_list_reads` char(1) DEFAULT NULL,
  `topics_list_pts` char(1) DEFAULT NULL,
  `topics_list_lastpost` char(1) DEFAULT NULL,
  `topics_list_lastpost_title` char(1) DEFAULT NULL,
  `topics_list_lastpost_avatar` char(1) DEFAULT NULL,
  `topics_list_author` char(1) DEFAULT NULL,
  `topics_list_author_avatar` char(1) DEFAULT NULL,
  `vote_threads` char(1) DEFAULT NULL,
  `forum_last_n` int(2) DEFAULT '0',
  `threadStyle` varchar(100) DEFAULT NULL,
  `commentsPerPage` varchar(100) DEFAULT NULL,
  `is_flat` char(1) DEFAULT NULL,
  `mandatory_contribution` char(1) DEFAULT NULL,
  PRIMARY KEY (`forumId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_forums`
--

LOCK TABLES `tiki_forums` WRITE;
/*!40000 ALTER TABLE `tiki_forums` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_forums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_forums_queue`
--

DROP TABLE IF EXISTS `tiki_forums_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_forums_queue` (
  `qId` int(14) NOT NULL AUTO_INCREMENT,
  `object` varchar(32) DEFAULT NULL,
  `parentId` int(14) DEFAULT NULL,
  `forumId` int(14) DEFAULT NULL,
  `timestamp` int(14) DEFAULT NULL,
  `user` varchar(200) DEFAULT '',
  `title` varchar(240) DEFAULT NULL,
  `data` text,
  `type` varchar(60) DEFAULT NULL,
  `hash` varchar(32) DEFAULT NULL,
  `topic_smiley` varchar(80) DEFAULT NULL,
  `topic_title` varchar(240) DEFAULT NULL,
  `summary` varchar(240) DEFAULT NULL,
  `in_reply_to` varchar(128) DEFAULT NULL,
  `tags` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`qId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_forums_queue`
--

LOCK TABLES `tiki_forums_queue` WRITE;
/*!40000 ALTER TABLE `tiki_forums_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_forums_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_forums_reported`
--

DROP TABLE IF EXISTS `tiki_forums_reported`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_forums_reported` (
  `threadId` int(12) NOT NULL DEFAULT '0',
  `forumId` int(12) NOT NULL DEFAULT '0',
  `parentId` int(12) NOT NULL DEFAULT '0',
  `user` varchar(200) DEFAULT '',
  `timestamp` int(14) DEFAULT NULL,
  `reason` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`threadId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_forums_reported`
--

LOCK TABLES `tiki_forums_reported` WRITE;
/*!40000 ALTER TABLE `tiki_forums_reported` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_forums_reported` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_freetagged_objects`
--

DROP TABLE IF EXISTS `tiki_freetagged_objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_freetagged_objects` (
  `tagId` int(12) NOT NULL AUTO_INCREMENT,
  `objectId` int(11) NOT NULL DEFAULT '0',
  `user` varchar(200) NOT NULL DEFAULT '',
  `created` int(14) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tagId`,`user`,`objectId`),
  KEY `tagId` (`tagId`),
  KEY `user` (`user`),
  KEY `objectId` (`objectId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_freetagged_objects`
--

LOCK TABLES `tiki_freetagged_objects` WRITE;
/*!40000 ALTER TABLE `tiki_freetagged_objects` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_freetagged_objects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_freetags`
--

DROP TABLE IF EXISTS `tiki_freetags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_freetags` (
  `tagId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tag` varchar(128) NOT NULL DEFAULT '',
  `raw_tag` varchar(150) NOT NULL DEFAULT '',
  `lang` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`tagId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_freetags`
--

LOCK TABLES `tiki_freetags` WRITE;
/*!40000 ALTER TABLE `tiki_freetags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_freetags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_friends`
--

DROP TABLE IF EXISTS `tiki_friends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_friends` (
  `user` varchar(200) NOT NULL DEFAULT '',
  `friend` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`user`(120),`friend`(120))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_friends`
--

LOCK TABLES `tiki_friends` WRITE;
/*!40000 ALTER TABLE `tiki_friends` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_friends` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_friendship_requests`
--

DROP TABLE IF EXISTS `tiki_friendship_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_friendship_requests` (
  `userFrom` varchar(200) NOT NULL DEFAULT '',
  `userTo` varchar(200) NOT NULL DEFAULT '',
  `tstamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`userFrom`(120),`userTo`(120))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_friendship_requests`
--

LOCK TABLES `tiki_friendship_requests` WRITE;
/*!40000 ALTER TABLE `tiki_friendship_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_friendship_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_galleries`
--

DROP TABLE IF EXISTS `tiki_galleries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_galleries` (
  `galleryId` int(14) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL DEFAULT '',
  `description` text,
  `created` int(14) DEFAULT NULL,
  `lastModif` int(14) DEFAULT NULL,
  `visible` char(1) DEFAULT NULL,
  `geographic` char(1) DEFAULT NULL,
  `theme` varchar(60) DEFAULT NULL,
  `user` varchar(200) DEFAULT '',
  `hits` int(14) DEFAULT NULL,
  `maxRows` int(10) DEFAULT NULL,
  `rowImages` int(10) DEFAULT NULL,
  `thumbSizeX` int(10) DEFAULT NULL,
  `thumbSizeY` int(10) DEFAULT NULL,
  `public` char(1) DEFAULT NULL,
  `sortorder` varchar(20) NOT NULL DEFAULT 'created',
  `sortdirection` varchar(4) NOT NULL DEFAULT 'desc',
  `galleryimage` varchar(20) NOT NULL DEFAULT 'first',
  `parentgallery` int(14) NOT NULL DEFAULT '-1',
  `showname` char(1) NOT NULL DEFAULT 'y',
  `showimageid` char(1) NOT NULL DEFAULT 'n',
  `showdescription` char(1) NOT NULL DEFAULT 'n',
  `showcreated` char(1) NOT NULL DEFAULT 'n',
  `showuser` char(1) NOT NULL DEFAULT 'n',
  `showhits` char(1) NOT NULL DEFAULT 'y',
  `showxysize` char(1) NOT NULL DEFAULT 'y',
  `showfilesize` char(1) NOT NULL DEFAULT 'n',
  `showfilename` char(1) NOT NULL DEFAULT 'n',
  `defaultscale` varchar(10) NOT NULL DEFAULT 'o',
  `showcategories` char(1) NOT NULL DEFAULT 'n',
  PRIMARY KEY (`galleryId`),
  KEY `name` (`name`),
  KEY `description` (`description`(255)),
  KEY `hits` (`hits`),
  KEY `parentgallery` (`parentgallery`),
  KEY `visibleUser` (`visible`,`user`),
  FULLTEXT KEY `ft` (`name`,`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_galleries`
--

LOCK TABLES `tiki_galleries` WRITE;
/*!40000 ALTER TABLE `tiki_galleries` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_galleries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_galleries_scales`
--

DROP TABLE IF EXISTS `tiki_galleries_scales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_galleries_scales` (
  `galleryId` int(14) NOT NULL DEFAULT '0',
  `scale` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`galleryId`,`scale`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_galleries_scales`
--

LOCK TABLES `tiki_galleries_scales` WRITE;
/*!40000 ALTER TABLE `tiki_galleries_scales` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_galleries_scales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_group_inclusion`
--

DROP TABLE IF EXISTS `tiki_group_inclusion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_group_inclusion` (
  `groupName` varchar(255) NOT NULL DEFAULT '',
  `includeGroup` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`groupName`(120),`includeGroup`(120))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_group_inclusion`
--

LOCK TABLES `tiki_group_inclusion` WRITE;
/*!40000 ALTER TABLE `tiki_group_inclusion` DISABLE KEYS */;
INSERT INTO `tiki_group_inclusion` VALUES ('Registered','Anonymous');
/*!40000 ALTER TABLE `tiki_group_inclusion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_group_watches`
--

DROP TABLE IF EXISTS `tiki_group_watches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_group_watches` (
  `watchId` int(12) NOT NULL AUTO_INCREMENT,
  `group` varchar(200) NOT NULL DEFAULT '',
  `event` varchar(40) NOT NULL DEFAULT '',
  `object` varchar(200) NOT NULL DEFAULT '',
  `title` varchar(250) DEFAULT NULL,
  `type` varchar(200) DEFAULT NULL,
  `url` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`watchId`),
  KEY `event-object-group` (`event`,`object`(100),`group`(50))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_group_watches`
--

LOCK TABLES `tiki_group_watches` WRITE;
/*!40000 ALTER TABLE `tiki_group_watches` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_group_watches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_groupalert`
--

DROP TABLE IF EXISTS `tiki_groupalert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_groupalert` (
  `groupName` varchar(255) NOT NULL DEFAULT '',
  `objectType` varchar(20) NOT NULL DEFAULT '',
  `objectId` varchar(10) NOT NULL DEFAULT '',
  `displayEachuser` char(1) DEFAULT NULL,
  PRIMARY KEY (`groupName`,`objectType`,`objectId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_groupalert`
--

LOCK TABLES `tiki_groupalert` WRITE;
/*!40000 ALTER TABLE `tiki_groupalert` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_groupalert` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_history`
--

DROP TABLE IF EXISTS `tiki_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_history` (
  `historyId` int(12) NOT NULL AUTO_INCREMENT,
  `pageName` varchar(160) NOT NULL DEFAULT '',
  `version` int(8) NOT NULL DEFAULT '0',
  `version_minor` int(8) NOT NULL DEFAULT '0',
  `lastModif` int(14) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `user` varchar(200) NOT NULL DEFAULT '',
  `ip` varchar(15) DEFAULT NULL,
  `comment` varchar(200) DEFAULT NULL,
  `data` longblob,
  `type` varchar(50) DEFAULT NULL,
  `is_html` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pageName`,`version`),
  KEY `user` (`user`),
  KEY `historyId` (`historyId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_history`
--

LOCK TABLES `tiki_history` WRITE;
/*!40000 ALTER TABLE `tiki_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_hotwords`
--

DROP TABLE IF EXISTS `tiki_hotwords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_hotwords` (
  `word` varchar(40) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`word`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_hotwords`
--

LOCK TABLES `tiki_hotwords` WRITE;
/*!40000 ALTER TABLE `tiki_hotwords` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_hotwords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_html_pages`
--

DROP TABLE IF EXISTS `tiki_html_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_html_pages` (
  `pageName` varchar(200) NOT NULL DEFAULT '',
  `content` longblob,
  `refresh` int(10) DEFAULT NULL,
  `type` char(1) DEFAULT NULL,
  `created` int(14) DEFAULT NULL,
  PRIMARY KEY (`pageName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_html_pages`
--

LOCK TABLES `tiki_html_pages` WRITE;
/*!40000 ALTER TABLE `tiki_html_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_html_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_html_pages_dynamic_zones`
--

DROP TABLE IF EXISTS `tiki_html_pages_dynamic_zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_html_pages_dynamic_zones` (
  `pageName` varchar(40) NOT NULL DEFAULT '',
  `zone` varchar(80) NOT NULL DEFAULT '',
  `type` char(2) DEFAULT NULL,
  `content` text,
  PRIMARY KEY (`pageName`,`zone`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_html_pages_dynamic_zones`
--

LOCK TABLES `tiki_html_pages_dynamic_zones` WRITE;
/*!40000 ALTER TABLE `tiki_html_pages_dynamic_zones` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_html_pages_dynamic_zones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_images`
--

DROP TABLE IF EXISTS `tiki_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_images` (
  `imageId` int(14) NOT NULL AUTO_INCREMENT,
  `galleryId` int(14) NOT NULL DEFAULT '0',
  `name` varchar(200) NOT NULL DEFAULT '',
  `description` text,
  `lon` float DEFAULT NULL,
  `lat` float DEFAULT NULL,
  `created` int(14) DEFAULT NULL,
  `user` varchar(200) DEFAULT '',
  `hits` int(14) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`imageId`),
  KEY `name` (`name`),
  KEY `description` (`description`(255)),
  KEY `hits` (`hits`),
  KEY `ti_gId` (`galleryId`),
  KEY `ti_cr` (`created`),
  KEY `ti_us` (`user`),
  FULLTEXT KEY `ft` (`name`,`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_images`
--

LOCK TABLES `tiki_images` WRITE;
/*!40000 ALTER TABLE `tiki_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_images_data`
--

DROP TABLE IF EXISTS `tiki_images_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_images_data` (
  `imageId` int(14) NOT NULL DEFAULT '0',
  `xsize` int(8) NOT NULL DEFAULT '0',
  `ysize` int(8) NOT NULL DEFAULT '0',
  `type` char(1) NOT NULL DEFAULT '',
  `filesize` int(14) DEFAULT NULL,
  `filetype` varchar(80) DEFAULT NULL,
  `filename` varchar(80) DEFAULT NULL,
  `data` longblob,
  `etag` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`imageId`,`xsize`,`ysize`,`type`),
  KEY `t_i_d_it` (`imageId`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_images_data`
--

LOCK TABLES `tiki_images_data` WRITE;
/*!40000 ALTER TABLE `tiki_images_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_images_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_integrator_reps`
--

DROP TABLE IF EXISTS `tiki_integrator_reps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_integrator_reps` (
  `repID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `path` varchar(255) NOT NULL DEFAULT '',
  `start_page` varchar(255) NOT NULL DEFAULT '',
  `css_file` varchar(255) NOT NULL DEFAULT '',
  `visibility` char(1) NOT NULL DEFAULT 'y',
  `cacheable` char(1) NOT NULL DEFAULT 'y',
  `expiration` int(11) NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  PRIMARY KEY (`repID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_integrator_reps`
--

LOCK TABLES `tiki_integrator_reps` WRITE;
/*!40000 ALTER TABLE `tiki_integrator_reps` DISABLE KEYS */;
INSERT INTO `tiki_integrator_reps` VALUES (1,'Doxygened (1.3.4) Documentation','','index.html','doxygen.css','n','y',0,'Use this repository as rule source for all your repositories based on doxygened docs. To setup yours just add new repository and copy rules from this repository :)');
/*!40000 ALTER TABLE `tiki_integrator_reps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_integrator_rules`
--

DROP TABLE IF EXISTS `tiki_integrator_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_integrator_rules` (
  `ruleID` int(11) NOT NULL AUTO_INCREMENT,
  `repID` int(11) NOT NULL DEFAULT '0',
  `ord` int(2) unsigned NOT NULL DEFAULT '0',
  `srch` blob NOT NULL,
  `repl` blob NOT NULL,
  `type` char(1) NOT NULL DEFAULT 'n',
  `casesense` char(1) NOT NULL DEFAULT 'y',
  `rxmod` varchar(20) NOT NULL DEFAULT '',
  `enabled` char(1) NOT NULL DEFAULT 'n',
  `description` text NOT NULL,
  PRIMARY KEY (`ruleID`),
  KEY `repID` (`repID`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_integrator_rules`
--

LOCK TABLES `tiki_integrator_rules` WRITE;
/*!40000 ALTER TABLE `tiki_integrator_rules` DISABLE KEYS */;
INSERT INTO `tiki_integrator_rules` VALUES (1,1,1,'.*<body[^>]*?>(.*?)</body.*','1','y','n','i','y','Extract code between <body> and </body> tags'),(2,1,2,'img src=(\"|\')(?!http://)','img src=1{path}/','y','n','i','y','Fix image paths'),(3,1,3,'href=(\"|\')(?!(#|(http|ftp)://))','href=1tiki-integrator.php?repID={repID}&file=','y','n','i','y','Replace internal links to integrator. Don not touch an external link.');
/*!40000 ALTER TABLE `tiki_integrator_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_invite`
--

DROP TABLE IF EXISTS `tiki_invite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_invite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `inviter` varchar(200) NOT NULL,
  `groups` varchar(255) DEFAULT NULL,
  `ts` int(11) NOT NULL,
  `emailsubject` varchar(255) NOT NULL,
  `emailcontent` text NOT NULL,
  `wikicontent` text,
  `wikipageafter` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_invite`
--

LOCK TABLES `tiki_invite` WRITE;
/*!40000 ALTER TABLE `tiki_invite` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_invite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_invited`
--

DROP TABLE IF EXISTS `tiki_invited`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_invited` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_invite` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `firstname` varchar(24) NOT NULL,
  `lastname` varchar(24) NOT NULL,
  `used` enum('no','registered','logged') NOT NULL,
  `used_on_user` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_invite` (`id_invite`),
  KEY `used_on_user` (`used_on_user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_invited`
--

LOCK TABLES `tiki_invited` WRITE;
/*!40000 ALTER TABLE `tiki_invited` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_invited` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_language`
--

DROP TABLE IF EXISTS `tiki_language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_language` (
  `id` int(14) NOT NULL AUTO_INCREMENT,
  `source` text NOT NULL,
  `lang` char(16) NOT NULL DEFAULT '',
  `tran` text,
  `changed` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_language`
--

LOCK TABLES `tiki_language` WRITE;
/*!40000 ALTER TABLE `tiki_language` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_link_cache`
--

DROP TABLE IF EXISTS `tiki_link_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_link_cache` (
  `cacheId` int(14) NOT NULL AUTO_INCREMENT,
  `url` varchar(250) DEFAULT NULL,
  `data` longblob,
  `refresh` int(14) DEFAULT NULL,
  PRIMARY KEY (`cacheId`),
  KEY `url` (`url`),
  KEY `urlindex` (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_link_cache`
--

LOCK TABLES `tiki_link_cache` WRITE;
/*!40000 ALTER TABLE `tiki_link_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_link_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_links`
--

DROP TABLE IF EXISTS `tiki_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_links` (
  `fromPage` varchar(160) NOT NULL DEFAULT '',
  `toPage` varchar(160) NOT NULL DEFAULT '',
  PRIMARY KEY (`fromPage`,`toPage`),
  KEY `toPage` (`toPage`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_links`
--

LOCK TABLES `tiki_links` WRITE;
/*!40000 ALTER TABLE `tiki_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_live_support_events`
--

DROP TABLE IF EXISTS `tiki_live_support_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_live_support_events` (
  `eventId` int(14) NOT NULL AUTO_INCREMENT,
  `reqId` varchar(32) NOT NULL DEFAULT '',
  `type` varchar(40) DEFAULT NULL,
  `seqId` int(14) DEFAULT NULL,
  `senderId` varchar(32) DEFAULT NULL,
  `data` text,
  `timestamp` int(14) DEFAULT NULL,
  PRIMARY KEY (`eventId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_live_support_events`
--

LOCK TABLES `tiki_live_support_events` WRITE;
/*!40000 ALTER TABLE `tiki_live_support_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_live_support_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_live_support_message_comments`
--

DROP TABLE IF EXISTS `tiki_live_support_message_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_live_support_message_comments` (
  `cId` int(12) NOT NULL AUTO_INCREMENT,
  `msgId` int(12) DEFAULT NULL,
  `data` text,
  `timestamp` int(14) DEFAULT NULL,
  PRIMARY KEY (`cId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_live_support_message_comments`
--

LOCK TABLES `tiki_live_support_message_comments` WRITE;
/*!40000 ALTER TABLE `tiki_live_support_message_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_live_support_message_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_live_support_messages`
--

DROP TABLE IF EXISTS `tiki_live_support_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_live_support_messages` (
  `msgId` int(12) NOT NULL AUTO_INCREMENT,
  `data` text,
  `timestamp` int(14) DEFAULT NULL,
  `user` varchar(200) NOT NULL DEFAULT '',
  `username` varchar(200) DEFAULT NULL,
  `priority` int(2) DEFAULT NULL,
  `status` char(1) DEFAULT NULL,
  `assigned_to` varchar(200) DEFAULT NULL,
  `resolution` varchar(100) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `module` int(4) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`msgId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_live_support_messages`
--

LOCK TABLES `tiki_live_support_messages` WRITE;
/*!40000 ALTER TABLE `tiki_live_support_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_live_support_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_live_support_modules`
--

DROP TABLE IF EXISTS `tiki_live_support_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_live_support_modules` (
  `modId` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(90) DEFAULT NULL,
  PRIMARY KEY (`modId`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_live_support_modules`
--

LOCK TABLES `tiki_live_support_modules` WRITE;
/*!40000 ALTER TABLE `tiki_live_support_modules` DISABLE KEYS */;
INSERT INTO `tiki_live_support_modules` VALUES (1,'wiki'),(2,'forums'),(3,'image galleries'),(4,'file galleries'),(5,'directory');
/*!40000 ALTER TABLE `tiki_live_support_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_live_support_operators`
--

DROP TABLE IF EXISTS `tiki_live_support_operators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_live_support_operators` (
  `user` varchar(200) NOT NULL DEFAULT '',
  `accepted_requests` int(10) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `longest_chat` int(10) DEFAULT NULL,
  `shortest_chat` int(10) DEFAULT NULL,
  `average_chat` int(10) DEFAULT NULL,
  `last_chat` int(14) DEFAULT NULL,
  `time_online` int(10) DEFAULT NULL,
  `votes` int(10) DEFAULT NULL,
  `points` int(10) DEFAULT NULL,
  `status_since` int(14) DEFAULT NULL,
  PRIMARY KEY (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_live_support_operators`
--

LOCK TABLES `tiki_live_support_operators` WRITE;
/*!40000 ALTER TABLE `tiki_live_support_operators` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_live_support_operators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_live_support_requests`
--

DROP TABLE IF EXISTS `tiki_live_support_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_live_support_requests` (
  `reqId` varchar(32) NOT NULL DEFAULT '',
  `user` varchar(200) NOT NULL DEFAULT '',
  `tiki_user` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `operator` varchar(200) DEFAULT NULL,
  `operator_id` varchar(32) DEFAULT NULL,
  `user_id` varchar(32) DEFAULT NULL,
  `reason` text,
  `req_timestamp` int(14) DEFAULT NULL,
  `timestamp` int(14) DEFAULT NULL,
  `status` varchar(40) DEFAULT NULL,
  `resolution` varchar(40) DEFAULT NULL,
  `chat_started` int(14) DEFAULT NULL,
  `chat_ended` int(14) DEFAULT NULL,
  PRIMARY KEY (`reqId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_live_support_requests`
--

LOCK TABLES `tiki_live_support_requests` WRITE;
/*!40000 ALTER TABLE `tiki_live_support_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_live_support_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_logs`
--

DROP TABLE IF EXISTS `tiki_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_logs` (
  `logId` int(8) NOT NULL AUTO_INCREMENT,
  `logtype` varchar(20) NOT NULL,
  `logmessage` text NOT NULL,
  `loguser` varchar(40) NOT NULL,
  `logip` varchar(200) DEFAULT NULL,
  `logclient` text NOT NULL,
  `logtime` int(14) NOT NULL,
  PRIMARY KEY (`logId`),
  KEY `logtype` (`logtype`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_logs`
--

LOCK TABLES `tiki_logs` WRITE;
/*!40000 ALTER TABLE `tiki_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_mail_events`
--

DROP TABLE IF EXISTS `tiki_mail_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_mail_events` (
  `event` varchar(200) DEFAULT NULL,
  `object` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_mail_events`
--

LOCK TABLES `tiki_mail_events` WRITE;
/*!40000 ALTER TABLE `tiki_mail_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_mail_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_mailin_accounts`
--

DROP TABLE IF EXISTS `tiki_mailin_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_mailin_accounts` (
  `accountId` int(12) NOT NULL AUTO_INCREMENT,
  `user` varchar(200) NOT NULL DEFAULT '',
  `account` varchar(50) NOT NULL DEFAULT '',
  `pop` varchar(255) DEFAULT NULL,
  `port` int(4) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `pass` varchar(100) DEFAULT NULL,
  `active` char(1) DEFAULT NULL,
  `type` varchar(40) DEFAULT NULL,
  `smtp` varchar(255) DEFAULT NULL,
  `useAuth` char(1) DEFAULT NULL,
  `smtpPort` int(4) DEFAULT NULL,
  `anonymous` char(1) NOT NULL DEFAULT 'y',
  `attachments` char(1) NOT NULL DEFAULT 'n',
  `article_topicId` int(4) DEFAULT NULL,
  `article_type` varchar(50) DEFAULT NULL,
  `discard_after` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`accountId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_mailin_accounts`
--

LOCK TABLES `tiki_mailin_accounts` WRITE;
/*!40000 ALTER TABLE `tiki_mailin_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_mailin_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_menu_languages`
--

DROP TABLE IF EXISTS `tiki_menu_languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_menu_languages` (
  `menuId` int(8) NOT NULL AUTO_INCREMENT,
  `language` char(16) NOT NULL DEFAULT '',
  PRIMARY KEY (`menuId`,`language`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_menu_languages`
--

LOCK TABLES `tiki_menu_languages` WRITE;
/*!40000 ALTER TABLE `tiki_menu_languages` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_menu_languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_menu_options`
--

DROP TABLE IF EXISTS `tiki_menu_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_menu_options` (
  `optionId` int(8) NOT NULL AUTO_INCREMENT,
  `menuId` int(8) DEFAULT NULL,
  `type` char(1) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `position` int(4) DEFAULT NULL,
  `section` text,
  `perm` text,
  `groupname` text,
  `userlevel` int(4) DEFAULT '0',
  `icon` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`optionId`),
  UNIQUE KEY `uniq_menu` (`menuId`,`name`(30),`url`(50),`position`,`section`(60),`perm`(50),`groupname`(50))
) ENGINE=MyISAM AUTO_INCREMENT=187 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_menu_options`
--

LOCK TABLES `tiki_menu_options` WRITE;
/*!40000 ALTER TABLE `tiki_menu_options` DISABLE KEYS */;
INSERT INTO `tiki_menu_options` VALUES (1,42,'o','Home','./',10,'','','',0,NULL),(2,42,'o','Search','tiki-searchresults.php',13,'feature_search_fulltext','tiki_p_search','',0,'xfce4-appfinder48x48'),(3,42,'o','Search','tiki-searchindex.php',13,'feature_search','tiki_p_search','',0,'xfce4-appfinder48x48'),(4,42,'o','Contact Us','tiki-contact.php',20,'feature_contact,feature_messages','','',0,NULL),(5,42,'o','Stats','tiki-stats.php',23,'feature_stats','tiki_p_view_stats','',0,NULL),(6,42,'o','Categories','tiki-browse_categories.php',25,'feature_categories','tiki_p_view_category','',0,NULL),(7,42,'o','Freetags','tiki-browse_freetags.php',27,'feature_freetags','tiki_p_view_freetags','',0,'vcard48x48'),(8,42,'o','Calendar','tiki-calendar.php',35,'feature_calendar','tiki_p_view_calendar','',0,'date48x48'),(9,42,'o','Users Map','tiki-gmap_usermap.php',36,'feature_gmap','','',0,NULL),(10,42,'o','Tiki Calendar','tiki-action_calendar.php',37,'feature_action_calendar','tiki_p_view_tiki_calendar','',0,NULL),(11,42,'o','Mobile','tiki-mobile.php',37,'feature_mobile','','',0,NULL),(12,42,'o','(debug)','javascript:toggle(\'debugconsole\')',40,'feature_debug_console','tiki_p_admin','',0,NULL),(13,42,'s','MyTiki','tiki-my_tiki.php',50,'feature_mytiki','','Registered',0,'userfiles48x48'),(14,42,'o','MyTiki Home','tiki-my_tiki.php',51,'feature_mytiki','','Registered',0,NULL),(15,42,'o','Preferences','tiki-user_preferences.php',55,'feature_mytiki,feature_userPreferences','','Registered',0,NULL),(16,42,'o','Messages','messu-mailbox.php',60,'feature_mytiki,feature_messages','tiki_p_messages','Registered',0,NULL),(17,42,'o','Tasks','tiki-user_tasks.php',65,'feature_mytiki,feature_tasks','tiki_p_tasks','Registered',0,NULL),(18,42,'o','Bookmarks','tiki-user_bookmarks.php',70,'feature_mytiki,feature_user_bookmarks','tiki_p_create_bookmarks','Registered',0,NULL),(19,42,'o','Modules','tiki-user_assigned_modules.php',75,'feature_mytiki,user_assigned_modules','tiki_p_configure_modules','Registered',0,NULL),(20,42,'o','Webmail','tiki-webmail.php',85,'feature_mytiki,feature_webmail','tiki_p_use_webmail','Registered',0,NULL),(21,42,'o','Contacts','tiki-contacts.php',87,'feature_mytiki,feature_contacts','','Registered',0,NULL),(22,42,'o','Notepad','tiki-notepad_list.php',90,'feature_mytiki,feature_notepad','tiki_p_notepad','Registered',0,NULL),(23,42,'o','My Files','tiki-userfiles.php',95,'feature_mytiki,feature_userfiles','tiki_p_userfiles','Registered',0,NULL),(24,42,'o','User Menu','tiki-usermenu.php',100,'feature_mytiki,feature_usermenu','tiki_p_usermenu','Registered',0,NULL),(25,42,'o','Mini Calendar','tiki-minical.php',105,'feature_mytiki,feature_minical','tiki_p_minical','Registered',0,NULL),(26,42,'o','My Watches','tiki-user_watches.php',110,'feature_mytiki,feature_user_watches','','Registered',0,NULL),(27,42,'s','Community','tiki-list_users.php',187,'feature_friends','tiki_p_list_users','',0,'users48x48'),(28,42,'o','User List','tiki-list_users.php',188,'feature_friends','tiki_p_list_users','',0,NULL),(29,42,'o','Friendship Network','tiki-friends.php',189,'feature_friends','','Registered',0,NULL),(30,42,'s','Wiki','tiki-index.php',200,'feature_wiki','tiki_p_view','',0,'wikipages48x48'),(31,42,'o','Wiki Home','tiki-index.php',202,'feature_wiki','tiki_p_view','',0,NULL),(32,42,'o','Last Changes','tiki-lastchanges.php',205,'feature_wiki,feature_lastChanges','tiki_p_view','',0,NULL),(33,42,'o','Dump','dump/new.tar',210,'feature_wiki,feature_dump','tiki_p_view','',0,NULL),(34,42,'o','Rankings','tiki-wiki_rankings.php',215,'feature_wiki,feature_wiki_rankings','tiki_p_view','',0,NULL),(35,42,'o','List Pages','tiki-listpages.php',220,'feature_wiki,feature_listPages','tiki_p_view','',0,NULL),(36,42,'o','Create a Wiki Page','tiki-listpages.php?cookietab=2#tab2',222,'feature_wiki,feature_listPages','tiki_p_view,tiki_p_edit','',0,NULL),(37,42,'o','Orphan Pages','tiki-orphan_pages.php',225,'feature_wiki,feature_listorphanPages','tiki_p_view','',0,NULL),(38,42,'o','Sandbox','tiki-editpage.php?page=sandbox',230,'feature_wiki,feature_sandbox','tiki_p_view','',0,NULL),(39,42,'o','Multiple Print','tiki-print_pages.php',235,'feature_wiki,feature_wiki_multiprint','tiki_p_view','',0,NULL),(40,42,'o','Send Pages','tiki-send_objects.php',240,'feature_wiki,feature_comm','tiki_p_view,tiki_p_send_pages','',0,NULL),(41,42,'o','Received Pages','tiki-received_pages.php',245,'feature_wiki,feature_comm','tiki_p_view,tiki_p_admin_received_pages','',0,NULL),(42,42,'o','Structures','tiki-admin_structures.php',250,'feature_wiki,feature_wiki_structure','tiki_p_view','',0,NULL),(43,42,'o','Mind Map','tiki-mindmap.php',255,'feature_wiki_mindmap','tiki_p_view','',0,NULL),(44,42,'s','Image Galleries','tiki-galleries.php',300,'feature_galleries','tiki_p_view_image_gallery','',0,'stock_select-color48x48'),(45,42,'o','Galleries','tiki-galleries.php',305,'feature_galleries','tiki_p_list_image_galleries','',0,NULL),(46,42,'o','Rankings','tiki-galleries_rankings.php',310,'feature_galleries,feature_gal_rankings','tiki_p_list_image_galleries','',0,NULL),(47,42,'o','Upload Image','tiki-upload_image.php',315,'feature_galleries','tiki_p_upload_images','',0,NULL),(48,42,'o','Directory Batch','tiki-batch_upload.php',318,'feature_galleries,feature_gal_batch','tiki_p_batch_upload','',0,NULL),(49,42,'o','System Gallery','tiki-list_gallery.php?galleryId=0',320,'feature_galleries','tiki_p_admin_galleries','',0,NULL),(50,42,'s','Articles','tiki-view_articles.php',350,'feature_articles','tiki_p_read_article','',0,'stock_bold48x48'),(51,42,'s','Articles','tiki-view_articles.php',350,'feature_articles','tiki_p_articles_read_heading','',0,'stock_bold48x48'),(52,42,'o','Articles Home','tiki-view_articles.php',355,'feature_articles','tiki_p_read_article','',0,NULL),(53,42,'o','Articles Home','tiki-view_articles.php',355,'feature_articles','tiki_p_articles_read_heading','',0,NULL),(54,42,'o','List Articles','tiki-list_articles.php',360,'feature_articles','tiki_p_read_article','',0,NULL),(55,42,'o','List Articles','tiki-list_articles.php',360,'feature_articles','tiki_p_articles_read_heading','',0,NULL),(56,42,'o','Rankings','tiki-cms_rankings.php',365,'feature_articles,feature_cms_rankings','tiki_p_read_article','',0,NULL),(57,42,'o','Submit Article','tiki-edit_submission.php',370,'feature_articles,feature_submissions','tiki_p_read_article,tiki_p_submit_article','',0,NULL),(58,42,'o','View submissions','tiki-list_submissions.php',375,'feature_articles,feature_submissions','tiki_p_read_article,tiki_p_submit_article','',0,NULL),(59,42,'o','View submissions','tiki-list_submissions.php',375,'feature_articles,feature_submissions','tiki_p_read_article,tiki_p_approve_submission','',0,NULL),(60,42,'o','View Submissions','tiki-list_submissions.php',375,'feature_articles,feature_submissions','tiki_p_read_article,tiki_p_remove_submission','',0,NULL),(61,42,'o','New Article','tiki-edit_article.php',380,'feature_articles','tiki_p_read_article,tiki_p_edit_article','',0,NULL),(62,42,'o','Send Articles','tiki-send_objects.php',385,'feature_articles,feature_comm','tiki_p_read_article,tiki_p_send_articles','',0,NULL),(63,42,'o','Received Articles','tiki-received_articles.php',385,'feature_articles,feature_comm','tiki_p_read_article,tiki_p_admin_received_articles','',0,NULL),(64,42,'o','Admin Types','tiki-article_types.php',395,'feature_articles','tiki_p_articles_admin_types','',0,NULL),(65,42,'o','Admin Topics','tiki-admin_topics.php',390,'feature_articles','tiki_p_articles_admin_topics','',0,NULL),(66,42,'s','Blogs','tiki-list_blogs.php',450,'feature_blogs','tiki_p_read_blog','',0,'blogs48x48'),(67,42,'o','List Blogs','tiki-list_blogs.php',455,'feature_blogs','tiki_p_read_blog','',0,NULL),(68,42,'o','Rankings','tiki-blog_rankings.php',460,'feature_blogs,feature_blog_rankings','tiki_p_read_blog','',0,NULL),(69,42,'o','Create/Edit Blog','tiki-edit_blog.php',465,'feature_blogs','tiki_p_read_blog,tiki_p_create_blogs','',0,NULL),(70,42,'o','Post','tiki-blog_post.php',470,'feature_blogs','tiki_p_read_blog,tiki_p_blog_post','',0,NULL),(71,42,'o','Admin Posts','tiki-list_posts.php',475,'feature_blogs','tiki_p_read_blog,tiki_p_blog_admin','',0,NULL),(72,42,'s','Forums','tiki-forums.php',500,'feature_forums','tiki_p_forum_read','',0,'stock_index48x48'),(73,42,'o','List Forums','tiki-forums.php',505,'feature_forums','tiki_p_forum_read','',0,NULL),(74,42,'o','Rankings','tiki-forum_rankings.php',510,'feature_forums,feature_forum_rankings','tiki_p_forum_read','',0,NULL),(75,42,'o','Admin Forums','tiki-admin_forums.php',515,'feature_forums','tiki_p_forum_read,tiki_p_admin_forum','',0,NULL),(76,42,'s','Directory','tiki-directory_browse.php',550,'feature_directory','tiki_p_view_directory','',0,NULL),(77,42,'o','Submit a new link','tiki-directory_add_site.php',555,'feature_directory','tiki_p_submit_link','',0,NULL),(78,42,'o','Browse Directory','tiki-directory_browse.php',560,'feature_directory','tiki_p_view_directory','',0,NULL),(79,42,'o','Admin Directory','tiki-directory_admin.php',565,'feature_directory','tiki_p_view_directory,tiki_p_admin_directory_cats','',0,NULL),(80,42,'o','Admin Directory','tiki-directory_admin.php',565,'feature_directory','tiki_p_view_directory,tiki_p_admin_directory_sites','',0,NULL),(81,42,'o','Admin Directory','tiki-directory_admin.php',565,'feature_directory','tiki_p_view_directory,tiki_p_validate_links','',0,NULL),(82,42,'s','File Galleries','tiki-list_file_gallery.php',600,'feature_file_galleries','tiki_p_list_file_galleries|tiki_p_view_file_gallery|tiki_p_upload_files','',0,'file-manager48x48'),(83,42,'o','List Galleries','tiki-list_file_gallery.php',605,'feature_file_galleries','tiki_p_list_file_galleries','',0,NULL),(84,42,'o','Rankings','tiki-file_galleries_rankings.php',610,'feature_file_galleries,feature_file_galleries_rankings','tiki_p_list_file_galleries','',0,NULL),(85,42,'o','Upload File','tiki-upload_file.php',615,'feature_file_galleries','tiki_p_upload_files','',0,NULL),(86,42,'o','Directory batch','tiki-batch_upload_files.php',617,'feature_file_galleries_batch','tiki_p_batch_upload_file_dir','',0,NULL),(87,42,'s','FAQs','tiki-list_faqs.php',650,'feature_faqs','tiki_p_view_faqs','',0,'stock_dialog_question48x48'),(88,42,'o','List FAQs','tiki-list_faqs.php',665,'feature_faqs','tiki_p_view_faqs','',0,NULL),(89,42,'o','Admin FAQs','tiki-list_faqs.php',660,'feature_faqs','tiki_p_admin_faqs','',0,NULL),(90,42,'s','Maps','tiki-map.php',700,'feature_maps','tiki_p_map_view','',0,'maps48x48'),(91,42,'o','Mapfiles','tiki-map_edit.php',705,'feature_maps','tiki_p_map_view','',0,NULL),(92,42,'o','Layer Management','tiki-map_upload.php',710,'feature_maps','tiki_p_map_edit','',0,NULL),(93,42,'s','Quizzes','tiki-list_quizzes.php',750,'feature_quizzes','tiki_p_take_quiz','',0,''),(94,42,'o','List Quizzes','tiki-list_quizzes.php',755,'feature_quizzes','tiki_p_take_quiz','',0,NULL),(95,42,'o','Quiz Stats','tiki-quiz_stats.php',760,'feature_quizzes','tiki_p_view_quiz_stats','',0,NULL),(96,42,'o','Admin Quizzes','tiki-edit_quiz.php',765,'feature_quizzes','tiki_p_admin_quizzes','',0,NULL),(97,42,'s','Spreadsheets','tiki-sheets.php',780,'feature_sheet','tiki_p_view_sheet','',0,NULL),(98,42,'o','List Sheets','tiki-sheets.php',782,'feature_sheet','tiki_p_view_sheet','',0,NULL),(99,42,'s','Trackers','tiki-list_trackers.php',800,'feature_trackers','tiki_p_list_trackers','',0,'gnome-settings-font48x48'),(100,42,'o','List Trackers','tiki-list_trackers.php',805,'feature_trackers','tiki_p_list_trackers','',0,NULL),(101,42,'o','Admin Trackers','tiki-admin_trackers.php',810,'feature_trackers','tiki_p_admin_trackers','',0,NULL),(102,42,'s','Surveys','tiki-list_surveys.php',850,'feature_surveys','tiki_p_take_survey','',0,''),(103,42,'o','List Surveys','tiki-list_surveys.php',855,'feature_surveys','tiki_p_take_survey','',0,NULL),(104,42,'o','Stats','tiki-survey_stats.php',860,'feature_surveys','tiki_p_view_survey_stats','',0,NULL),(105,42,'o','Admin Surveys','tiki-admin_surveys.php',865,'feature_surveys','tiki_p_admin_surveys','',0,NULL),(106,42,'s','Newsletters','tiki-newsletters.php',900,'feature_newsletters','tiki_p_subscribe_newsletters','',0,'messages48x48'),(107,42,'s','Newsletters','tiki-newsletters.php',900,'feature_newsletters','tiki_p_send_newsletters','',0,'messages48x48'),(108,42,'s','Newsletters','tiki-newsletters.php',900,'feature_newsletters','tiki_p_admin_newsletters','',0,'messages48x48'),(109,42,'s','Newsletters','tiki-newsletters.php',900,'feature_newsletters','tiki_p_list_newsletters','',0,'messages48x48'),(110,42,'o','Send Newsletters','tiki-send_newsletters.php',905,'feature_newsletters','tiki_p_send_newsletters','',0,NULL),(111,42,'o','Admin Newsletters','tiki-admin_newsletters.php',910,'feature_newsletters','tiki_p_admin_newsletters','',0,NULL),(112,42,'r','Admin','tiki-admin.php',1050,'','tiki_p_admin','',0,'icon-configuration48x48'),(113,42,'r','Admin','tiki-admin.php',1050,'','tiki_p_admin_categories','',0,'icon-configuration48x48'),(114,42,'r','Admin','tiki-admin.php',1050,'','tiki_p_admin_banners','',0,'icon-configuration48x48'),(115,42,'r','Admin','tiki-admin.php',1050,'','tiki_p_edit_templates','',0,'icon-configuration48x48'),(116,42,'r','Admin','tiki-admin.php',1050,'','tiki_p_edit_cookies','',0,'icon-configuration48x48'),(117,42,'r','Admin','tiki-admin.php',1050,'','tiki_p_admin_dynamic','',0,'icon-configuration48x48'),(118,42,'r','Admin','tiki-admin.php',1050,'','tiki_p_admin_mailin','',0,'icon-configuration48x48'),(119,42,'r','Admin','tiki-admin.php',1050,'','tiki_p_edit_content_templates','',0,'icon-configuration48x48'),(120,42,'r','Admin','tiki-admin.php',1050,'','tiki_p_edit_html_pages','',0,'icon-configuration48x48'),(121,42,'r','Admin','tiki-admin.php',1050,'','tiki_p_view_referer_stats','',0,'icon-configuration48x48'),(122,42,'r','Admin','tiki-admin.php',1050,'','tiki_p_admin_shoutbox','',0,'icon-configuration48x48'),(123,42,'r','Admin','tiki-admin.php',1050,'','tiki_p_live_support_admin','',0,'icon-configuration48x48'),(124,42,'r','Admin','tiki-admin.php',1050,'','user_is_operator','',0,'icon-configuration48x48'),(125,42,'r','Admin','tiki-admin.php',1050,'feature_integrator','tiki_p_admin_integrator','',0,'icon-configuration48x48'),(126,42,'r','Admin','tiki-admin.php',1050,'feature_edit_templates','tiki_p_edit_templates','',0,'icon-configuration48x48'),(127,42,'r','Admin','tiki-admin.php',1050,'feature_view_tpl','tiki_p_edit_templates','',0,'icon-configuration48x48'),(128,42,'r','Admin','tiki-admin.php',1050,'feature_editcss','tiki_p_create_css','',0,'icon-configuration48x48'),(129,42,'r','Admin','tiki-admin.php',1050,'','tiki_p_admin_contribution','',0,'icon-configuration48x48'),(130,42,'r','Admin','tiki-admin.php',1050,'','tiki_p_admin_users','',0,'icon-configuration48x48'),(131,42,'r','Admin','tiki-admin.php',1050,'','tiki_p_admin_toolbars','',0,'icon-configuration48x48'),(132,42,'r','Admin','tiki-admin.php',1050,'','tiki_p_edit_menu','',0,'icon-configuration48x48'),(133,42,'r','Admin','tiki-admin.php',1050,'','tiki_p_clean_cache','',0,'icon-configuration48x48'),(134,42,'r','Admin','tiki-admin.php',1050,'','tiki_p_admin_modules','',0,'icon-configuration48x48'),(135,42,'o','Admin Home','tiki-admin.php',1051,'','tiki_p_admin','',0,NULL),(136,42,'o','Live Support','tiki-live_support_admin.php',1055,'feature_live_support','tiki_p_live_support_admin','',0,NULL),(137,42,'o','Live Support','tiki-live_support_admin.php',1055,'feature_live_support','user_is_operator','',0,NULL),(138,42,'o','Banning','tiki-admin_banning.php',1060,'feature_banning','tiki_p_admin_banning','',0,NULL),(139,42,'o','Calendar','tiki-admin_calendars.php',1065,'feature_calendar','tiki_p_admin_calendar','',0,NULL),(140,42,'o','Users','tiki-adminusers.php',1070,'','tiki_p_admin_users','',0,NULL),(141,42,'o','Groups','tiki-admingroups.php',1075,'','tiki_p_admin','',0,NULL),(142,42,'o','External Pages Cache','tiki-list_cache.php',1080,'cachepages','tiki_p_admin','',0,NULL),(143,42,'o','Modules','tiki-admin_modules.php',1085,'','tiki_p_admin_modules','',0,NULL),(144,42,'o','Hotwords','tiki-admin_hotwords.php',1095,'feature_hotwords','tiki_p_admin','',0,NULL),(145,42,'o','Edit languages','tiki-edit_languages.php',1098,'lang_use_db','tiki_p_edit_languages','',0,NULL),(146,42,'o','External Feeds','tiki-admin_rssmodules.php',1100,'','tiki_p_admin_rssmodules','',0,NULL),(147,42,'o','Menus','tiki-admin_menus.php',1105,'','tiki_p_edit_menu','',0,NULL),(148,42,'o','Polls','tiki-admin_polls.php',1110,'feature_polls','tiki_p_admin_polls','',0,NULL),(149,42,'o','Mail Notifications','tiki-admin_notifications.php',1120,'','tiki_p_admin_notifications','',0,NULL),(150,42,'o','Search Stats','tiki-search_stats.php',1125,'feature_search_stats','tiki_p_admin','',0,NULL),(151,42,'o','Theme Control','tiki-theme_control.php',1130,'feature_theme_control','tiki_p_admin','',0,NULL),(152,42,'o','Toolbars','tiki-admin_toolbars.php',1135,'','tiki_p_admin_toolbars','',0,NULL),(153,42,'o','Transitions','tiki-admin_transitions.php',1140,'','tiki_p_admin','',0,NULL),(154,42,'o','Categories','tiki-admin_categories.php',1145,'feature_categories','tiki_p_admin_categories','',0,NULL),(155,42,'o','Banners','tiki-list_banners.php',1150,'feature_banners','tiki_p_admin_banners','',0,NULL),(156,42,'o','Edit Templates','tiki-edit_templates.php',1155,'feature_edit_templates','tiki_p_edit_templates','',0,NULL),(157,42,'o','View Templates','tiki-edit_templates.php',1155,'feature_view_tpl','tiki_p_edit_templates','',2,NULL),(158,42,'o','Edit CSS','tiki-edit_css.php',1158,'feature_editcss','tiki_p_create_css','',2,NULL),(159,42,'o','Dynamic content','tiki-list_contents.php',1165,'feature_dynamic_content','tiki_p_admin_dynamic','',0,NULL),(160,42,'o','Mail-in','tiki-admin_mailin.php',1175,'feature_mailin','tiki_p_admin_mailin','',0,NULL),(161,42,'o','HTML Pages','tiki-admin_html_pages.php',1185,'feature_html_pages','tiki_p_edit_html_pages','',0,NULL),(162,42,'o','Shoutbox','tiki-shoutbox.php',1190,'feature_shoutbox','tiki_p_admin_shoutbox','',0,NULL),(163,42,'o','Shoutbox Words','tiki-admin_shoutbox_words.php',1191,'feature_shoutbox','tiki_p_admin_shoutbox','',0,NULL),(164,42,'o','Referer Stats','tiki-referer_stats.php',1195,'feature_referer_stats','tiki_p_view_referer_stats','',0,NULL),(165,42,'o','Integrator','tiki-admin_integrator.php',1205,'feature_integrator','tiki_p_admin_integrator','',0,NULL),(166,42,'o','phpinfo','tiki-phpinfo.php',1215,'','tiki_p_admin','',0,NULL),(167,42,'o','Tiki Cache/Sys Admin','tiki-admin_system.php',1230,'','tiki_p_clean_cache','',0,NULL),(168,42,'o','Tiki Importer','tiki-importer.php',1240,'','tiki_p_admin_importer','',0,NULL),(169,42,'o','Tiki Logs','tiki-syslog.php',1245,'','tiki_p_admin','',0,NULL),(170,42,'o','Security Admin','tiki-admin_security.php',1250,'','tiki_p_admin','',0,NULL),(171,42,'o','Action Log','tiki-admin_actionlog.php',1255,'feature_actionlog','tiki_p_admin','',0,NULL),(172,42,'o','Action Log','tiki-admin_actionlog.php',1255,'feature_actionlog','tiki_p_view_actionlog','',0,NULL),(173,42,'o','Action Log','tiki-admin_actionlog.php',1255,'feature_actionlog','tiki_p_view_actionlog_owngroups','',0,NULL),(174,42,'o','Content Templates','tiki-admin_content_templates.php',1256,'feature_wiki_templates','tiki_p_edit_content_templates','',0,NULL),(175,42,'o','Comments','tiki-list_comments.php',1260,'feature_wiki_comments','tiki_p_admin','',0,NULL),(176,42,'o','Comments','tiki-list_comments.php',1260,'feature_article_comments','tiki_p_admin','',0,NULL),(177,42,'o','Comments','tiki-list_comments.php',1260,'feature_file_galleries_comments','tiki_p_admin','',0,NULL),(178,42,'o','Comments','tiki-list_comments.php',1260,'feature_image_galleries_comments','tiki_p_admin','',0,NULL),(179,42,'o','Comments','tiki-list_comments.php',1260,'feature_poll_comments','tiki_p_admin','',0,NULL),(180,42,'o','Comments','tiki-list_comments.php',1260,'feature_faq_comments','tiki_p_admin','',0,NULL),(181,42,'o','Contribution','tiki-admin_contribution.php',1265,'feature_contribution','tiki_p_admin_contribution','',0,NULL),(182,42,'s','Kaltura Video','tiki-list_kaltura_entries.php',950,'feature_kaltura','tiki_p_admin | tiki_p_admin_kaltura | tiki_p_list_videos','',0,NULL),(183,42,'o','List Entries','tiki-list_kaltura_entries.php',952,'feature_kaltura','tiki_p_admin | tiki_p_admin_kaltura | tiki_p_list_videos','',0,NULL),(184,42,'o','Upload Media','tiki-kaltura_upload.php',954,'feature_kaltura','tiki_p_admin | tiki_p_admin_kaltura | tiki_p_upload_videos','',0,NULL),(185,42,'o','Permissions','tiki-objectpermissions.php',1077,'','tiki_p_admin|tiki_p_admin_objects','',0,NULL),(186,42,'o','Social networks','tiki-socialnetworks.php',115,'feature_mytiki,feature_socialnetworks','tiki_p_socialnetworks|tiki_p_admin_socialnetworks','Registered',0,NULL);
/*!40000 ALTER TABLE `tiki_menu_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_menus`
--

DROP TABLE IF EXISTS `tiki_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_menus` (
  `menuId` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `description` text,
  `type` char(1) DEFAULT NULL,
  `icon` varchar(200) DEFAULT NULL,
  `use_items_icons` char(1) NOT NULL DEFAULT 'n',
  PRIMARY KEY (`menuId`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_menus`
--

LOCK TABLES `tiki_menus` WRITE;
/*!40000 ALTER TABLE `tiki_menus` DISABLE KEYS */;
INSERT INTO `tiki_menus` VALUES (42,'Application menu','Main extensive navigation menu','d',NULL,'y');
/*!40000 ALTER TABLE `tiki_menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_minical_events`
--

DROP TABLE IF EXISTS `tiki_minical_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_minical_events` (
  `user` varchar(200) DEFAULT '',
  `eventId` int(12) NOT NULL AUTO_INCREMENT,
  `title` varchar(250) DEFAULT NULL,
  `description` text,
  `start` int(14) DEFAULT NULL,
  `end` int(14) DEFAULT NULL,
  `security` char(1) DEFAULT NULL,
  `duration` int(3) DEFAULT NULL,
  `topicId` int(12) DEFAULT NULL,
  `reminded` char(1) DEFAULT NULL,
  PRIMARY KEY (`eventId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_minical_events`
--

LOCK TABLES `tiki_minical_events` WRITE;
/*!40000 ALTER TABLE `tiki_minical_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_minical_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_minical_topics`
--

DROP TABLE IF EXISTS `tiki_minical_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_minical_topics` (
  `user` varchar(200) DEFAULT '',
  `topicId` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `filename` varchar(200) DEFAULT NULL,
  `filetype` varchar(200) DEFAULT NULL,
  `filesize` varchar(200) DEFAULT NULL,
  `data` longblob,
  `path` varchar(250) DEFAULT NULL,
  `isIcon` char(1) DEFAULT NULL,
  PRIMARY KEY (`topicId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_minical_topics`
--

LOCK TABLES `tiki_minical_topics` WRITE;
/*!40000 ALTER TABLE `tiki_minical_topics` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_minical_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_minichat`
--

DROP TABLE IF EXISTS `tiki_minichat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_minichat` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `channel` varchar(31) DEFAULT NULL,
  `ts` int(10) unsigned NOT NULL,
  `user` varchar(31) DEFAULT NULL,
  `nick` varchar(31) DEFAULT NULL,
  `msg` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `channel` (`channel`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_minichat`
--

LOCK TABLES `tiki_minichat` WRITE;
/*!40000 ALTER TABLE `tiki_minichat` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_minichat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_modules`
--

DROP TABLE IF EXISTS `tiki_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_modules` (
  `moduleId` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `position` char(1) NOT NULL DEFAULT '',
  `ord` int(4) NOT NULL DEFAULT '0',
  `type` char(1) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `cache_time` int(14) DEFAULT NULL,
  `rows` int(4) DEFAULT NULL,
  `params` text,
  `groups` text,
  PRIMARY KEY (`moduleId`),
  KEY `positionType` (`position`,`type`),
  KEY `namePosOrdParam` (`name`(100),`position`,`ord`,`params`(140))
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_modules`
--

LOCK TABLES `tiki_modules` WRITE;
/*!40000 ALTER TABLE `tiki_modules` DISABLE KEYS */;
INSERT INTO `tiki_modules` VALUES (1,'Application Menu','l',30,NULL,NULL,0,NULL,'flip=y','a:1:{i:0;s:10:\"Registered\";}');
/*!40000 ALTER TABLE `tiki_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_newsletter_groups`
--

DROP TABLE IF EXISTS `tiki_newsletter_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_newsletter_groups` (
  `nlId` int(12) NOT NULL DEFAULT '0',
  `groupName` varchar(255) NOT NULL DEFAULT '',
  `code` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`nlId`,`groupName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_newsletter_groups`
--

LOCK TABLES `tiki_newsletter_groups` WRITE;
/*!40000 ALTER TABLE `tiki_newsletter_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_newsletter_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_newsletter_included`
--

DROP TABLE IF EXISTS `tiki_newsletter_included`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_newsletter_included` (
  `nlId` int(12) NOT NULL DEFAULT '0',
  `includedId` int(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`nlId`,`includedId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_newsletter_included`
--

LOCK TABLES `tiki_newsletter_included` WRITE;
/*!40000 ALTER TABLE `tiki_newsletter_included` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_newsletter_included` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_newsletter_pages`
--

DROP TABLE IF EXISTS `tiki_newsletter_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_newsletter_pages` (
  `nlId` int(12) NOT NULL,
  `wikiPageName` varchar(160) NOT NULL,
  `validateAddrs` char(1) NOT NULL DEFAULT 'n',
  `addToList` char(1) NOT NULL DEFAULT 'n',
  PRIMARY KEY (`nlId`,`wikiPageName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_newsletter_pages`
--

LOCK TABLES `tiki_newsletter_pages` WRITE;
/*!40000 ALTER TABLE `tiki_newsletter_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_newsletter_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_newsletter_subscriptions`
--

DROP TABLE IF EXISTS `tiki_newsletter_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_newsletter_subscriptions` (
  `nlId` int(12) NOT NULL DEFAULT '0',
  `email` varchar(255) NOT NULL DEFAULT '',
  `code` varchar(32) DEFAULT NULL,
  `valid` char(1) DEFAULT NULL,
  `subscribed` int(14) DEFAULT NULL,
  `isUser` char(1) NOT NULL DEFAULT 'n',
  `included` char(1) NOT NULL DEFAULT 'n',
  PRIMARY KEY (`nlId`,`email`,`isUser`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_newsletter_subscriptions`
--

LOCK TABLES `tiki_newsletter_subscriptions` WRITE;
/*!40000 ALTER TABLE `tiki_newsletter_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_newsletter_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_newsletters`
--

DROP TABLE IF EXISTS `tiki_newsletters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_newsletters` (
  `nlId` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `description` text,
  `created` int(14) DEFAULT NULL,
  `lastSent` int(14) DEFAULT NULL,
  `editions` int(10) DEFAULT NULL,
  `users` int(10) DEFAULT NULL,
  `allowUserSub` char(1) DEFAULT 'y',
  `allowAnySub` char(1) DEFAULT NULL,
  `unsubMsg` char(1) DEFAULT 'y',
  `validateAddr` char(1) DEFAULT 'y',
  `frequency` int(14) DEFAULT NULL,
  `allowTxt` char(1) DEFAULT 'y',
  `author` varchar(200) DEFAULT NULL,
  `allowArticleClip` char(1) DEFAULT 'y',
  `autoArticleClip` char(1) DEFAULT 'n',
  `articleClipTypes` text,
  `articleClipRange` int(14) DEFAULT NULL,
  PRIMARY KEY (`nlId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_newsletters`
--

LOCK TABLES `tiki_newsletters` WRITE;
/*!40000 ALTER TABLE `tiki_newsletters` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_newsletters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_object_attributes`
--

DROP TABLE IF EXISTS `tiki_object_attributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_object_attributes` (
  `attributeId` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `itemId` varchar(255) NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `value` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`attributeId`),
  UNIQUE KEY `item_attribute_uq` (`type`,`itemId`,`attribute`),
  KEY `attribute_lookup_ix` (`attribute`,`value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_object_attributes`
--

LOCK TABLES `tiki_object_attributes` WRITE;
/*!40000 ALTER TABLE `tiki_object_attributes` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_object_attributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_object_ratings`
--

DROP TABLE IF EXISTS `tiki_object_ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_object_ratings` (
  `catObjectId` int(12) NOT NULL DEFAULT '0',
  `pollId` int(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`catObjectId`,`pollId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_object_ratings`
--

LOCK TABLES `tiki_object_ratings` WRITE;
/*!40000 ALTER TABLE `tiki_object_ratings` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_object_ratings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_object_relations`
--

DROP TABLE IF EXISTS `tiki_object_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_object_relations` (
  `relationId` int(11) NOT NULL AUTO_INCREMENT,
  `relation` varchar(25) NOT NULL,
  `source_type` varchar(50) NOT NULL,
  `source_itemId` varchar(255) NOT NULL,
  `target_type` varchar(50) NOT NULL,
  `target_itemId` varchar(255) NOT NULL,
  PRIMARY KEY (`relationId`),
  KEY `relation_source_ix` (`source_type`,`source_itemId`),
  KEY `relation_target_ix` (`target_type`,`target_itemId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_object_relations`
--

LOCK TABLES `tiki_object_relations` WRITE;
/*!40000 ALTER TABLE `tiki_object_relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_object_relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_objects`
--

DROP TABLE IF EXISTS `tiki_objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_objects` (
  `objectId` int(12) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) DEFAULT NULL,
  `itemId` varchar(255) DEFAULT NULL,
  `description` text,
  `created` int(14) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `href` varchar(200) DEFAULT NULL,
  `hits` int(8) DEFAULT NULL,
  `comments_locked` char(1) NOT NULL DEFAULT 'n',
  PRIMARY KEY (`objectId`),
  KEY `type` (`type`,`objectId`),
  KEY `itemId` (`itemId`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_objects`
--

LOCK TABLES `tiki_objects` WRITE;
/*!40000 ALTER TABLE `tiki_objects` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_objects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_page_drafts`
--

DROP TABLE IF EXISTS `tiki_page_drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_page_drafts` (
  `user` varchar(200) NOT NULL DEFAULT '',
  `pageName` varchar(255) NOT NULL,
  `data` mediumtext,
  `description` varchar(200) DEFAULT NULL,
  `comment` varchar(200) DEFAULT NULL,
  `lastModif` int(14) DEFAULT NULL,
  PRIMARY KEY (`pageName`(120),`user`(120))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_page_drafts`
--

LOCK TABLES `tiki_page_drafts` WRITE;
/*!40000 ALTER TABLE `tiki_page_drafts` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_page_drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_page_footnotes`
--

DROP TABLE IF EXISTS `tiki_page_footnotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_page_footnotes` (
  `user` varchar(200) NOT NULL DEFAULT '',
  `pageName` varchar(250) NOT NULL DEFAULT '',
  `data` text,
  PRIMARY KEY (`user`(150),`pageName`(100))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_page_footnotes`
--

LOCK TABLES `tiki_page_footnotes` WRITE;
/*!40000 ALTER TABLE `tiki_page_footnotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_page_footnotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_pages`
--

DROP TABLE IF EXISTS `tiki_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_pages` (
  `page_id` int(14) NOT NULL AUTO_INCREMENT,
  `pageName` varchar(160) NOT NULL DEFAULT '',
  `hits` int(8) DEFAULT NULL,
  `data` mediumtext,
  `description` varchar(200) DEFAULT NULL,
  `lastModif` int(14) DEFAULT NULL,
  `comment` varchar(200) DEFAULT NULL,
  `version` int(8) NOT NULL DEFAULT '0',
  `version_minor` int(8) NOT NULL DEFAULT '0',
  `user` varchar(200) DEFAULT '',
  `ip` varchar(15) DEFAULT NULL,
  `flag` char(1) DEFAULT NULL,
  `points` int(8) DEFAULT NULL,
  `votes` int(8) DEFAULT NULL,
  `cache` longtext,
  `wiki_cache` int(10) DEFAULT NULL,
  `cache_timestamp` int(14) DEFAULT NULL,
  `pageRank` decimal(4,3) DEFAULT NULL,
  `creator` varchar(200) DEFAULT NULL,
  `page_size` int(10) unsigned DEFAULT '0',
  `lang` varchar(16) DEFAULT NULL,
  `lockedby` varchar(200) DEFAULT NULL,
  `is_html` tinyint(1) DEFAULT '0',
  `created` int(14) DEFAULT NULL,
  `wysiwyg` char(1) DEFAULT NULL,
  `wiki_authors_style` varchar(20) DEFAULT '',
  `comments_enabled` char(1) DEFAULT NULL,
  `keywords` text,
  PRIMARY KEY (`page_id`),
  UNIQUE KEY `pageName` (`pageName`),
  KEY `data` (`data`(255)),
  KEY `pageRank` (`pageRank`),
  KEY `lastModif` (`lastModif`),
  FULLTEXT KEY `ft` (`pageName`,`description`,`data`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_pages`
--

LOCK TABLES `tiki_pages` WRITE;
/*!40000 ALTER TABLE `tiki_pages` DISABLE KEYS */;
INSERT INTO `tiki_pages` VALUES (1,'HomePage',0,'{GROUP(groups=Admins)}\n!Thank you for installing Tiki.\n\nThe entire Tiki Community would like to thank you and help you get introduced to Tiki.\n\n!How To Get Started\nTiki has more than 1000 features and settings.\n\nThis allows you to create both very simple and complex websites.\n\nWe understand that so many features might seem overwhelming at first. This is why we offer you two different ways to __Get Started__ with Tiki.\n\n{DIV(width=\"48%\",float=\"right\")}\n-=Manual Setup using Admin Panel=-\n!![tiki-admin.php|Get Started using Admin Panel]\n__Who Should Use This__\n*You are familiar with software Admin Panels\n*You enjoy exploring and playing with many options\n*You already know Tiki\n\n{DIV}{DIV(width=\"48%\",float=\"left\")}\n-=Easy Setup using Profiles=-\n!![tiki-admin.php?profile=&categories%5B%5D=6.x&categories%5B%5D=Featured+profiles&repository=http%3a%2f%2fprofiles.tiki.org%2fprofiles&page=profiles&preloadlist=y&list=List#step2|Get Started using Profiles]\n__Who Should Use This__\n*You want to get started quickly\n*You don\'t feel like learning the Admin Panel right away\n*You want to quickly test out some of Tiki\'s Features\n\n!!Featured Profiles\n\n__Collaborative Community__ ([tiki-admin.php?profile=&categories%5B%5D=6.x&categories%5B%5D=Featured+profiles&repository=http%3a%2f%2fprofiles.tiki.org%2fprofiles&page=profiles&preloadlist=y&list=List#step2|apply profile now])\nSetup to help subject experts and enthusiasts work together to build a Knowledge Base\n*Wiki Editing\n*Personal Member Spaces\n*Forums\n*Blogs\n\n__Personal Blog and Profile__ ([tiki-admin.php?profile=&categories%5B%5D=6.x&categories%5B%5D=Featured+profiles&repository=http%3a%2f%2fprofiles.tiki.org%2fprofiles&page=profiles&preloadlist=y&list=List#step2|apply profile now])\nSetup with many cool features to help you integrate the Social Web and establish a strong presence in the Blogosphere\n*Blog (Full set of blog related features)\n*Image Gallery\n*RSS Integration\n*Video Log\n\n__Company Intranet__ ([tiki-admin.php?profile=&categories%5B%5D=6.x&categories%5B%5D=Featured+profiles&repository=http%3a%2f%2fprofiles.tiki.org%2fprofiles&page=profiles&preloadlist=y&list=List#step2|apply profile now])\nSetup for a Corporate Intranet of a typical medium-sized business.\n*Company News Articles\n*Executive Blog\n*File Repository & Management\n*Collaborative Wiki\n\n__Small Organization Web Presence__ ([tiki-admin.php?profile=&categories%5B%5D=6.x&categories%5B%5D=Featured+profiles&repository=http%3a%2f%2fprofiles.tiki.org%2fprofiles&page=profiles&preloadlist=y&list=List#step2|apply profile now])\nSetup for a Web Presence of a typical small business or non-profit.\n*Company News & Updates\n*Highlight Company\'s Products and Services\n*File Gallery (great for Media Kit)\n*Contact Form\n\n{DIV}{ELSE}\n\n!Congratulations\nThis is the default homepage for your Tiki. If you are seeing this page, your installation was successful.\n\nYou can change this page after logging in. Please review the [http://doc.tiki.org/wiki+syntax|wiki syntax] for editing details.\n\n\n!!{img src=pics/icons/star.png alt=\"Star\"} Get started.\nTo begin configuring your site:\n{FANCYLIST()}\n1) Log in with your newly created password. \n2) Manually Enable specific Tiki features. \n3) Run Tiki Profiles to quickly get up and running \n{FANCYLIST}\n\n!!{img src=pics/icons/help.png alt=\"Help\"} Need help?\nFor more information:\n*[http://info.tiki.org/Learn+More|Learn more about Tiki].\n*[http://info.tiki.org/Help+Others|Get help], including the [http://doc.tiki.org|official documentation] and [http://tiki.org/forums|support forums].\n*[http://info.tiki.org/Join+the+community|Join the Tiki community].\n{GROUP}','',1305469961,'Tiki initialization',1,0,'admin','0.0.0.0','',NULL,NULL,NULL,NULL,NULL,NULL,'admin',3630,'en','',0,1305469961,'n','',NULL,NULL);
/*!40000 ALTER TABLE `tiki_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_pages_changes`
--

DROP TABLE IF EXISTS `tiki_pages_changes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_pages_changes` (
  `page_id` int(14) NOT NULL DEFAULT '0',
  `version` int(10) NOT NULL DEFAULT '0',
  `segments_added` int(10) DEFAULT NULL,
  `segments_removed` int(10) DEFAULT NULL,
  `segments_total` int(10) DEFAULT NULL,
  PRIMARY KEY (`page_id`,`version`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_pages_changes`
--

LOCK TABLES `tiki_pages_changes` WRITE;
/*!40000 ALTER TABLE `tiki_pages_changes` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_pages_changes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_pages_translation_bits`
--

DROP TABLE IF EXISTS `tiki_pages_translation_bits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_pages_translation_bits` (
  `translation_bit_id` int(14) NOT NULL AUTO_INCREMENT,
  `page_id` int(14) NOT NULL,
  `version` int(8) NOT NULL,
  `source_translation_bit` int(10) DEFAULT NULL,
  `original_translation_bit` int(10) DEFAULT NULL,
  `flags` set('critical') DEFAULT '',
  PRIMARY KEY (`translation_bit_id`),
  KEY `page_id` (`page_id`),
  KEY `original_translation_bit` (`original_translation_bit`),
  KEY `source_translation_bit` (`source_translation_bit`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_pages_translation_bits`
--

LOCK TABLES `tiki_pages_translation_bits` WRITE;
/*!40000 ALTER TABLE `tiki_pages_translation_bits` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_pages_translation_bits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_pageviews`
--

DROP TABLE IF EXISTS `tiki_pageviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_pageviews` (
  `day` int(14) NOT NULL DEFAULT '0',
  `pageviews` int(14) DEFAULT NULL,
  PRIMARY KEY (`day`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_pageviews`
--

LOCK TABLES `tiki_pageviews` WRITE;
/*!40000 ALTER TABLE `tiki_pageviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_pageviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_payment_received`
--

DROP TABLE IF EXISTS `tiki_payment_received`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_payment_received` (
  `paymentReceivedId` int(11) NOT NULL AUTO_INCREMENT,
  `paymentRequestId` int(11) NOT NULL,
  `payment_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `amount` decimal(7,2) DEFAULT NULL,
  `type` varchar(15) DEFAULT NULL,
  `details` text,
  `userId` int(8) DEFAULT NULL,
  PRIMARY KEY (`paymentReceivedId`),
  KEY `payment_request_ix` (`paymentRequestId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_payment_received`
--

LOCK TABLES `tiki_payment_received` WRITE;
/*!40000 ALTER TABLE `tiki_payment_received` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_payment_received` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_payment_requests`
--

DROP TABLE IF EXISTS `tiki_payment_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_payment_requests` (
  `paymentRequestId` int(11) NOT NULL AUTO_INCREMENT,
  `amount` decimal(7,2) NOT NULL,
  `amount_paid` decimal(7,2) NOT NULL DEFAULT '0.00',
  `currency` char(3) NOT NULL,
  `request_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `due_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `cancel_date` timestamp NULL DEFAULT NULL,
  `description` varchar(100) NOT NULL,
  `actions` text,
  `detail` text,
  `userId` int(8) DEFAULT NULL,
  PRIMARY KEY (`paymentRequestId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_payment_requests`
--

LOCK TABLES `tiki_payment_requests` WRITE;
/*!40000 ALTER TABLE `tiki_payment_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_payment_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_perspective_preferences`
--

DROP TABLE IF EXISTS `tiki_perspective_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_perspective_preferences` (
  `perspectiveId` int(11) NOT NULL,
  `pref` varchar(40) NOT NULL,
  `value` text,
  PRIMARY KEY (`perspectiveId`,`pref`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_perspective_preferences`
--

LOCK TABLES `tiki_perspective_preferences` WRITE;
/*!40000 ALTER TABLE `tiki_perspective_preferences` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_perspective_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_perspectives`
--

DROP TABLE IF EXISTS `tiki_perspectives`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_perspectives` (
  `perspectiveId` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`perspectiveId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_perspectives`
--

LOCK TABLES `tiki_perspectives` WRITE;
/*!40000 ALTER TABLE `tiki_perspectives` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_perspectives` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_plugin_security`
--

DROP TABLE IF EXISTS `tiki_plugin_security`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_plugin_security` (
  `fingerprint` varchar(200) NOT NULL,
  `status` varchar(10) NOT NULL,
  `added_by` varchar(200) DEFAULT NULL,
  `approval_by` varchar(200) DEFAULT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_objectType` varchar(20) NOT NULL,
  `last_objectId` varchar(200) NOT NULL,
  PRIMARY KEY (`fingerprint`),
  KEY `last_object` (`last_objectType`,`last_objectId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_plugin_security`
--

LOCK TABLES `tiki_plugin_security` WRITE;
/*!40000 ALTER TABLE `tiki_plugin_security` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_plugin_security` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_poll_objects`
--

DROP TABLE IF EXISTS `tiki_poll_objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_poll_objects` (
  `catObjectId` int(11) NOT NULL DEFAULT '0',
  `pollId` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`catObjectId`,`pollId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_poll_objects`
--

LOCK TABLES `tiki_poll_objects` WRITE;
/*!40000 ALTER TABLE `tiki_poll_objects` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_poll_objects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_poll_options`
--

DROP TABLE IF EXISTS `tiki_poll_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_poll_options` (
  `pollId` int(8) NOT NULL DEFAULT '0',
  `optionId` int(8) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) DEFAULT NULL,
  `position` int(4) NOT NULL DEFAULT '0',
  `votes` int(8) DEFAULT NULL,
  PRIMARY KEY (`optionId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_poll_options`
--

LOCK TABLES `tiki_poll_options` WRITE;
/*!40000 ALTER TABLE `tiki_poll_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_poll_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_poll_votes`
--

DROP TABLE IF EXISTS `tiki_poll_votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_poll_votes` (
  `pollId` int(11) NOT NULL,
  `optionId` int(11) NOT NULL,
  `voteId` int(11) NOT NULL AUTO_INCREMENT,
  `identification` varchar(300) NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`voteId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_poll_votes`
--

LOCK TABLES `tiki_poll_votes` WRITE;
/*!40000 ALTER TABLE `tiki_poll_votes` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_poll_votes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_polls`
--

DROP TABLE IF EXISTS `tiki_polls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_polls` (
  `pollId` int(8) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) DEFAULT NULL,
  `votes` int(8) DEFAULT NULL,
  `active` char(1) DEFAULT NULL,
  `publishDate` int(14) DEFAULT NULL,
  `voteConsiderationSpan` int(4) DEFAULT '0',
  `anonym` enum('a','u','i','c') NOT NULL DEFAULT 'u',
  PRIMARY KEY (`pollId`),
  KEY `tiki_poll_lookup` (`active`,`title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_polls`
--

LOCK TABLES `tiki_polls` WRITE;
/*!40000 ALTER TABLE `tiki_polls` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_polls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_preferences`
--

DROP TABLE IF EXISTS `tiki_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_preferences` (
  `name` varchar(40) NOT NULL DEFAULT '',
  `value` text,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_preferences`
--

LOCK TABLES `tiki_preferences` WRITE;
/*!40000 ALTER TABLE `tiki_preferences` DISABLE KEYS */;
INSERT INTO `tiki_preferences` VALUES ('browsertitle','switched on pbx'),('sender_email','info@switchedonpbx.org'),('https_login','encouraged'),('https_port','443'),('error_reporting_level','0'),('error_reporting_adminonly','n'),('smarty_notice_reporting','n'),('log_tpl','n'),('feature_switch_ssl_mode','n'),('feature_show_stay_in_ssl_mode','y'),('language','en'),('lastUpdatePrefs','3'),('case_patched','y');
/*!40000 ALTER TABLE `tiki_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_private_messages`
--

DROP TABLE IF EXISTS `tiki_private_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_private_messages` (
  `messageId` int(8) NOT NULL AUTO_INCREMENT,
  `toNickname` varchar(200) NOT NULL DEFAULT '',
  `poster` varchar(200) NOT NULL DEFAULT 'anonymous',
  `timestamp` int(14) DEFAULT NULL,
  `received` tinyint(1) NOT NULL DEFAULT '0',
  `message` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`messageId`),
  KEY `received` (`received`),
  KEY `timestamp` (`timestamp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_private_messages`
--

LOCK TABLES `tiki_private_messages` WRITE;
/*!40000 ALTER TABLE `tiki_private_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_private_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_profile_symbols`
--

DROP TABLE IF EXISTS `tiki_profile_symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_profile_symbols` (
  `domain` varchar(50) NOT NULL,
  `profile` varchar(100) NOT NULL,
  `object` varchar(150) NOT NULL,
  `type` varchar(20) NOT NULL,
  `value` varchar(50) NOT NULL,
  `named` enum('y','n') NOT NULL,
  `creation_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`domain`,`profile`,`object`),
  KEY `named` (`named`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_profile_symbols`
--

LOCK TABLES `tiki_profile_symbols` WRITE;
/*!40000 ALTER TABLE `tiki_profile_symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_profile_symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_programmed_content`
--

DROP TABLE IF EXISTS `tiki_programmed_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_programmed_content` (
  `pId` int(8) NOT NULL AUTO_INCREMENT,
  `contentId` int(8) NOT NULL DEFAULT '0',
  `content_type` varchar(20) NOT NULL DEFAULT 'static',
  `publishDate` int(14) NOT NULL DEFAULT '0',
  `data` text,
  PRIMARY KEY (`pId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_programmed_content`
--

LOCK TABLES `tiki_programmed_content` WRITE;
/*!40000 ALTER TABLE `tiki_programmed_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_programmed_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_quiz_question_options`
--

DROP TABLE IF EXISTS `tiki_quiz_question_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_quiz_question_options` (
  `optionId` int(10) NOT NULL AUTO_INCREMENT,
  `questionId` int(10) DEFAULT NULL,
  `optionText` text,
  `points` int(4) DEFAULT NULL,
  PRIMARY KEY (`optionId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_quiz_question_options`
--

LOCK TABLES `tiki_quiz_question_options` WRITE;
/*!40000 ALTER TABLE `tiki_quiz_question_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_quiz_question_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_quiz_questions`
--

DROP TABLE IF EXISTS `tiki_quiz_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_quiz_questions` (
  `questionId` int(10) NOT NULL AUTO_INCREMENT,
  `quizId` int(10) DEFAULT NULL,
  `question` text,
  `position` int(4) DEFAULT NULL,
  `type` char(1) DEFAULT NULL,
  `maxPoints` int(4) DEFAULT NULL,
  PRIMARY KEY (`questionId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_quiz_questions`
--

LOCK TABLES `tiki_quiz_questions` WRITE;
/*!40000 ALTER TABLE `tiki_quiz_questions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_quiz_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_quiz_results`
--

DROP TABLE IF EXISTS `tiki_quiz_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_quiz_results` (
  `resultId` int(10) NOT NULL AUTO_INCREMENT,
  `quizId` int(10) DEFAULT NULL,
  `fromPoints` int(4) DEFAULT NULL,
  `toPoints` int(4) DEFAULT NULL,
  `answer` text,
  PRIMARY KEY (`resultId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_quiz_results`
--

LOCK TABLES `tiki_quiz_results` WRITE;
/*!40000 ALTER TABLE `tiki_quiz_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_quiz_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_quiz_stats`
--

DROP TABLE IF EXISTS `tiki_quiz_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_quiz_stats` (
  `quizId` int(10) NOT NULL DEFAULT '0',
  `questionId` int(10) NOT NULL DEFAULT '0',
  `optionId` int(10) NOT NULL DEFAULT '0',
  `votes` int(10) DEFAULT NULL,
  PRIMARY KEY (`quizId`,`questionId`,`optionId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_quiz_stats`
--

LOCK TABLES `tiki_quiz_stats` WRITE;
/*!40000 ALTER TABLE `tiki_quiz_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_quiz_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_quiz_stats_sum`
--

DROP TABLE IF EXISTS `tiki_quiz_stats_sum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_quiz_stats_sum` (
  `quizId` int(10) NOT NULL DEFAULT '0',
  `quizName` varchar(255) DEFAULT NULL,
  `timesTaken` int(10) DEFAULT NULL,
  `avgpoints` decimal(5,2) DEFAULT NULL,
  `avgavg` decimal(5,2) DEFAULT NULL,
  `avgtime` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`quizId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_quiz_stats_sum`
--

LOCK TABLES `tiki_quiz_stats_sum` WRITE;
/*!40000 ALTER TABLE `tiki_quiz_stats_sum` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_quiz_stats_sum` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_quizzes`
--

DROP TABLE IF EXISTS `tiki_quizzes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_quizzes` (
  `quizId` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `canRepeat` char(1) DEFAULT NULL,
  `storeResults` char(1) DEFAULT NULL,
  `questionsPerPage` int(4) DEFAULT NULL,
  `timeLimited` char(1) DEFAULT NULL,
  `timeLimit` int(14) DEFAULT NULL,
  `created` int(14) DEFAULT NULL,
  `taken` int(10) DEFAULT NULL,
  `immediateFeedback` char(1) DEFAULT NULL,
  `showAnswers` char(1) DEFAULT NULL,
  `shuffleQuestions` char(1) DEFAULT NULL,
  `shuffleAnswers` char(1) DEFAULT NULL,
  `publishDate` int(14) DEFAULT NULL,
  `expireDate` int(14) DEFAULT NULL,
  `bDeleted` char(1) DEFAULT NULL,
  `nAuthor` int(4) DEFAULT NULL,
  `bOnline` char(1) DEFAULT NULL,
  `bRandomQuestions` char(1) DEFAULT NULL,
  `nRandomQuestions` tinyint(4) DEFAULT NULL,
  `bLimitQuestionsPerPage` char(1) DEFAULT NULL,
  `nLimitQuestionsPerPage` tinyint(4) DEFAULT NULL,
  `bMultiSession` char(1) DEFAULT NULL,
  `nCanRepeat` tinyint(4) DEFAULT NULL,
  `sGradingMethod` varchar(80) DEFAULT NULL,
  `sShowScore` varchar(80) DEFAULT NULL,
  `sShowCorrectAnswers` varchar(80) DEFAULT NULL,
  `sPublishStats` varchar(80) DEFAULT NULL,
  `bAdditionalQuestions` char(1) DEFAULT NULL,
  `bForum` char(1) DEFAULT NULL,
  `sForum` varchar(80) DEFAULT NULL,
  `sPrologue` text,
  `sData` text,
  `sEpilogue` text,
  `passingperct` int(4) DEFAULT '0',
  PRIMARY KEY (`quizId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_quizzes`
--

LOCK TABLES `tiki_quizzes` WRITE;
/*!40000 ALTER TABLE `tiki_quizzes` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_quizzes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_rating_configs`
--

DROP TABLE IF EXISTS `tiki_rating_configs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_rating_configs` (
  `ratingConfigId` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `expiry` int(11) NOT NULL DEFAULT '3600',
  `formula` text NOT NULL,
  `callbacks` text,
  PRIMARY KEY (`ratingConfigId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_rating_configs`
--

LOCK TABLES `tiki_rating_configs` WRITE;
/*!40000 ALTER TABLE `tiki_rating_configs` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_rating_configs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_rating_obtained`
--

DROP TABLE IF EXISTS `tiki_rating_obtained`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_rating_obtained` (
  `ratingId` int(11) NOT NULL AUTO_INCREMENT,
  `ratingConfigId` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `object` int(11) NOT NULL,
  `expire` int(11) NOT NULL,
  `value` float NOT NULL,
  PRIMARY KEY (`ratingId`),
  UNIQUE KEY `tiki_obtained_rating_uq` (`type`,`object`,`ratingConfigId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_rating_obtained`
--

LOCK TABLES `tiki_rating_obtained` WRITE;
/*!40000 ALTER TABLE `tiki_rating_obtained` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_rating_obtained` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_received_articles`
--

DROP TABLE IF EXISTS `tiki_received_articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_received_articles` (
  `receivedArticleId` int(14) NOT NULL AUTO_INCREMENT,
  `receivedFromSite` varchar(200) DEFAULT NULL,
  `receivedFromUser` varchar(200) DEFAULT NULL,
  `receivedDate` int(14) DEFAULT NULL,
  `title` varchar(80) DEFAULT NULL,
  `authorName` varchar(60) DEFAULT NULL,
  `size` int(12) DEFAULT NULL,
  `useImage` char(1) DEFAULT NULL,
  `image_name` varchar(80) DEFAULT NULL,
  `image_type` varchar(80) DEFAULT NULL,
  `image_size` int(14) DEFAULT NULL,
  `image_x` int(4) DEFAULT NULL,
  `image_y` int(4) DEFAULT NULL,
  `image_data` longblob,
  `publishDate` int(14) DEFAULT NULL,
  `expireDate` int(14) DEFAULT NULL,
  `created` int(14) DEFAULT NULL,
  `heading` text,
  `body` longblob,
  `hash` varchar(32) DEFAULT NULL,
  `author` varchar(200) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `rating` decimal(3,2) DEFAULT NULL,
  PRIMARY KEY (`receivedArticleId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_received_articles`
--

LOCK TABLES `tiki_received_articles` WRITE;
/*!40000 ALTER TABLE `tiki_received_articles` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_received_articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_received_pages`
--

DROP TABLE IF EXISTS `tiki_received_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_received_pages` (
  `receivedPageId` int(14) NOT NULL AUTO_INCREMENT,
  `pageName` varchar(160) NOT NULL DEFAULT '',
  `data` longblob,
  `description` varchar(200) DEFAULT NULL,
  `comment` varchar(200) DEFAULT NULL,
  `receivedFromSite` varchar(200) DEFAULT NULL,
  `receivedFromUser` varchar(200) DEFAULT NULL,
  `receivedDate` int(14) DEFAULT NULL,
  `parent` varchar(255) DEFAULT NULL,
  `position` tinyint(3) unsigned DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `structureName` varchar(250) DEFAULT NULL,
  `parentName` varchar(250) DEFAULT NULL,
  `page_alias` varchar(250) DEFAULT '',
  `pos` int(4) DEFAULT NULL,
  PRIMARY KEY (`receivedPageId`),
  KEY `structureName` (`structureName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_received_pages`
--

LOCK TABLES `tiki_received_pages` WRITE;
/*!40000 ALTER TABLE `tiki_received_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_received_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_referer_stats`
--

DROP TABLE IF EXISTS `tiki_referer_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_referer_stats` (
  `referer` varchar(255) NOT NULL DEFAULT '',
  `hits` int(10) DEFAULT NULL,
  `last` int(14) DEFAULT NULL,
  PRIMARY KEY (`referer`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_referer_stats`
--

LOCK TABLES `tiki_referer_stats` WRITE;
/*!40000 ALTER TABLE `tiki_referer_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_referer_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_registration_fields`
--

DROP TABLE IF EXISTS `tiki_registration_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_registration_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'text',
  `show` tinyint(1) NOT NULL DEFAULT '1',
  `size` varchar(10) DEFAULT '10',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_registration_fields`
--

LOCK TABLES `tiki_registration_fields` WRITE;
/*!40000 ALTER TABLE `tiki_registration_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_registration_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_related_categories`
--

DROP TABLE IF EXISTS `tiki_related_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_related_categories` (
  `categId` int(10) NOT NULL DEFAULT '0',
  `relatedTo` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`categId`,`relatedTo`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_related_categories`
--

LOCK TABLES `tiki_related_categories` WRITE;
/*!40000 ALTER TABLE `tiki_related_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_related_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_rss_feeds`
--

DROP TABLE IF EXISTS `tiki_rss_feeds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_rss_feeds` (
  `name` varchar(60) NOT NULL DEFAULT '',
  `rssVer` char(1) NOT NULL DEFAULT '1',
  `refresh` int(8) DEFAULT '300',
  `lastUpdated` int(14) DEFAULT NULL,
  `cache` longblob,
  PRIMARY KEY (`name`,`rssVer`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_rss_feeds`
--

LOCK TABLES `tiki_rss_feeds` WRITE;
/*!40000 ALTER TABLE `tiki_rss_feeds` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_rss_feeds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_rss_items`
--

DROP TABLE IF EXISTS `tiki_rss_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_rss_items` (
  `rssItemId` int(11) NOT NULL AUTO_INCREMENT,
  `rssId` int(11) NOT NULL,
  `guid` varchar(255) NOT NULL,
  `url` text NOT NULL,
  `publication_date` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) DEFAULT NULL,
  `description` text,
  `content` text,
  PRIMARY KEY (`rssItemId`),
  UNIQUE KEY `tiki_rss_items_item` (`rssId`,`guid`),
  KEY `tiki_rss_items_rss` (`rssId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_rss_items`
--

LOCK TABLES `tiki_rss_items` WRITE;
/*!40000 ALTER TABLE `tiki_rss_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_rss_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_rss_modules`
--

DROP TABLE IF EXISTS `tiki_rss_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_rss_modules` (
  `rssId` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `description` text,
  `url` varchar(255) NOT NULL DEFAULT '',
  `refresh` int(8) DEFAULT NULL,
  `lastUpdated` int(14) DEFAULT NULL,
  `showTitle` char(1) DEFAULT 'n',
  `showPubDate` char(1) DEFAULT 'n',
  `sitetitle` varchar(255) DEFAULT NULL,
  `siteurl` varchar(255) DEFAULT NULL,
  `actions` text,
  PRIMARY KEY (`rssId`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_rss_modules`
--

LOCK TABLES `tiki_rss_modules` WRITE;
/*!40000 ALTER TABLE `tiki_rss_modules` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_rss_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_schema`
--

DROP TABLE IF EXISTS `tiki_schema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_schema` (
  `patch_name` varchar(100) NOT NULL,
  `install_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`patch_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_schema`
--

LOCK TABLES `tiki_schema` WRITE;
/*!40000 ALTER TABLE `tiki_schema` DISABLE KEYS */;
INSERT INTO `tiki_schema` VALUES ('00000000_schema_change_tiki','2011-05-15 14:29:57'),('20060116_showlastDownLoad_tiki','2011-05-15 14:29:57'),('20080227_invite_tiki','2011-05-15 14:29:57'),('20080809_semlinks_tiki','2011-05-15 14:29:57'),('20080827_bigfeaturetype_tiki','2011-05-15 14:29:57'),('20080829_pagealiasdata_tiki','2011-05-15 14:29:57'),('20080829_pluginvalidation_tiki','2011-05-15 14:29:57'),('20080901_pluginvalidation_tiki','2011-05-15 14:29:57'),('20080902_trackerparsedesc_tiki','2011-05-15 14:29:57'),('20080905_feature_tip_tiki','2011-05-15 14:29:57'),('20080916_webservice_registry_tiki','2011-05-15 14:29:57'),('20080922_calendar_customstatus_tiki','2011-05-15 14:29:57'),('20080924_webmail_tiki','2011-05-15 14:29:57'),('20080926_bannerindex_tiki','2011-05-15 14:29:57'),('20081004_mindmap_menu_tiki','2011-05-15 14:29:57'),('20081006_comments_moderation_tiki','2011-05-15 14:29:57'),('20081008_bit_flags_nullable_tiki','2011-05-15 14:29:57'),('20081010_filter_perms_tiki','2011-05-15 14:29:57'),('20081014_trust_input_perm_tiki','2011-05-15 14:29:57'),('20081018_filter_perms_tiki','2011-05-15 14:29:57'),('20081019_score_tiki','2011-05-15 14:29:57'),('20081022_application_menu_tiki','2011-05-15 14:29:57'),('20081024_fulltext_file_tiki','2011-05-15 14:29:57'),('20081027_calendar_tiki','2011-05-15 14:29:57'),('20081027_file_galleries_tiki','2011-05-15 14:29:57'),('20081027_groupalert_tiki','2011-05-15 14:29:57'),('20081027_surveys_tiki','2011-05-15 14:29:57'),('20081027_trackers_tiki','2011-05-15 14:29:57'),('20081027_wysiwyg_history_tiki','2011-05-15 14:29:57'),('20081029_tracker_index_tiki','2011-05-15 14:29:57'),('20081102_application_menu_structures_tiki','2011-05-15 14:29:57'),('20081105_calendar_items_allday_tiki','2011-05-15 14:29:57'),('20081107_menu42_tiki','2011-05-15 14:29:57'),('20081112_tiki_p_tracker_view_comments_tiki','2011-05-15 14:29:57'),('20081114_tiki_banner_tiki','2011-05-15 14:29:57'),('20081119_tiki_p_export_tracker_tiki','2011-05-15 14:29:57'),('20081120_showCategories_tiki','2011-05-15 14:29:57'),('20081120_tiki_poll_structures_update_tiki','2011-05-15 14:29:57'),('20081125_tiki_tracker_types_tiki','2011-05-15 14:29:57'),('20081127_calendar_recurrence_tiki','2011-05-15 14:29:57'),('20081130_tiki_users_permission_tiki','2011-05-15 14:29:57'),('20081211_newsletter_files_tiki','2011-05-15 14:29:57'),('20081211_score_tiki','2011-05-15 14:29:57'),('20081212_tiki_p_view_backlinks_tiki','2011-05-15 14:29:57'),('20081214_webservice_post_tiki','2011-05-15 14:29:57'),('20090106_group_watch_tiki','2011-05-15 14:29:57'),('20090120_sefurl_rules_tiki','2011-05-15 14:29:57'),('20090129_callendar_search_tiki','2011-05-15 14:29:57'),('20090203_null_tiki','2011-05-15 14:29:57'),('20090205_forum_and_comments_locking_tiki','2011-05-15 14:29:57'),('20090205_menucase_tiki','2011-05-15 14:29:57'),('20090205_menus_items_icons_tiki','2011-05-15 14:29:57'),('20090206_content_tpl_menu_tiki','2011-05-15 14:29:57'),('20090206_poll_tiki','2011-05-15 14:29:57'),('20090211_mailnotification_tiki','2011-05-15 14:29:57'),('20090212_forum_tiki','2011-05-15 14:29:57'),('20090220_admin_section_tiki','2011-05-15 14:29:57'),('20090226_admin_menu_tiki','2011-05-15 14:29:57'),('20090301_browsertitle_tiki','2011-05-15 14:29:57'),('20090304_tiki_p_view_backlink_without_s_tiki','2011-05-15 14:29:57'),('20090306_menu_perms_tiki','2011-05-15 14:29:57'),('20090306_text_for_menu_options_tiki','2011-05-15 14:29:57'),('20090310_application_menu_tiki','2011-05-15 14:29:57'),('20090310_feature_search_show_object_filter_tiki','2011-05-15 14:29:57'),('20090311_remove_mod_menu_application_menu_tiki','2011-05-15 14:29:57'),('20090316_index_tiki','2011-05-15 14:29:57'),('20090323_maxUserImpressions_banners_tiki','2011-05-15 14:29:57'),('20090330_quicktags_renames_tiki','2011-05-15 14:29:57'),('20090401_newsletters_included_tiki','2011-05-15 14:29:57'),('20090401_replace_shoutjax_with_shoutbox_tiki','2011-05-15 14:29:57'),('20090401_replace_switch_lang2_with_switch_lang_tiki','2011-05-15 14:29:57'),('20090416_plugin_security_tiki','2011-05-15 14:29:57'),('20090416_quicktags_kil_email_tiki','2011-05-15 14:29:57'),('20090416_quicktags_plugin_helpers_tiki','2011-05-15 14:29:57'),('20090427_filegal_optionalize_tiki','2011-05-15 14:29:57'),('20090429_groupId_tiki','2011-05-15 14:29:57'),('20090513_calendar_priority_tiki','2011-05-15 14:29:57'),('20090513_swffix_tiki','2011-05-15 14:29:57'),('20090513_wiki_similar_permission_tiki','2011-05-15 14:29:57'),('20090515_score_tiki','2011-05-15 14:29:57'),('20090602_webmail_protocols_tiki','2011-05-15 14:29:57'),('20090605_tiki_p_modify_tracker_items_pending_closed_tiki','2011-05-15 14:29:57'),('20090617_add_new_table_for_reports_tiki','2011-05-15 14:29:57'),('20090623_actionlog_view_article_tiki','2011-05-15 14:29:57'),('20090626_change_pear_auth_preferences_to_ldap_tiki','2011-05-15 14:29:57'),('20090707_tiki_p_delete_account_tiki','2011-05-15 14:29:57'),('20090713_tiki_importer_permission_and_menu_entry_tiki','2011-05-15 14:29:57'),('20090715_sefurl_for_filegalleries_tiki','2011-05-15 14:29:57'),('20090720_perspectives_tiki','2011-05-15 14:29:57'),('20090721_webmail_ext_public_tiki','2011-05-15 14:29:57'),('20090727_category_permissions_tiki','2011-05-15 14:29:57'),('20090727_user_votings_index_tiki','2011-05-15 14:29:57'),('20090730_p_list_newsletters_tiki','2011-05-15 14:29:57'),('20090803_perspective_permission_tiki','2011-05-15 14:29:57'),('20090804_kaltura_permissions_tiki','2011-05-15 14:29:57'),('20090804_menu_search_tiki','2011-05-15 14:29:57'),('20090805_kill_newsreader_tiki','2011-05-15 14:29:57'),('20090805_remove_drawings_prefs_etc_tiki','2011-05-15 14:29:57'),('20090805_remove_games_tiki','2011-05-15 14:29:57'),('20090806_group_permissions_tiki','2011-05-15 14:29:57'),('20090806_menu_list_trackers_tiki','2011-05-15 14:29:57'),('20090806_perms_featurechecks_tiki','2011-05-15 14:29:57'),('20090806_remove_charts_tiki','2011-05-15 14:29:57'),('20090806_remove_latin_collations_tiki','2011-05-15 14:29:57'),('20090806_strasa_option_rename_tiki','2011-05-15 14:29:57'),('20090807_transitions_tiki','2011-05-15 14:29:57'),('20090808_add_wiki_minor_edits_tiki','2011-05-15 14:29:57'),('20090809_marc_needs_more_space_tiki','2011-05-15 14:29:57'),('20090811_filegals_container_tiki','2011-05-15 14:29:57'),('20090811_kaltura_editor_pref_tiki','2011-05-15 14:29:57'),('20090811_quizzes_tiki','2011-05-15 14:29:57'),('20090811_rename_quicktags_to_toolbars_tiki','2011-05-15 14:29:57'),('20090823_kaltura_menu_options_tiki','2011-05-15 14:29:57'),('20090826_group_expiration_tiki','2011-05-15 14:29:57'),('20090904_wysiwyg_newsletters_tiki','2011-05-15 14:29:57'),('20090911_tracker_item_change_user_tiki','2011-05-15 14:29:57'),('20090912_change_feature_name_for_lesser_magic_tiki','2011-05-15 14:29:57'),('20090913_plugin_security_addedby_tiki','2011-05-15 14:29:57'),('20090915_change_perms_for_browse_cats_tiki','2011-05-15 14:29:57'),('20090921_logo_tiki','2011-05-15 14:29:57'),('20090921_workspaces_tiki','2011-05-15 14:29:57'),('20090923_mod_change_category_defaults_tiki','2011-05-15 14:29:57'),('20090925_online_logged_users_modules_merge_tiki','2011-05-15 14:29:57'),('20090927_top_images_modules_merge_tiki','2011-05-15 14:29:57'),('20090928_galaxia_leftovers_tiki','2011-05-15 14:29:57'),('20090928_last_images_modules_merge_tiki','2011-05-15 14:29:57'),('20090928_transition_guards_text_tiki','2011-05-15 14:29:57'),('20091004_last_tracker_items_modules_merge_tiki','2011-05-15 14:29:57'),('20091007_update_database_structure_tiki','2011-05-15 14:29:57'),('20091008_reg_group_includes_anon_tiki','2011-05-15 14:29:57'),('20091011_serurl_dl_order_tiki','2011-05-15 14:29:57'),('20091013_fix_perms_tiki','2011-05-15 14:29:57'),('20091015_application_menu_admin_renames_tiki','2011-05-15 14:29:57'),('20091016_categorization_tracker_item_tiki','2011-05-15 14:29:57'),('20091019_article_by_rating_modules_merge_tiki','2011-05-15 14:29:57'),('20091019_last_articles_modules_merge_tiki','2011-05-15 14:29:57'),('20091019_users_perms_types_tidying_tiki','2011-05-15 14:29:57'),('20091020_bigger_user_prefs_tiki','2011-05-15 14:29:57'),('20091020_faq_created_tiki','2011-05-15 14:29:57'),('20091020_kaltura_tiki','2011-05-15 14:29:57'),('20091020_remove_charts_tiki','2011-05-15 14:29:57'),('20091020_sefurl_trackeritem_tiki','2011-05-15 14:29:57'),('20091021_moz_pagelist_tiki','2011-05-15 14:29:57'),('20091023_bookmarks_name_lengthen_tiki','2011-05-15 14:29:57'),('20091023_nul_categ_tiki','2011-05-15 14:29:57'),('20091023_report_tiki','2011-05-15 14:29:57'),('20091027_multiple_session_handler_tiki','2011-05-15 14:29:57'),('20091028_quota_tiki','2011-05-15 14:29:57'),('20091030_wiki_watch_tiki','2011-05-15 14:29:57'),('20091103_upgrade_categperm_tiki','2011-05-15 14:29:57'),('20091105_auth_tokens_tiki','2011-05-15 14:29:57'),('20091111_fgal_size_tiki','2011-05-15 14:29:57'),('20091112_rename_mnu_application_menu_tiki','2011-05-15 14:29:57'),('20091112_template_type_tiki','2011-05-15 14:29:57'),('20091113_old_categ_perm_tiki','2011-05-15 14:29:57'),('20091118_sefurl_tiki','2011-05-15 14:29:57'),('20091120_poll_lookup_index_tiki','2011-05-15 14:29:57'),('20091120_username_pattern_tiki','2011-05-15 14:29:57'),('20091123_dns_permission_tiki','2011-05-15 14:29:57'),('20091123_metrics_tiki','2011-05-15 14:29:57'),('20091123_upgrade_categperm_2_tiki','2011-05-15 14:29:57'),('20091124_fgal_backlink_tiki','2011-05-15 14:29:57'),('20091124_metrics_dsn_tiki','2011-05-15 14:29:57'),('20091125_wiki_comments_per_page_tiki','2011-05-15 14:29:57'),('20091126_dynamic_variables_i18n_tiki','2011-05-15 14:29:57'),('20091204_filegal_wiki_syntax_tiki','2011-05-15 14:29:57'),('20091204_tiki_p_view_newsletter_tiki','2011-05-15 14:29:57'),('20091208_backlink_perms_tiki','2011-05-15 14:29:57'),('20091209_rss_feeds_name_tiki','2011-05-15 14:29:57'),('20091210_charset_tiki','2011-05-15 14:29:57'),('20091210_dcs_type_tiki','2011-05-15 14:29:57'),('20091214_perspective_management_tiki','2011-05-15 14:29:57'),('20091216_show_backlinks_tiki','2011-05-15 14:29:57'),('20091228_page_keywords_tiki','2011-05-15 14:29:57'),('20100101_search_modules_merge_tiki','2011-05-15 14:29:57'),('20100101_search_wiki_page_modules_merge_tiki','2011-05-15 14:29:57'),('20100104_tiki_p_tracker_revote_ratings_tiki','2011-05-15 14:29:57'),('20100106_forum_att_list_nb_tiki','2011-05-15 14:29:57'),('20100107_payment_tiki','2011-05-15 14:29:57'),('20100113_forum_display_tiki','2011-05-15 14:29:57'),('20100114_tiki_actionlog_merge_tiki','2011-05-15 14:29:57'),('20100115_admin_modules_menu_tiki','2011-05-15 14:29:57'),('20100115_tiki_p_admin_modules_tiki','2011-05-15 14:29:57'),('20100115_translations_in_progress_tiki','2011-05-15 14:29:57'),('20100117_old_doc_tw_o_url_tiki','2011-05-15 14:29:57'),('20100118_blog_use_author_tiki','2011-05-15 14:29:57'),('20100118_forum_display_tiki','2011-05-15 14:29:57'),('20100126_file_lastDownload_tiki','2011-05-15 14:29:57'),('20100128_tiki_p_blog_view_ref_tiki','2011-05-15 14:29:57'),('20100129_clean_up_tiki','2011-05-15 14:29:57'),('20100129_events_kil_tiki','2011-05-15 14:29:57'),('20100203_payment_detail_tiki','2011-05-15 14:29:57'),('20100205_tiki_p_wiki_view_ref_tiki','2011-05-15 14:29:57'),('20100207_repair_file_galleries_tiki','2011-05-15 14:29:57'),('20100211_rss_items_tiki','2011-05-15 14:29:57'),('20100211_tiki_perms_menu_item_tiki','2011-05-15 14:29:57'),('20100211_tiki_sheet_add_parseValues_tiki','2011-05-15 14:29:57'),('20100212_rss_automation_tiki','2011-05-15 14:29:57'),('20100213_group_inclusion_key_tiki','2011-05-15 14:29:57'),('20100214_workspaces_remove_menu_items_tiki','2011-05-15 14:29:57'),('20100215_create_tiki_user_login_cookies_tiki','2011-05-15 14:29:57'),('20100215_rating_permissions_tiki','2011-05-15 14:29:57'),('20100216_attributes_tiki','2011-05-15 14:29:57'),('20100216_kil_moz_screencast_tiki','2011-05-15 14:29:57'),('20100216_rename_tikisheet_tiki','2011-05-15 14:29:57'),('20100217_rating_config_tiki','2011-05-15 14:29:57'),('20100218_auth_token_reuse_tiki','2011-05-15 14:29:57'),('20100222_add_webmail_fromEmail_field_tiki','2011-05-15 14:29:57'),('20100222_sheet_toolbar_default_tiki','2011-05-15 14:29:57'),('20100223_blog_always_owner_tiki','2011-05-15 14:29:57'),('20100224_object_relations_tiki','2011-05-15 14:29:57'),('20100226_menu_template_feature_check_tiki','2011-05-15 14:29:57'),('20100226_tracker_dump_perm_tiki','2011-05-15 14:29:57'),('20100302_filegal_images_max_sizes_tiki','2011-05-15 14:29:57'),('20100308_file_delete_after_tiki','2011-05-15 14:29:57'),('20100309_add_sheet_parent_tiki','2011-05-15 14:29:57'),('20100312_emailPattern_tiki','2011-05-15 14:29:57'),('20100324_newsletters_clippings_tiki','2011-05-15 14:29:57'),('20100409_bigger_module_params_tiki','2011-05-15 14:29:57'),('20100414_actionlog_pref_tiki','2011-05-15 14:29:57'),('20100414_actionlog_system_tiki','2011-05-15 14:29:57'),('20100419_bigbluebutton_tiki','2011-05-15 14:29:57'),('20100422_tracker_log_tiki','2011-05-15 14:29:57'),('20100429_newsletter_pages_tiki','2011-05-15 14:29:57'),('20100507_flash_banner_tiki','2011-05-15 14:29:57'),('20100519_actionlog_tiki','2011-05-15 14:29:57'),('20100525_tracker_validation_message_tiki','2011-05-15 14:29:57'),('20100525_tracker_validation_tiki','2011-05-15 14:29:57'),('20100611_rss_items_url_tiki','2011-05-15 14:29:57'),('20100617_sefurl_user_info_tiki','2011-05-15 14:29:57'),('20100618_calendar_participation_tiki','2011-05-15 14:29:57'),('20100621_pageprefixaliasdata_tiki','2011-05-15 14:29:57'),('20100622_pageprefixtrackeritemid_tiki','2011-05-15 14:29:57'),('20100623_semantic_to_relation_tiki','2011-05-15 14:29:57'),('20100624_banning_index_tiki','2011-05-15 14:29:57'),('20100628_payment_user_tiki','2011-05-15 14:29:57'),('20100629_remove_feature_blog_comments_tiki','2011-05-15 14:29:57'),('20100702_discount_tiki','2011-05-15 14:29:57'),('20100712_remove_unsupported_feed_formats_tiki','2011-05-15 14:29:57'),('20100713_rename_feed_prefs_tiki','2011-05-15 14:29:57'),('20100714_batch_transition_tiki','2011-05-15 14:29:57'),('20100716_user_selector_pref_rename_tiki','2011-05-15 14:29:57'),('20100720_tiki_p_view_page_contribution_tiki','2011-05-15 14:29:57'),('20100721_batch_transition_rollback_tiki','2011-05-15 14:29:57'),('20100721_todo_tiki','2011-05-15 14:29:57'),('20100721_todonotif_tiki','2011-05-15 14:29:57'),('20100727_tiki_p_promote_page_tiki','2011-05-15 14:29:57'),('20100730_list_image_article_tiki','2011-05-15 14:29:57'),('20100802_tiki_p_share_tiki','2011-05-15 14:29:57'),('20100802_url_shortener_tiki','2011-05-15 14:29:57'),('20100804_remove_tiki_languages_tiki','2011-05-15 14:29:57'),('20100806_blog_posts_header_tiki','2011-05-15 14:29:57'),('20100807_alter_tiki_translate_fields_to_text_tiki','2011-05-15 14:29:57'),('20100810_title_comments_upgrade_tiki','2011-05-15 14:29:57'),('20100812_blog_control_max_related_content_tiki','2011-05-15 14:29:57'),('20100812_blog_show_related_content_tiki','2011-05-15 14:29:57'),('20100817_add_email_and_website_fields_to_comments_tiki','2011-05-15 14:29:57'),('20100817_credits_tiki','2011-05-15 14:29:57'),('20100817_rename_preference_wiki_comments_notitle_tiki','2011-05-15 14:29:57'),('20100818_watch_tiki','2011-05-15 14:29:57'),('20100820_blog_posts_wysiwyg_tiki','2011-05-15 14:29:57'),('20100820_feed_fields_text_and_desc_are_not_empty_tiki','2011-05-15 14:29:57'),('20100824_blog_post_excerpt_tiki','2011-05-15 14:29:57'),('20100825_add_changed_column_to_tiki_language_table_tiki','2011-05-15 14:29:57'),('20100825_remove_blog_option_use_title_tiki','2011-05-15 14:29:57'),('20100830_sheet_add_styles_and_classes_tiki','2011-05-15 14:29:57'),('20100831_freetag_tiki','2011-05-15 14:29:57'),('20100901_duplic_actionlog_tiki','2011-05-15 14:29:57'),('20100901_expire_tiki','2011-05-15 14:29:57'),('20100902_invit_tiki','2011-05-15 14:29:57'),('20100903_article_ispublished_tiki','2011-05-15 14:29:57'),('20100906_sheet_toolbar_default_tiki','2011-05-15 14:29:57'),('20100909_alter_tiki_language_fields_to_text_tiki','2011-05-15 14:29:57'),('20100909_ckeditor_upgrade_tiki','2011-05-15 14:29:57'),('20100909_lengthen_wiki_attachments_filename_tiki','2011-05-15 14:29:57'),('20100910_new_fields_for_tiki_blogs_tiki','2011-05-15 14:29:57'),('20100912_rename_autosave_pref_tiki','2011-05-15 14:29:57'),('20100915_add_edit_languages_menu_option_tiki','2011-05-15 14:29:57'),('20100919_tiki_page_contribution_tiki','2011-05-15 14:29:57'),('20100920_ckeditor_remove_pref_tiki','2011-05-15 14:29:57'),('20100920_jq_sheet_remove_pref_tiki','2011-05-15 14:29:57'),('20100920_todo_event_tiki','2011-05-15 14:29:57'),('20100923_fix_column_position_tiki','2011-05-15 14:29:57'),('20100923_social_networking_permission_and_menuitem_tiki','2011-05-15 14:29:57'),('20100925_fix_some_default_value_tiki','2011-05-15 14:29:57'),('20100927_better_column_fix_tiki','2011-05-15 14:29:57'),('20100928_sefurl_regex_reordering_tiki','2011-05-15 14:29:57'),('20101015_tiki_admin_perms_tiki','2011-05-15 14:29:57'),('20101025_profile_sources_pref_tikiwiki_to_tiki','2011-05-15 14:29:57'),('20101027_rename_invit_to_invite_tiki','2011-05-15 14:29:57'),('20101028_p_invit_tiki','2011-05-15 14:29:57'),('20101203_fgal_archive_default_tiki','2011-05-15 14:29:57'),('20110104_sefurl_trackeritem_tiki','2011-05-15 14:29:57'),('99999999_image_plugins_kill_tiki','2011-05-15 14:29:57');
/*!40000 ALTER TABLE `tiki_schema` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_score`
--

DROP TABLE IF EXISTS `tiki_score`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_score` (
  `event` varchar(40) NOT NULL DEFAULT '',
  `score` int(11) NOT NULL DEFAULT '0',
  `expiration` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`event`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_score`
--

LOCK TABLES `tiki_score` WRITE;
/*!40000 ALTER TABLE `tiki_score` DISABLE KEYS */;
INSERT INTO `tiki_score` VALUES ('login',1,0),('login_remain',2,60),('profile_fill',10,0),('profile_see',2,0),('profile_is_seen',1,0),('friend_new',10,0),('message_receive',1,0),('message_send',2,0),('article_read',2,0),('article_comment',5,0),('article_new',20,0),('article_is_read',1,0),('article_is_commented',2,0),('fgallery_new',10,0),('fgallery_new_file',10,0),('fgallery_download',5,0),('fgallery_is_downloaded',5,0),('igallery_new',10,0),('igallery_new_img',6,0),('igallery_see_img',3,0),('igallery_img_seen',1,0),('blog_new',20,0),('blog_post',5,0),('blog_read',2,0),('blog_comment',2,0),('blog_is_read',3,0),('blog_is_commented',3,0),('wiki_new',10,0),('wiki_edit',5,0),('wiki_attach_file',3,0);
/*!40000 ALTER TABLE `tiki_score` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_search_stats`
--

DROP TABLE IF EXISTS `tiki_search_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_search_stats` (
  `term` varchar(50) NOT NULL DEFAULT '',
  `hits` int(10) DEFAULT NULL,
  PRIMARY KEY (`term`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_search_stats`
--

LOCK TABLES `tiki_search_stats` WRITE;
/*!40000 ALTER TABLE `tiki_search_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_search_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_searchindex`
--

DROP TABLE IF EXISTS `tiki_searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_searchindex` (
  `searchword` varchar(80) NOT NULL DEFAULT '',
  `location` varchar(80) NOT NULL DEFAULT '',
  `page` varchar(255) NOT NULL DEFAULT '',
  `count` int(11) NOT NULL DEFAULT '1',
  `last_update` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`searchword`,`location`,`page`(80)),
  KEY `last_update` (`last_update`),
  KEY `location` (`location`(50),`page`(200))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_searchindex`
--

LOCK TABLES `tiki_searchindex` WRITE;
/*!40000 ALTER TABLE `tiki_searchindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_searchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_searchsyllable`
--

DROP TABLE IF EXISTS `tiki_searchsyllable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_searchsyllable` (
  `syllable` varchar(80) NOT NULL DEFAULT '',
  `lastUsed` int(11) NOT NULL DEFAULT '0',
  `lastUpdated` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`syllable`),
  KEY `lastUsed` (`lastUsed`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_searchsyllable`
--

LOCK TABLES `tiki_searchsyllable` WRITE;
/*!40000 ALTER TABLE `tiki_searchsyllable` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_searchsyllable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_searchwords`
--

DROP TABLE IF EXISTS `tiki_searchwords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_searchwords` (
  `syllable` varchar(80) NOT NULL DEFAULT '',
  `searchword` varchar(80) NOT NULL DEFAULT '',
  PRIMARY KEY (`syllable`,`searchword`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_searchwords`
--

LOCK TABLES `tiki_searchwords` WRITE;
/*!40000 ALTER TABLE `tiki_searchwords` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_searchwords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_secdb`
--

DROP TABLE IF EXISTS `tiki_secdb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_secdb` (
  `md5_value` varchar(32) NOT NULL,
  `filename` varchar(250) NOT NULL,
  `tiki_version` varchar(60) NOT NULL,
  `severity` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`md5_value`,`filename`(100),`tiki_version`),
  KEY `sdb_fn` (`filename`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_secdb`
--

LOCK TABLES `tiki_secdb` WRITE;
/*!40000 ALTER TABLE `tiki_secdb` DISABLE KEYS */;
INSERT INTO `tiki_secdb` VALUES ('99820d0c38be9fe493fa228316ea6617','./about.php','6.3',0),('3aa1f2f29bbc103c931234aa715cef53','./antibot.php','6.3',0),('8fb35f083de4fdbe84fc602140ca89bc','./article_image.php','6.3',0),('8b662f5f9e441f0789314d6b6ff80027','./backups/index.php','6.3',0),('767d94e90c2cfdaef057e9c04c815d9d','./banner_click.php','6.3',0),('5177c739e7fdd40543b0cbacb75a0b69','./banner_image.php','6.3',0),('4538673b2b15afd8533c6155ca16474e','./categorize.php','6.3',0),('1c72883388568012c43491cdc44bc3a6','./categorize_list.php','6.3',0),('1d64db4a492ead105da17c4f9306e6d9','./comments.php','6.3',0),('f0d33ddab45bfec469f85e3169a4aa6d','./commxmlrpc.php','6.3',0),('4e80d852129f05b643ccff0c548d6a34','./contribution.php','6.3',0),('d855d83ba9ef16cfb51d4949ee37ff85','./copyrights.php','6.3',0),('a7e5fb9b76a9f94bf2c4084ccdf37042','./css/index.php','6.3',0),('8b662f5f9e441f0789314d6b6ff80027','./db/index.php','6.3',0),('e9a756da8900d8c49942182a6c12cad8','./db/tiki-db-adodb.php','6.3',0),('4a5d9caaffb1484826f0676635a901f1','./db/tiki-db-pdo.php','6.3',0),('0ec5268a9f4b34ec2bd55fbe39c77d31','./db/tiki-db.php','6.3',0),('08b7db1cd25c7924c098506c79c5af95','./display_banner.php','6.3',0),('a0c9bc463e605de6146cabbd7a027ee6','./doc/devtools/buildincrement.php','6.3',0),('c2753396ed2c51da8446aaf1def900d7','./doc/devtools/convert_templates_prefs-2.0.php','6.3',0),('f8c2bb3662ff31fd46b7c1ce567eeb48','./doc/devtools/convert_tpl_ajax.php','6.3',0),('acd24aa7b7561a8f1641a063225b8b9c','./doc/devtools/extract-img-db-to-fs.php','6.3',0),('3d34f910a7eea4852f84b271c8a3a0d3','./doc/devtools/fix-encoding.php','6.3',0),('a5c856f250e2d39b70116577fded8275','./doc/devtools/ggg-trace.php','6.3',0),('c05103f84d6e9593f4e43e0af174ba8d','./doc/devtools/index.php','6.3',0),('61fccdbb580e1d9d30edf261b124f028','./doc/devtools/lessermagicreport.php','6.3',0),('2e0ea9bc97b6c9424df9d4b827329705','./doc/devtools/parse_tiki.php','6.3',0),('319a5feecbeb9c6949c668c7ee14a523','./doc/devtools/restorehelp.php','6.3',0),('abd86747e4383919d773252ca40e21bd','./doc/devtools/search_smarty_prefs-2.0.php','6.3',0),('cc1568f694df4761a15599cd4d69b29c','./doc/devtools/securitycheck.php','6.3',0),('d7b77e09dbac5a5490919f1c0fc76af4','./doc/devtools/stripcomments.php','6.3',0),('a68b63663113c249cc53e5c8fee66656','./doc/devtools/svnbranch.php','6.3',0),('152480811a1640f66102c698336810b0','./doc/devtools/svnbranchreview.php','6.3',0),('270ced6c986f64e6a21422f6a6bacb21','./doc/devtools/svnbranchupdate.php','6.3',0),('d6f59b21fc3e96ce46da2fcb3a4ccaeb','./doc/devtools/svnmerge.php','6.3',0),('74ee67c93d083dbeda31866acdc7a9b0','./doc/devtools/svnswitch.php','6.3',0),('3b7aea51acc2df50a60cb674b8584df7','./doc/devtools/svntools.php','6.3',0),('c33924c9b349a9a05766745f368fb4af','./doc/devtools/sync.php','6.3',0),('740564d4b24c975a0d81d0c92616fb89','./doc/devtools/tiki-create_md5.php','6.3',0),('28703047b2a00036d415a4209b2b6e85','./doc/devtools/tiki-show_raw_links.php','6.3',0),('cba82206541f029870eba9e6cac49ec9','./doc/devtools/usergeo.php','6.3',0),('a595789232032c28cd630aa680ef371a','./doc/index.php','6.3',0),('a595789232032c28cd630aa680ef371a','./dump/index.php','6.3',0),('a0c6a9c9db77d9a4b56f43733eafcbc7','./fgal_listing_conf.php','6.3',0),('a595789232032c28cd630aa680ef371a','./files/index.php','6.3',0),('984ba1b844d198008b847e6de529f82a','./files/templates/index.php','6.3',0),('984ba1b844d198008b847e6de529f82a','./files/templates/listpages/index.php','6.3',0),('25e06282f9d059c001a5b1e9579dad35','./freetag_apply.php','6.3',0),('99d9ccf05f999a79dcbe6c195e8c1493','./freetag_list.php','6.3',0),('7e35abac0479a8dc3c08867a4fef34e2','./get_strings.php','6.3',0),('ed5e2fb1dde125ae5fb5760b0046df3c','./help.php','6.3',0),('a595789232032c28cd630aa680ef371a','./images/index.php','6.3',0),('9acc7c02bedcbbafc40b88611fc6c516','./img/avatars/index.php','6.3',0),('6a363b68a8ca7f0fd1f7f02869d5ed01','./img/flags/flagnames.php','6.3',0),('9acc7c02bedcbbafc40b88611fc6c516','./img/flags/index.php','6.3',0),('9acc7c02bedcbbafc40b88611fc6c516','./img/icn/index.php','6.3',0),('9acc7c02bedcbbafc40b88611fc6c516','./img/icons/index.php','6.3',0),('9acc7c02bedcbbafc40b88611fc6c516','./img/icons2/index.php','6.3',0),('f9ab6a201485bf841c8fb818dc06b594','./img/index.php','6.3',0),('9acc7c02bedcbbafc40b88611fc6c516','./img/mytiki/index.php','6.3',0),('9acc7c02bedcbbafc40b88611fc6c516','./img/smiles/index.php','6.3',0),('9acc7c02bedcbbafc40b88611fc6c516','./img/tiki/index.php','6.3',0),('9acc7c02bedcbbafc40b88611fc6c516','./img/trackers/index.php','6.3',0),('9acc7c02bedcbbafc40b88611fc6c516','./img/webmail/index.php','6.3',0),('9acc7c02bedcbbafc40b88611fc6c516','./img/wiki/index.php','6.3',0),('9acc7c02bedcbbafc40b88611fc6c516','./img/wiki_up/index.php','6.3',0),('02b62802294457b7db9278df1877bf83','./index.php','6.3',0),('dce03f6486a71b6be7a494243a945092','./installer/index.php','6.3',0),('480cb951ed908c474c4154a6eec9f929','./installer/installlib.php','6.3',0),('9bf3dbf20a7ac6b20882a547e23ddbf6','./installer/schema/20090416_plugin_security_tiki.php','6.3',0),('2e3cfe80ac3086f9f3be6cc082cee7ed','./installer/schema/20090923_mod_change_category_defaults_tiki.php','6.3',0),('99bb67b25622b312a0e922e6d9c93410','./installer/schema/20091004_last_tracker_items_modules_merge_tiki.php','6.3',0),('1f99a7886ebffa65c747e9f0c6acca4e','./installer/schema/20091019_article_by_rating_modules_merge_tiki.php','6.3',0),('653ed8ab5c779ddd0be96e34bef60c67','./installer/schema/20091019_last_articles_modules_merge_tiki.php','6.3',0),('66dd09ad21e673ec4ca5a38c0e64e43f','./installer/schema/20091103_upgrade_categperm_tiki.php','6.3',0),('728474b7dd8fc5b9f021d085565ca5e9','./installer/schema/20091123_upgrade_categperm_2_tiki.php','6.3',0),('223175bfe6a078f3f8cbd69f273c3c7a','./installer/schema/20091214_perspective_management_tiki.php','6.3',0),('7381dbef094d917bbc970b3e37585aab','./installer/schema/20100207_repair_file_galleries_tiki.php','6.3',0),('8969c26d71e99dc60f492618bbb8f33a','./installer/schema/20100507_flash_banner_tiki.php','6.3',0),('803745a7c504d8d243c89961bd419de8','./installer/schema/20100623_semantic_to_relation_tiki.php','6.3',0),('f6a00a3286d11f668f704ce24c63ced5','./installer/schema/20100927_better_column_fix_tiki.php','6.3',0),('4786c9dec91d4b2242a88bc850c2f6fc','./installer/schema/99999999_image_plugins_kill_tiki.php','6.3',0),('0ea5a9cd0bb34dadc34c421111a44164','./installer/schema/index.php','6.3',0),('ae7aefd4c1cbe8bd19f6d6364f7131cb','./installer/shell.php','6.3',0),('73b95aa878e4e55e8f0895fec3a524c5','./installer/tiki-installer.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/ar/index.php','6.3',0),('ea5750c20cb4ef33526a12c7b94011b4','./lang/ar/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/ca/index.php','6.3',0),('1cae24cf841422896a1b691f998cbd89','./lang/ca/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/cn/index.php','6.3',0),('03c3e6e94b260c387ba8b57c47f25126','./lang/cn/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/cs/index.php','6.3',0),('f6e6fd79b2fd221057ba916724fd005b','./lang/cs/language.php','6.3',0),('5263c374d47f479fdd7cdce0981152ff','./lang/cy/index.php','6.3',0),('daa897106d7832da259b85c8fcc2cca2','./lang/cy/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/da/index.php','6.3',0),('a9503c42b3f15d580866b93798ed8a7e','./lang/da/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/de/index.php','6.3',0),('5d9a99e24f77c339e797654662b40d46','./lang/de/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/dk/index.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/el/index.php','6.3',0),('3f1a6113fefe3fe65e49e09b4d49477d','./lang/el/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/en-uk/index.php','6.3',0),('9ddf2b18a164564d5447bd529c67b135','./lang/en-uk/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/en/index.php','6.3',0),('de63ff9bcf8a9c0d28ec6ac742391d5e','./lang/en/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/es/index.php','6.3',0),('0746290c3e53537927c3a5cbf8af5c7c','./lang/es/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/fa/index.php','6.3',0),('f46d5e138450a7436f7d2f3bb0de9734','./lang/fa/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/fi/index.php','6.3',0),('bb5e639396cc642d611171bdfeaa81ad','./lang/fi/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/fj/index.php','6.3',0),('a3c140c77aadadaf3aa07fe170002e24','./lang/fj/language.php','6.3',0),('95f3c9b3cca41d925bbe90d87ba46b01','./lang/flagmapping.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/fr/index.php','6.3',0),('572e632f7d06cb79ffb60040dd2ae08a','./lang/fr/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/fy-NL/index.php','6.3',0),('1fb330d401172af2deb2b557f38861fc','./lang/fy-NL/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/gl/index.php','6.3',0),('3c53abb581a65a3a8b62e76010ea4370','./lang/gl/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/he/index.php','6.3',0),('5ff4491aa450e0392afc3ef960bc0242','./lang/he/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/hr/index.php','6.3',0),('fd54b332cfb5eca2ecc83acbc96ab1bb','./lang/hr/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/hu/index.php','6.3',0),('a935201fb9649ff6ec296e180f6fdc9b','./lang/hu/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/id/index.php','6.3',0),('941d1b26b7cbd1dfd7a6711cab8f4e75','./lang/id/language.php','6.3',0),('14c070144fa34ec76700d162a83266a4','./lang/index.php','6.3',0),('84489fc39acc52af2b94670682750f95','./lang/is/index.php','6.3',0),('98aacdc29ed0aeaf4e22afb14733b18f','./lang/is/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/it/index.php','6.3',0),('eae57d651d0c8fb5c98dda55d7172984','./lang/it/language.php','6.3',0),('c92fea4736a74e1dde1f9f702dbb387b','./lang/iu/index.php','6.3',0),('ff2c4eec84759581101afc8fea131be8','./lang/iu/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/ja/index.php','6.3',0),('c315af9780d70119507edc503ff181db','./lang/ja/language.php','6.3',0),('f772842b4232f4504e01d9de4a7d392c','./lang/ko/language.php','6.3',0),('a576fe3cb5e044d42c4caba1098fbb0d','./lang/langmapping.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/lt/index.php','6.3',0),('eb081089de926d289e2e6c890fbc2db0','./lang/lt/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/nl/index.php','6.3',0),('10a2d594a7530d642a53e12ddd1b2dfd','./lang/nl/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/no/index.php','6.3',0),('dbb7eca01b1d138da006835ee97122f0','./lang/no/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/pl/index.php','6.3',0),('ab84a48300040918b4d4d2e2dee368b9','./lang/pl/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/pt-br/index.php','6.3',0),('db8b3149d44dd1e0505eaa39f0b40d25','./lang/pt-br/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/pt/index.php','6.3',0),('80b7b2ba4a862f5e9d9bf4bda8802c0d','./lang/pt/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/rm/index.php','6.3',0),('7789c8e07f4e732fbef2c96983c10ffa','./lang/rm/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/ro/index.php','6.3',0),('15430a996ffe17b3e9c7508a1c11c7a5','./lang/ro/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/ru/index.php','6.3',0),('efeda99c67e8fa2b82c0c4a75cab2436','./lang/ru/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/sb/index.php','6.3',0),('d72f8fd2d24461096044e7ada502e968','./lang/sb/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/si/index.php','6.3',0),('99d0e5b95ff65834efc551cd5ac0b72b','./lang/si/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/sk/index.php','6.3',0),('296591715381b4c97cdcbc5b19c1dff4','./lang/sk/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/sl/index.php','6.3',0),('bdbe0014f8c074e48cc1d7a5865033db','./lang/sl/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/sq/index.php','6.3',0),('2fb10e551facc69ce96cb34d8fc59b29','./lang/sq/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/sr-latn/index.php','6.3',0),('552c3b482221fa19a9bca776e51602ea','./lang/sr-latn/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/sv/index.php','6.3',0),('280e5edbcfb7f90d2ab3ef8aecb214cd','./lang/sv/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/sw/index.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/tr/index.php','6.3',0),('238d6b25c4c3d731cc20f0286776ff20','./lang/tr/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/tv/index.php','6.3',0),('928e7f749a93825caee9dc26ee468894','./lang/tv/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/tw/index.php','6.3',0),('69350f0e39e089d3374884059f8bf3cc','./lang/tw/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/uk/index.php','6.3',0),('1edfef041468ac55f284472590b700e9','./lang/uk/language.php','6.3',0),('7295d7502f07fcb3f7a302d7009c4e19','./lang/vi/index.php','6.3',0),('5075d5d65ff13e747584cefbbca79524','./lang/vi/language.php','6.3',0),('690092e9f5f5e53adc9a9918c3c2ffde','./lib/Babelfish.php','6.3',0),('809658c6425f35b50bd4bacb6d0b1673','./lib/Horde/Yaml.php','6.3',0),('92e19794b66466dccf9e271ae81496ea','./lib/Horde/Yaml/Dumper.php','6.3',0),('5708a9a233c09cf03fe9f37cecd6619f','./lib/Horde/Yaml/Exception.php','6.3',0),('f6cd764c871e1004d5ef9553e828ded5','./lib/Horde/Yaml/Loader.php','6.3',0),('1515261fc34e2a763337f936b49f00c6','./lib/Horde/Yaml/Node.php','6.3',0),('61c54f96b795046fe34a3000878af3c3','./lib/TikiWebdav/Auth/Default.php','6.3',0),('b8a52fe602696295f2441c97f3e8ffd0','./lib/TikiWebdav/Backend/File.php','6.3',0),('bf346984d6282da7d7c803fb4876b483','./lib/TikiWebdav/PathFactories/File.php','6.3',0),('5ae0fbd310bf564c2431a0ed9a8d2399','./lib/TikiWebdav/Server.php','6.3',0),('a6f02f0773616c5fc25ece40d1935a12','./lib/TikiWebdav/autoload.php','6.3',0),('fd8c33e21cf29569d61c82af627cbcd3','./lib/admin/adminlib.php','6.3',0),('a2dc06dca7aeb113ee5943292d2c4fe7','./lib/admin/index.php','6.3',0),('64e55337b61aea78b5f09ffc8ec99508','./lib/adodb/adodb-active-record.inc.php','6.3',0),('85d6a5563681e4ba6ab506a11e6fdf7d','./lib/adodb/adodb-active-recordx.inc.php','6.3',0),('db96167213233bcd01081742a7f84f92','./lib/adodb/adodb-csvlib.inc.php','6.3',0),('ab5c09d857a109261f2ff160602240fb','./lib/adodb/adodb-datadict.inc.php','6.3',0),('e76c52524f38c42f9c6fe8fc16e4c7a7','./lib/adodb/adodb-error.inc.php','6.3',0),('5adda31fbccb7c666535a332f530c636','./lib/adodb/adodb-errorhandler.inc.php','6.3',0),('7ab4957859c051ba7401fa1f1dc60d3b','./lib/adodb/adodb-errorpear.inc.php','6.3',0),('526bb8bb6d32dc14ac5fb569343f281f','./lib/adodb/adodb-exceptions.inc.php','6.3',0),('360456539eabb9bbd08622829df546a7','./lib/adodb/adodb-iterator.inc.php','6.3',0),('7e3134038851eac3fd9153835f59dfe2','./lib/adodb/adodb-lib.inc.php','6.3',0),('1b010ac54b5a9c4b780c8c5235d199ce','./lib/adodb/adodb-memcache.lib.inc.php','6.3',0),('3e971532841807d1aed85ac6f41e182d','./lib/adodb/adodb-pager.inc.php','6.3',0),('2f1f8148f56868be9833b1e70492bfa2','./lib/adodb/adodb-pear.inc.php','6.3',0),('4575ae1800be0c4a861f8f3a18d4f0f9','./lib/adodb/adodb-perf.inc.php','6.3',0),('e5ceb444a527b07cf7182be679584c9f','./lib/adodb/adodb-php4.inc.php','6.3',0),('2ef85aecdab2c9479fb0726fd54c5c7a','./lib/adodb/adodb-time.inc.php','6.3',0),('d2563ca7be8620796e3474d8211a5b06','./lib/adodb/adodb-xmlschema.inc.php','6.3',0),('5f7b7c1259f06250c783b47ca489b8a8','./lib/adodb/adodb-xmlschema03.inc.php','6.3',0),('28e802e8b9cab09aaa4bb764fbea3bc6','./lib/adodb/adodb.inc.php','6.3',0),('8a022e02714ce3186f310cc65d936ad5','./lib/adodb/contrib/toxmlrpc.inc.php','6.3',0),('38fe9f98fc07d45695dbe53303569029','./lib/adodb/datadict/datadict-access.inc.php','6.3',0),('58f4a77c1f03cbc7c90f91d47405d401','./lib/adodb/datadict/datadict-db2.inc.php','6.3',0),('c97ce14989b4f144d947e6faf360252e','./lib/adodb/datadict/datadict-firebird.inc.php','6.3',0),('3505573480a37065b105c7de67a271d4','./lib/adodb/datadict/datadict-generic.inc.php','6.3',0),('3f44cdc5f08d8a87f343d4db51002508','./lib/adodb/datadict/datadict-ibase.inc.php','6.3',0),('43ba7a347bb17c80f828353a6cf44cf0','./lib/adodb/datadict/datadict-informix.inc.php','6.3',0),('39d7c941f202b3f7b074a0cc3605acf3','./lib/adodb/datadict/datadict-mssql.inc.php','6.3',0),('58da7814c8380bc488b05450128d613f','./lib/adodb/datadict/datadict-mssqlnative.inc.php','6.3',0),('fb0118c5d0dc015010b2d507ba535cd6','./lib/adodb/datadict/datadict-mysql.inc.php','6.3',0),('1e19a284b6103671816d6e94e16c7394','./lib/adodb/datadict/datadict-oci8.inc.php','6.3',0),('583a97275aa3a74577e3c9a03dab8cba','./lib/adodb/datadict/datadict-postgres.inc.php','6.3',0),('d6c7db5a9ebd6992ff85e92d6ee3ac03','./lib/adodb/datadict/datadict-sapdb.inc.php','6.3',0),('1415650f4e09503773e19aa365546093','./lib/adodb/datadict/datadict-sqlite.inc.php','6.3',0),('c944e95026cfeb4c3ad037b54dd48963','./lib/adodb/datadict/datadict-sybase.inc.php','6.3',0),('e812ee4d5efa1bc6a22887d96c36e19c','./lib/adodb/drivers/adodb-access.inc.php','6.3',0),('3d9f78fb98cdaca8ce6a00bf42bc0d66','./lib/adodb/drivers/adodb-ado.inc.php','6.3',0),('92d32171f1798a23632aec91758afd2e','./lib/adodb/drivers/adodb-ado5.inc.php','6.3',0),('8605773dddccb80a3e888adbaf430c60','./lib/adodb/drivers/adodb-ado_access.inc.php','6.3',0),('c27240a54c31616eef76180865be57bb','./lib/adodb/drivers/adodb-ado_mssql.inc.php','6.3',0),('c7c7bdbe70ba9a4e541a032080c0a118','./lib/adodb/drivers/adodb-ads.inc.php','6.3',0),('a9fc50b040bedd548262bb2248a26c81','./lib/adodb/drivers/adodb-borland_ibase.inc.php','6.3',0),('82b39abc901a0c70de013ef93819f0a0','./lib/adodb/drivers/adodb-csv.inc.php','6.3',0),('febecec6c6d421dba7a35152e00d29e0','./lib/adodb/drivers/adodb-db2.inc.php','6.3',0),('db0d756533f626a9f7c9510f846d32f0','./lib/adodb/drivers/adodb-db2oci.inc.php','6.3',0),('dd44f4773557171a8e0057338c9573c9','./lib/adodb/drivers/adodb-db2ora.inc.php','6.3',0),('8587914deed44386f6cffa0599400983','./lib/adodb/drivers/adodb-fbsql.inc.php','6.3',0),('b89eae4c1e00161ebe0a13e915ea92b0','./lib/adodb/drivers/adodb-firebird.inc.php','6.3',0),('daf79564e648b2c56a65828df853d6d4','./lib/adodb/drivers/adodb-ibase.inc.php','6.3',0),('5bebbcc860fe21e491e40e13d1c2183e','./lib/adodb/drivers/adodb-informix.inc.php','6.3',0),('1595ca33278db1d5342244b41b5d6c71','./lib/adodb/drivers/adodb-informix72.inc.php','6.3',0),('830d017ecc4e578baffd37f6da8d6418','./lib/adodb/drivers/adodb-ldap.inc.php','6.3',0),('c4a2bb5ff0cc47d72496359e4b571412','./lib/adodb/drivers/adodb-mssql.inc.php','6.3',0),('3c9efbac90d487e9c3192e8376ce30de','./lib/adodb/drivers/adodb-mssql_n.inc.php','6.3',0),('5f05465497a61340dee3fa6c72eaa80d','./lib/adodb/drivers/adodb-mssqlnative.inc.php','6.3',0),('5cd8cd6cc1f30d85562d1c00c1bd2c33','./lib/adodb/drivers/adodb-mssqlpo.inc.php','6.3',0),('c168ff83d92bb526bfc46c8a35d64cb1','./lib/adodb/drivers/adodb-mysql.inc.php','6.3',0),('90d6a335ec2977530dc7803ce7c68735','./lib/adodb/drivers/adodb-mysqli.inc.php','6.3',0),('c0e7631e321b66af0939585c89b700d5','./lib/adodb/drivers/adodb-mysqlpo.inc.php','6.3',0),('85c8668e5848c77f8b5d37ef92a1997c','./lib/adodb/drivers/adodb-mysqlt.inc.php','6.3',0),('a3da7d8b0f71de3a65bb9b2742f614d1','./lib/adodb/drivers/adodb-netezza.inc.php','6.3',0),('e825a765645cafa863807af5cc4d6f1b','./lib/adodb/drivers/adodb-oci8.inc.php','6.3',0),('6f30b70a8832b60c8d06a892e043379e','./lib/adodb/drivers/adodb-oci8.old.inc.php','6.3',0),('39e896cb94621edde16f02662c372c64','./lib/adodb/drivers/adodb-oci805.inc.php','6.3',0),('0b13dd43212625b961513a4cd16b5c09','./lib/adodb/drivers/adodb-oci8po.inc.php','6.3',0),('c837194afd61f5a7138c72033c980239','./lib/adodb/drivers/adodb-odbc.inc.php','6.3',0),('d6bd4af80a4f7ea24c5bbfddcc66f4a2','./lib/adodb/drivers/adodb-odbc_db2.inc.php','6.3',0),('9d2c5048f421038f4f3b1839d06b190a','./lib/adodb/drivers/adodb-odbc_mssql.inc.php','6.3',0),('811d6fc9f268578387f48fc896ae1647','./lib/adodb/drivers/adodb-odbc_oracle.inc.php','6.3',0),('3882a6ad4bd00731b08da51fa3d71395','./lib/adodb/drivers/adodb-odbtp.inc.php','6.3',0),('abbeb4dbaf838988a458c271feb4b95e','./lib/adodb/drivers/adodb-odbtp_unicode.inc.php','6.3',0),('3fe400989cc807f2739b5704dfbcfc60','./lib/adodb/drivers/adodb-oracle.inc.php','6.3',0),('b6ebf8499eaec2d172dea13ce302fb59','./lib/adodb/drivers/adodb-pdo.inc.php','6.3',0),('ec5ad7f84d86b66b3a6dfb78f7501123','./lib/adodb/drivers/adodb-pdo_mssql.inc.php','6.3',0),('b29d56463c718663dbdb75e3ad914def','./lib/adodb/drivers/adodb-pdo_mysql.inc.php','6.3',0),('76c7a7cdfd741999e4d87f1e6f4b1500','./lib/adodb/drivers/adodb-pdo_oci.inc.php','6.3',0),('1f049710a52ab95997765fad9e882a7e','./lib/adodb/drivers/adodb-pdo_pgsql.inc.php','6.3',0),('8203a2b2291d241d54e81477fe975641','./lib/adodb/drivers/adodb-pdo_sqlite.inc.php','6.3',0),('4229030f20214dfe3955053be6267596','./lib/adodb/drivers/adodb-postgres.inc.php','6.3',0),('67fffffeb783992b14fe18ab9a7dd680','./lib/adodb/drivers/adodb-postgres64.inc.php','6.3',0),('00171bd6fdab78b20c7010e32c37a7a0','./lib/adodb/drivers/adodb-postgres7.inc.php','6.3',0),('0d1fdbe1e7d3a6b1ecb211bb41981737','./lib/adodb/drivers/adodb-postgres8.inc.php','6.3',0),('3505ce7b12fa571ba35d12ca5a595237','./lib/adodb/drivers/adodb-proxy.inc.php','6.3',0),('942c04463de819d9c39308356b440887','./lib/adodb/drivers/adodb-sapdb.inc.php','6.3',0),('ea7eddf0099ba27da2db4ad51d36a2e2','./lib/adodb/drivers/adodb-sqlanywhere.inc.php','6.3',0),('167bbdb8751fb31dc15d97ad55e6e435','./lib/adodb/drivers/adodb-sqlite.inc.php','6.3',0),('17f6bd2f48d385b89af781c777f63d2e','./lib/adodb/drivers/adodb-sqlitepo.inc.php','6.3',0),('64d6525f77e2596d8a20629f7570eba6','./lib/adodb/drivers/adodb-sybase.inc.php','6.3',0),('689fb42ab90584d1caa42a88cbcefd3c','./lib/adodb/drivers/adodb-sybase_ase.inc.php','6.3',0),('2c6ef1d06f438174bd1f4864a490f862','./lib/adodb/drivers/adodb-vfp.inc.php','6.3',0),('56602de7a184aa22984f46954b22934b','./lib/adodb/lang/adodb-ar.inc.php','6.3',0),('37b0880076545e8d8e3809002c8b1960','./lib/adodb/lang/adodb-bg.inc.php','6.3',0),('ed08fdc9f392628cf2bf5eb9c814eb6a','./lib/adodb/lang/adodb-bgutf8.inc.php','6.3',0),('b9030fa70d9d0f2ba408ac61c31958c3','./lib/adodb/lang/adodb-ca.inc.php','6.3',0),('155efb4dceeced3de044f660a9528265','./lib/adodb/lang/adodb-cn.inc.php','6.3',0),('6964322c13c74d4435a42c3d14ab7d6a','./lib/adodb/lang/adodb-cz.inc.php','6.3',0),('2ea23878b1027f3d07c8a9b8bbe4e3a3','./lib/adodb/lang/adodb-da.inc.php','6.3',0),('26c57777b17e3ff924b83d3ac36a6e1c','./lib/adodb/lang/adodb-de.inc.php','6.3',0),('c5420bb506f4eae64a6f84e33bb31523','./lib/adodb/lang/adodb-en.inc.php','6.3',0),('de0722a45173d1e076216f41090232d1','./lib/adodb/lang/adodb-es.inc.php','6.3',0),('32b94a998cb1a8b1ee14089af407d585','./lib/adodb/lang/adodb-esperanto.inc.php','6.3',0),('32dd4402ea6055f588cc4c999f1dd21f','./lib/adodb/lang/adodb-fa.inc.php','6.3',0),('dd47dbd2afc066b15e4944297da957b2','./lib/adodb/lang/adodb-fr.inc.php','6.3',0),('f308d107e1335ec36f71f101bc5324cf','./lib/adodb/lang/adodb-hu.inc.php','6.3',0),('15e2c634116779844db3c9e8f1c4ceb0','./lib/adodb/lang/adodb-it.inc.php','6.3',0),('ed3d417b04f361e178f1a258d193b929','./lib/adodb/lang/adodb-nl.inc.php','6.3',0),('8a53c82baf19cf137ef125d7e410c647','./lib/adodb/lang/adodb-pl.inc.php','6.3',0),('14cc56d6565900543e3b26130aace1b7','./lib/adodb/lang/adodb-pt-br.inc.php','6.3',0),('71052ad0e1622d8514b5a41622d2ce33','./lib/adodb/lang/adodb-ro.inc.php','6.3',0),('e828ddb6371ea135bfff0d6b59229eb3','./lib/adodb/lang/adodb-ru1251.inc.php','6.3',0),('81fac3276333ca136f83c1f3c35f5f3f','./lib/adodb/lang/adodb-sv.inc.php','6.3',0),('822a0c4c44527e99acdb3bc2f50ff6f1','./lib/adodb/lang/adodb-uk1251.inc.php','6.3',0),('201d8ae7eda2a23f6b71c9d88ac77ded','./lib/adodb/lang/adodb_th.inc.php','6.3',0),('5abeb5902f7f36cfc27520900f148164','./lib/adodb/pear/Auth/Container/ADOdb.php','6.3',0),('6827101a86cfcfac47a097238bf4fa23','./lib/adodb/perf/perf-db2.inc.php','6.3',0),('39d9a38a22c20a7b7b7dde3dec24da47','./lib/adodb/perf/perf-informix.inc.php','6.3',0),('53ee35cc94fe1d8e532952b7ec1dfa69','./lib/adodb/perf/perf-mssql.inc.php','6.3',0),('4e45b7da355f7300c5fc8547ca9f202e','./lib/adodb/perf/perf-mssqlnative.inc.php','6.3',0),('7b7ca3e0d1e68c249f2b98b9502161f4','./lib/adodb/perf/perf-mysql.inc.php','6.3',0),('2f3a26cb63a8654987ec4f7030bf2e5f','./lib/adodb/perf/perf-oci8.inc.php','6.3',0),('6245339eef3895f67e1a1947eee2d946','./lib/adodb/perf/perf-postgres.inc.php','6.3',0),('a423422f9f9398e3669b5f1879157838','./lib/adodb/pivottable.inc.php','6.3',0),('cd4e50501a4e93cbf2c483d67dfa1c5b','./lib/adodb/rsfilter.inc.php','6.3',0),('ebb57c7469946a64c4252bb59276689a','./lib/adodb/server.php','6.3',0),('6c473be2d6e69092672d0f8df7b90fe0','./lib/adodb/session/adodb-compress-bzip2.php','6.3',0),('a7771364ee536ecdd9aa974a9cf5ebfd','./lib/adodb/session/adodb-compress-gzip.php','6.3',0),('f2462fd839ae3e6f21d72a8e1be56e99','./lib/adodb/session/adodb-cryptsession.php','6.3',0),('14db9569ea91a84c414771bb0f249cde','./lib/adodb/session/adodb-cryptsession2.php','6.3',0),('08dc4b43b66614c7edc1caf81fcb4d09','./lib/adodb/session/adodb-encrypt-mcrypt.php','6.3',0),('b1535c929c4e27e55a284bd8842379d6','./lib/adodb/session/adodb-encrypt-md5.php','6.3',0),('8161ad5bd305eed1deb9670f578c984a','./lib/adodb/session/adodb-encrypt-secret.php','6.3',0),('33ec3cadbdee21ddf3199458d6b94db6','./lib/adodb/session/adodb-encrypt-sha1.php','6.3',0),('414f85519a96b9a356909cc01c9b58b3','./lib/adodb/session/adodb-session-clob.php','6.3',0),('703dc9969d5b89f8cb6883bd05deb790','./lib/adodb/session/adodb-session-clob2.php','6.3',0),('ab6c269f92326c7d70ba2fabff571b61','./lib/adodb/session/adodb-session.php','6.3',0),('4067c186e0ae268b718f95dbde77da48','./lib/adodb/session/adodb-session2.php','6.3',0),('4dad264ca0f5f669be480305f6be8835','./lib/adodb/session/crypt.inc.php','6.3',0),('39efaebf074096a8736ffbcb8c9a644c','./lib/adodb/session/old/adodb-cryptsession.php','6.3',0),('c4c895a14c892311114a295e7d069d5f','./lib/adodb/session/old/adodb-session-clob.php','6.3',0),('282277237bbde90cd4f2999f96c972ca','./lib/adodb/session/old/adodb-session.php','6.3',0),('5a4e4fde0da690423376a99610929101','./lib/adodb/session/old/crypt.inc.php','6.3',0),('3514b11651b24c2a444cf829c13c848e','./lib/adodb/toexport.inc.php','6.3',0),('f6967c4a18db47ea938c71e279170a0c','./lib/adodb/tohtml.inc.php','6.3',0),('9270d97999286be6dd2f6acb51d38cdc','./lib/ajax/ajaxlib.php','6.3',0),('b50cf26eb99fb2ae614000ef5a55f571','./lib/ajax/autosave.php','6.3',0),('e447abb5f84279389e3cbec85ee4618b','./lib/ajax/xajax/copyright.inc.php','6.3',0),('39211b13e13ca8e3b810aa783b909a77','./lib/ajax/xajax/xajax_core/xajaxAIO.inc.php','6.3',0),('9ed2e12e0a8e37c89fb6eeda8818ce32','./lib/articles/artlib.php','6.3',0),('81d597411bb313c64f939cc14a49903c','./lib/articles/index.php','6.3',0),('7a50e2ae8d9798da84ab01d5244cbe0c','./lib/attributes/attributelib.php','6.3',0),('a429a6655a8a51e8bbe5c832f34f03cc','./lib/attributes/relationlib.php','6.3',0),('b4a7f32df378260bd565ad2656da83c8','./lib/auth/PasswordHash.php','6.3',0),('81d597411bb313c64f939cc14a49903c','./lib/auth/index.php','6.3',0),('8d82c2d4bd222e84cbb6c146fb68c17c','./lib/auth/ldap.php','6.3',0),('21511b73d03c98341a64fc992d2ab1d1','./lib/auth/phpbb.php','6.3',0),('075c73e38a1dce899efc1e36aa224868','./lib/auth/tokens.php','6.3',0),('703ba43d0bf81f2c4cad61e477183d6e','./lib/ban/banlib.php','6.3',0),('81d597411bb313c64f939cc14a49903c','./lib/ban/index.php','6.3',0),('a8bbde1e8544089d901f4e0cf34afc16','./lib/banners/bannerlib.php','6.3',0),('81d597411bb313c64f939cc14a49903c','./lib/banners/index.php','6.3',0),('071fd5b7b6e61cbeff521d597c31a42f','./lib/bigbluebuttonlib.php','6.3',0),('8ba166969ad70739852774dd2be3e183','./lib/blogs/bloglib.php','6.3',0),('81d597411bb313c64f939cc14a49903c','./lib/blogs/index.php','6.3',0),('da3aed0f5b31f70cf15e4b64acd6baee','./lib/bookmarks/bookmarklib.php','6.3',0),('81d597411bb313c64f939cc14a49903c','./lib/bookmarks/index.php','6.3',0),('17ee9f9934a571eb6bc36998ebb8f8ee','./lib/breadcrumblib.php','6.3',0),('4555ad187b6b5b2c40a525685f614349','./lib/cache/cachelib.php','6.3',0),('81d597411bb313c64f939cc14a49903c','./lib/cache/index.php','6.3',0),('43e37328b0f84ddef8dbc3f7e586a047','./lib/cache/memcachelib.php','6.3',0),('a0511b2a4df3aac7d08891cf89d4cba5','./lib/cache/pagecache.php','6.3',0),('b59f95f320292469a49d82568817d2d1','./lib/calendar/calendarlib.php','6.3',0),('ab730f756c2a254dbb4d44edaa49f7aa','./lib/calendar/calrecurrence.php','6.3',0),('81d597411bb313c64f939cc14a49903c','./lib/calendar/index.php','6.3',0),('dbf9855e85d0d191926a0758ad90c7b7','./lib/calendar/tikicalendarlib.php','6.3',0),('740007b106c89b7b1cfd7c3f2d2361cb','./lib/captcha/captchalib.php','6.3',0),('36e2e3f767d277aff3fd06afa3bd793c','./lib/captcha/index.php','6.3',0),('36d0f084fa959ab493f3ae85f75623d9','./lib/categories/categlib.php','6.3',0),('81d597411bb313c64f939cc14a49903c','./lib/categories/index.php','6.3',0),('4c9307fd425f86d370d9f3b8fe9cc9d3','./lib/ckeditor/ckeditor.php','6.3',0),('0e9c078a1e716918bf7ef12f10c7e5cf','./lib/ckeditor/ckeditor_php4.php','6.3',0),('517c0b72a069a2f391d84a36e5e7f20b','./lib/ckeditor/ckeditor_php5.php','6.3',0),('4a580f0e593dd8851d9c625cd44227d5','./lib/commcenter/commlib.php','6.3',0),('81d597411bb313c64f939cc14a49903c','./lib/commcenter/index.php','6.3',0),('d7f40494a49521c496832c0b3efcb80b','./lib/comments/commentslib.php','6.3',0),('00e4ba093c70caff668ac99c602b3b36','./lib/contribution/contributionlib.php','6.3',0),('81d597411bb313c64f939cc14a49903c','./lib/contribution/index.php','6.3',0),('1e6be28884a8b2394b58c9a2b5cb466e','./lib/copyrights/copyrightslib.php','6.3',0),('81d597411bb313c64f939cc14a49903c','./lib/copyrights/index.php','6.3',0),('6f608573f8cf5eed95fc3035154ca086','./lib/core/Category/Manipulator.php','6.3',0),('c9c202598935c5c3ef6e2eb37ca01849','./lib/core/DeclFilter.php','6.3',0),('18f004415fd99ea3f211407a0e31f679','./lib/core/DeclFilter/CatchAllFilterRule.php','6.3',0),('4fd929c1d1e362a66f25cd660f09d2f7','./lib/core/DeclFilter/CatchAllUnsetRule.php','6.3',0),('4e02b4d17ebee533242e5d959f408259','./lib/core/DeclFilter/FilterRule.php','6.3',0),('d3ee63531b7687c25c1ff9f9bd0a8c0a','./lib/core/DeclFilter/KeyPatternFilterRule.php','6.3',0),('a9f6124f5d35371b117fa3f6c02a7f8c','./lib/core/DeclFilter/KeyPatternUnsetRule.php','6.3',0),('8324ac39d1a968535452d3cc2ec2da9e','./lib/core/DeclFilter/Rule.php','6.3',0),('1ca782e823fef1cc4b9b362c6e59d60a','./lib/core/DeclFilter/StaticKeyFilterRule.php','6.3',0),('02ee680393386a0858c4addab6e0a5b3','./lib/core/DeclFilter/StaticKeyUnsetRule.php','6.3',0),('71306a5c71a3c9b5108a953993bfd714','./lib/core/DeclFilter/UnsetRule.php','6.3',0),('f50845bf57d348ecdd482f34f1d2ccde','./lib/core/JitFilter.php','6.3',0),('9225be1b3362b848ba4885e0fd4c5e71','./lib/core/JitFilter/Element.php','6.3',0),('2ed28f3026e6e4369f4cb7a7ab4cc42e','./lib/core/Math/Formula/Element.php','6.3',0),('ca03ee769dfa07ba303880aa6531c4d6','./lib/core/Math/Formula/Exception.php','6.3',0),('d2f848db91c544e417b33b9e969324a4','./lib/core/Math/Formula/Function.php','6.3',0),('e884771b4a3c06596ff66c4bc7d702ee','./lib/core/Math/Formula/Function/Add.php','6.3',0),('2ae5402a3a1448e7d21610210bfd078f','./lib/core/Math/Formula/Function/Mul.php','6.3',0),('4cc487b4be34f767afc5c9b3507bd1f3','./lib/core/Math/Formula/Function/Str.php','6.3',0),('a1bf03cdfe5152799ecddd3eac60d1a7','./lib/core/Math/Formula/Parser.php','6.3',0),('a2347a6a8274f3b2150943542cc2e2ea','./lib/core/Math/Formula/Parser/Exception.php','6.3',0),('08a32964a4387143a0ebd63fe5263918','./lib/core/Math/Formula/Runner.php','6.3',0),('6f4c7c7216dc1acd1ae680a6a86bc69b','./lib/core/Math/Formula/Runner/Exception.php','6.3',0),('6ea909915a65ebf5cbc9bdf8bdc93b61','./lib/core/Math/Formula/Tokenizer.php','6.3',0),('a7d0a73ad846dd0a13b83247d8c24037','./lib/core/Multilingual/Aligner/BilingualAligner.php','6.3',0),('48ae05197f63fbd4a918b8ab40a97107','./lib/core/Multilingual/Aligner/MockMTWrapper.php','6.3',0),('068f816aa1a8868739d2e9d42a7236e9','./lib/core/Multilingual/Aligner/SentenceAlignments.php','6.3',0),('b10daa16df66c1fcc5b1878ebccc9d11','./lib/core/Multilingual/Aligner/SentenceAlignments3.php','6.3',0),('a057fdb8661edb74bae3b8c90d90d09d','./lib/core/Multilingual/Aligner/SentenceSegmentor.php','6.3',0),('bd40eab6a95c3787aee993ed289181ec','./lib/core/Multilingual/Aligner/ShortestPathFinder.php','6.3',0),('7ab7b18cd2cfe131debbd8aa978501d5','./lib/core/Multilingual/Aligner/UpdatePages.php','6.3',0),('14b9b6a481f068e62529ec764f6abfe3','./lib/core/Multilingual/Aligner/UpdateSentences.php','6.3',0),('7e8c5b16057a3391f05a0756ae829a4d','./lib/core/Multilingual/MachineTranslation/GoogleTranslateWrapper.php','6.3',0),('a3dfa80feb338e4dbce0ec01a93951d7','./lib/core/Perms.php','6.3',0),('1691df5c1565a0407e283fe5f4206b1c','./lib/core/Perms/Accessor.php','6.3',0),('f0264fc9715fd1a1738079f1da8be085','./lib/core/Perms/Applier.php','6.3',0),('d77a06ed02e4ba44e7f24d64f94a37a3','./lib/core/Perms/Check.php','6.3',0),('4b4b68a948cd561aa95e6fbaddf9345c','./lib/core/Perms/Check/Alternate.php','6.3',0),('7385fb71d3c8e5b6906b4518fd4ce5f2','./lib/core/Perms/Check/Creator.php','6.3',0),('80f66dd959a3dc8acb92c80f16496e7c','./lib/core/Perms/Check/Direct.php','6.3',0),('89e35398682b20f26389eab4c49a513f','./lib/core/Perms/Check/Indirect.php','6.3',0),('7970ac08450de5bc59a3f524ffd8b532','./lib/core/Perms/Reflection/Category.php','6.3',0),('b4a3d38ce76aeded0a8d22e48964db50','./lib/core/Perms/Reflection/Container.php','6.3',0),('c51754309842fe37b676dcea72afd6ef','./lib/core/Perms/Reflection/Factory.php','6.3',0),('cbd4ebd0c2fc76b391c0d475d1d00aad','./lib/core/Perms/Reflection/Global.php','6.3',0),('80dce65ea843ec6231c90cb3beb76f95','./lib/core/Perms/Reflection/Object.php','6.3',0),('dcb1f8d2505462caffce83c7dd70ebc3','./lib/core/Perms/Reflection/PermissionComparator.php','6.3',0),('bb82f155954d254e1205e48b86fa78dc','./lib/core/Perms/Reflection/PermissionSet.php','6.3',0),('86662476867131f36d3279d249f7c420','./lib/core/Perms/Reflection/Quick.php','6.3',0),('91ded1f975b25250446e1751d92135a9','./lib/core/Perms/Resolver.php','6.3',0),('cdac85f9e9e49fd16547dfc2d2eee91f','./lib/core/Perms/Resolver/Default.php','6.3',0),('59b58dd7da1e5c298a9b48b863949c28','./lib/core/Perms/Resolver/Static.php','6.3',0),('f31ff821d40ec46752417c3e3fc3b4bc','./lib/core/Perms/ResolverFactory.php','6.3',0),('dcdff2c6358a63126713988a7362d096','./lib/core/Perms/ResolverFactory/CategoryFactory.php','6.3',0),('d3e8b7eff90afaf322d5fa83af72cd1b','./lib/core/Perms/ResolverFactory/GlobalFactory.php','6.3',0),('13426ee14c20aab233ced3d462b1316b','./lib/core/Perms/ResolverFactory/ObjectFactory.php','6.3',0),('992869bf24b686098b5d9af9098d49f5','./lib/core/Perms/ResolverFactory/StaticFactory.php','6.3',0),('5a90a8ff9b81f0cc4c250d2a71ec24f3','./lib/core/Perms/ResolverFactory/TestFactory.php','6.3',0),('f1070823bd2be92dbe1d2366df63ccf5','./lib/core/StandardAnalyzer/Analyzer/Standard.php','6.3',0),('6852b177c646934dc8f82f6b7eaa6ee4','./lib/core/StandardAnalyzer/Analyzer/Standard/English.php','6.3',0),('f801926728ae279fabbb9307aa04db34','./lib/core/StandardAnalyzer/TokenFilter/EnglishStemmer.php','6.3',0),('e237ad52fa48662c8e8aebb07ac394ae','./lib/core/StandardAnalyzer/TokenFilter/EnglishStemmer/PorterStemmer.php','6.3',0),('ad95ca003b27d0872f7b973033ec3a5a','./lib/core/TikiDb.php','6.3',0),('c033eacb27de22040d79384a55005e11','./lib/core/TikiDb/Adodb.php','6.3',0),('030da18fa1de6a4594f3c1f4a0d78139','./lib/core/TikiDb/Bridge.php','6.3',0),('0275436130cbfb9052e0522b0fb8e209','./lib/core/TikiDb/ErrorHandler.php','6.3',0),('02e93e3f641a6a188aa0e498017f5ff8','./lib/core/TikiDb/Exception.php','6.3',0),('ba569b94b4f65d2b576def42984ad5aa','./lib/core/TikiDb/MasterSlaveDispatch.php','6.3',0),('158712b84da352e755440025ab6f4207','./lib/core/TikiDb/Pdo.php','6.3',0),('38f677a00d7c389d3dd2e5bee508d097','./lib/core/TikiFilter.php','6.3',0),('164b3839ed0878b9fc0fca1cb00a9441','./lib/core/TikiFilter/AttributeType.php','6.3',0),('39a8fd70da703d6575605507e053b5fb','./lib/core/TikiFilter/Callback.php','6.3',0),('7074f703e9820cbfbb7cdf5f02bcee59','./lib/core/TikiFilter/HtmlPurifier.php','6.3',0),('5999fbaa31c778155a68dcc062c295c3','./lib/core/TikiFilter/PreventXss.php','6.3',0),('6a059599351ee5a10ace3445a3d5ee9b','./lib/core/TikiFilter/RawUnsafe.php','6.3',0),('da8bb59271816ff7a86857afefa97131','./lib/core/TikiFilter/Word.php','6.3',0),('08a40f6ae10e1e14318c32d9a465f092','./lib/core/Transition.php','6.3',0),('ec122b9bdc4954951c8daad261b14896','./lib/core/WikiParser/OutputLink.php','6.3',0),('0534f5d333069a01f524d67a79fd8f2e','./lib/core/WikiParser/PluginArgumentParser.php','6.3',0),('d2d15e94b26f0077e0229fb041a6c92e','./lib/core/WikiParser/PluginDefinition.php','6.3',0),('75c6ff5033cece552c4a03a33458981c','./lib/core/WikiParser/PluginMatcher.php','6.3',0),('34cee40fc873b4fe1cdec112689251c5','./lib/core/WikiParser/PluginOutput.php','6.3',0),('d2b73028d6973ff5a7f5d767d97cd257','./lib/core/WikiParser/PluginParser.php','6.3',0),('19fa5bd1125f16c68a4d42a8090f2240','./lib/core/WikiParser/PluginRepository.php','6.3',0),('f1856e383b015578a9ac6011a0bbd371','./lib/core/WikiParser/PluginRunner.php','6.3',0),('c21076433ce49f5bcb237f5590283884','./lib/core/Zend/Acl.php','6.3',0),('c741047cfa5b477d6e98378a37f6bc1c','./lib/core/Zend/Acl/Assert/Interface.php','6.3',0),('7967093c8c44681a894157126c83e52b','./lib/core/Zend/Acl/Exception.php','6.3',0),('e5c1e95f900ed231fdfb8ee08a9f7104','./lib/core/Zend/Acl/Resource.php','6.3',0),('755f7b2a1582112d95761ff1323411dd','./lib/core/Zend/Acl/Resource/Interface.php','6.3',0),('3b313407ae31049f8ccb92f0c4d69c81','./lib/core/Zend/Acl/Role.php','6.3',0),('1408162f81475415565476f72bfca5b5','./lib/core/Zend/Acl/Role/Interface.php','6.3',0),('e60a1327e234c3fdc62ceb5529a62748','./lib/core/Zend/Acl/Role/Registry.php','6.3',0),('bd1afe5853ae3439ec4472d073575dc9','./lib/core/Zend/Acl/Role/Registry/Exception.php','6.3',0),('3e81575b4d185d0cc4daa0516d18393c','./lib/core/Zend/Amf/Adobe/Auth.php','6.3',0),('683e78b6144d0ff2476f016676e4cd80','./lib/core/Zend/Amf/Adobe/DbInspector.php','6.3',0),('e19adc5efc46f1bdbe78927c5ec04cb0','./lib/core/Zend/Amf/Adobe/Introspector.php','6.3',0),('ffeb60948cb2837e76873a5122de2a8c','./lib/core/Zend/Amf/Auth/Abstract.php','6.3',0),('2b460fb491078abf97f5791770bda21b','./lib/core/Zend/Amf/Constants.php','6.3',0),('4324f7d78f642d2ca43e1d7bc9944b05','./lib/core/Zend/Amf/Exception.php','6.3',0),('6e4df16c16bda97eafc6416a39fdfe3d','./lib/core/Zend/Amf/Parse/Amf0/Deserializer.php','6.3',0),('8ee4da17653b4213781147cba9140609','./lib/core/Zend/Amf/Parse/Amf0/Serializer.php','6.3',0),('eb9d65762541c63f83a90e0013e13f4d','./lib/core/Zend/Amf/Parse/Amf3/Deserializer.php','6.3',0),('2f5a22f2fc7839df3f25c4c6f98f4c00','./lib/core/Zend/Amf/Parse/Amf3/Serializer.php','6.3',0),('8616214649b5689ea59939ccf9a4121c','./lib/core/Zend/Amf/Parse/Deserializer.php','6.3',0),('e23fa4da25967f1b542c65a3024646b5','./lib/core/Zend/Amf/Parse/InputStream.php','6.3',0),('7b967c634ba60dfd95d6a1f4965ff55b','./lib/core/Zend/Amf/Parse/OutputStream.php','6.3',0),('b238bf15921d5fd1602b3b8c8cdcd6d5','./lib/core/Zend/Amf/Parse/Resource/MysqlResult.php','6.3',0),('94c21a6853d580487cd1372f46f5c090','./lib/core/Zend/Amf/Parse/Resource/MysqliResult.php','6.3',0),('4d444bb5ab2b1de2b86de1f016c2bf99','./lib/core/Zend/Amf/Parse/Resource/Stream.php','6.3',0),('1eba018524452806292b036a0d0320fd','./lib/core/Zend/Amf/Parse/Serializer.php','6.3',0),('d9f7fe244c2aea02eba87f71d1a1057d','./lib/core/Zend/Amf/Parse/TypeLoader.php','6.3',0),('77ab99048a87244be0df22665b7bc4f6','./lib/core/Zend/Amf/Request.php','6.3',0),('1be05f7d10ab32a3cf12035b390244a7','./lib/core/Zend/Amf/Request/Http.php','6.3',0),('c6adcae34fd6bb76a7c3428891899f8d','./lib/core/Zend/Amf/Response.php','6.3',0),('c95b469f3d14e7ba56a49dcd6dcb1dc7','./lib/core/Zend/Amf/Response/Http.php','6.3',0),('54a021723a5c9a49a8718a1ce710531d','./lib/core/Zend/Amf/Server.php','6.3',0),('d2a28febbb202da638cb1e759ee76d9e','./lib/core/Zend/Amf/Server/Exception.php','6.3',0),('d03547e0336c85b8e5994cab1095c449','./lib/core/Zend/Amf/Util/BinaryStream.php','6.3',0),('ad402815ed3ede54a2967266153ac3cb','./lib/core/Zend/Amf/Value/ByteArray.php','6.3',0),('a8d4466dd759a8b19030d8759941f08b','./lib/core/Zend/Amf/Value/MessageBody.php','6.3',0),('ac2f19556d1530a0bd88f6a7a020d7d5','./lib/core/Zend/Amf/Value/MessageHeader.php','6.3',0),('ead070f1a65564b2f06df9b11845ddf6','./lib/core/Zend/Amf/Value/Messaging/AbstractMessage.php','6.3',0),('65d394b4bfee849ce010622a1359563d','./lib/core/Zend/Amf/Value/Messaging/AcknowledgeMessage.php','6.3',0),('bf5ae50ce539fea1c56022c913b1320d','./lib/core/Zend/Amf/Value/Messaging/ArrayCollection.php','6.3',0),('2957cd1f33e6030efeddf978dfd49733','./lib/core/Zend/Amf/Value/Messaging/AsyncMessage.php','6.3',0),('c459b041a2d908bf60ade9ea570ab4b7','./lib/core/Zend/Amf/Value/Messaging/CommandMessage.php','6.3',0),('544c006bb2f8f77caba09cbd8b398832','./lib/core/Zend/Amf/Value/Messaging/ErrorMessage.php','6.3',0),('5e73a16299acd499f60755f12efce401','./lib/core/Zend/Amf/Value/Messaging/RemotingMessage.php','6.3',0),('3c695cdd523ba60aed7de400ec23339b','./lib/core/Zend/Amf/Value/TraitsInfo.php','6.3',0),('2b7465724238b30f9c292f9f4648b0dd','./lib/core/Zend/Application.php','6.3',0),('b815427eaee29d097e3598f506852095','./lib/core/Zend/Application/Bootstrap/Bootstrap.php','6.3',0),('d852fff3459cd75323781a9f5fe34a20','./lib/core/Zend/Application/Bootstrap/BootstrapAbstract.php','6.3',0),('e6f8453619228969eb9bd698390bc91a','./lib/core/Zend/Application/Bootstrap/Bootstrapper.php','6.3',0),('0edc51409d44f8e8f2ebbe3def7b8e0a','./lib/core/Zend/Application/Bootstrap/Exception.php','6.3',0),('a186fdb4fa6a0b0312d6db97d7edaa0e','./lib/core/Zend/Application/Bootstrap/ResourceBootstrapper.php','6.3',0),('eab0be56927338ada628d5e8ecb48757','./lib/core/Zend/Application/Exception.php','6.3',0),('31c111cbd20f12b2c299fdb715248e1b','./lib/core/Zend/Application/Module/Autoloader.php','6.3',0),('1ad77790e3a5bedfe2afe4defb1ce63c','./lib/core/Zend/Application/Module/Bootstrap.php','6.3',0),('182e21e8baa47dcdf2b0d58286b899e5','./lib/core/Zend/Application/Resource/Cachemanager.php','6.3',0),('c266404efd9aaa47c59e5b2d746bc78c','./lib/core/Zend/Application/Resource/Db.php','6.3',0),('8a76ce9baec4bffd733332ff65530cb7','./lib/core/Zend/Application/Resource/Dojo.php','6.3',0),('7c8aebb115d0b00f387e0b343b9fc541','./lib/core/Zend/Application/Resource/Exception.php','6.3',0),('3c7833e2e2423ca5c171b7d9c4ac1c0d','./lib/core/Zend/Application/Resource/Frontcontroller.php','6.3',0),('e3d247cd3196816859226dddc400cc92','./lib/core/Zend/Application/Resource/Layout.php','6.3',0),('638c1fa7e8ba6a198aeb4178a6b8cc3f','./lib/core/Zend/Application/Resource/Locale.php','6.3',0),('af7a39ebc2c53a6d524988764643d7b7','./lib/core/Zend/Application/Resource/Log.php','6.3',0),('a7351bbef678306eb304266a61f04e51','./lib/core/Zend/Application/Resource/Mail.php','6.3',0),('858266e728c91eb686cc0a5ac9b05fab','./lib/core/Zend/Application/Resource/Modules.php','6.3',0),('d3a60f24fe5efa50a265caee4adcdd17','./lib/core/Zend/Application/Resource/Multidb.php','6.3',0),('bd39df08c0d0c5388119c4f871195035','./lib/core/Zend/Application/Resource/Navigation.php','6.3',0),('b45e47581f8cac1f8fa7cfe30957f329','./lib/core/Zend/Application/Resource/Resource.php','6.3',0),('51edf72c69da3bf32234a521b64e0627','./lib/core/Zend/Application/Resource/ResourceAbstract.php','6.3',0),('bd8b93c8656caacb5dbebc28e9bcb608','./lib/core/Zend/Application/Resource/Router.php','6.3',0),('298313f0e44e00fa8b34bd51258738f3','./lib/core/Zend/Application/Resource/Session.php','6.3',0),('8fc799ca3c78bcbc01f4234d2b1cebbd','./lib/core/Zend/Application/Resource/Translate.php','6.3',0),('263c0887391ecd57ccaacd4454ffeb98','./lib/core/Zend/Application/Resource/View.php','6.3',0),('5fdc040dda37db2b6767322ef7ecf24c','./lib/core/Zend/Auth.php','6.3',0),('93e56aa165edafab22d2d70e609f12ec','./lib/core/Zend/Auth/Adapter/DbTable.php','6.3',0),('c4da3b1f1aec5a8a59cb1e03cd085650','./lib/core/Zend/Auth/Adapter/Digest.php','6.3',0),('bc5f71219010deec583b8bcf3b419e72','./lib/core/Zend/Auth/Adapter/Exception.php','6.3',0),('43b4674025d98cf401ca2494c7b05157','./lib/core/Zend/Auth/Adapter/Http.php','6.3',0),('a1359a8296e299750a7343d741a6fd0e','./lib/core/Zend/Auth/Adapter/Http/Resolver/Exception.php','6.3',0),('6287dd2c27f079d30f11e4dc48b9d380','./lib/core/Zend/Auth/Adapter/Http/Resolver/File.php','6.3',0),('e17526a33c60541acc690e0da610f542','./lib/core/Zend/Auth/Adapter/Http/Resolver/Interface.php','6.3',0),('c0753731bb5be4585f5895dfcbf31fee','./lib/core/Zend/Auth/Adapter/InfoCard.php','6.3',0),('867866139d11c344332f7a2959ae1c12','./lib/core/Zend/Auth/Adapter/Interface.php','6.3',0),('1d625979c692737d1527f4d2f3e9a857','./lib/core/Zend/Auth/Adapter/Ldap.php','6.3',0),('aee98dec2dc33cafc96ed4e7a736c4be','./lib/core/Zend/Auth/Adapter/OpenId.php','6.3',0),('b673c02d24de4c4e4ba5b48fd2d950ad','./lib/core/Zend/Auth/Exception.php','6.3',0),('74fa4ed17032e512afc9c32613fe6b19','./lib/core/Zend/Auth/Result.php','6.3',0),('9a4795a429dba22d640e92f2955083b4','./lib/core/Zend/Auth/Storage/Exception.php','6.3',0),('43b16a17421a66eba0b6e648b7445452','./lib/core/Zend/Auth/Storage/Interface.php','6.3',0),('7fdfe6e843287a4bf6c42cff93ae123f','./lib/core/Zend/Auth/Storage/NonPersistent.php','6.3',0),('efacc93385ad8220037488f8c36782e6','./lib/core/Zend/Auth/Storage/Session.php','6.3',0),('c1dcf36c94527723cbd95c2885e5058f','./lib/core/Zend/Barcode.php','6.3',0),('ce682b3f6e34f6beeb5c84d44ec7a7e0','./lib/core/Zend/Barcode/Exception.php','6.3',0),('2b9bfbe716c7b4fc97dc801c4b8c6025','./lib/core/Zend/Barcode/Object/Code25.php','6.3',0),('ae14b18bd2d478a1da843d2e6eeefb2d','./lib/core/Zend/Barcode/Object/Code25interleaved.php','6.3',0),('61bba25233f7f9e2eac7204ce4ff2443','./lib/core/Zend/Barcode/Object/Code39.php','6.3',0),('46d0b0374bec8faa12a3f0eb95986fe9','./lib/core/Zend/Barcode/Object/Ean13.php','6.3',0),('e11719d121a4f3c1daae1b8455080185','./lib/core/Zend/Barcode/Object/Ean2.php','6.3',0),('c129cd22647d1f53e3969c4026933d76','./lib/core/Zend/Barcode/Object/Ean5.php','6.3',0),('9dcd5c2c588c3a6ec11b74aafdb04f07','./lib/core/Zend/Barcode/Object/Ean8.php','6.3',0),('2fb3995abfccee2c8f0f23291f54b32b','./lib/core/Zend/Barcode/Object/Error.php','6.3',0),('27466a4c45b0b2edae17a6f2d324642f','./lib/core/Zend/Barcode/Object/Exception.php','6.3',0),('dcf11b2fc7d7589b5c40377c943feac4','./lib/core/Zend/Barcode/Object/Identcode.php','6.3',0),('656d21874857328c91fba916cc60f8ac','./lib/core/Zend/Barcode/Object/Itf14.php','6.3',0),('3ffd2ba10f9dc84a9970feb5843ee53d','./lib/core/Zend/Barcode/Object/Leitcode.php','6.3',0),('8d8c774d8d01f4c47f8edeffb2a2235c','./lib/core/Zend/Barcode/Object/ObjectAbstract.php','6.3',0),('e9073199f7981121797b071bab726d14','./lib/core/Zend/Barcode/Object/Planet.php','6.3',0),('204074ba566e25aa40e3976b05b613f3','./lib/core/Zend/Barcode/Object/Postnet.php','6.3',0),('62bef4dc84b14e82c49c0226e56fa103','./lib/core/Zend/Barcode/Object/Royalmail.php','6.3',0),('fff5c86374b707e2136118b77414a70e','./lib/core/Zend/Barcode/Object/Upca.php','6.3',0),('7bb99d15d6f7c4f18e9814097e4125b6','./lib/core/Zend/Barcode/Object/Upce.php','6.3',0),('e93afd095bde3fda81fbea08b44bccbd','./lib/core/Zend/Barcode/Renderer/Exception.php','6.3',0),('2aab53b3994047cbc7ab172e6eced112','./lib/core/Zend/Barcode/Renderer/Image.php','6.3',0),('61be0d33b4b2a02e9f65dd2348f0aed7','./lib/core/Zend/Barcode/Renderer/Pdf.php','6.3',0),('caeb3bc5e906a23e8de37fedf7b9d14b','./lib/core/Zend/Barcode/Renderer/RendererAbstract.php','6.3',0),('5f85e81d7eff5b472e7c73512748aa1f','./lib/core/Zend/Cache.php','6.3',0),('242c7f6e09c9db5183d208e6e8ab6f14','./lib/core/Zend/Cache/Backend.php','6.3',0),('500edb3636839a6fd2c0161f522417af','./lib/core/Zend/Cache/Backend/Apc.php','6.3',0),('2b1ed225721f7f587f65d75d90fa91d3','./lib/core/Zend/Cache/Backend/BlackHole.php','6.3',0),('75b626b11e0be4d0455e89ff14e1abd9','./lib/core/Zend/Cache/Backend/ExtendedInterface.php','6.3',0),('11a72a19d6a45e3f7d496ca25fae299e','./lib/core/Zend/Cache/Backend/File.php','6.3',0),('c10046d2506da12af31f3fea27dfd77a','./lib/core/Zend/Cache/Backend/Interface.php','6.3',0),('29151dda05e0de66260099e96d7eeb41','./lib/core/Zend/Cache/Backend/Memcached.php','6.3',0),('410920650e5d8e1021993be9ae9880f5','./lib/core/Zend/Cache/Backend/Sqlite.php','6.3',0),('047e23f798aa981929263d41f8c54e91','./lib/core/Zend/Cache/Backend/Static.php','6.3',0),('115d9b81a899dc88690c6483ee2e5539','./lib/core/Zend/Cache/Backend/Test.php','6.3',0),('e8696b65cd34c44a47f58f41ccc6da69','./lib/core/Zend/Cache/Backend/TwoLevels.php','6.3',0),('e96b78d17618f60b4529ae316fe5501a','./lib/core/Zend/Cache/Backend/Xcache.php','6.3',0),('8db0bd823326df03d54753ab2f4c72c1','./lib/core/Zend/Cache/Backend/ZendPlatform.php','6.3',0),('aa56aa28265110ef8019f73b87d09513','./lib/core/Zend/Cache/Backend/ZendServer.php','6.3',0),('d499573f0ac627932b08cde9d1cd2859','./lib/core/Zend/Cache/Backend/ZendServer/Disk.php','6.3',0),('acbf64bcad586c310aaf5f07061ef101','./lib/core/Zend/Cache/Backend/ZendServer/ShMem.php','6.3',0),('3b06645c9206591ab1528f0473e58e6c','./lib/core/Zend/Cache/Core.php','6.3',0),('a4e028ec8041a96d0f1b4c7998b13850','./lib/core/Zend/Cache/Exception.php','6.3',0),('b1d2c280a21eaacf93e3201bb7b0ae3a','./lib/core/Zend/Cache/Frontend/Capture.php','6.3',0),('186a7fb4c2a2eb81d391999576bd7873','./lib/core/Zend/Cache/Frontend/Class.php','6.3',0),('f6053dfd65e0af988bcf2b76fba31b06','./lib/core/Zend/Cache/Frontend/File.php','6.3',0),('432f1ffc7574d1a7f69a921372234859','./lib/core/Zend/Cache/Frontend/Function.php','6.3',0),('bc45bc515c51f362fe8566cd3a43194d','./lib/core/Zend/Cache/Frontend/Output.php','6.3',0),('53ac913d58385b8cb5f371e5aab1499d','./lib/core/Zend/Cache/Frontend/Page.php','6.3',0),('9086624035b82a8cfe60edbfef07d8fd','./lib/core/Zend/Cache/Manager.php','6.3',0),('af9735391caa767a6b3afcbba4f831a0','./lib/core/Zend/Captcha/Adapter.php','6.3',0),('edd3b135460629c02b021573736e92b7','./lib/core/Zend/Captcha/Base.php','6.3',0),('2798957f1da2562ff095b8ff9761d652','./lib/core/Zend/Captcha/Dumb.php','6.3',0),('cb333a470cb4a904b9c3d494c2a7ba97','./lib/core/Zend/Captcha/Exception.php','6.3',0),('f2e2c543fc723bca0185810f9fad7ac2','./lib/core/Zend/Captcha/Figlet.php','6.3',0),('0861417258bbbf817e77420d1f950332','./lib/core/Zend/Captcha/Image.php','6.3',0),('655b54f607f15245e96a18a175076e82','./lib/core/Zend/Captcha/ReCaptcha.php','6.3',0),('33217176d29d8e75d2fa5dc55a271040','./lib/core/Zend/Captcha/Word.php','6.3',0),('2c2ca62cc857c7db50a4dcae8866b65a','./lib/core/Zend/CodeGenerator/Abstract.php','6.3',0),('9618231b649004247c4ef553ff161273','./lib/core/Zend/CodeGenerator/Exception.php','6.3',0),('0aae53d2f2c595b77353fa728e74b50a','./lib/core/Zend/CodeGenerator/Php/Abstract.php','6.3',0),('e6ab7f66a3cf7c73db36fb02ceedac3d','./lib/core/Zend/CodeGenerator/Php/Body.php','6.3',0),('8f96f762eb93f71489d1067e0d4a1ef8','./lib/core/Zend/CodeGenerator/Php/Class.php','6.3',0),('dac843c4673084d44fa3d91edc2093f4','./lib/core/Zend/CodeGenerator/Php/Docblock.php','6.3',0),('ad58fdb18cf9a804352b1595a9681236','./lib/core/Zend/CodeGenerator/Php/Docblock/Tag.php','6.3',0),('91c8c1b479f9599c88acb57241ef4383','./lib/core/Zend/CodeGenerator/Php/Docblock/Tag/License.php','6.3',0),('56aa4583300863ff743bdbce04e4e9e5','./lib/core/Zend/CodeGenerator/Php/Docblock/Tag/Param.php','6.3',0),('805ca415fecfebf1d516d9e593d119d7','./lib/core/Zend/CodeGenerator/Php/Docblock/Tag/Return.php','6.3',0),('098905c3a8dc70e8620d527212a2bb2f','./lib/core/Zend/CodeGenerator/Php/Exception.php','6.3',0),('2415a7c2e76111f200e498c4a8147475','./lib/core/Zend/CodeGenerator/Php/File.php','6.3',0),('d6cadf8923a8f264bd7efb865dc03ead','./lib/core/Zend/CodeGenerator/Php/Member/Abstract.php','6.3',0),('e7d25459118cc3cc454b2eb0678a14dc','./lib/core/Zend/CodeGenerator/Php/Member/Container.php','6.3',0),('c545d21cc4a9fedf55e44df6824ee624','./lib/core/Zend/CodeGenerator/Php/Method.php','6.3',0),('09ab1475e2c43e34a4cfc46018c63024','./lib/core/Zend/CodeGenerator/Php/Parameter.php','6.3',0),('9383f65c0bf38049fa20674b20a34f29','./lib/core/Zend/CodeGenerator/Php/Parameter/DefaultValue.php','6.3',0),('2b094813d39fc573fb71ef6228ab240c','./lib/core/Zend/CodeGenerator/Php/Property.php','6.3',0),('76a5be639091dc8fc2298a2123738185','./lib/core/Zend/CodeGenerator/Php/Property/DefaultValue.php','6.3',0),('94daabcac5405ed71a6f4be1a22e8f54','./lib/core/Zend/Config.php','6.3',0),('a3d9bae85950ab94a8efac669bec58bd','./lib/core/Zend/Config/Exception.php','6.3',0),('459d7207cd39ed253a68364dae05ebcf','./lib/core/Zend/Config/Ini.php','6.3',0),('927464d61ee0163aad93b2244a86e88c','./lib/core/Zend/Config/Writer.php','6.3',0),('e1c3e1203bb01412878d18e62f209648','./lib/core/Zend/Config/Writer/Array.php','6.3',0),('49f853b25f78e532aa5525c6efa185e5','./lib/core/Zend/Config/Writer/FileAbstract.php','6.3',0),('b8712f74bfc7f95d0b4f92a220408749','./lib/core/Zend/Config/Writer/Ini.php','6.3',0),('b25d2b97a438a0a23e3eb77ce384f9f4','./lib/core/Zend/Config/Writer/Xml.php','6.3',0),('b821dbfd0011cc1a8723ca62ea27d74e','./lib/core/Zend/Config/Xml.php','6.3',0),('d2d2877d0cc5344cbb98d5623892c0ab','./lib/core/Zend/Console/Getopt.php','6.3',0),('79eb37440646675ca860687251d86850','./lib/core/Zend/Console/Getopt/Exception.php','6.3',0),('13f71a34fad60b6cb23571f03c762db6','./lib/core/Zend/Controller/Action.php','6.3',0),('6d47a10fceca83cfad79dedb4af07474','./lib/core/Zend/Controller/Action/Exception.php','6.3',0),('8652fbcad5b00311a61a61d92b40a6d5','./lib/core/Zend/Controller/Action/Helper/Abstract.php','6.3',0),('20a7204dc36ce3b20792af3c35ca05a0','./lib/core/Zend/Controller/Action/Helper/ActionStack.php','6.3',0),('9c2bda05d3ef4280723a335d7ee34246','./lib/core/Zend/Controller/Action/Helper/AjaxContext.php','6.3',0),('331679ad2eb8f47a1345311001c86e8e','./lib/core/Zend/Controller/Action/Helper/AutoComplete/Abstract.php','6.3',0),('5e58b7ed862c3f69b910f80af044c459','./lib/core/Zend/Controller/Action/Helper/AutoCompleteDojo.php','6.3',0),('6ab27b4f21d5282e3e3d7484266867c8','./lib/core/Zend/Controller/Action/Helper/AutoCompleteScriptaculous.php','6.3',0),('775e7c30297219515c73d0bde9c21a4f','./lib/core/Zend/Controller/Action/Helper/Cache.php','6.3',0),('7203d34ace647dc74a338e63e5ed08f2','./lib/core/Zend/Controller/Action/Helper/ContextSwitch.php','6.3',0),('ad076e02b82c683ce4917e47244d6d04','./lib/core/Zend/Controller/Action/Helper/FlashMessenger.php','6.3',0),('43c2d15642c0c0411f2528da262dff96','./lib/core/Zend/Controller/Action/Helper/Json.php','6.3',0),('c3fcc2aefdc895529ec72c9bc49b7f6e','./lib/core/Zend/Controller/Action/Helper/Redirector.php','6.3',0),('4563b11c4d95854aad95b1587759d427','./lib/core/Zend/Controller/Action/Helper/Url.php','6.3',0),('53342267b2bb93bdb70a5207ef30adff','./lib/core/Zend/Controller/Action/Helper/ViewRenderer.php','6.3',0),('6f6c5c7ff22b005fe6553c37eddc954a','./lib/core/Zend/Controller/Action/HelperBroker.php','6.3',0),('e47478a8b743ba135f4b28552092e03a','./lib/core/Zend/Controller/Action/HelperBroker/PriorityStack.php','6.3',0),('66e6369cc06cd7a006bd4c541a611201','./lib/core/Zend/Controller/Action/Interface.php','6.3',0),('cfbfa0650c7d4df0e3ebd57cef4b56c6','./lib/core/Zend/Controller/Dispatcher/Abstract.php','6.3',0),('733e9de5128b657ea1d971fca4c2f125','./lib/core/Zend/Controller/Dispatcher/Exception.php','6.3',0),('8de9e687c88235ff0bf24219253f9ddf','./lib/core/Zend/Controller/Dispatcher/Interface.php','6.3',0),('ebb08421a86e5d1afdac97849dc4da4f','./lib/core/Zend/Controller/Dispatcher/Standard.php','6.3',0),('7901fac79bb5e6e70ff78c7ea5d27bdd','./lib/core/Zend/Controller/Exception.php','6.3',0),('a88e1c285e8bcb3808280651b4690ac3','./lib/core/Zend/Controller/Front.php','6.3',0),('170bbabec0aadbb79cc724f9604f9fd8','./lib/core/Zend/Controller/Plugin/Abstract.php','6.3',0),('3ce6b50710cec802b379c49f72d27143','./lib/core/Zend/Controller/Plugin/ActionStack.php','6.3',0),('266b9680f53e162d38df9e6ec390c2f1','./lib/core/Zend/Controller/Plugin/Broker.php','6.3',0),('6f8f3fe833d93fb4bfc85ffefa14c12a','./lib/core/Zend/Controller/Plugin/ErrorHandler.php','6.3',0),('58c17521cf5c27fd8d5252138a2e6258','./lib/core/Zend/Controller/Plugin/PutHandler.php','6.3',0),('4f766314dd46980b6a579bd318cccb3c','./lib/core/Zend/Controller/Request/Abstract.php','6.3',0),('2e193eccf705c83a4853242ddacb50d2','./lib/core/Zend/Controller/Request/Apache404.php','6.3',0),('d3c9ccaa2abd41415f8c26b550041a6f','./lib/core/Zend/Controller/Request/Exception.php','6.3',0),('4e051f55238745537ea01951f4ee9c77','./lib/core/Zend/Controller/Request/Http.php','6.3',0),('3846ed9269324eaa70c13763ff092f9e','./lib/core/Zend/Controller/Request/HttpTestCase.php','6.3',0),('39952c3da1d6efd601c05bf569a8460f','./lib/core/Zend/Controller/Request/Simple.php','6.3',0),('27ac2c9660fe1d9096eb8437c91928ad','./lib/core/Zend/Controller/Response/Abstract.php','6.3',0),('b12faf9a5f966058ace3a41382bab0fa','./lib/core/Zend/Controller/Response/Cli.php','6.3',0),('19bd8a17b9b48fd4926e1c486b1b04e4','./lib/core/Zend/Controller/Response/Exception.php','6.3',0),('8e1882a1eb2ad27c552c6dccf0183464','./lib/core/Zend/Controller/Response/Http.php','6.3',0),('a92f6fc74edaffaa2c3947a9ab9c3a8e','./lib/core/Zend/Controller/Response/HttpTestCase.php','6.3',0),('28205a868440354f7d810682f83cbe88','./lib/core/Zend/Controller/Router/Abstract.php','6.3',0),('d6ef6c4993b433a618445c97c03c5f22','./lib/core/Zend/Controller/Router/Exception.php','6.3',0),('66b8dab25fdb5467686f18f70c6e9503','./lib/core/Zend/Controller/Router/Interface.php','6.3',0),('c586127a59b236b16007557ba77eda96','./lib/core/Zend/Controller/Router/Rewrite.php','6.3',0),('c978bd2c0847ff767785a4206941a58e','./lib/core/Zend/Controller/Router/Route.php','6.3',0),('b3c5f6e78674fd2278291d87bb031d4b','./lib/core/Zend/Controller/Router/Route/Abstract.php','6.3',0),('030490d900dfda67afe373397ec1b984','./lib/core/Zend/Controller/Router/Route/Chain.php','6.3',0),('5b2bc680c5b4be14608bd13ad2a04969','./lib/core/Zend/Controller/Router/Route/Hostname.php','6.3',0),('86d5aa68039d66adf72eef7f8a47cf7a','./lib/core/Zend/Controller/Router/Route/Interface.php','6.3',0),('e8570793fd4cf663f049bf8ba31a017a','./lib/core/Zend/Controller/Router/Route/Module.php','6.3',0),('fbd8437072a5d318191cc9ff50070cf3','./lib/core/Zend/Controller/Router/Route/Regex.php','6.3',0),('3128ca3c67e9aac000693f81aa0bbf40','./lib/core/Zend/Controller/Router/Route/Static.php','6.3',0),('253294887114953ef0df71436a3197cc','./lib/core/Zend/Crypt.php','6.3',0),('15989c2759f54a7b0c048e569c1cf06f','./lib/core/Zend/Crypt/DiffieHellman.php','6.3',0),('4c3796d08465f7713e30728eaa27848f','./lib/core/Zend/Crypt/DiffieHellman/Exception.php','6.3',0),('a7f1858fc85e0d51976fbffbefb75300','./lib/core/Zend/Crypt/Exception.php','6.3',0),('85bb69b562530fd0cb145833ec688b9a','./lib/core/Zend/Crypt/Hmac.php','6.3',0),('ec15eecd2b6270f64568a0f5dd81a160','./lib/core/Zend/Crypt/Hmac/Exception.php','6.3',0),('8b15ba77bc573c7b462aca6b38a9a350','./lib/core/Zend/Crypt/Math.php','6.3',0),('4fe2dfe1fdab6dc1458818f5195538b8','./lib/core/Zend/Crypt/Math/BigInteger.php','6.3',0),('57f63091e1ee955c61503cd8bf4455fc','./lib/core/Zend/Crypt/Math/BigInteger/Bcmath.php','6.3',0),('f7b6eee47c5d0d77f6a8bb8d36b86dd2','./lib/core/Zend/Crypt/Math/BigInteger/Exception.php','6.3',0),('fb44be4b1c32dacc12b0facae9d6996d','./lib/core/Zend/Crypt/Math/BigInteger/Gmp.php','6.3',0),('aed4d9a443d8f0d7a65fe0ccad078190','./lib/core/Zend/Crypt/Math/BigInteger/Interface.php','6.3',0),('8a562dc5a2a2eed681687ccff127e048','./lib/core/Zend/Crypt/Math/Exception.php','6.3',0),('7c1bb9e8940cfd9277d652db2e6627f8','./lib/core/Zend/Crypt/Rsa.php','6.3',0),('d2685cf8b50331f0e15539e67c184b73','./lib/core/Zend/Crypt/Rsa/Key.php','6.3',0),('7aa48f021b3761f4174c0ad122589a6b','./lib/core/Zend/Crypt/Rsa/Key/Private.php','6.3',0),('70ec2834c6935c29692e5df152b39efc','./lib/core/Zend/Crypt/Rsa/Key/Public.php','6.3',0),('67984c8f4006aeab5a87ef5323d81204','./lib/core/Zend/Currency.php','6.3',0),('da47085a7f84bf26ac464bd6b88fe3e7','./lib/core/Zend/Currency/CurrencyInterface.php','6.3',0),('2091ab332d6202b9243e4c6d4d9a98d8','./lib/core/Zend/Currency/Exception.php','6.3',0),('7915b5354a17b5417b916dcfeaec64f3','./lib/core/Zend/Date.php','6.3',0),('364f4043eebbc0a3ed2dd7781bbcff2f','./lib/core/Zend/Date/Cities.php','6.3',0),('fcd918affa602bd134559f4adb735290','./lib/core/Zend/Date/DateObject.php','6.3',0),('5eca814ef7a77b727313f4bd71cd1822','./lib/core/Zend/Date/Exception.php','6.3',0),('125d539703b42959985c01ea840f342c','./lib/core/Zend/Db.php','6.3',0),('f8498b9478de7a458216cb140a83cedf','./lib/core/Zend/Db/Adapter/Abstract.php','6.3',0),('454c70ee30a47e36cef4e731ea2473a6','./lib/core/Zend/Db/Adapter/Db2.php','6.3',0),('bef26426ba50458b3a0fadca0dd67d50','./lib/core/Zend/Db/Adapter/Db2/Exception.php','6.3',0),('e2262944c8adf628e07cbd92d18e6a15','./lib/core/Zend/Db/Adapter/Exception.php','6.3',0),('8b12bb24501b5bde47b89ba12bf38f29','./lib/core/Zend/Db/Adapter/Mysqli.php','6.3',0),('5db2f2d90f5961592346f581c1e8f0a2','./lib/core/Zend/Db/Adapter/Mysqli/Exception.php','6.3',0),('7b427061e7ef9ed5044cc663b5363f77','./lib/core/Zend/Db/Adapter/Oracle.php','6.3',0),('78dfda38a5e954e479033e989b45d25c','./lib/core/Zend/Db/Adapter/Oracle/Exception.php','6.3',0),('1d137a592a23d33e2efa05171aa296d9','./lib/core/Zend/Db/Adapter/Pdo/Abstract.php','6.3',0),('2f3060f57f7eab8b41318ab52cdb1de3','./lib/core/Zend/Db/Adapter/Pdo/Ibm.php','6.3',0),('abd5de02e4fbf5cead5e34cdcffcf9b6','./lib/core/Zend/Db/Adapter/Pdo/Ibm/Db2.php','6.3',0),('0aa0e79723b481b5e9d4699d937d3dec','./lib/core/Zend/Db/Adapter/Pdo/Ibm/Ids.php','6.3',0),('4db15c687f4b034faee1e7e918423678','./lib/core/Zend/Db/Adapter/Pdo/Mssql.php','6.3',0),('d6bf07bdd6508e7564c749c56ff0ee56','./lib/core/Zend/Db/Adapter/Pdo/Mysql.php','6.3',0),('d889db36410be461614d22ecbb9fc582','./lib/core/Zend/Db/Adapter/Pdo/Oci.php','6.3',0),('1d13a5bc5ff5b86e4c05f505ee786963','./lib/core/Zend/Db/Adapter/Pdo/Pgsql.php','6.3',0),('58c9dcd0916fa33279f02fdc4b5edfb8','./lib/core/Zend/Db/Adapter/Pdo/Sqlite.php','6.3',0),('b51c601aa9b5304e866990707cdcc6f6','./lib/core/Zend/Db/Adapter/Sqlsrv.php','6.3',0),('17af08cd634b391e6c84e779a976ebc8','./lib/core/Zend/Db/Adapter/Sqlsrv/Exception.php','6.3',0),('03e983c4f726f678fd6ab0fc7752218b','./lib/core/Zend/Db/Exception.php','6.3',0),('f4a7fe0245bafd58ce75e06cec23ad4f','./lib/core/Zend/Db/Expr.php','6.3',0),('363376efd1bd22b57c843e4d84edf44e','./lib/core/Zend/Db/Profiler.php','6.3',0),('5456f9556120cc1427bcea455d214344','./lib/core/Zend/Db/Profiler/Exception.php','6.3',0),('cd8c5cdcab5b3799b7dfb5b08e5ea5f1','./lib/core/Zend/Db/Profiler/Firebug.php','6.3',0),('e840cb1f0f3db7c43f132dea0304ad21','./lib/core/Zend/Db/Profiler/Query.php','6.3',0),('637b624ac4e92cca9a2842fed0d88d3d','./lib/core/Zend/Db/Select.php','6.3',0),('ccbd5c402523fc861f7d0a5a2d0e5ee0','./lib/core/Zend/Db/Select/Exception.php','6.3',0),('de2ca0f2b42eaf789a98dc48beaa73fa','./lib/core/Zend/Db/Statement.php','6.3',0),('7b3a0e9ca8459f7c5c4e9a3bd34c2419','./lib/core/Zend/Db/Statement/Db2.php','6.3',0),('80d8b0138fe794182ce0d374e59fe0ca','./lib/core/Zend/Db/Statement/Db2/Exception.php','6.3',0),('434d92c99a9ff35d273981c2e6ae7558','./lib/core/Zend/Db/Statement/Exception.php','6.3',0),('86323575d37ea81a1771139413c6e1f1','./lib/core/Zend/Db/Statement/Interface.php','6.3',0),('cc05e90c7a7a1c42c89d0a91b516cb0d','./lib/core/Zend/Db/Statement/Mysqli.php','6.3',0),('d3a7d7115eadfd6272960d9443e3e831','./lib/core/Zend/Db/Statement/Mysqli/Exception.php','6.3',0),('2e8465accfdb0233e35b34bbbfb6a15f','./lib/core/Zend/Db/Statement/Oracle.php','6.3',0),('aeda32640108e2c8bd05a9c04d80ea4c','./lib/core/Zend/Db/Statement/Oracle/Exception.php','6.3',0),('90d2c04c84556184f6ad3d64bd29301f','./lib/core/Zend/Db/Statement/Pdo.php','6.3',0),('48ecd6a5d6f5c9c169ca485cf3fef157','./lib/core/Zend/Db/Statement/Pdo/Ibm.php','6.3',0),('050333477292bd959486a90819930155','./lib/core/Zend/Db/Statement/Pdo/Oci.php','6.3',0),('c11cb3e0daf2c8e2f12a4faabe45cf81','./lib/core/Zend/Db/Statement/Sqlsrv.php','6.3',0),('41372d58939fa34c4f7046b0fcd354e6','./lib/core/Zend/Db/Statement/Sqlsrv/Exception.php','6.3',0),('b4239154e337740b8e909d4969ae5229','./lib/core/Zend/Db/Table.php','6.3',0),('95977d36f0497432d50e0a2057adc2fe','./lib/core/Zend/Db/Table/Abstract.php','6.3',0),('b25a10d9dea29b6c4f8fe6ce2849c178','./lib/core/Zend/Db/Table/Definition.php','6.3',0),('7f963aae5826206492f19c90c4786ad7','./lib/core/Zend/Db/Table/Exception.php','6.3',0),('34f9da669bc187fb515657e0420b1279','./lib/core/Zend/Db/Table/Row.php','6.3',0),('2047bbf791266863ed636c005318843e','./lib/core/Zend/Db/Table/Row/Abstract.php','6.3',0),('6cb0e2e9c000ec025d5e807f9a5736f5','./lib/core/Zend/Db/Table/Row/Exception.php','6.3',0),('8a4155535d5bc845798f014bde74c5ce','./lib/core/Zend/Db/Table/Rowset.php','6.3',0),('723af21fb1930b0a8951ce01a0f1cba4','./lib/core/Zend/Db/Table/Rowset/Abstract.php','6.3',0),('f62900230111f98b56e6d97410f907ff','./lib/core/Zend/Db/Table/Rowset/Exception.php','6.3',0),('ba94cab7a7397b2479653396bddd96cc','./lib/core/Zend/Db/Table/Select.php','6.3',0),('147aa2607b5028a3906912debb75b229','./lib/core/Zend/Db/Table/Select/Exception.php','6.3',0),('7fa205ced57ef23bf1c972624d3a2f65','./lib/core/Zend/Debug.php','6.3',0),('e6e8c4f4706e0061330fd7f33360e6b6','./lib/core/Zend/Dojo.php','6.3',0),('853f1a879308cb7d6b0d1968c18c86f5','./lib/core/Zend/Dojo/BuildLayer.php','6.3',0),('4fe4734c8dc77cfb6b8377a2f0557d1b','./lib/core/Zend/Dojo/Data.php','6.3',0),('80758228d298fd5ff12cd77fd290d0e8','./lib/core/Zend/Dojo/Exception.php','6.3',0),('d2e3a7aaceedb24944fd96bd63dc8283','./lib/core/Zend/Dojo/Form.php','6.3',0),('701ad97525b904ea3b2b2bca84bb1353','./lib/core/Zend/Dojo/Form/Decorator/AccordionContainer.php','6.3',0),('59dd4cf72a07bb357276b8ad95c4c5a0','./lib/core/Zend/Dojo/Form/Decorator/AccordionPane.php','6.3',0),('4730dacbfa7633a5401b9412ab55f73e','./lib/core/Zend/Dojo/Form/Decorator/BorderContainer.php','6.3',0),('9483d4d0ad9d39f469ab6ba3afc824fa','./lib/core/Zend/Dojo/Form/Decorator/ContentPane.php','6.3',0),('dbf14e24807211d7d94c842ae41cbfe4','./lib/core/Zend/Dojo/Form/Decorator/DijitContainer.php','6.3',0),('caa002ab120e1b497b7cde8abf89586c','./lib/core/Zend/Dojo/Form/Decorator/DijitElement.php','6.3',0),('e61b3bd76c74fca5a575fc2e9045d1d1','./lib/core/Zend/Dojo/Form/Decorator/DijitForm.php','6.3',0),('81593cc9361a2d344d898f6da7f97c6d','./lib/core/Zend/Dojo/Form/Decorator/SplitContainer.php','6.3',0),('a1db80abdd8a40256880380ccb7959cc','./lib/core/Zend/Dojo/Form/Decorator/StackContainer.php','6.3',0),('bd30e38a123a2a8a431ef99460fdb270','./lib/core/Zend/Dojo/Form/Decorator/TabContainer.php','6.3',0),('efe971e6d4c63eee773f10c69c5991d2','./lib/core/Zend/Dojo/Form/DisplayGroup.php','6.3',0),('bb09a520b4bce363ffd31d2cb7896613','./lib/core/Zend/Dojo/Form/Element/Button.php','6.3',0),('3c887743353a9b1ea57fec8eca2532c0','./lib/core/Zend/Dojo/Form/Element/CheckBox.php','6.3',0),('3d247359e00734ca16ae7ee3beda215b','./lib/core/Zend/Dojo/Form/Element/ComboBox.php','6.3',0),('d3a84c9d002fb8b75858890be6b03245','./lib/core/Zend/Dojo/Form/Element/CurrencyTextBox.php','6.3',0),('a04a8168e757cca4339e922cbde235a5','./lib/core/Zend/Dojo/Form/Element/DateTextBox.php','6.3',0),('4a8827b461c7d1309b09f2e6f2a457a2','./lib/core/Zend/Dojo/Form/Element/Dijit.php','6.3',0),('a892870e1c8f27c42a3e5cb9eab3098e','./lib/core/Zend/Dojo/Form/Element/DijitMulti.php','6.3',0),('fc7423f54909b73f9f1bc710135df8e0','./lib/core/Zend/Dojo/Form/Element/Editor.php','6.3',0),('fb7c9919e3c2d5df1963fb683f56d8ea','./lib/core/Zend/Dojo/Form/Element/FilteringSelect.php','6.3',0),('39ff06a76cb38a7087f3cfc3381ba1ea','./lib/core/Zend/Dojo/Form/Element/HorizontalSlider.php','6.3',0),('f6ecd17fdfbd25564146aee863cf4412','./lib/core/Zend/Dojo/Form/Element/NumberSpinner.php','6.3',0),('72b3a0bb09a5b5d7e9211ee31db12c8e','./lib/core/Zend/Dojo/Form/Element/NumberTextBox.php','6.3',0),('a38bb97e77a111319b0baf9e572870bc','./lib/core/Zend/Dojo/Form/Element/PasswordTextBox.php','6.3',0),('f3be08a4ca3e3640f3683fc78145394d','./lib/core/Zend/Dojo/Form/Element/RadioButton.php','6.3',0),('00eb4875cf7964401ebe7e968e65073c','./lib/core/Zend/Dojo/Form/Element/SimpleTextarea.php','6.3',0),('5fd9773308ed5eaf8bdd7f3b463f998c','./lib/core/Zend/Dojo/Form/Element/Slider.php','6.3',0),('e58a70cbeb15b4d3656e96c113097f41','./lib/core/Zend/Dojo/Form/Element/SubmitButton.php','6.3',0),('69f006905e2630d47244f014fbbd5d8d','./lib/core/Zend/Dojo/Form/Element/TextBox.php','6.3',0),('38c0dfb162c0f63a887f6cf63c81799f','./lib/core/Zend/Dojo/Form/Element/Textarea.php','6.3',0),('d3bfdedf948706216729649c0cd5e987','./lib/core/Zend/Dojo/Form/Element/TimeTextBox.php','6.3',0),('6a2501f0ef71fad24954f5cb88569d11','./lib/core/Zend/Dojo/Form/Element/ValidationTextBox.php','6.3',0),('678e492e1c7709d653d7a585a73bcc76','./lib/core/Zend/Dojo/Form/Element/VerticalSlider.php','6.3',0),('b89ece3397dfa26fbabef07e1bd75b88','./lib/core/Zend/Dojo/Form/SubForm.php','6.3',0),('dfbbc696f9df8e3785aa55f6489976c7','./lib/core/Zend/Dojo/View/Exception.php','6.3',0),('c79cbc19dd5b6f25037a4e331ae55269','./lib/core/Zend/Dojo/View/Helper/AccordionContainer.php','6.3',0),('4c79a61b44b2935164b0df43592fe447','./lib/core/Zend/Dojo/View/Helper/AccordionPane.php','6.3',0),('aab543bac39379e1f5df659ad40f8e49','./lib/core/Zend/Dojo/View/Helper/BorderContainer.php','6.3',0),('8136dfd6ebf3e2c096b85a2f64cd435b','./lib/core/Zend/Dojo/View/Helper/Button.php','6.3',0),('8b02b9cbd38dd9bbda81939d980a0d9c','./lib/core/Zend/Dojo/View/Helper/CheckBox.php','6.3',0),('f3bc008fc645e54e513b68aab2b961a8','./lib/core/Zend/Dojo/View/Helper/ComboBox.php','6.3',0),('61b5c006e2642484fa06bc65493b001a','./lib/core/Zend/Dojo/View/Helper/ContentPane.php','6.3',0),('1a033c56749d72641f274691f20dd14c','./lib/core/Zend/Dojo/View/Helper/CurrencyTextBox.php','6.3',0),('b0e31753205ee06bc49230f401b6c76d','./lib/core/Zend/Dojo/View/Helper/CustomDijit.php','6.3',0),('9bf2580c6cea924efefbc1ac46783212','./lib/core/Zend/Dojo/View/Helper/DateTextBox.php','6.3',0),('fcc85b5283649ea3f8fe79d3257560d8','./lib/core/Zend/Dojo/View/Helper/Dijit.php','6.3',0),('5de2438cb30d35a055805ad9022d2831','./lib/core/Zend/Dojo/View/Helper/DijitContainer.php','6.3',0),('7420e2dec19a6861b27b966b34d73981','./lib/core/Zend/Dojo/View/Helper/Dojo.php','6.3',0),('e1bb463f5a6fda8572cba80bbbdfa9f3','./lib/core/Zend/Dojo/View/Helper/Dojo/Container.php','6.3',0),('a666213550f7726513cdd4aa2655684f','./lib/core/Zend/Dojo/View/Helper/Editor.php','6.3',0),('4d7be8f35a8026b764ad2df9eb58fde0','./lib/core/Zend/Dojo/View/Helper/FilteringSelect.php','6.3',0),('961b1a2937ea317b6826ae6218768260','./lib/core/Zend/Dojo/View/Helper/Form.php','6.3',0),('7679797ab40571dc70e4680ed17451ba','./lib/core/Zend/Dojo/View/Helper/HorizontalSlider.php','6.3',0),('3815c01d5e0c10a98fab64ee10a188d5','./lib/core/Zend/Dojo/View/Helper/NumberSpinner.php','6.3',0),('88c071baa7c9889473abd5652edcec1d','./lib/core/Zend/Dojo/View/Helper/NumberTextBox.php','6.3',0),('dcab902ba5a08a9825b9e26e59ca7de0','./lib/core/Zend/Dojo/View/Helper/PasswordTextBox.php','6.3',0),('89b8ddf554d8e273326c8130a1076e36','./lib/core/Zend/Dojo/View/Helper/RadioButton.php','6.3',0),('e443f26b0a86ab80ddb9304b4b597f09','./lib/core/Zend/Dojo/View/Helper/SimpleTextarea.php','6.3',0),('72f0fd67aef8bd65eac88ed253612339','./lib/core/Zend/Dojo/View/Helper/Slider.php','6.3',0),('beb1c68fec17486069dfecdc07244bc5','./lib/core/Zend/Dojo/View/Helper/SplitContainer.php','6.3',0),('1f8e7dee217fe685a20ce6e857139bde','./lib/core/Zend/Dojo/View/Helper/StackContainer.php','6.3',0),('b4e91b25c940e1f00efc10d89d66971f','./lib/core/Zend/Dojo/View/Helper/SubmitButton.php','6.3',0),('dc12c4c94aaad5cf16937c9d9f1708f3','./lib/core/Zend/Dojo/View/Helper/TabContainer.php','6.3',0),('b42b302657a71889433ee086e21667d9','./lib/core/Zend/Dojo/View/Helper/TextBox.php','6.3',0),('284f5733c2162943c9d7d3e54ce7e2eb','./lib/core/Zend/Dojo/View/Helper/Textarea.php','6.3',0),('085c8b67c5cd854cbdf273b93be45e28','./lib/core/Zend/Dojo/View/Helper/TimeTextBox.php','6.3',0),('0a607cddb79f10b734b553dfced40b16','./lib/core/Zend/Dojo/View/Helper/ValidationTextBox.php','6.3',0),('d420f3cf5bdf19b2b2a37dfa5d56402c','./lib/core/Zend/Dojo/View/Helper/VerticalSlider.php','6.3',0),('a214e7eb88a320a64ff85f818f72b5d7','./lib/core/Zend/Dom/Exception.php','6.3',0),('52c91d1e5077160cf04f5a162511be3a','./lib/core/Zend/Dom/Query.php','6.3',0),('436b17459f82643919c1d93c75b4106f','./lib/core/Zend/Dom/Query/Css2Xpath.php','6.3',0),('186e7898da59800ed7c6f68ab8da93bf','./lib/core/Zend/Dom/Query/Result.php','6.3',0),('55ee8977abba3e9c8c56937432434c4c','./lib/core/Zend/Exception.php','6.3',0),('80eac8398a6ad2e353760ac61c086ba1','./lib/core/Zend/Feed.php','6.3',0),('3553a01c714ec8acb61b89a82ed0afb2','./lib/core/Zend/Feed/Abstract.php','6.3',0),('ba66134577f7dba467836a0076238db4','./lib/core/Zend/Feed/Atom.php','6.3',0),('58aa0f6449ce60f9d65e45148419a483','./lib/core/Zend/Feed/Builder.php','6.3',0),('7157e9eebec8727b1f98e23139106110','./lib/core/Zend/Feed/Builder/Entry.php','6.3',0),('d934e281d66ad9d2ccd0684d8354dbc3','./lib/core/Zend/Feed/Builder/Exception.php','6.3',0),('d1f6fb17a497b4e64d18ba420c82ccbf','./lib/core/Zend/Feed/Builder/Header.php','6.3',0),('d94ee6f0d0ce3945849e02d4ec600573','./lib/core/Zend/Feed/Builder/Header/Itunes.php','6.3',0),('4e07ac3b0da445542c6b19d43da34114','./lib/core/Zend/Feed/Builder/Interface.php','6.3',0),('3ea97aa2672bafd22aef6810211fad98','./lib/core/Zend/Feed/Element.php','6.3',0),('8aec2450524184c213c452b4a98103c3','./lib/core/Zend/Feed/Entry/Abstract.php','6.3',0),('35a9c4539fbf36f5da823a3c46febe9e','./lib/core/Zend/Feed/Entry/Atom.php','6.3',0),('effe4f70f4fc4230977ad1afd100ef1e','./lib/core/Zend/Feed/Entry/Rss.php','6.3',0),('446a053aec73204a06d0128d9432de24','./lib/core/Zend/Feed/Exception.php','6.3',0),('3cb1bb1ef086fbfab1231d57515b4e0f','./lib/core/Zend/Feed/Pubsubhubbub.php','6.3',0),('19b4dc9d3cbc81e57e443c606f69f88c','./lib/core/Zend/Feed/Pubsubhubbub/CallbackAbstract.php','6.3',0),('11c40912b61031b8cf2d90c93c29609a','./lib/core/Zend/Feed/Pubsubhubbub/CallbackInterface.php','6.3',0),('fc845eddcf78ebd4aa39cbaa906befa6','./lib/core/Zend/Feed/Pubsubhubbub/Exception.php','6.3',0),('ff240872e6e1f242265380d5090b28ba','./lib/core/Zend/Feed/Pubsubhubbub/HttpResponse.php','6.3',0),('8eff037970e3e4b3588ebc19be872e90','./lib/core/Zend/Feed/Pubsubhubbub/Model/ModelAbstract.php','6.3',0),('2465991e4bcea9537d682d6bbf4d7b63','./lib/core/Zend/Feed/Pubsubhubbub/Model/Subscription.php','6.3',0),('c8a2877b452a8dfc74a720451aa66d15','./lib/core/Zend/Feed/Pubsubhubbub/Model/SubscriptionInterface.php','6.3',0),('597918bdae14468879cc377c88f0fa47','./lib/core/Zend/Feed/Pubsubhubbub/Publisher.php','6.3',0),('01ef664744b3dad9280f6c1e37a1b40f','./lib/core/Zend/Feed/Pubsubhubbub/Subscriber.php','6.3',0),('277dfb53f56f26ccb8f9dfffb794df3b','./lib/core/Zend/Feed/Pubsubhubbub/Subscriber/Callback.php','6.3',0),('50234595001e84191ffba46e64afb55c','./lib/core/Zend/Feed/Reader.php','6.3',0),('f9e96acdf888e11771b21357a7bd679f','./lib/core/Zend/Feed/Reader/Collection.php','6.3',0),('1cbe4abe01326ca3f0a11db2375cddcd','./lib/core/Zend/Feed/Reader/Collection/Author.php','6.3',0),('0c80ea2107aec4b9acda8c0c299c630e','./lib/core/Zend/Feed/Reader/Collection/Category.php','6.3',0),('2aaa75afb40ad869dd89f77638a70cb0','./lib/core/Zend/Feed/Reader/Collection/CollectionAbstract.php','6.3',0),('dce3c8b91b643b578df4c161f9eb09ee','./lib/core/Zend/Feed/Reader/Entry/Atom.php','6.3',0),('8f5e5153e7265f804b174cc01af99a7c','./lib/core/Zend/Feed/Reader/Entry/Rss.php','6.3',0),('787310cc7abe6bf1228c5e91ea4a69e3','./lib/core/Zend/Feed/Reader/EntryAbstract.php','6.3',0),('f246139859e3885e46a29ef8f15c2153','./lib/core/Zend/Feed/Reader/EntryInterface.php','6.3',0),('48e67f2c8ae33c55bb903f17ea3d8687','./lib/core/Zend/Feed/Reader/Extension/Atom/Entry.php','6.3',0),('81e81c2d8acae19cc1e0fcec50509dc9','./lib/core/Zend/Feed/Reader/Extension/Atom/Feed.php','6.3',0),('7d80919a5be8113e1ed4974ff94c05fa','./lib/core/Zend/Feed/Reader/Extension/Content/Entry.php','6.3',0),('0b53f409ee3f850696659582e2dd4222','./lib/core/Zend/Feed/Reader/Extension/CreativeCommons/Entry.php','6.3',0),('975d64352ab930809dc7c078b570c3e6','./lib/core/Zend/Feed/Reader/Extension/CreativeCommons/Feed.php','6.3',0),('ef4df0c79a9e23f4a752fed5e2aa3025','./lib/core/Zend/Feed/Reader/Extension/DublinCore/Entry.php','6.3',0),('f686a144d80fde72ca6fabe7482435de','./lib/core/Zend/Feed/Reader/Extension/DublinCore/Feed.php','6.3',0),('9a3bc156c5655b4459989101203a4e5b','./lib/core/Zend/Feed/Reader/Extension/EntryAbstract.php','6.3',0),('18471a5963ae43b67f83999773750996','./lib/core/Zend/Feed/Reader/Extension/FeedAbstract.php','6.3',0),('8277b075784da7d4de4564fa71a60038','./lib/core/Zend/Feed/Reader/Extension/Podcast/Entry.php','6.3',0),('27e5873f3f32aeb57ab140eef138c550','./lib/core/Zend/Feed/Reader/Extension/Podcast/Feed.php','6.3',0),('b7353458e6e2b7104ed9272fc5867399','./lib/core/Zend/Feed/Reader/Extension/Slash/Entry.php','6.3',0),('88310128643ec38e9ba6c35dd895b340','./lib/core/Zend/Feed/Reader/Extension/Syndication/Feed.php','6.3',0),('4217ef9ffeb1f6623b87b5a002fa545a','./lib/core/Zend/Feed/Reader/Extension/Thread/Entry.php','6.3',0),('edc40bd9da5c21612f57b68f803c23e7','./lib/core/Zend/Feed/Reader/Extension/WellFormedWeb/Entry.php','6.3',0),('56560d54ba0e06208fb561516308caf4','./lib/core/Zend/Feed/Reader/Feed/Atom.php','6.3',0),('c67aa90fecea01edc3625c244f53d72f','./lib/core/Zend/Feed/Reader/Feed/Atom/Source.php','6.3',0),('aefefa67df5abf714407523cad8964ed','./lib/core/Zend/Feed/Reader/Feed/Rss.php','6.3',0),('08a946e9742e45a019dada0f2b88e0e8','./lib/core/Zend/Feed/Reader/FeedAbstract.php','6.3',0),('01a5c19f25817010f203890219bf8c46','./lib/core/Zend/Feed/Reader/FeedInterface.php','6.3',0),('6df9a9a0cbc2fb92e99dbc8636ca8573','./lib/core/Zend/Feed/Reader/FeedSet.php','6.3',0),('7d06f9fa9c544db9d185facaa19a698b','./lib/core/Zend/Feed/Rss.php','6.3',0),('eca6f675d110a1a9df70352849f8a6a1','./lib/core/Zend/Feed/Writer.php','6.3',0),('755bfcc608fb02ddd8afee56e3d3bc54','./lib/core/Zend/Feed/Writer/Deleted.php','6.3',0),('878be8332c7a35f5664b9699ed304340','./lib/core/Zend/Feed/Writer/Entry.php','6.3',0),('85d55334c2ded3efc4d7ecbca1c5e041','./lib/core/Zend/Feed/Writer/Exception/InvalidMethodException.php','6.3',0),('bb6fbc903584778745a936a5ec7578ac','./lib/core/Zend/Feed/Writer/Extension/Atom/Renderer/Feed.php','6.3',0),('d0276d8eefa81b20fdc59f4e875faa68','./lib/core/Zend/Feed/Writer/Extension/Content/Renderer/Entry.php','6.3',0),('13f1fb54ab30ebdf0b5af19f7dd76646','./lib/core/Zend/Feed/Writer/Extension/DublinCore/Renderer/Entry.php','6.3',0),('a8936d70b3c0d7430681194b671026b1','./lib/core/Zend/Feed/Writer/Extension/DublinCore/Renderer/Feed.php','6.3',0),('2c9b00ba6cbf0d100aa6f117c1ca9fe9','./lib/core/Zend/Feed/Writer/Extension/ITunes/Entry.php','6.3',0),('46ab40001e132b8149e58738390fff6b','./lib/core/Zend/Feed/Writer/Extension/ITunes/Feed.php','6.3',0),('dfc4c0adca57dae5f29f94fad751641b','./lib/core/Zend/Feed/Writer/Extension/ITunes/Renderer/Entry.php','6.3',0),('b34b3339b4ab5994df6ae7f212765ec4','./lib/core/Zend/Feed/Writer/Extension/ITunes/Renderer/Feed.php','6.3',0),('e35203c299f23338be88a856970efa6e','./lib/core/Zend/Feed/Writer/Extension/RendererAbstract.php','6.3',0),('ce22ba3ba766cb701cd0efbddafc3e80','./lib/core/Zend/Feed/Writer/Extension/RendererInterface.php','6.3',0),('ccaa408268ac466b8c9f92c7f3984110','./lib/core/Zend/Feed/Writer/Extension/Slash/Renderer/Entry.php','6.3',0),('32e812c02c15802b63aadb001ece4c01','./lib/core/Zend/Feed/Writer/Extension/Threading/Renderer/Entry.php','6.3',0),('f6ebf72dad673d63a73303c85f5ec35a','./lib/core/Zend/Feed/Writer/Extension/WellFormedWeb/Renderer/Entry.php','6.3',0),('76b6b919c9efdf79c9d0e02de826af71','./lib/core/Zend/Feed/Writer/Feed.php','6.3',0),('add7593fa5db9738f7ca082386cad2e6','./lib/core/Zend/Feed/Writer/Feed/FeedAbstract.php','6.3',0),('6b5f5ac90757004d8b1c0a586108930e','./lib/core/Zend/Feed/Writer/Renderer/Entry/Atom.php','6.3',0),('825fe651b3a7c87bf0d663ae9a5e0e94','./lib/core/Zend/Feed/Writer/Renderer/Entry/Atom/Deleted.php','6.3',0),('1b12f6201008c47da00f25408995e870','./lib/core/Zend/Feed/Writer/Renderer/Entry/Rss.php','6.3',0),('7986b7b15c41481dd9992f256d2853d3','./lib/core/Zend/Feed/Writer/Renderer/Feed/Atom.php','6.3',0),('41064f782b8a107ce6d991fd58508dfd','./lib/core/Zend/Feed/Writer/Renderer/Feed/Atom/AtomAbstract.php','6.3',0),('5ed7e85d1553f33e139932bbbdd9f6ff','./lib/core/Zend/Feed/Writer/Renderer/Feed/Atom/Source.php','6.3',0),('d5113f8d1e05a91c1be8f9ded916e5a1','./lib/core/Zend/Feed/Writer/Renderer/Feed/Rss.php','6.3',0),('035f3635d7c6526c899d98a31960ac04','./lib/core/Zend/Feed/Writer/Renderer/RendererAbstract.php','6.3',0),('67e8c442d7c8e544885276ffd0b581a6','./lib/core/Zend/Feed/Writer/Renderer/RendererInterface.php','6.3',0),('eb76f0a94cdccfc85ad286ceaf82597c','./lib/core/Zend/Feed/Writer/Source.php','6.3',0),('52d0f6a5ab443b282989f36138fa50ab','./lib/core/Zend/File/Transfer.php','6.3',0),('a0ad5d3a51d8c285ee60fcb55cc30fca','./lib/core/Zend/File/Transfer/Adapter/Abstract.php','6.3',0),('2bd98e491d0909999401376387fd4484','./lib/core/Zend/File/Transfer/Adapter/Http.php','6.3',0),('a126c3cc5ea53045f74e6801b431aa52','./lib/core/Zend/File/Transfer/Exception.php','6.3',0),('46aa5064f9f882ff76138c813242da3d','./lib/core/Zend/Filter.php','6.3',0),('8d1fa9dffe3658f52192cfc0af0f2385','./lib/core/Zend/Filter/Alnum.php','6.3',0),('661ccf0fcfb1368148853fa9c1082882','./lib/core/Zend/Filter/Alpha.php','6.3',0),('a2d7c99e74d37a9159b7c022ab4e8a34','./lib/core/Zend/Filter/BaseName.php','6.3',0),('066cab1d912108abef9f5a20696cbfaf','./lib/core/Zend/Filter/Boolean.php','6.3',0),('4bb2828d812de5b12a7e5317c7bea25f','./lib/core/Zend/Filter/Callback.php','6.3',0),('8efa22ed2d5199f310e35c7a708306a2','./lib/core/Zend/Filter/Compress.php','6.3',0),('aa4d16d24620203fd20f97f633bf8680','./lib/core/Zend/Filter/Compress/Bz2.php','6.3',0),('1b06019bf68f13be2f8f07658a32b1bc','./lib/core/Zend/Filter/Compress/CompressAbstract.php','6.3',0),('57dc11590120af393023a57c108b9712','./lib/core/Zend/Filter/Compress/CompressInterface.php','6.3',0),('439fa393e7f8880065137bbb959ab186','./lib/core/Zend/Filter/Compress/Gz.php','6.3',0),('541c3c3b1d3a6bec8e97efc3f06de907','./lib/core/Zend/Filter/Compress/Lzf.php','6.3',0),('ed39c2fff1a918fb8450de12c8d58d6d','./lib/core/Zend/Filter/Compress/Rar.php','6.3',0),('39b6bf60127f5fcceb2b02142669e97b','./lib/core/Zend/Filter/Compress/Tar.php','6.3',0),('51403d6151e1572b33877080284bc285','./lib/core/Zend/Filter/Compress/Zip.php','6.3',0),('912d428662170950cfee0cb45718c2f6','./lib/core/Zend/Filter/Decompress.php','6.3',0),('f96be997c62a42a5538e37c57f1b9724','./lib/core/Zend/Filter/Decrypt.php','6.3',0),('2c329a3c4167ad050c9cc1b113a1173e','./lib/core/Zend/Filter/Digits.php','6.3',0),('057011be5510e20ba509843a6562801a','./lib/core/Zend/Filter/Dir.php','6.3',0),('92b3b4ffaf104a7825163f89abe7844e','./lib/core/Zend/Filter/Encrypt.php','6.3',0),('b8819a18065178fe2353dd76be8c5791','./lib/core/Zend/Filter/Encrypt/Interface.php','6.3',0),('693e72ecf0e52728c76f17702c192259','./lib/core/Zend/Filter/Encrypt/Mcrypt.php','6.3',0),('9cf5b3a81f6600c1dd9aacdd9de3640d','./lib/core/Zend/Filter/Encrypt/Openssl.php','6.3',0),('08569414208cd5fb16852e88abbba0ac','./lib/core/Zend/Filter/Exception.php','6.3',0),('67749620fd977e114c8cc6951218ef46','./lib/core/Zend/Filter/File/Decrypt.php','6.3',0),('adf19c1314e7a89c8ed92a7828623865','./lib/core/Zend/Filter/File/Encrypt.php','6.3',0),('3d5d4e487002d073ec68485f12d26164','./lib/core/Zend/Filter/File/LowerCase.php','6.3',0),('dcab41fd42517d034612faab15081751','./lib/core/Zend/Filter/File/Rename.php','6.3',0),('b26254af2a019631b7192ffd59819a8c','./lib/core/Zend/Filter/File/UpperCase.php','6.3',0),('d1dbae1a5ce00105fc98f0be7807a6eb','./lib/core/Zend/Filter/HtmlEntities.php','6.3',0),('9408fd2502fe4f5d81d3c8eee5924dd2','./lib/core/Zend/Filter/Inflector.php','6.3',0),('8c26eac1423072fd88f776c9f4bb494d','./lib/core/Zend/Filter/Input.php','6.3',0),('33ea5f988108f3c9aafb2246b8d0471e','./lib/core/Zend/Filter/Int.php','6.3',0),('28c0b9ef2d067bbc5f3657828e9e0692','./lib/core/Zend/Filter/Interface.php','6.3',0),('b935764ce8ab0196da4f85e112e8f195','./lib/core/Zend/Filter/LocalizedToNormalized.php','6.3',0),('2a2450df53294030293941fb748dc7f1','./lib/core/Zend/Filter/NormalizedToLocalized.php','6.3',0),('3fab4ae154d73aff458a24de7f2f4728','./lib/core/Zend/Filter/Null.php','6.3',0),('ce732a7b37a4d761615cf95c8f687afb','./lib/core/Zend/Filter/PregReplace.php','6.3',0),('804ece04e5f024edd07234755637b795','./lib/core/Zend/Filter/RealPath.php','6.3',0),('593d43cfc7fbf3430f47751f1959fa77','./lib/core/Zend/Filter/StringToLower.php','6.3',0),('b863b95a9dd508c05eff33785b6b224d','./lib/core/Zend/Filter/StringToUpper.php','6.3',0),('e3f19f27fa7f75c25b516c50f3a1fb3d','./lib/core/Zend/Filter/StringTrim.php','6.3',0),('c25fa755332bd184db08b38500a128fc','./lib/core/Zend/Filter/StripNewlines.php','6.3',0),('f46470c7e29c51084c105af45d4a8f25','./lib/core/Zend/Filter/StripTags.php','6.3',0),('ba1342d52db419cf702ee8227a186af0','./lib/core/Zend/Filter/Word/CamelCaseToDash.php','6.3',0),('b80f8836ee087c1562d4e086be00b9f1','./lib/core/Zend/Filter/Word/CamelCaseToSeparator.php','6.3',0),('d8a25a6beade772f0ff5762b0609ac86','./lib/core/Zend/Filter/Word/CamelCaseToUnderscore.php','6.3',0),('8338945d465a6ac98309d1690a50f18a','./lib/core/Zend/Filter/Word/DashToCamelCase.php','6.3',0),('bc2ea76bcd9e91f32c85a3506fb0249b','./lib/core/Zend/Filter/Word/DashToSeparator.php','6.3',0),('5bfdf0d5711f443544211877aec7b6a7','./lib/core/Zend/Filter/Word/DashToUnderscore.php','6.3',0),('2fce3ddeb62689658ec4bd32e230bce7','./lib/core/Zend/Filter/Word/Separator/Abstract.php','6.3',0),('68ac4157d35c21e95d1db1718aa99707','./lib/core/Zend/Filter/Word/SeparatorToCamelCase.php','6.3',0),('cc4d0ec56d410ca34a547668ab8f34a3','./lib/core/Zend/Filter/Word/SeparatorToDash.php','6.3',0),('9c79982eacbb45cf4babc247b5caea06','./lib/core/Zend/Filter/Word/SeparatorToSeparator.php','6.3',0),('1f378e43b3396228ba891893c8ec8178','./lib/core/Zend/Filter/Word/UnderscoreToCamelCase.php','6.3',0),('7dc708bd1a006132185ca7ae9d351653','./lib/core/Zend/Filter/Word/UnderscoreToDash.php','6.3',0),('a9d46a4999e465c82ab9d1f9f4dd173d','./lib/core/Zend/Filter/Word/UnderscoreToSeparator.php','6.3',0),('0335569c0dfb6ecab8867f93c9dd6257','./lib/core/Zend/Form.php','6.3',0),('0ff0b049bc0d5fdcb40d29acf656392a','./lib/core/Zend/Form/Decorator/Abstract.php','6.3',0),('01b689e56f6c536b186b9590f6982f32','./lib/core/Zend/Form/Decorator/Callback.php','6.3',0),('8d11d80dd23480687cd1bfe78b698a0e','./lib/core/Zend/Form/Decorator/Captcha.php','6.3',0),('dfcd612a6bf90581dc17d463c7ba66a3','./lib/core/Zend/Form/Decorator/Captcha/Word.php','6.3',0),('30b64125898e6295ec9ed80199b2fc78','./lib/core/Zend/Form/Decorator/Description.php','6.3',0),('229c22ea099260ef584e9b40294bf864','./lib/core/Zend/Form/Decorator/DtDdWrapper.php','6.3',0),('7a91629dd0be60384be6f03e557709d5','./lib/core/Zend/Form/Decorator/Errors.php','6.3',0),('7962a84ac4c2237f155d27f8265660b9','./lib/core/Zend/Form/Decorator/Exception.php','6.3',0),('e2fd5f5a145acf41b5c40c567f0a903a','./lib/core/Zend/Form/Decorator/Fieldset.php','6.3',0),('441e2551d0ac8262632a41dc4b379b87','./lib/core/Zend/Form/Decorator/File.php','6.3',0),('2c9a31b8aecd34b5ea9404fc6d0961ad','./lib/core/Zend/Form/Decorator/Form.php','6.3',0),('9b4aded6ab771c74e615e3c16e757fce','./lib/core/Zend/Form/Decorator/FormElements.php','6.3',0),('a0e17292bc560095149162f8a7c952ee','./lib/core/Zend/Form/Decorator/FormErrors.php','6.3',0),('f139ee89b2c84b5e2ead80767add1e29','./lib/core/Zend/Form/Decorator/HtmlTag.php','6.3',0),('652c8e5a5dac8300ebd3ea820dc76553','./lib/core/Zend/Form/Decorator/Image.php','6.3',0),('bc80c41ab5e2d65b48163f40db8da612','./lib/core/Zend/Form/Decorator/Interface.php','6.3',0),('bc71494f0371666e2022b20104b84838','./lib/core/Zend/Form/Decorator/Label.php','6.3',0),('1f52ff650a356c7fe55b5d0f9619f76a','./lib/core/Zend/Form/Decorator/Marker/File/Interface.php','6.3',0),('c35bbe77e85fcc5d497c5f6ffede82ec','./lib/core/Zend/Form/Decorator/PrepareElements.php','6.3',0),('f6ed0e3fdc995bda927bf238785fc3b5','./lib/core/Zend/Form/Decorator/Tooltip.php','6.3',0),('9eb497cc0544f54a6e5ad459ea5cb88f','./lib/core/Zend/Form/Decorator/ViewHelper.php','6.3',0),('11a2aa48135756d36aaf7ebc849e783f','./lib/core/Zend/Form/Decorator/ViewScript.php','6.3',0),('366968f378ee734432fe1ef4bfba0ffe','./lib/core/Zend/Form/DisplayGroup.php','6.3',0),('840e659c0ad424060c7b8cfaf0144202','./lib/core/Zend/Form/Element.php','6.3',0),('c618889047a2b0c0ddfd264fa64e97ba','./lib/core/Zend/Form/Element/Button.php','6.3',0),('58ddd87b27360079f62a1e0dcd4433ef','./lib/core/Zend/Form/Element/Captcha.php','6.3',0),('0e04644f09eeb054ab0b77e937a85845','./lib/core/Zend/Form/Element/Checkbox.php','6.3',0),('adedfae71f4f52ec842611ca61c11f0d','./lib/core/Zend/Form/Element/Exception.php','6.3',0),('fee5099aa9cd19e6d45e01e842853bfd','./lib/core/Zend/Form/Element/File.php','6.3',0),('3934538f705f80fc7f81b5f444eb6bd0','./lib/core/Zend/Form/Element/Hash.php','6.3',0),('95e6af6ed843bbe376a7069fbc33da53','./lib/core/Zend/Form/Element/Hidden.php','6.3',0),('8f8309003699a78ee5f8ff0900333470','./lib/core/Zend/Form/Element/Image.php','6.3',0),('cb29968989e7761c9499ef2f1e3d28eb','./lib/core/Zend/Form/Element/Multi.php','6.3',0),('b2ba22e72489e3f224e9c934a7352c38','./lib/core/Zend/Form/Element/MultiCheckbox.php','6.3',0),('7bb5825790cc945fb9ed30b4a229b854','./lib/core/Zend/Form/Element/Multiselect.php','6.3',0),('f2cbcd045cd2babe9da2b33246b4cc69','./lib/core/Zend/Form/Element/Password.php','6.3',0),('9c12588d892ac213460f26a4b3eb11a1','./lib/core/Zend/Form/Element/Radio.php','6.3',0),('ea03efe270a47e1ca270e9a017f61109','./lib/core/Zend/Form/Element/Reset.php','6.3',0),('9c32b088b8ec945a26cd01a07d75fccd','./lib/core/Zend/Form/Element/Select.php','6.3',0),('dde981f26441b382b7887e25b4dfa7a5','./lib/core/Zend/Form/Element/Submit.php','6.3',0),('8ffcb474d4bd25872ce6d7ca40de729a','./lib/core/Zend/Form/Element/Text.php','6.3',0),('3f89cc0d94d7dec7445f34672c874898','./lib/core/Zend/Form/Element/Textarea.php','6.3',0),('998cdfba44b4cc11145f5d3475abea82','./lib/core/Zend/Form/Element/Xhtml.php','6.3',0),('9b2a506f74225e54538ec566c8104e7d','./lib/core/Zend/Form/Exception.php','6.3',0),('0d6a25eccc18fff70e01954cd6837bde','./lib/core/Zend/Form/SubForm.php','6.3',0),('ca016ddd44d4df6766dadd200dbca45c','./lib/core/Zend/Gdata.php','6.3',0),('a4541b9afd4272f19a14cbcbecc7919e','./lib/core/Zend/Gdata/App.php','6.3',0),('897265f3a388c7824c81cbe618c46ecd','./lib/core/Zend/Gdata/App/AuthException.php','6.3',0),('0d72d7043d5e0cd3909d8c2c5e4c5bad','./lib/core/Zend/Gdata/App/BadMethodCallException.php','6.3',0),('567e5b62065b714eb0feb6e3cabe6966','./lib/core/Zend/Gdata/App/Base.php','6.3',0),('e49caac8543569d8684ab203196ed656','./lib/core/Zend/Gdata/App/BaseMediaSource.php','6.3',0),('9bcffb74c66d97221909256e8caa8561','./lib/core/Zend/Gdata/App/CaptchaRequiredException.php','6.3',0),('f3f1078c84d4463cda82d4ca7c0c1875','./lib/core/Zend/Gdata/App/Entry.php','6.3',0),('1080dcfd1ca365b4542c3f64be911a4d','./lib/core/Zend/Gdata/App/Exception.php','6.3',0),('79cf3931bf03dd72f9847e463786a1f6','./lib/core/Zend/Gdata/App/Extension.php','6.3',0),('69aa50c2b9cfe23076c8a9c5c29be630','./lib/core/Zend/Gdata/App/Extension/Author.php','6.3',0),('51856b3e790e7d38acae196964a22e09','./lib/core/Zend/Gdata/App/Extension/Category.php','6.3',0),('40da31c93e1a0b69256dc65cee3c70c5','./lib/core/Zend/Gdata/App/Extension/Content.php','6.3',0),('690f68bbbe17648ccfbffe31ecdd9d46','./lib/core/Zend/Gdata/App/Extension/Contributor.php','6.3',0),('d34505a92910743b4d3c013c0ec6908e','./lib/core/Zend/Gdata/App/Extension/Control.php','6.3',0),('ef0aadcf550c1e11ad178dc7965d3489','./lib/core/Zend/Gdata/App/Extension/Draft.php','6.3',0),('b8f4eab2f0d9e83acc8159a9167639eb','./lib/core/Zend/Gdata/App/Extension/Edited.php','6.3',0),('6098bcefbf91691da4f43b23054fca39','./lib/core/Zend/Gdata/App/Extension/Element.php','6.3',0),('8152730b25011c2f44dd0654de8ee70a','./lib/core/Zend/Gdata/App/Extension/Email.php','6.3',0),('0da88009b3250bdc838c63c0f44d736c','./lib/core/Zend/Gdata/App/Extension/Generator.php','6.3',0),('3411ecc66299adf30bc919af91a9abf4','./lib/core/Zend/Gdata/App/Extension/Icon.php','6.3',0),('13d248661168a1ceba6674b1381452eb','./lib/core/Zend/Gdata/App/Extension/Id.php','6.3',0),('044239fd0090511f9f0e767fe04a0cfc','./lib/core/Zend/Gdata/App/Extension/Link.php','6.3',0),('a2744c8b879d3b0443aa8b191c974b46','./lib/core/Zend/Gdata/App/Extension/Logo.php','6.3',0),('f32d50bf3edfcd8f2e48458d725c17b8','./lib/core/Zend/Gdata/App/Extension/Name.php','6.3',0),('525401c3385190767ddba4287930efb3','./lib/core/Zend/Gdata/App/Extension/Person.php','6.3',0),('61d82ca88ae613a689aeca3ee269aa06','./lib/core/Zend/Gdata/App/Extension/Published.php','6.3',0),('f71732f574b5a887b94d4d17c1daa8a8','./lib/core/Zend/Gdata/App/Extension/Rights.php','6.3',0),('2266fad27fd7802b022f5976bce37b52','./lib/core/Zend/Gdata/App/Extension/Source.php','6.3',0),('cfe01e13a9b1a06544399e83004c8b33','./lib/core/Zend/Gdata/App/Extension/Subtitle.php','6.3',0),('2971f80a5d54bab6ff338130a2a01d63','./lib/core/Zend/Gdata/App/Extension/Summary.php','6.3',0),('d1fae06ab65c2f9cf5f32f81160cfa36','./lib/core/Zend/Gdata/App/Extension/Text.php','6.3',0),('5119081c6c536271065f602970ca9898','./lib/core/Zend/Gdata/App/Extension/Title.php','6.3',0),('e1e3cdbc4b6a157c7914dc7146e4f3fb','./lib/core/Zend/Gdata/App/Extension/Updated.php','6.3',0),('8a02c28c423915f4c1a99cb1146142a6','./lib/core/Zend/Gdata/App/Extension/Uri.php','6.3',0),('7770626b7f218bf00b3f109690b4cf3d','./lib/core/Zend/Gdata/App/Feed.php','6.3',0),('42b10aae8efbd53388a3057cc0c3a7e6','./lib/core/Zend/Gdata/App/FeedEntryParent.php','6.3',0),('2b024926fcfd541caccf2545bd95147a','./lib/core/Zend/Gdata/App/FeedSourceParent.php','6.3',0),('05a1aac0ad48bdeab07182bf0c605cdd','./lib/core/Zend/Gdata/App/HttpException.php','6.3',0),('00110fd5fe30f93f562754f65c038a96','./lib/core/Zend/Gdata/App/IOException.php','6.3',0),('5268441307f48303c631bcbface43af9','./lib/core/Zend/Gdata/App/InvalidArgumentException.php','6.3',0),('a5313cc496157e7bef6e7332a1bb06c3','./lib/core/Zend/Gdata/App/LoggingHttpClientAdapterSocket.php','6.3',0),('fa53821a66825262d67f9f0631e35983','./lib/core/Zend/Gdata/App/MediaEntry.php','6.3',0),('8bda1776d8f4889e85c72d08226c095b','./lib/core/Zend/Gdata/App/MediaFileSource.php','6.3',0),('26fb7760afd66b0712fdb214800040f8','./lib/core/Zend/Gdata/App/MediaSource.php','6.3',0),('876375f4a702a72736cdc3f59be3b45a','./lib/core/Zend/Gdata/App/Util.php','6.3',0),('ba961eb4b3027e787aa72c2edcde3078','./lib/core/Zend/Gdata/App/VersionException.php','6.3',0),('9c8090e08c8402b30cc6e302aabf5d62','./lib/core/Zend/Gdata/AuthSub.php','6.3',0),('ad7f1979f642292cb899dfa56b83ae92','./lib/core/Zend/Gdata/Books.php','6.3',0),('0c159bbc459e0ec707f2e88d91918239','./lib/core/Zend/Gdata/Books/CollectionEntry.php','6.3',0),('ccd68ec97def69e09790d0d66d2d374b','./lib/core/Zend/Gdata/Books/CollectionFeed.php','6.3',0),('6d53dd37e1d03614694b5fe49b58b0a7','./lib/core/Zend/Gdata/Books/Extension/AnnotationLink.php','6.3',0),('b5f5f15251be9e273095f42459703306','./lib/core/Zend/Gdata/Books/Extension/BooksCategory.php','6.3',0),('b6995c1471a2862e8960ccd4f35769ff','./lib/core/Zend/Gdata/Books/Extension/BooksLink.php','6.3',0),('b9edd10e51809119c06b76458ba4d8d3','./lib/core/Zend/Gdata/Books/Extension/Embeddability.php','6.3',0),('346a5ea0b631c37b1043b246d0e95123','./lib/core/Zend/Gdata/Books/Extension/InfoLink.php','6.3',0),('1740ef86526ba8e8cbd48ed6ebec9b0d','./lib/core/Zend/Gdata/Books/Extension/PreviewLink.php','6.3',0),('5f3d34be403ddfa4d328658e0bb9459a','./lib/core/Zend/Gdata/Books/Extension/Review.php','6.3',0),('8efda5e42cca67745dd544d4c3aca19b','./lib/core/Zend/Gdata/Books/Extension/ThumbnailLink.php','6.3',0),('ce07e4c22c34090fc4cccc82ace9e020','./lib/core/Zend/Gdata/Books/Extension/Viewability.php','6.3',0),('dedaaddca7a00094f38e509d78673a14','./lib/core/Zend/Gdata/Books/VolumeEntry.php','6.3',0),('7faa26c5fe3c63020d93d78fbcd2b969','./lib/core/Zend/Gdata/Books/VolumeFeed.php','6.3',0),('566efebfb867f0b4192b2519b2f191e2','./lib/core/Zend/Gdata/Books/VolumeQuery.php','6.3',0),('d298012fadfbe3afe86342db8797b3ed','./lib/core/Zend/Gdata/Calendar.php','6.3',0),('9a6c917dc3c4f53340a2a1f80f0ec08a','./lib/core/Zend/Gdata/Calendar/EventEntry.php','6.3',0),('d45ff3fda485aceb4be52579decfec9c','./lib/core/Zend/Gdata/Calendar/EventFeed.php','6.3',0),('e72755bf075b7b0ebd7165b66404355a','./lib/core/Zend/Gdata/Calendar/EventQuery.php','6.3',0),('c806befdb5de885b5443621daaf98802','./lib/core/Zend/Gdata/Calendar/Extension/AccessLevel.php','6.3',0),('724b9f3a4cd82a0db257a18ee86a6704','./lib/core/Zend/Gdata/Calendar/Extension/Color.php','6.3',0),('41313c7eb8d5ad10e1791baee651bcaa','./lib/core/Zend/Gdata/Calendar/Extension/Hidden.php','6.3',0),('658337ef549cea3a92791bae799aecef','./lib/core/Zend/Gdata/Calendar/Extension/Link.php','6.3',0),('258668f2769b244684f774484f850836','./lib/core/Zend/Gdata/Calendar/Extension/QuickAdd.php','6.3',0),('5fd7fbb2ba4e7e0e4940dc5577dbbd9a','./lib/core/Zend/Gdata/Calendar/Extension/Selected.php','6.3',0),('1c891fcabaace5ab6267af44d2bb7337','./lib/core/Zend/Gdata/Calendar/Extension/SendEventNotifications.php','6.3',0),('b81fe7257471c692c870537c429c9019','./lib/core/Zend/Gdata/Calendar/Extension/Timezone.php','6.3',0),('1b506caae4ff4fa2caf8fe7fbf18be64','./lib/core/Zend/Gdata/Calendar/Extension/WebContent.php','6.3',0),('847b65bd94a4f70b1485c533a9bebfb5','./lib/core/Zend/Gdata/Calendar/ListEntry.php','6.3',0),('756347233a86358f1b32ebc1499cb467','./lib/core/Zend/Gdata/Calendar/ListFeed.php','6.3',0),('9d3c09bbcd83ec51d4ab4a47929d67ca','./lib/core/Zend/Gdata/ClientLogin.php','6.3',0),('4619753c54b1acaea35d218510a02a17','./lib/core/Zend/Gdata/Docs.php','6.3',0),('36b3e3a0dfdcd9d4fecc8fb9e8208778','./lib/core/Zend/Gdata/Docs/DocumentListEntry.php','6.3',0),('5472cb92a451a226db091156443f69fc','./lib/core/Zend/Gdata/Docs/DocumentListFeed.php','6.3',0),('87724a35c02a9e8a64d3028c227a3f19','./lib/core/Zend/Gdata/Docs/Query.php','6.3',0),('f37d104b3d5cd04600e2c98d48dfe15b','./lib/core/Zend/Gdata/DublinCore.php','6.3',0),('9eaf6544d9438282c8c03e4f49197ec9','./lib/core/Zend/Gdata/DublinCore/Extension/Creator.php','6.3',0),('206221ad5fdd47d2cb57bfbf8287706f','./lib/core/Zend/Gdata/DublinCore/Extension/Date.php','6.3',0),('b1a8b18d8ed158284fe2ee4193b72297','./lib/core/Zend/Gdata/DublinCore/Extension/Description.php','6.3',0),('f77e42a386b6e96552317f2338461d2d','./lib/core/Zend/Gdata/DublinCore/Extension/Format.php','6.3',0),('cb20e3715766afa63d0cf1c7e2246554','./lib/core/Zend/Gdata/DublinCore/Extension/Identifier.php','6.3',0),('1498cd0da605bbe5dcc57c496262b12b','./lib/core/Zend/Gdata/DublinCore/Extension/Language.php','6.3',0),('fab159e1bb69eebdaacd8754219971d3','./lib/core/Zend/Gdata/DublinCore/Extension/Publisher.php','6.3',0),('2f5fa36711681a74494169bf7fc240b7','./lib/core/Zend/Gdata/DublinCore/Extension/Rights.php','6.3',0),('0ee2c31265e05ba74d5c3b1482838fe4','./lib/core/Zend/Gdata/DublinCore/Extension/Subject.php','6.3',0),('227393b2b7dfddf6d0ba3cc167f3286c','./lib/core/Zend/Gdata/DublinCore/Extension/Title.php','6.3',0),('94290ecfdc01f7692faed81d92a59ec8','./lib/core/Zend/Gdata/Entry.php','6.3',0),('d3a651401bb9ed85bf7e3e2b9412108e','./lib/core/Zend/Gdata/Exif.php','6.3',0),('fc10a9e18ff665ca851f8217af7bd443','./lib/core/Zend/Gdata/Exif/Entry.php','6.3',0),('17daacc18153ca2ab7834291d1dc5b05','./lib/core/Zend/Gdata/Exif/Extension/Distance.php','6.3',0),('0f67b13eda99fd273cd4d248471d1125','./lib/core/Zend/Gdata/Exif/Extension/Exposure.php','6.3',0),('45d17fafd0614c314dc6694dba3496ad','./lib/core/Zend/Gdata/Exif/Extension/FStop.php','6.3',0),('5cdf0361d0ec5cb2bf5c3464ab146263','./lib/core/Zend/Gdata/Exif/Extension/Flash.php','6.3',0),('973a9fd1fea602a5b3161b77790681a4','./lib/core/Zend/Gdata/Exif/Extension/FocalLength.php','6.3',0),('93b6a89216aeba47ad683b2f278b1975','./lib/core/Zend/Gdata/Exif/Extension/ImageUniqueId.php','6.3',0),('3c099768c71f282fe9d4509c24e43c13','./lib/core/Zend/Gdata/Exif/Extension/Iso.php','6.3',0),('2450a4b725e9709469bb83ecebfc187e','./lib/core/Zend/Gdata/Exif/Extension/Make.php','6.3',0),('3d5f5b63eccb5121797bcb5d5f3eb31c','./lib/core/Zend/Gdata/Exif/Extension/Model.php','6.3',0),('414fa12f380d24afc83469c3aad2dbd3','./lib/core/Zend/Gdata/Exif/Extension/Tags.php','6.3',0),('21bad42b3b08d96788a698451082c368','./lib/core/Zend/Gdata/Exif/Extension/Time.php','6.3',0),('cd5613283530c814bffbe3ceacd55a1d','./lib/core/Zend/Gdata/Exif/Feed.php','6.3',0),('cb22d6a5fc8798169d0d605c41aa5483','./lib/core/Zend/Gdata/Extension.php','6.3',0),('013d4575d6760d1a495b888a20b55536','./lib/core/Zend/Gdata/Extension/AttendeeStatus.php','6.3',0),('5729b7214bcdc3f00dc1d41534a3bd2c','./lib/core/Zend/Gdata/Extension/AttendeeType.php','6.3',0),('cf7b30b6cc624727812ced7033f67e47','./lib/core/Zend/Gdata/Extension/Comments.php','6.3',0),('cf44ff5b7d19846b196566e9f1a20220','./lib/core/Zend/Gdata/Extension/EntryLink.php','6.3',0),('9d482730912b41b5e11558d86832ef34','./lib/core/Zend/Gdata/Extension/EventStatus.php','6.3',0),('bdd79104bc4e54f4a5b0c8ad8b7d46b6','./lib/core/Zend/Gdata/Extension/ExtendedProperty.php','6.3',0),('b45e2ab1670da033316a2eeac12d0814','./lib/core/Zend/Gdata/Extension/FeedLink.php','6.3',0),('13b6685a859b521bd39dd2ce33d0e004','./lib/core/Zend/Gdata/Extension/OpenSearchItemsPerPage.php','6.3',0),('9340fdb91ea51f005874f1179d575610','./lib/core/Zend/Gdata/Extension/OpenSearchStartIndex.php','6.3',0),('98798e6ac97f10504fcee98a80ce14e1','./lib/core/Zend/Gdata/Extension/OpenSearchTotalResults.php','6.3',0),('cb8758b57455d986481675cc589fe834','./lib/core/Zend/Gdata/Extension/OriginalEvent.php','6.3',0),('121509a09c3775c68601b792d02a8068','./lib/core/Zend/Gdata/Extension/Rating.php','6.3',0),('46fc9b3dd404049a691b062e432f2b6d','./lib/core/Zend/Gdata/Extension/Recurrence.php','6.3',0),('3744a888ef4954a03c9641d180a6c684','./lib/core/Zend/Gdata/Extension/RecurrenceException.php','6.3',0),('0d45b4f3795dc1a52dc040940cc486bd','./lib/core/Zend/Gdata/Extension/Reminder.php','6.3',0),('75138e0083533d94879d0cd06ea265e3','./lib/core/Zend/Gdata/Extension/Transparency.php','6.3',0),('17c5ca25d4c51ae3e74c656307dda538','./lib/core/Zend/Gdata/Extension/Visibility.php','6.3',0),('6f821603c1cdf06320ae942aa4a3156b','./lib/core/Zend/Gdata/Extension/When.php','6.3',0),('77fe0204566d6aeab1152edf442b8ec6','./lib/core/Zend/Gdata/Extension/Where.php','6.3',0),('358c7a2f1ff43c386d5c3a43d85529e4','./lib/core/Zend/Gdata/Extension/Who.php','6.3',0),('51577d63bd0a2934eab333b2f5dfa2ad','./lib/core/Zend/Gdata/Feed.php','6.3',0),('8dfef0ae56f62f99e23f07debd13e8f9','./lib/core/Zend/Gdata/Gapps.php','6.3',0),('37b54a7fcce8a12336019a494b68e876','./lib/core/Zend/Gdata/Gapps/EmailListEntry.php','6.3',0),('b58e14be01d5ebfb9ff8005eed91295c','./lib/core/Zend/Gdata/Gapps/EmailListFeed.php','6.3',0),('35576ef1d5ca95bd18bb5b63a604e860','./lib/core/Zend/Gdata/Gapps/EmailListQuery.php','6.3',0),('b6adc0a7d34c9c17bbbc926868357939','./lib/core/Zend/Gdata/Gapps/EmailListRecipientEntry.php','6.3',0),('341f9c47de920b948bb1c2701969bc1c','./lib/core/Zend/Gdata/Gapps/EmailListRecipientFeed.php','6.3',0),('60afc67280ccedbc44798866fe683a68','./lib/core/Zend/Gdata/Gapps/EmailListRecipientQuery.php','6.3',0),('f59c71ca31ca422e765317a7bfd93cce','./lib/core/Zend/Gdata/Gapps/Error.php','6.3',0),('08201f9dc9bcc6ea433c56950e8d6216','./lib/core/Zend/Gdata/Gapps/Extension/EmailList.php','6.3',0),('9e45981416c3a60aeb94f5641af36abf','./lib/core/Zend/Gdata/Gapps/Extension/Login.php','6.3',0),('2d1f8f4e85ab0e4a35dbe7844a89fe1d','./lib/core/Zend/Gdata/Gapps/Extension/Name.php','6.3',0),('44f73acf2a64f76787538eaa98e5dc81','./lib/core/Zend/Gdata/Gapps/Extension/Nickname.php','6.3',0),('0d3f34592b9f0ad1a7676be087770cb4','./lib/core/Zend/Gdata/Gapps/Extension/Property.php','6.3',0),('08e36fa26f6c8e250751a93ef31bbb13','./lib/core/Zend/Gdata/Gapps/Extension/Quota.php','6.3',0),('28c2efe926161c068831301cf2d30333','./lib/core/Zend/Gdata/Gapps/GroupEntry.php','6.3',0),('03d228501e23b2dcd25922ecf9c8a39e','./lib/core/Zend/Gdata/Gapps/GroupFeed.php','6.3',0),('3345ca670c03f88c2c11b68ed59539b3','./lib/core/Zend/Gdata/Gapps/GroupQuery.php','6.3',0),('16d34d4c2c54c8d72723c16990b4114b','./lib/core/Zend/Gdata/Gapps/MemberEntry.php','6.3',0),('84d62ad675354b380fc5f66a02d6e3e9','./lib/core/Zend/Gdata/Gapps/MemberFeed.php','6.3',0),('dfbacdbf4c989204af5b42ed87eef46a','./lib/core/Zend/Gdata/Gapps/MemberQuery.php','6.3',0),('2f012c32dcbb0703b769774dac41a2b9','./lib/core/Zend/Gdata/Gapps/NicknameEntry.php','6.3',0),('b03e791b5f908c75ddd256379bbcce7b','./lib/core/Zend/Gdata/Gapps/NicknameFeed.php','6.3',0),('14ceaba9bf1a265db97b43d61308ef51','./lib/core/Zend/Gdata/Gapps/NicknameQuery.php','6.3',0),('30b06921596676ffe45efa3b049c340b','./lib/core/Zend/Gdata/Gapps/OwnerEntry.php','6.3',0),('8c75c62d6980a12534722560a45ed7e1','./lib/core/Zend/Gdata/Gapps/OwnerFeed.php','6.3',0),('6499cb7464ab8ede23b13eb68b63de13','./lib/core/Zend/Gdata/Gapps/OwnerQuery.php','6.3',0),('d193492b19841da6337fe0f23f91e330','./lib/core/Zend/Gdata/Gapps/Query.php','6.3',0),('33817df4758cea163ee0d6a11987991e','./lib/core/Zend/Gdata/Gapps/ServiceException.php','6.3',0),('93839e3844047acdbba010b0da9031d2','./lib/core/Zend/Gdata/Gapps/UserEntry.php','6.3',0),('6eb44c014de1e611a45cb93100d6b007','./lib/core/Zend/Gdata/Gapps/UserFeed.php','6.3',0),('a9444eb1afa2ed325375a5c72c8e2888','./lib/core/Zend/Gdata/Gapps/UserQuery.php','6.3',0),('9a700caf1a8217cc35b0d5aa0dc72b4d','./lib/core/Zend/Gdata/Gbase.php','6.3',0),('52f3c997a273e42d710947f867f77bcd','./lib/core/Zend/Gdata/Gbase/Entry.php','6.3',0),('b9c9a6889b49d538de5863e72e4fca88','./lib/core/Zend/Gdata/Gbase/Extension/BaseAttribute.php','6.3',0),('7ad71f5b4ed3964843c0ba7099ae910f','./lib/core/Zend/Gdata/Gbase/Feed.php','6.3',0),('f01511c265889cee8561892d92951c14','./lib/core/Zend/Gdata/Gbase/ItemEntry.php','6.3',0),('07f9603349b3364fc398d8248ddc7f7c','./lib/core/Zend/Gdata/Gbase/ItemFeed.php','6.3',0),('e3b184ab78f59fe033810a664a9d0f80','./lib/core/Zend/Gdata/Gbase/ItemQuery.php','6.3',0),('c9bc0bd9a993d70b5ec8d24bdc019359','./lib/core/Zend/Gdata/Gbase/Query.php','6.3',0),('943263bd68976a5120f04952f0b08bca','./lib/core/Zend/Gdata/Gbase/SnippetEntry.php','6.3',0),('d276f14e809efb32be09a3d6634bc151','./lib/core/Zend/Gdata/Gbase/SnippetFeed.php','6.3',0),('4c509648a3ec28e37dc0db0fd643a640','./lib/core/Zend/Gdata/Gbase/SnippetQuery.php','6.3',0),('3a86d7abfa336ce4e8d4e28518ddf7d1','./lib/core/Zend/Gdata/Geo.php','6.3',0),('f2c039bd805146ce4a8dedd505d86d2f','./lib/core/Zend/Gdata/Geo/Entry.php','6.3',0),('3551b30864fc774816ca8e03b432385b','./lib/core/Zend/Gdata/Geo/Extension/GeoRssWhere.php','6.3',0),('e66c11471aaad649ab7608704d082b74','./lib/core/Zend/Gdata/Geo/Extension/GmlPoint.php','6.3',0),('bd2f7eb88f2d3130b672a3bd6aae1b01','./lib/core/Zend/Gdata/Geo/Extension/GmlPos.php','6.3',0),('14b7d72dff5f1b52ea3b399f68b5b732','./lib/core/Zend/Gdata/Geo/Feed.php','6.3',0),('e51ad20cf0bb14f578efb95deee0d2c0','./lib/core/Zend/Gdata/Health.php','6.3',0),('e0a10bff1ba75db595ef6573674d03dd','./lib/core/Zend/Gdata/Health/Extension/Ccr.php','6.3',0),('323503a02f82e7bfc4dc8e40786bbf87','./lib/core/Zend/Gdata/Health/ProfileEntry.php','6.3',0),('8f8b5c8d816991b51c59ab062a21102c','./lib/core/Zend/Gdata/Health/ProfileFeed.php','6.3',0),('125e48f750075d2b0f6ed9951abbf7a1','./lib/core/Zend/Gdata/Health/ProfileListEntry.php','6.3',0),('1ba9f1a464625010b4d4d53d81b0711e','./lib/core/Zend/Gdata/Health/ProfileListFeed.php','6.3',0),('77e7e0e1d0a4690aeb3809fbf78e2fba','./lib/core/Zend/Gdata/Health/Query.php','6.3',0),('2adaa2c9bcfb1be7d26f93cba209da44','./lib/core/Zend/Gdata/HttpAdapterStreamingProxy.php','6.3',0),('596ed30620f54ff1a7d9548b8d5037ef','./lib/core/Zend/Gdata/HttpAdapterStreamingSocket.php','6.3',0),('6f91d6cdbd25c20cf175623ed14513fd','./lib/core/Zend/Gdata/HttpClient.php','6.3',0),('5d8acc411d059b68a2603b2689bbd350','./lib/core/Zend/Gdata/Kind/EventEntry.php','6.3',0),('b652dee99d1dae7bc46b89ed4d1e2fd9','./lib/core/Zend/Gdata/Media.php','6.3',0),('8eecdee296f239bac2d18808dd78792e','./lib/core/Zend/Gdata/Media/Entry.php','6.3',0),('ad51b6ba5d6463d5b6e52cd40011ac3e','./lib/core/Zend/Gdata/Media/Extension/MediaCategory.php','6.3',0),('6a809826c84e3b5ec4596d39a552ca4c','./lib/core/Zend/Gdata/Media/Extension/MediaContent.php','6.3',0),('e66487ff6e4d7a281e34c7d29e606ea1','./lib/core/Zend/Gdata/Media/Extension/MediaCopyright.php','6.3',0),('496e4436d5d4ea367d66a1ac41773b70','./lib/core/Zend/Gdata/Media/Extension/MediaCredit.php','6.3',0),('754be86284a8e59ebf485a11f5b677f0','./lib/core/Zend/Gdata/Media/Extension/MediaDescription.php','6.3',0),('7fc2722568aace07699e1fbe4a011dae','./lib/core/Zend/Gdata/Media/Extension/MediaGroup.php','6.3',0),('fed4c2d14796f9737764e688584a6f65','./lib/core/Zend/Gdata/Media/Extension/MediaHash.php','6.3',0),('ebeb888724b597619e6e07e9dc2e63d2','./lib/core/Zend/Gdata/Media/Extension/MediaKeywords.php','6.3',0),('ecf15b50c17c7b9ce3e595e4533ef953','./lib/core/Zend/Gdata/Media/Extension/MediaPlayer.php','6.3',0),('002d5885c7b17e3bbf68f71e56105a44','./lib/core/Zend/Gdata/Media/Extension/MediaRating.php','6.3',0),('fd3da2d8f7aa3785c2184a11f13d229f','./lib/core/Zend/Gdata/Media/Extension/MediaRestriction.php','6.3',0),('7e3a226066b54315a5299bf3bac57fad','./lib/core/Zend/Gdata/Media/Extension/MediaText.php','6.3',0),('e15b2049c3944b2e2355583bcebe0846','./lib/core/Zend/Gdata/Media/Extension/MediaThumbnail.php','6.3',0),('ac1b17fa9511e1015a3895f78063df5c','./lib/core/Zend/Gdata/Media/Extension/MediaTitle.php','6.3',0),('ee02b856dad52dd2af43e1ef80d988bc','./lib/core/Zend/Gdata/Media/Feed.php','6.3',0),('98127f64a22a6be3ecabbc1803d09504','./lib/core/Zend/Gdata/MediaMimeStream.php','6.3',0),('bf4701e590e4a1f2345db3857f11dfc7','./lib/core/Zend/Gdata/MimeBodyString.php','6.3',0),('c4086b5c46d05afb25336790ef5827dd','./lib/core/Zend/Gdata/MimeFile.php','6.3',0),('9a31cfeb3051de33f8e0dd45810e88ab','./lib/core/Zend/Gdata/Photos.php','6.3',0),('a278e6ac77bd8cc5f68a495a0690e160','./lib/core/Zend/Gdata/Photos/AlbumEntry.php','6.3',0),('a9247f6fb71f85535493596d180680d7','./lib/core/Zend/Gdata/Photos/AlbumFeed.php','6.3',0),('0c868964d5649ea61af2274102033c4a','./lib/core/Zend/Gdata/Photos/AlbumQuery.php','6.3',0),('75e62841c270722bce44004c05207668','./lib/core/Zend/Gdata/Photos/CommentEntry.php','6.3',0),('9b4fb7b649b11e18c0b46e3ee6dc9141','./lib/core/Zend/Gdata/Photos/Extension/Access.php','6.3',0),('49386357ddb343d1c564435f76744076','./lib/core/Zend/Gdata/Photos/Extension/AlbumId.php','6.3',0),('d278ea054bef4cb3409aec1cd5dc85b8','./lib/core/Zend/Gdata/Photos/Extension/BytesUsed.php','6.3',0),('d3f034eacda91e951965f4cf970e3667','./lib/core/Zend/Gdata/Photos/Extension/Checksum.php','6.3',0),('ab470b2f2ddbe7061a7ccfaa1681ed71','./lib/core/Zend/Gdata/Photos/Extension/Client.php','6.3',0),('c2b0712e2f625a43b437858cbb63c6fd','./lib/core/Zend/Gdata/Photos/Extension/CommentCount.php','6.3',0),('d85bb7267f970617f167781456063102','./lib/core/Zend/Gdata/Photos/Extension/CommentingEnabled.php','6.3',0),('8ae5fc08d2c876300629c6eb7ecfe2ea','./lib/core/Zend/Gdata/Photos/Extension/Height.php','6.3',0),('f68207aa47f364a50c5ed2303af8baab','./lib/core/Zend/Gdata/Photos/Extension/Id.php','6.3',0),('3e272dd55520bc4b6d1671a3b2069097','./lib/core/Zend/Gdata/Photos/Extension/Location.php','6.3',0),('b7105528ef0008b28326b4108d5df138','./lib/core/Zend/Gdata/Photos/Extension/MaxPhotosPerAlbum.php','6.3',0),('83049866d36707d964ca8f2271f569b2','./lib/core/Zend/Gdata/Photos/Extension/Name.php','6.3',0),('6ccf6f2c8821a7075bc2d675f1f855a8','./lib/core/Zend/Gdata/Photos/Extension/Nickname.php','6.3',0),('50c4536c4ab864d0065b29a5d6d7326f','./lib/core/Zend/Gdata/Photos/Extension/NumPhotos.php','6.3',0),('859adc0eff2787cd7c665c03694834c2','./lib/core/Zend/Gdata/Photos/Extension/NumPhotosRemaining.php','6.3',0),('2ac02bda479b4be246353cd0dfd1ae32','./lib/core/Zend/Gdata/Photos/Extension/PhotoId.php','6.3',0),('36e5ed357eda5621a729b54aea060721','./lib/core/Zend/Gdata/Photos/Extension/Position.php','6.3',0),('fd66f18799d438abed8c62b0bdc53106','./lib/core/Zend/Gdata/Photos/Extension/QuotaCurrent.php','6.3',0),('d167aa03f11bb7e50e43bf58b1dad3b4','./lib/core/Zend/Gdata/Photos/Extension/QuotaLimit.php','6.3',0),('db56a1dbe035e1907e69a4d4c5ba4cb9','./lib/core/Zend/Gdata/Photos/Extension/Rotation.php','6.3',0),('74016f5c323be2a140fb65b0dd4e0753','./lib/core/Zend/Gdata/Photos/Extension/Size.php','6.3',0),('d2147260c4dee064eeab7170833b71f1','./lib/core/Zend/Gdata/Photos/Extension/Thumbnail.php','6.3',0),('28881434f423f1e27ad9991900767412','./lib/core/Zend/Gdata/Photos/Extension/Timestamp.php','6.3',0),('d6e72c114f8624095765620b93fee8d5','./lib/core/Zend/Gdata/Photos/Extension/User.php','6.3',0),('ea1fb30e08fc6030e0ed0bff7453f59d','./lib/core/Zend/Gdata/Photos/Extension/Version.php','6.3',0),('cbf6ab24c94e1a7ae4ec3b1b24aa3e80','./lib/core/Zend/Gdata/Photos/Extension/Weight.php','6.3',0),('d994934665d850c977488fc0330ad5f2','./lib/core/Zend/Gdata/Photos/Extension/Width.php','6.3',0),('6bbd478f88c4d336238730bf582538f3','./lib/core/Zend/Gdata/Photos/PhotoEntry.php','6.3',0),('e4bc1cdb97ff6609bc6b7285ef4c7c2b','./lib/core/Zend/Gdata/Photos/PhotoFeed.php','6.3',0),('133d7e93516d24ea1a5cf90d68fb8612','./lib/core/Zend/Gdata/Photos/PhotoQuery.php','6.3',0),('84a1eccf2f050161f11fd251d3adf8d9','./lib/core/Zend/Gdata/Photos/TagEntry.php','6.3',0),('b3fa04a9a9057169979dd4a826a4ce6c','./lib/core/Zend/Gdata/Photos/UserEntry.php','6.3',0),('6b938f2c70dd7957cd343c4f2ecd76dc','./lib/core/Zend/Gdata/Photos/UserFeed.php','6.3',0),('3aa05fbac246f96d497f1d43c2d7df5f','./lib/core/Zend/Gdata/Photos/UserQuery.php','6.3',0),('60253582d060f2956d7eb474b83ec810','./lib/core/Zend/Gdata/Query.php','6.3',0),('df393690e490b17bb9e18e9fd9986245','./lib/core/Zend/Gdata/Spreadsheets.php','6.3',0),('7e045ade0e848c1ca285002020d5a5f2','./lib/core/Zend/Gdata/Spreadsheets/CellEntry.php','6.3',0),('a7c0f3ab243ed504930a851074c29381','./lib/core/Zend/Gdata/Spreadsheets/CellFeed.php','6.3',0),('9153639a74477f1938dac9619ba5629b','./lib/core/Zend/Gdata/Spreadsheets/CellQuery.php','6.3',0),('de3486eee2ba033fdbc8d4b99f37c9f5','./lib/core/Zend/Gdata/Spreadsheets/DocumentQuery.php','6.3',0),('60854f2a9b9e97537ab425138be113ad','./lib/core/Zend/Gdata/Spreadsheets/Extension/Cell.php','6.3',0),('6f239dd6ec4a0a4e499949c75d6f1ea4','./lib/core/Zend/Gdata/Spreadsheets/Extension/ColCount.php','6.3',0),('a417334cc6afc3c429821a0660f3cc3e','./lib/core/Zend/Gdata/Spreadsheets/Extension/Custom.php','6.3',0),('1fa26456b73c01e1a0bf54a9a0e008ea','./lib/core/Zend/Gdata/Spreadsheets/Extension/RowCount.php','6.3',0),('f39308f53467e3f5b480a9fbf0c569fe','./lib/core/Zend/Gdata/Spreadsheets/ListEntry.php','6.3',0),('de0529b93296a4f87af7fc6bfebb78c8','./lib/core/Zend/Gdata/Spreadsheets/ListFeed.php','6.3',0),('91c911bb8fd48a8026f1711640908f8a','./lib/core/Zend/Gdata/Spreadsheets/ListQuery.php','6.3',0),('5ef75ea4bacf4ba899fabc4d95c50472','./lib/core/Zend/Gdata/Spreadsheets/SpreadsheetEntry.php','6.3',0),('2ccf34a32cf780b1add50e16bfa334f3','./lib/core/Zend/Gdata/Spreadsheets/SpreadsheetFeed.php','6.3',0),('a651d27ef12981fb09237f0c2cc0854e','./lib/core/Zend/Gdata/Spreadsheets/WorksheetEntry.php','6.3',0),('c721e15f0c0913a52a15afe0bf6a0c89','./lib/core/Zend/Gdata/Spreadsheets/WorksheetFeed.php','6.3',0),('e99ed3486e3663432fc071cc0b233839','./lib/core/Zend/Gdata/YouTube.php','6.3',0),('0cce7d5a02dfefe3b9882e787b006ae0','./lib/core/Zend/Gdata/YouTube/ActivityEntry.php','6.3',0),('c131c2483e8d70c60592bcf8599da549','./lib/core/Zend/Gdata/YouTube/ActivityFeed.php','6.3',0),('87bbe7e04cd64e646d48526bfcd9e306','./lib/core/Zend/Gdata/YouTube/CommentEntry.php','6.3',0),('e37125e9440eaa9b41767dce45c12851','./lib/core/Zend/Gdata/YouTube/CommentFeed.php','6.3',0),('1beaaffad43a61005cac479cd5a922cf','./lib/core/Zend/Gdata/YouTube/ContactEntry.php','6.3',0),('e61661028bd572dba901222c7937f545','./lib/core/Zend/Gdata/YouTube/ContactFeed.php','6.3',0),('4977098adc4f2a9f305108253186f0c4','./lib/core/Zend/Gdata/YouTube/Extension/AboutMe.php','6.3',0),('6e5949fb1c817ca5cbf7d0daa7331fbe','./lib/core/Zend/Gdata/YouTube/Extension/Age.php','6.3',0),('b0f8001ee8ac0dd7ea6514b48671fd8e','./lib/core/Zend/Gdata/YouTube/Extension/Books.php','6.3',0),('48bd682c97f795d47d1f6250e83fb1ca','./lib/core/Zend/Gdata/YouTube/Extension/Company.php','6.3',0),('400465929fae01cba3a64bc04fb868a3','./lib/core/Zend/Gdata/YouTube/Extension/Control.php','6.3',0),('b5c2d38ecc5ed5c2501dcb2ac47164d3','./lib/core/Zend/Gdata/YouTube/Extension/CountHint.php','6.3',0),('e082356d2fa0d5412c644ed3382c6d6f','./lib/core/Zend/Gdata/YouTube/Extension/Description.php','6.3',0),('51904b8b56a2a92548c31054fec04749','./lib/core/Zend/Gdata/YouTube/Extension/Duration.php','6.3',0),('1598088606362886776269b685aac42e','./lib/core/Zend/Gdata/YouTube/Extension/FirstName.php','6.3',0),('7be854efc91c1a5feff3e9068570f16b','./lib/core/Zend/Gdata/YouTube/Extension/Gender.php','6.3',0),('11e95b4347cf4727ba2216e1ed04101c','./lib/core/Zend/Gdata/YouTube/Extension/Hobbies.php','6.3',0),('16b6709a6b196f6592e77f01b290f03b','./lib/core/Zend/Gdata/YouTube/Extension/Hometown.php','6.3',0),('595725fa9f678b68cb1fb5523bc225b3','./lib/core/Zend/Gdata/YouTube/Extension/LastName.php','6.3',0),('247bea8f33e32d2943d834e9fc44ee9e','./lib/core/Zend/Gdata/YouTube/Extension/Link.php','6.3',0),('4f6be10e9d4bbadb6811a5b1c41f2e76','./lib/core/Zend/Gdata/YouTube/Extension/Location.php','6.3',0),('9badfdf522680b4686efcf5d1a31288e','./lib/core/Zend/Gdata/YouTube/Extension/MediaContent.php','6.3',0),('acc6e83d58be3e2a3e2eba190077762b','./lib/core/Zend/Gdata/YouTube/Extension/MediaCredit.php','6.3',0),('9a419e2c47bbb75a9109af9feabd6294','./lib/core/Zend/Gdata/YouTube/Extension/MediaGroup.php','6.3',0),('ed16309c5bd80f5a988affa33005297e','./lib/core/Zend/Gdata/YouTube/Extension/MediaRating.php','6.3',0),('0c540616b44cd4ca85ecdd1589f3ba57','./lib/core/Zend/Gdata/YouTube/Extension/Movies.php','6.3',0),('45d01c5de043ce17be4bd78d94dc3d0e','./lib/core/Zend/Gdata/YouTube/Extension/Music.php','6.3',0),('360164caa5d7fa5717914f7ce093d9bb','./lib/core/Zend/Gdata/YouTube/Extension/NoEmbed.php','6.3',0),('23d59d1025d0fd43ceb1106a99a0a363','./lib/core/Zend/Gdata/YouTube/Extension/Occupation.php','6.3',0),('d3dc1f733cc49d6bf2e23afc3fb9052a','./lib/core/Zend/Gdata/YouTube/Extension/PlaylistId.php','6.3',0),('08c15fe3cb3285a1ade2ab324062f480','./lib/core/Zend/Gdata/YouTube/Extension/PlaylistTitle.php','6.3',0),('0ecbef89e6342cfbb8e82050cf35a415','./lib/core/Zend/Gdata/YouTube/Extension/Position.php','6.3',0),('19e9ba3e45b9613f632c32584799f1ae','./lib/core/Zend/Gdata/YouTube/Extension/Private.php','6.3',0),('4642625ceee19c6cdf52125cb5fed7b6','./lib/core/Zend/Gdata/YouTube/Extension/QueryString.php','6.3',0),('617d5031a5651e09a61248638c411324','./lib/core/Zend/Gdata/YouTube/Extension/Racy.php','6.3',0),('dfbd4b79b4834d439ff72c552a30e649','./lib/core/Zend/Gdata/YouTube/Extension/Recorded.php','6.3',0),('f1b321bbf2e05197c7bf017d474d6137','./lib/core/Zend/Gdata/YouTube/Extension/Relationship.php','6.3',0),('86695e18d27766441e9ec859f2f093b3','./lib/core/Zend/Gdata/YouTube/Extension/ReleaseDate.php','6.3',0),('cfa293cc040d854eb2329653cece7112','./lib/core/Zend/Gdata/YouTube/Extension/School.php','6.3',0),('6a2963bd74c4e9df8be7946c35f65c90','./lib/core/Zend/Gdata/YouTube/Extension/State.php','6.3',0),('8b9c8959af006a423bc9de23cd034e05','./lib/core/Zend/Gdata/YouTube/Extension/Statistics.php','6.3',0),('9e234c4488290159d6a70725b256e668','./lib/core/Zend/Gdata/YouTube/Extension/Status.php','6.3',0),('d210ffad83dc612958f00b52877c0c95','./lib/core/Zend/Gdata/YouTube/Extension/Token.php','6.3',0),('9885df747d11037994351ac2be7a4142','./lib/core/Zend/Gdata/YouTube/Extension/Uploaded.php','6.3',0),('e0ef78c2135eef50c4662a245604ec31','./lib/core/Zend/Gdata/YouTube/Extension/Username.php','6.3',0),('1ea5063d4f5a5374a3f5a0fd3b56ab90','./lib/core/Zend/Gdata/YouTube/Extension/VideoId.php','6.3',0),('749531500540ac2f671ce549919200b5','./lib/core/Zend/Gdata/YouTube/InboxEntry.php','6.3',0),('d1ff11ba36a519786bfb6cfe2ed11223','./lib/core/Zend/Gdata/YouTube/InboxFeed.php','6.3',0),('7b7942d21fe6f9848dd69af1bb0aa581','./lib/core/Zend/Gdata/YouTube/MediaEntry.php','6.3',0),('b335e61cf1707a004f845c859348877c','./lib/core/Zend/Gdata/YouTube/PlaylistListEntry.php','6.3',0),('e9476864b5035ca9fc688c51bc3fdcf5','./lib/core/Zend/Gdata/YouTube/PlaylistListFeed.php','6.3',0),('82c9567946b88afdb198c35a707c05a5','./lib/core/Zend/Gdata/YouTube/PlaylistVideoEntry.php','6.3',0),('d3e31781f58b19eed56c3e6b41ef7a3a','./lib/core/Zend/Gdata/YouTube/PlaylistVideoFeed.php','6.3',0),('74040415208c2458613204f0d0e7278a','./lib/core/Zend/Gdata/YouTube/SubscriptionEntry.php','6.3',0),('9938cd0a2d98b29d6226f3db61df3c18','./lib/core/Zend/Gdata/YouTube/SubscriptionFeed.php','6.3',0),('ec2013a331858b4eae598b58913dc29c','./lib/core/Zend/Gdata/YouTube/UserProfileEntry.php','6.3',0),('7e499497771cf90f3734fdbf95dd2710','./lib/core/Zend/Gdata/YouTube/VideoEntry.php','6.3',0),('9086780b1c4a9908638fc42faac0a952','./lib/core/Zend/Gdata/YouTube/VideoFeed.php','6.3',0),('fa8f40e1972d27f82d9608b6e26cd812','./lib/core/Zend/Gdata/YouTube/VideoQuery.php','6.3',0),('2005e24dd4f88ecf6a35ee13eacdcdeb','./lib/core/Zend/Http/Client.php','6.3',0),('b72e0f0495b60481ae32f08f0ee2ec09','./lib/core/Zend/Http/Client/Adapter/Curl.php','6.3',0),('def7f4ad433bf5cbc713374fc3d05b52','./lib/core/Zend/Http/Client/Adapter/Exception.php','6.3',0),('d9051a5567fa46be590fc4d81c813f79','./lib/core/Zend/Http/Client/Adapter/Interface.php','6.3',0),('53932e84942a7d1bf1067919f81ad53d','./lib/core/Zend/Http/Client/Adapter/Proxy.php','6.3',0),('99c1989a8f28d0ff1649f7597a128f96','./lib/core/Zend/Http/Client/Adapter/Socket.php','6.3',0),('37329e310317a4a257cf8f249d730474','./lib/core/Zend/Http/Client/Adapter/Stream.php','6.3',0),('710410b85972847385229d8f505bbd8b','./lib/core/Zend/Http/Client/Adapter/Test.php','6.3',0),('cd577813c4fdf04d44d72f65de87ca60','./lib/core/Zend/Http/Client/Exception.php','6.3',0),('4add982e5d76f3732f69a34c943e674f','./lib/core/Zend/Http/Cookie.php','6.3',0),('05a240d667385737e71b0af9618b8fd8','./lib/core/Zend/Http/CookieJar.php','6.3',0),('abf90d4872b8e5d09650c9730e573f88','./lib/core/Zend/Http/Exception.php','6.3',0),('d68eae655695abd3b548a6a2a5d729af','./lib/core/Zend/Http/Response.php','6.3',0),('e1a2547a90470d8c69c9088ed45454e5','./lib/core/Zend/Http/Response/Stream.php','6.3',0),('364da3a56aa7c707c8de3a572596cea5','./lib/core/Zend/InfoCard.php','6.3',0),('7125fffc227869651c606d7229f83808','./lib/core/Zend/InfoCard/Adapter/Default.php','6.3',0),('329826fd6b6aebe4e753e001a985bbe8','./lib/core/Zend/InfoCard/Adapter/Exception.php','6.3',0),('7b17670f540ee37492a60108431a6580','./lib/core/Zend/InfoCard/Adapter/Interface.php','6.3',0),('9f864528589bd13a0a4b6c5bbfef5bf7','./lib/core/Zend/InfoCard/Cipher.php','6.3',0),('1b795d0db73effc0651821208c1e3fe9','./lib/core/Zend/InfoCard/Cipher/Exception.php','6.3',0),('f29da48555064e26a4993d4b479e1402','./lib/core/Zend/InfoCard/Cipher/Pki/Adapter/Abstract.php','6.3',0),('5b673f96dbc12a7a4bc6381647ad9ace','./lib/core/Zend/InfoCard/Cipher/Pki/Adapter/Rsa.php','6.3',0),('0acb5d79523db6315a0365738683ab1c','./lib/core/Zend/InfoCard/Cipher/Pki/Interface.php','6.3',0),('f786b8765af5595d293c7ac595ec85e4','./lib/core/Zend/InfoCard/Cipher/Pki/Rsa/Interface.php','6.3',0),('25f8933e94105061bff3e8402a6799b3','./lib/core/Zend/InfoCard/Cipher/Symmetric/Adapter/Abstract.php','6.3',0),('541b279802788b7432fef407b9e3cd01','./lib/core/Zend/InfoCard/Cipher/Symmetric/Adapter/Aes128cbc.php','6.3',0),('fba2b869bb1df54a019c8ee59a966abe','./lib/core/Zend/InfoCard/Cipher/Symmetric/Adapter/Aes256cbc.php','6.3',0),('53580e699564c3bbacca31dbe687ca29','./lib/core/Zend/InfoCard/Cipher/Symmetric/Aes128cbc/Interface.php','6.3',0),('d38e17a8347031b93c03012cb127cf6c','./lib/core/Zend/InfoCard/Cipher/Symmetric/Aes256cbc/Interface.php','6.3',0),('7b6f42afc7a6e87c2fcd063f9d0410d0','./lib/core/Zend/InfoCard/Cipher/Symmetric/Interface.php','6.3',0),('8691dc4f484eb8f234da06826d41faf3','./lib/core/Zend/InfoCard/Claims.php','6.3',0),('cccc2408c4f92b00d7e28b73db59608e','./lib/core/Zend/InfoCard/Exception.php','6.3',0),('3dc78fc02c87681f856c6ca01612aee8','./lib/core/Zend/InfoCard/Xml/Assertion.php','6.3',0),('475c4f340ea70909cedea7cec9f32b6a','./lib/core/Zend/InfoCard/Xml/Assertion/Interface.php','6.3',0),('29b5770a03c9ab3947b5961e290e9541','./lib/core/Zend/InfoCard/Xml/Assertion/Saml.php','6.3',0),('f5a82fa9774c952d1128443eef08d889','./lib/core/Zend/InfoCard/Xml/Element.php','6.3',0),('0c1989eaf63f330160211e78fb0197ef','./lib/core/Zend/InfoCard/Xml/Element/Interface.php','6.3',0),('5d82cb340f46174b501df05c784590a2','./lib/core/Zend/InfoCard/Xml/EncryptedData.php','6.3',0),('028a06d7739ebc4bb6d9a189388fc47c','./lib/core/Zend/InfoCard/Xml/EncryptedData/Abstract.php','6.3',0),('9a399215e4b539a5dc8cae5b669dad8d','./lib/core/Zend/InfoCard/Xml/EncryptedData/XmlEnc.php','6.3',0),('e9710ed3ba43850d7a8fef343775fd5f','./lib/core/Zend/InfoCard/Xml/EncryptedKey.php','6.3',0),('7b985e6421d7f90b43dc8c55e87150e0','./lib/core/Zend/InfoCard/Xml/Exception.php','6.3',0),('dcfc7af8cab0be4f51791983a9830715','./lib/core/Zend/InfoCard/Xml/KeyInfo.php','6.3',0),('9189485428c7b4ba421255537a05fb5b','./lib/core/Zend/InfoCard/Xml/KeyInfo/Abstract.php','6.3',0),('42210a06af7a203e6117549d9b5b7eaf','./lib/core/Zend/InfoCard/Xml/KeyInfo/Default.php','6.3',0),('5849c079546412622d571e22012cb0f0','./lib/core/Zend/InfoCard/Xml/KeyInfo/Interface.php','6.3',0),('7fc0d0a0bea50f0eb777d7b9d4aae68c','./lib/core/Zend/InfoCard/Xml/KeyInfo/XmlDSig.php','6.3',0),('f14719d154fcc9aea9110a64e3bbe400','./lib/core/Zend/InfoCard/Xml/Security.php','6.3',0),('e05f7f7b83efb6a412f43f5377fa1c0b','./lib/core/Zend/InfoCard/Xml/Security/Exception.php','6.3',0),('0a5fc4932343aa03f2fa51654c51efe0','./lib/core/Zend/InfoCard/Xml/Security/Transform.php','6.3',0),('dafbb1753ebda53e9a6d2c6cd03d66d8','./lib/core/Zend/InfoCard/Xml/Security/Transform/EnvelopedSignature.php','6.3',0),('4372d19b97143061e6af3f36a58d99a0','./lib/core/Zend/InfoCard/Xml/Security/Transform/Exception.php','6.3',0),('50ac5fff0249afca49a95a7713c2f8fb','./lib/core/Zend/InfoCard/Xml/Security/Transform/Interface.php','6.3',0),('ab51d3a2b58be7152d7c495cb885fdc8','./lib/core/Zend/InfoCard/Xml/Security/Transform/XmlExcC14N.php','6.3',0),('bcae2fefcb93563c45f61b0777563e69','./lib/core/Zend/InfoCard/Xml/SecurityTokenReference.php','6.3',0),('62715221d3b96e0ecdbb92a2397c3054','./lib/core/Zend/Json.php','6.3',0),('ec5246cf351fddcd19d7c2508437937b','./lib/core/Zend/Json/Decoder.php','6.3',0),('412c338f8593409b19992804fd517b77','./lib/core/Zend/Json/Encoder.php','6.3',0),('e7dbee0b148a80926a1cb92aee503086','./lib/core/Zend/Json/Exception.php','6.3',0),('7a40039b5e3100725a598ae4bf7c60cd','./lib/core/Zend/Json/Expr.php','6.3',0),('7ec40d8f6963abee04edb8ada0d9ba38','./lib/core/Zend/Json/Server.php','6.3',0),('f0c83e556711f956fc4d43fb252f70c4','./lib/core/Zend/Json/Server/Cache.php','6.3',0),('15ae6f90c4977e7d3c3cebe84f862c5d','./lib/core/Zend/Json/Server/Error.php','6.3',0),('3506f8157064f60a189b003420a74d5e','./lib/core/Zend/Json/Server/Exception.php','6.3',0),('c08edcf82dec7fa53e0dc38c807dd593','./lib/core/Zend/Json/Server/Request.php','6.3',0),('31bf74b8f9b2e7ff380356a1eb5866d2','./lib/core/Zend/Json/Server/Request/Http.php','6.3',0),('0ba2a61b5239fbabfb37d3d4887d0461','./lib/core/Zend/Json/Server/Response.php','6.3',0),('81a4911923fb1227b0256e33fb5ab633','./lib/core/Zend/Json/Server/Response/Http.php','6.3',0),('76da58c6b5e2a170cd858fad1c4ae52b','./lib/core/Zend/Json/Server/Smd.php','6.3',0),('e491dd2e79cc5a96aca04bb09bcf94ce','./lib/core/Zend/Json/Server/Smd/Service.php','6.3',0),('44cf35b4538a69089161625c8a37decb','./lib/core/Zend/Layout.php','6.3',0),('3db229787136bc8fcedfb99f22771a61','./lib/core/Zend/Layout/Controller/Action/Helper/Layout.php','6.3',0),('abdcd487224cb3b399ac74aec6319a13','./lib/core/Zend/Layout/Controller/Plugin/Layout.php','6.3',0),('4ff6db4ca7067822c8f88568d7a40025','./lib/core/Zend/Layout/Exception.php','6.3',0),('36f2b4ea3f0200f1338e0bccee324525','./lib/core/Zend/Ldap.php','6.3',0),('c8df1c121e6bd0c342daf837c9149b86','./lib/core/Zend/Ldap/Attribute.php','6.3',0),('dd98277038d69a92ccdbad33d7f15bb5','./lib/core/Zend/Ldap/Collection.php','6.3',0),('5f9329178247e2e917dd93963fdf63f6','./lib/core/Zend/Ldap/Collection/Iterator/Default.php','6.3',0),('570fc079df4d6f9b0a65212253feb984','./lib/core/Zend/Ldap/Converter.php','6.3',0),('de6229c5dfcdb9ccc2e686e9bd97f967','./lib/core/Zend/Ldap/Converter/Exception.php','6.3',0),('464335ee1bb744aeef32930c98ec1add','./lib/core/Zend/Ldap/Dn.php','6.3',0),('404649909f313eb52c939bf00ca31a07','./lib/core/Zend/Ldap/Exception.php','6.3',0),('ac106ea3221972349b2e5cd5eb380b54','./lib/core/Zend/Ldap/Filter.php','6.3',0),('f8fd8a6cea6f60c1a929d2a936795be8','./lib/core/Zend/Ldap/Filter/Abstract.php','6.3',0),('9cb7d38badb4727606704d2c4e4004a9','./lib/core/Zend/Ldap/Filter/And.php','6.3',0),('96492677032561fc3f5557eb516f87f7','./lib/core/Zend/Ldap/Filter/Exception.php','6.3',0),('315302d48aeee18639bce8315c89278d','./lib/core/Zend/Ldap/Filter/Logical.php','6.3',0),('ce824ada8777d04a5982d7d6b233b62e','./lib/core/Zend/Ldap/Filter/Mask.php','6.3',0),('c2fafe55c1069288d6b6bd734c89298a','./lib/core/Zend/Ldap/Filter/Not.php','6.3',0),('f5352caab84383df55b8496f02ad8d3e','./lib/core/Zend/Ldap/Filter/Or.php','6.3',0),('a6f8e5bf7d3e3ed134977be05bd7309b','./lib/core/Zend/Ldap/Filter/String.php','6.3',0),('e3a7aafc3065532f177d186e5f22c71b','./lib/core/Zend/Ldap/Ldif/Encoder.php','6.3',0),('99573f71b7eec606b788152a4d422492','./lib/core/Zend/Ldap/Node.php','6.3',0),('b48f7bb7675f04a71e9259b5ae0b47da','./lib/core/Zend/Ldap/Node/Abstract.php','6.3',0),('0f4dd6276a040ed81f502044b1240d81','./lib/core/Zend/Ldap/Node/ChildrenIterator.php','6.3',0),('d9f96700aabf45e3a56509b568b77996','./lib/core/Zend/Ldap/Node/Collection.php','6.3',0),('7b52e0fff5db265cc17a6750acc86ae3','./lib/core/Zend/Ldap/Node/RootDse.php','6.3',0),('1b4613a36e4ca7ed612df0977dd4b18d','./lib/core/Zend/Ldap/Node/RootDse/ActiveDirectory.php','6.3',0),('239cc942d52142ae2fe80d59ab6e9a92','./lib/core/Zend/Ldap/Node/RootDse/OpenLdap.php','6.3',0),('dc36d3c873db70ebf99f7bee9290c9de','./lib/core/Zend/Ldap/Node/RootDse/eDirectory.php','6.3',0),('9c4cd69eb83c29f5268cfdc603c26a07','./lib/core/Zend/Ldap/Node/Schema.php','6.3',0),('fd11aa13c74081542edfff711c14f420','./lib/core/Zend/Ldap/Node/Schema/ActiveDirectory.php','6.3',0),('728ab45571f3ad1b92cb17398ab0a9b1','./lib/core/Zend/Ldap/Node/Schema/AttributeType/ActiveDirectory.php','6.3',0),('bb6bee8b6026c1a984a9a83cfeacfe67','./lib/core/Zend/Ldap/Node/Schema/AttributeType/Interface.php','6.3',0),('6feb41eb4b0a2f411b5baefe888765a8','./lib/core/Zend/Ldap/Node/Schema/AttributeType/OpenLdap.php','6.3',0),('5fc1550226091482a6163b2bcf073c29','./lib/core/Zend/Ldap/Node/Schema/Item.php','6.3',0),('3a525b76f87bb34e53c0e4d33f97123c','./lib/core/Zend/Ldap/Node/Schema/ObjectClass/ActiveDirectory.php','6.3',0),('97c93bda8eaa03b6a0e2c476a37b33e9','./lib/core/Zend/Ldap/Node/Schema/ObjectClass/Interface.php','6.3',0),('59d9b71d42dad4577da9ef8f7cfbac53','./lib/core/Zend/Ldap/Node/Schema/ObjectClass/OpenLdap.php','6.3',0),('3acbf71b4e2692c1c57ef7056e399c14','./lib/core/Zend/Ldap/Node/Schema/OpenLdap.php','6.3',0),('e9edda03a78527c8008669ff81b40638','./lib/core/Zend/Loader.php','6.3',0),('f8197bc57e23aa9718cb0059180765d4','./lib/core/Zend/Loader/Autoloader.php','6.3',0),('efc2422c622971806ae2c3ef79286db1','./lib/core/Zend/Loader/Autoloader/Interface.php','6.3',0),('5de93d4bf6e110dc7d0f9c05902e6573','./lib/core/Zend/Loader/Autoloader/Resource.php','6.3',0),('f6bbb81c336c1b2690a6cbdfa709501c','./lib/core/Zend/Loader/Exception.php','6.3',0),('35acd4cf90e3999fe0ae140a15698521','./lib/core/Zend/Loader/PluginLoader.php','6.3',0),('e0fb132d1f5c64687d559ede0f906330','./lib/core/Zend/Loader/PluginLoader/Exception.php','6.3',0),('76720deb90f2ef24d23a304cc7b96e64','./lib/core/Zend/Loader/PluginLoader/Interface.php','6.3',0),('ba0450e1c912086b60dbc8ee06ded18f','./lib/core/Zend/Locale.php','6.3',0),('67b9a5b575afe312e3fdca40c5e9b3ea','./lib/core/Zend/Locale/Data.php','6.3',0),('5963920fd6ae02184a92f238a0ca61f2','./lib/core/Zend/Locale/Data/Translation.php','6.3',0),('ea3e9e9172a7d6f9f9f1a1020193cab1','./lib/core/Zend/Locale/Exception.php','6.3',0),('d5245cae6176786cdc17c9a5faf74cb3','./lib/core/Zend/Locale/Format.php','6.3',0),('59957baf4fefac2c2ebe95a0e8365471','./lib/core/Zend/Locale/Math.php','6.3',0),('88bdb43cf6949fd6c91200b29a366f29','./lib/core/Zend/Locale/Math/Exception.php','6.3',0),('6c248dc31e5c0506cd138892724c7e1b','./lib/core/Zend/Locale/Math/PhpMath.php','6.3',0),('d8285cbe879391e58f352c466607b130','./lib/core/Zend/Log.php','6.3',0),('54b8550ae35eca6f605f7d16a6053608','./lib/core/Zend/Log/Exception.php','6.3',0),('e585ad2c4e312716ae843e416a2b69da','./lib/core/Zend/Log/FactoryInterface.php','6.3',0),('39522e9c1ed6ba406f428ac53264d636','./lib/core/Zend/Log/Filter/Abstract.php','6.3',0),('d59401f6c39879e0137802ee0f43fd28','./lib/core/Zend/Log/Filter/Interface.php','6.3',0),('da5d396b2cf03fc6f0024fe6cbe995b9','./lib/core/Zend/Log/Filter/Message.php','6.3',0),('17032fa0f5b1ba803a2c31f19930c20a','./lib/core/Zend/Log/Filter/Priority.php','6.3',0),('efd4483688e16cbb90b504812b3bc2ec','./lib/core/Zend/Log/Filter/Suppress.php','6.3',0),('1c69e7af369b505d7291c01308dcb381','./lib/core/Zend/Log/Formatter/Firebug.php','6.3',0),('ef3f3e5016ab000d429b0556d758aefe','./lib/core/Zend/Log/Formatter/Interface.php','6.3',0),('7258190d3f66898c5f03837afb968fd0','./lib/core/Zend/Log/Formatter/Simple.php','6.3',0),('a5b5c30042e9a70261862d1aa76c9a30','./lib/core/Zend/Log/Formatter/Xml.php','6.3',0),('73f50bc09a77627a633a29c484bb8828','./lib/core/Zend/Log/Writer/Abstract.php','6.3',0),('2c5a9fec643dee4d02a94886c3ba8e04','./lib/core/Zend/Log/Writer/Db.php','6.3',0),('6ef52fcc07da9e640ef2642b4289f5fc','./lib/core/Zend/Log/Writer/Firebug.php','6.3',0),('ff02d0b37c5b1b7e00bfb96ee61f5f7c','./lib/core/Zend/Log/Writer/Mail.php','6.3',0),('a9698e437211639fdf4e794df54998f5','./lib/core/Zend/Log/Writer/Mock.php','6.3',0),('93aaf89c29ef50cb846ca6f6fa4bf13b','./lib/core/Zend/Log/Writer/Null.php','6.3',0),('c74881e835eb93aaa444df8988f11aff','./lib/core/Zend/Log/Writer/Stream.php','6.3',0),('ca24012af9c7f9f7d800f114afaf5808','./lib/core/Zend/Log/Writer/Syslog.php','6.3',0),('699bfe166b15ed65881c5d7afc3e2e72','./lib/core/Zend/Log/Writer/ZendMonitor.php','6.3',0),('d08fbd86745b29a2c4ba56adaedee237','./lib/core/Zend/Mail.php','6.3',0),('56e68f3bb16297010133ac554c1ee36b','./lib/core/Zend/Mail/Exception.php','6.3',0),('63c730a1a3707d501ee5332cf7528953','./lib/core/Zend/Mail/Message.php','6.3',0),('d3845bb82daa4e524077eacaf3f077f1','./lib/core/Zend/Mail/Message/File.php','6.3',0),('51c523a3c2359ded2a2ec3cf9bd05a7b','./lib/core/Zend/Mail/Message/Interface.php','6.3',0),('76dd606459c83a71b18b255dcf80a859','./lib/core/Zend/Mail/Part.php','6.3',0),('c6b72eb9f8ed50de2fe4fb03368b9a30','./lib/core/Zend/Mail/Part/File.php','6.3',0),('369d3ca5fd9763f5769d7de6516e9faa','./lib/core/Zend/Mail/Part/Interface.php','6.3',0),('f52ae318624e48961abc62321c7448a7','./lib/core/Zend/Mail/Protocol/Abstract.php','6.3',0),('bdfe53c9e6b69f4376d7449aed13b806','./lib/core/Zend/Mail/Protocol/Exception.php','6.3',0),('7d6e23de50222381de8d8698c73913ea','./lib/core/Zend/Mail/Protocol/Imap.php','6.3',0),('87d2f86a9755d84014948d78737cbec8','./lib/core/Zend/Mail/Protocol/Pop3.php','6.3',0),('ccb525c91ea87e6db5053a990141ad3c','./lib/core/Zend/Mail/Protocol/Smtp.php','6.3',0),('4313bde2d8818c2885489f93f174e96a','./lib/core/Zend/Mail/Protocol/Smtp/Auth/Crammd5.php','6.3',0),('d8d79a1ad2270d1b11cedd0e6adf79ed','./lib/core/Zend/Mail/Protocol/Smtp/Auth/Login.php','6.3',0),('525be1d1d0410c21ce7ff909288bf032','./lib/core/Zend/Mail/Protocol/Smtp/Auth/Plain.php','6.3',0),('03278fc22648640e81af5ad2f802cb93','./lib/core/Zend/Mail/Storage.php','6.3',0),('1ab551f4e641d852aab46e5faa8721f5','./lib/core/Zend/Mail/Storage/Abstract.php','6.3',0),('584b3a07c603249637411e26331ced98','./lib/core/Zend/Mail/Storage/Exception.php','6.3',0),('fb63f2c3ef09a2be2ad2a052b8d1b99e','./lib/core/Zend/Mail/Storage/Folder.php','6.3',0),('3bb18d3e6c9c59a26a6217b17a7af9e6','./lib/core/Zend/Mail/Storage/Folder/Interface.php','6.3',0),('fb26d4f49ea02f0811541fefd18c2242','./lib/core/Zend/Mail/Storage/Folder/Maildir.php','6.3',0),('5cbc49b45320da70e345fe55e3e3c124','./lib/core/Zend/Mail/Storage/Folder/Mbox.php','6.3',0),('4e1a0b7f9712f33d8abfe22e3325ef19','./lib/core/Zend/Mail/Storage/Imap.php','6.3',0),('333869328cdf1eb44e264db3843ca3a7','./lib/core/Zend/Mail/Storage/Maildir.php','6.3',0),('01079e23716f3a926a11aa676dd5a337','./lib/core/Zend/Mail/Storage/Mbox.php','6.3',0),('a7bfe8d50633ad27d22d5d5840cd5007','./lib/core/Zend/Mail/Storage/Pop3.php','6.3',0),('3c25392d4402e0b6926e2b44badb9c5d','./lib/core/Zend/Mail/Storage/Writable/Interface.php','6.3',0),('7aede92ff40f9dbabeeb3f6edc77f842','./lib/core/Zend/Mail/Storage/Writable/Maildir.php','6.3',0),('130ca6f412111dd9feba8780dbeeb990','./lib/core/Zend/Mail/Transport/Abstract.php','6.3',0),('4cd3827e1490b604ca38eb7ab05123a8','./lib/core/Zend/Mail/Transport/Exception.php','6.3',0),('7012364562bfd879bfa123856919fbda','./lib/core/Zend/Mail/Transport/Sendmail.php','6.3',0),('c609e9edd56e12fe2654d3298c2b4fea','./lib/core/Zend/Mail/Transport/Smtp.php','6.3',0),('f456b179e8aa322f6153751ed29c4db0','./lib/core/Zend/Markup.php','6.3',0),('b1c5ba5d583530a4e8fac18762004d69','./lib/core/Zend/Markup/Exception.php','6.3',0),('a38d67ba1dd584ec4cc0edac1c217641','./lib/core/Zend/Markup/Parser/Bbcode.php','6.3',0),('ae3c05cb043fba32edd879121d98eaa2','./lib/core/Zend/Markup/Parser/Exception.php','6.3',0),('9264af16622d2e24c8943a9ae80941fc','./lib/core/Zend/Markup/Parser/ParserInterface.php','6.3',0),('dc58a86557f9a69a6736680f9083af08','./lib/core/Zend/Markup/Parser/Textile.php','6.3',0),('fc41d12711556ac9e51f7712c144491c','./lib/core/Zend/Markup/Renderer/Exception.php','6.3',0),('9021bbbd838c9ab791a4d185f98edf72','./lib/core/Zend/Markup/Renderer/Html.php','6.3',0),('05e66adaacc845eee728d4a367d92ad3','./lib/core/Zend/Markup/Renderer/Html/Code.php','6.3',0),('743adae788dc74799de8fbf479c240b8','./lib/core/Zend/Markup/Renderer/Html/HtmlAbstract.php','6.3',0),('fc668cfc5d0f3eb41fed6c660a8ce117','./lib/core/Zend/Markup/Renderer/Html/Img.php','6.3',0),('f4a9a07ac2532b154b667d2c942086b8','./lib/core/Zend/Markup/Renderer/Html/List.php','6.3',0),('b940d4a6135a051ad131b0ce2d45c394','./lib/core/Zend/Markup/Renderer/Html/Url.php','6.3',0),('c7d52d781f51ae422c8b41577363f786','./lib/core/Zend/Markup/Renderer/RendererAbstract.php','6.3',0),('c93d289a48bac4aaf18a4159b5e27837','./lib/core/Zend/Markup/Renderer/TokenConverterInterface.php','6.3',0),('682c1d0d33a517b6d5c57985835e2ed5','./lib/core/Zend/Markup/Token.php','6.3',0),('3b54a6c04f517356f4fd04e869054097','./lib/core/Zend/Markup/TokenList.php','6.3',0),('141685c97b340b0b624df98293d50228','./lib/core/Zend/Measure/Abstract.php','6.3',0),('0bbb505e50bc3fbc25743f072f28ddbd','./lib/core/Zend/Measure/Acceleration.php','6.3',0),('64267ec90b8818417a9b1d908687da63','./lib/core/Zend/Measure/Angle.php','6.3',0),('f7a2653e312d45e39b9fedf31fd4e59b','./lib/core/Zend/Measure/Area.php','6.3',0),('d00c5d3b118bbbc1cb83bd2752b092e3','./lib/core/Zend/Measure/Binary.php','6.3',0),('c787c88c9754e104acde300b386cc825','./lib/core/Zend/Measure/Capacitance.php','6.3',0),('7aac9261ef5c163a255740061ddcabb4','./lib/core/Zend/Measure/Cooking/Volume.php','6.3',0),('4fa58972dc3c95b8a7ecbbb297782799','./lib/core/Zend/Measure/Cooking/Weight.php','6.3',0),('5b14a677465d9ed8c3ae3ebd4f5b7c23','./lib/core/Zend/Measure/Current.php','6.3',0),('50a4c054f6589217b059de94d1c6abe5','./lib/core/Zend/Measure/Density.php','6.3',0),('83088c66b69b3a15ce7554ef730d6275','./lib/core/Zend/Measure/Energy.php','6.3',0),('eec6aeadb109586bbf24b4b891967d23','./lib/core/Zend/Measure/Exception.php','6.3',0),('8ce6a4c4995e8991bd5452bc45e41d01','./lib/core/Zend/Measure/Flow/Mass.php','6.3',0),('718871b0eccb8357c3eb0f03cecacfa8','./lib/core/Zend/Measure/Flow/Mole.php','6.3',0),('c1357e15493f35e5331d9b2659b9c18e','./lib/core/Zend/Measure/Flow/Volume.php','6.3',0),('1f8373600208886cffc610780889dade','./lib/core/Zend/Measure/Force.php','6.3',0),('e491e01126f7bfad7b2e7f78e46d4159','./lib/core/Zend/Measure/Frequency.php','6.3',0),('815a08ca17474e5cad2d43c393eff768','./lib/core/Zend/Measure/Illumination.php','6.3',0),('063e97e219ad381d23dfc92616cd9357','./lib/core/Zend/Measure/Length.php','6.3',0),('720cc7f825858cbe16cc372bfabec6f7','./lib/core/Zend/Measure/Lightness.php','6.3',0),('c41c8b9588fd083fabd04c9cde0c2a52','./lib/core/Zend/Measure/Number.php','6.3',0),('dcaa1f5f542e46c36385de285db2ee3e','./lib/core/Zend/Measure/Power.php','6.3',0),('db746ccd725c487073bbd7587649118a','./lib/core/Zend/Measure/Pressure.php','6.3',0),('df4c92bda36ed7e41148a279d4a83f85','./lib/core/Zend/Measure/Speed.php','6.3',0),('3ae0da1b81cc60d609bc4499cba1e02e','./lib/core/Zend/Measure/Temperature.php','6.3',0),('2115c3159dbfd4378753c8639343cf7f','./lib/core/Zend/Measure/Time.php','6.3',0),('e2afe74154548499c2a24bd307a45551','./lib/core/Zend/Measure/Torque.php','6.3',0),('320caa199c6e4e2913c280f331f7e40f','./lib/core/Zend/Measure/Viscosity/Dynamic.php','6.3',0),('0f4d877985e8ae48bba44fad84806c20','./lib/core/Zend/Measure/Viscosity/Kinematic.php','6.3',0),('796ddc173165cc33ba31ea7c4e97d6f2','./lib/core/Zend/Measure/Volume.php','6.3',0),('31d9ceccadaf73086c4738fbf7a71248','./lib/core/Zend/Measure/Weight.php','6.3',0),('57a29adc2daf82f5bc5bea8c64ddb786','./lib/core/Zend/Memory.php','6.3',0),('6eac5dc87ef61ab2b20f9f8de357e3b5','./lib/core/Zend/Memory/AccessController.php','6.3',0),('6bf219a47e70ab82956805b1fd888e7d','./lib/core/Zend/Memory/Container.php','6.3',0),('a583cedfa36fd083899bca9609eb6805','./lib/core/Zend/Memory/Container/Interface.php','6.3',0),('311fd936e95e2385cf1011d314378395','./lib/core/Zend/Memory/Container/Locked.php','6.3',0),('b43c2b168021655002e1ed5cc75fb87e','./lib/core/Zend/Memory/Container/Movable.php','6.3',0),('b77fafe7a71f6eaee77f59abf1871a7b','./lib/core/Zend/Memory/Exception.php','6.3',0),('bbeb3ec7e94ff5213657e6b9067d208d','./lib/core/Zend/Memory/Manager.php','6.3',0),('7fa1d907e8b5ec9b03fcb9e3115ecc6d','./lib/core/Zend/Memory/Value.php','6.3',0),('59b07d53b02a489f6f86df75d3b3f560','./lib/core/Zend/Mime.php','6.3',0),('deae9e73d2dec524a97a03ac11f1ceea','./lib/core/Zend/Mime/Decode.php','6.3',0),('18ff65da2325044c81d5cc7ef37833c9','./lib/core/Zend/Mime/Exception.php','6.3',0),('ad915cfa8f64627407799c036ac892b5','./lib/core/Zend/Mime/Message.php','6.3',0),('c3921dc663a288d42e683753d9153985','./lib/core/Zend/Mime/Part.php','6.3',0),('b0cf1f6d7400ff171fa2ed9e9689cf0e','./lib/core/Zend/Navigation.php','6.3',0),('7bf7daa457028690f84cb0b489438831','./lib/core/Zend/Navigation/Container.php','6.3',0),('7868f7f8d7cae90b5b9cb187e6b1d1a0','./lib/core/Zend/Navigation/Exception.php','6.3',0),('af5dc7c06e43c62c6f30c47e66952c75','./lib/core/Zend/Navigation/Page.php','6.3',0),('0d6198de51c1fe18fe1931118f6955ce','./lib/core/Zend/Navigation/Page/Mvc.php','6.3',0),('41644f9687169aadf66bcbe55c8a0c59','./lib/core/Zend/Navigation/Page/Uri.php','6.3',0),('3ffcf49df2b29404b422c007a42b369d','./lib/core/Zend/Oauth.php','6.3',0),('c1dd1743d4617a08a735429d8f910d3e','./lib/core/Zend/Oauth/Client.php','6.3',0),('69ea32745248fc55721d3eb8baff033b','./lib/core/Zend/Oauth/Config.php','6.3',0),('d2cea8ae9a90afa52e04be270cae7848','./lib/core/Zend/Oauth/Config/ConfigInterface.php','6.3',0),('c1e958d833b34db29033bdea6a43f4a1','./lib/core/Zend/Oauth/Consumer.php','6.3',0),('43ecfbbbb9a288ee807b3d52a6b897ec','./lib/core/Zend/Oauth/Exception.php','6.3',0),('a09947fd4b1fcb882e0cd18e0f395acc','./lib/core/Zend/Oauth/Http.php','6.3',0),('5abfd122e6de1fcad77f02918516a8ad','./lib/core/Zend/Oauth/Http/AccessToken.php','6.3',0),('03eef826a80cc206930a1b1385b56e6f','./lib/core/Zend/Oauth/Http/RequestToken.php','6.3',0),('69f8051d7247856d36b0ceffefa41b70','./lib/core/Zend/Oauth/Http/UserAuthorization.php','6.3',0),('937b9ee7369f81ce642e96d602147565','./lib/core/Zend/Oauth/Http/Utility.php','6.3',0),('c101fc46c3370b90256c4ff6c13f900d','./lib/core/Zend/Oauth/Signature/Hmac.php','6.3',0),('f52a50f9c2922c0a547805301adabba0','./lib/core/Zend/Oauth/Signature/Plaintext.php','6.3',0),('c13903096c40132467213fb4c94539f6','./lib/core/Zend/Oauth/Signature/Rsa.php','6.3',0),('811fb6fa6cd7581022be5d0565cb04bd','./lib/core/Zend/Oauth/Signature/SignatureAbstract.php','6.3',0),('a82a4a39b3ee2120dee368bef5eb386d','./lib/core/Zend/Oauth/Token.php','6.3',0),('2a31cb5a151611b4a618a09290909bcc','./lib/core/Zend/Oauth/Token/Access.php','6.3',0),('c608899625679142eb12f9d6168436d5','./lib/core/Zend/Oauth/Token/AuthorizedRequest.php','6.3',0),('5cc0e54995de5e765fa1e8d4a503d840','./lib/core/Zend/Oauth/Token/Request.php','6.3',0),('82ba78a718fbe6aa9318dbfc591f4cd3','./lib/core/Zend/OpenId.php','6.3',0),('1673652be4c531617dfe60649ff07d5d','./lib/core/Zend/OpenId/Consumer.php','6.3',0),('c09ed474fe9952a81b71f4f793b569ed','./lib/core/Zend/OpenId/Consumer/Storage.php','6.3',0),('9dee65f20f852c0dacd355262fa0ab94','./lib/core/Zend/OpenId/Consumer/Storage/File.php','6.3',0),('a6646d800c6569ade03a8cfbbe624a09','./lib/core/Zend/OpenId/Exception.php','6.3',0),('f1cc1f9fa721b497f6b050035004e7bb','./lib/core/Zend/OpenId/Extension.php','6.3',0),('c491a76c698a139ba432a9c68637d005','./lib/core/Zend/OpenId/Extension/Sreg.php','6.3',0),('cbfbd910d11a62b87fd48e33320445a6','./lib/core/Zend/OpenId/Provider.php','6.3',0),('7ee7aab5ed5c4abde3d5f8046b143153','./lib/core/Zend/OpenId/Provider/Storage.php','6.3',0),('773f8605273c2bf7e859bdc110ec0446','./lib/core/Zend/OpenId/Provider/Storage/File.php','6.3',0),('9f41d175bf6eab232f4a9e0458d3afea','./lib/core/Zend/OpenId/Provider/User.php','6.3',0),('433c29a59f7b9f2761f1e88aed37ac9b','./lib/core/Zend/OpenId/Provider/User/Session.php','6.3',0),('3ccfddaaf05b5d8ea49df74c7e75bc68','./lib/core/Zend/Paginator.php','6.3',0),('85502cbdd40611b4d8c2999ab657c893','./lib/core/Zend/Paginator/Adapter/Array.php','6.3',0),('4c223abdbe17424fc9ad93c85f446803','./lib/core/Zend/Paginator/Adapter/DbSelect.php','6.3',0),('7db65123dc95ab6061181215197275ba','./lib/core/Zend/Paginator/Adapter/DbTableSelect.php','6.3',0),('14efa0869d2d78132cebc074efba7d2f','./lib/core/Zend/Paginator/Adapter/Interface.php','6.3',0),('2f1eb927d8f2d76330e1cb094415dfc0','./lib/core/Zend/Paginator/Adapter/Iterator.php','6.3',0),('b459e4dbbd18dfaf8d20f4fb71967f61','./lib/core/Zend/Paginator/Adapter/Null.php','6.3',0),('05324e36a2cd17d71f0d98bcbd833050','./lib/core/Zend/Paginator/AdapterAggregate.php','6.3',0),('8d0d85345c5e0074198799149639eef6','./lib/core/Zend/Paginator/Exception.php','6.3',0),('fbb66ed2b5b6c4e38d0ebbc8c42095c1','./lib/core/Zend/Paginator/ScrollingStyle/All.php','6.3',0),('d8f6a53595e1a5bae42daf429c33c822','./lib/core/Zend/Paginator/ScrollingStyle/Elastic.php','6.3',0),('60b3d9c3019bea13d2a4c14d09477c87','./lib/core/Zend/Paginator/ScrollingStyle/Interface.php','6.3',0),('b0a2f94d09238b9b7de0c83c5e144c83','./lib/core/Zend/Paginator/ScrollingStyle/Jumping.php','6.3',0),('7992759e03e056d45f4b5aadfd8dfc95','./lib/core/Zend/Paginator/ScrollingStyle/Sliding.php','6.3',0),('a666bc521faec2dc1a5b6b8cd8eb1a61','./lib/core/Zend/Paginator/SerializableLimitIterator.php','6.3',0),('dfdf09eef02ce528f23952dd8aef3c15','./lib/core/Zend/Pdf.php','6.3',0),('fa26459c8cdb5c74ecbea514718e6fa2','./lib/core/Zend/Pdf/Action.php','6.3',0),('d8d0f27a17bc667a3700955853402924','./lib/core/Zend/Pdf/Action/GoTo.php','6.3',0),('0f03fb8109c550be9bcced200fd19d0d','./lib/core/Zend/Pdf/Action/GoTo3DView.php','6.3',0),('72a586516f1186d904d58886684841d6','./lib/core/Zend/Pdf/Action/GoToE.php','6.3',0),('b337fc1cde3dfe7b662c375bca994b54','./lib/core/Zend/Pdf/Action/GoToR.php','6.3',0),('54f2431e458ac8efb6f84d2e7c4465e3','./lib/core/Zend/Pdf/Action/Hide.php','6.3',0),('642c83338ae29d14e3cb276bc75d1618','./lib/core/Zend/Pdf/Action/ImportData.php','6.3',0),('ec45ea5ac54490e846894147005e29b1','./lib/core/Zend/Pdf/Action/JavaScript.php','6.3',0),('fed6c8f9af81d0fc1d0f19210383373f','./lib/core/Zend/Pdf/Action/Launch.php','6.3',0),('b263f715a6edea198429d5d0c52626d0','./lib/core/Zend/Pdf/Action/Movie.php','6.3',0),('165442b16a5200cfebd83bef44f9894c','./lib/core/Zend/Pdf/Action/Named.php','6.3',0),('102d5c7a7b7ac090a9fa8397ef4204e3','./lib/core/Zend/Pdf/Action/Rendition.php','6.3',0),('653631f7629aa50b3d58f3afbe5e6630','./lib/core/Zend/Pdf/Action/ResetForm.php','6.3',0),('7a714f541bd3951a74bc2c6b99c704c8','./lib/core/Zend/Pdf/Action/SetOCGState.php','6.3',0),('9c5e056085f5ae2f30399497a74e83db','./lib/core/Zend/Pdf/Action/Sound.php','6.3',0),('3a8d29dbf4ef538cb999da8b176d02be','./lib/core/Zend/Pdf/Action/SubmitForm.php','6.3',0),('9eca2e1bdb1e0a337b722ffa63052bf5','./lib/core/Zend/Pdf/Action/Thread.php','6.3',0),('2819c7b9a8ac42accffcc69831c7652e','./lib/core/Zend/Pdf/Action/Trans.php','6.3',0),('0534de6c9789fcc2648ee2013dfa3bc0','./lib/core/Zend/Pdf/Action/URI.php','6.3',0),('e5351e3ac40b8df0e3b9f6f846c64bb5','./lib/core/Zend/Pdf/Action/Unknown.php','6.3',0),('d2ed31dd04183d8c031e64810655b876','./lib/core/Zend/Pdf/Annotation.php','6.3',0),('8ea32131797b834f1dab074d3244dc6e','./lib/core/Zend/Pdf/Annotation/FileAttachment.php','6.3',0),('77fa74003814625589915bdf1608a3b3','./lib/core/Zend/Pdf/Annotation/Link.php','6.3',0),('ef10cb6298c4b17dd43d4e15f2209710','./lib/core/Zend/Pdf/Annotation/Markup.php','6.3',0),('e5e54cba473c3c9a1b4a8b1b1ecfac82','./lib/core/Zend/Pdf/Annotation/Text.php','6.3',0),('48570d1992eeed19888914a377f0585b','./lib/core/Zend/Pdf/Cmap.php','6.3',0),('b512951eb9f1560ab1b68c40afeaf751','./lib/core/Zend/Pdf/Cmap/ByteEncoding.php','6.3',0),('6ecb8ad9ce5c1c23ce9033c15050d379','./lib/core/Zend/Pdf/Cmap/ByteEncoding/Static.php','6.3',0),('9bc47b603b15eb3205910f09ea8b3c14','./lib/core/Zend/Pdf/Cmap/SegmentToDelta.php','6.3',0),('92a67c13540a39f804d02674f6efcb67','./lib/core/Zend/Pdf/Cmap/TrimmedTable.php','6.3',0),('1043c94cdd7f4f9fec67a413983ef736','./lib/core/Zend/Pdf/Color.php','6.3',0),('1b8f16c0597db04e7d11e7b3146aa9a4','./lib/core/Zend/Pdf/Color/Cmyk.php','6.3',0),('e8c66a5a925528e9f7e814706d1a6e92','./lib/core/Zend/Pdf/Color/GrayScale.php','6.3',0),('6d733b74b820b5fb9022d00c8ccfc29d','./lib/core/Zend/Pdf/Color/Html.php','6.3',0),('f7839d3ac525e608c2fff5329853568a','./lib/core/Zend/Pdf/Color/Rgb.php','6.3',0),('58c68a806fca2b68d606598fed56112b','./lib/core/Zend/Pdf/Destination.php','6.3',0),('ef8782cc31e2ce11b6660ba6c61eb0f7','./lib/core/Zend/Pdf/Destination/Explicit.php','6.3',0),('a846dc9dba0dfc96b04335f5a6c6d44c','./lib/core/Zend/Pdf/Destination/Fit.php','6.3',0),('e5dd10b2aadc606400bead954150d7ab','./lib/core/Zend/Pdf/Destination/FitBoundingBox.php','6.3',0),('36757dc867311cfe11f86a5f20a35cb3','./lib/core/Zend/Pdf/Destination/FitBoundingBoxHorizontally.php','6.3',0),('fdc82e80465fa7a670c538fd17ed9446','./lib/core/Zend/Pdf/Destination/FitBoundingBoxVertically.php','6.3',0),('ada82d95708aea35b3e7db0c42bb9cca','./lib/core/Zend/Pdf/Destination/FitHorizontally.php','6.3',0),('82dc720d68f4892c76bc67182858393a','./lib/core/Zend/Pdf/Destination/FitRectangle.php','6.3',0),('f0a81a3b2538ff85fe72e39e2921e567','./lib/core/Zend/Pdf/Destination/FitVertically.php','6.3',0),('5df0980e87216692a3011eb1e8900d45','./lib/core/Zend/Pdf/Destination/Named.php','6.3',0),('9c04391cca8449d3ebebfa06922ce437','./lib/core/Zend/Pdf/Destination/Unknown.php','6.3',0),('3a81df09fc9028e247c80cfd9bede42b','./lib/core/Zend/Pdf/Destination/Zoom.php','6.3',0),('49902dce92a798871f2946ef3d17c2a0','./lib/core/Zend/Pdf/Element.php','6.3',0),('0ee5f8ce02b6ceb728125cd39b28e293','./lib/core/Zend/Pdf/Element/Array.php','6.3',0),('4277391f1ae2f52c421ec46c4cea71d1','./lib/core/Zend/Pdf/Element/Boolean.php','6.3',0),('e9c134c323f1d71658faa76a8e7e5ec6','./lib/core/Zend/Pdf/Element/Dictionary.php','6.3',0),('6a9c63c3512fa647074290b07cd9fb69','./lib/core/Zend/Pdf/Element/Name.php','6.3',0),('483be5533716966c1a079e6fcda5121a','./lib/core/Zend/Pdf/Element/Null.php','6.3',0),('1d41c4f4027d2e6601dfe1fb550164e3','./lib/core/Zend/Pdf/Element/Numeric.php','6.3',0),('8af16a41329849a78fad5382bfffbae6','./lib/core/Zend/Pdf/Element/Object.php','6.3',0),('e8c099ebc2a49a552c9d5bdd9f6102f5','./lib/core/Zend/Pdf/Element/Object/Stream.php','6.3',0),('d86d3d790ff653fc4864f1179d490254','./lib/core/Zend/Pdf/Element/Reference.php','6.3',0),('51a539061d35c5f35ad4f7659e596b88','./lib/core/Zend/Pdf/Element/Reference/Context.php','6.3',0),('a32d304f823aa8e1a7ed30dbdeb4d1f5','./lib/core/Zend/Pdf/Element/Reference/Table.php','6.3',0),('fed57ba614d7b5a600d5abfcc80aed81','./lib/core/Zend/Pdf/Element/Stream.php','6.3',0),('6b85f6d707867b73c7a83b8f90633d23','./lib/core/Zend/Pdf/Element/String.php','6.3',0),('1440a6b84869e92e837acd18f21df794','./lib/core/Zend/Pdf/Element/String/Binary.php','6.3',0),('fb08aa25056e3f33d5e8d3b0bf2da85c','./lib/core/Zend/Pdf/ElementFactory.php','6.3',0),('ab8ab2577b547eccf83ff382c6df4243','./lib/core/Zend/Pdf/ElementFactory/Interface.php','6.3',0),('3d033712e3c77c69cab7ea16857c1d5f','./lib/core/Zend/Pdf/ElementFactory/Proxy.php','6.3',0),('203fe5e83eca761a8f5f2dd2e2f8a37f','./lib/core/Zend/Pdf/Exception.php','6.3',0),('c0f5bbbf62ba8ee4d50306325ef5b4ca','./lib/core/Zend/Pdf/FileParser.php','6.3',0),('eed7590201d197bcb80d0f9bb72284fb','./lib/core/Zend/Pdf/FileParser/Font.php','6.3',0),('8b8e9a89eef574e54250d228aa0d12ea','./lib/core/Zend/Pdf/FileParser/Font/OpenType.php','6.3',0),('7d750f4a0ffc2ea49046ec7245f322cd','./lib/core/Zend/Pdf/FileParser/Font/OpenType/TrueType.php','6.3',0),('389b08b11cbde73aea1c1dc2d397e34e','./lib/core/Zend/Pdf/FileParser/Image.php','6.3',0),('525faef904711d274fa34b0d4a3bc198','./lib/core/Zend/Pdf/FileParser/Image/Png.php','6.3',0),('03b99ad8c0b890f9ba6e13a1e703e3c1','./lib/core/Zend/Pdf/FileParserDataSource.php','6.3',0),('b7fdfdb97605a8496510ad4479e00de6','./lib/core/Zend/Pdf/FileParserDataSource/File.php','6.3',0),('fdd78e14ab43cb42d737b6b0cbb634e9','./lib/core/Zend/Pdf/FileParserDataSource/String.php','6.3',0),('a4962debb612069e367a17266bb3c05c','./lib/core/Zend/Pdf/Filter/Ascii85.php','6.3',0),('efe58f1d76a0795be6c0beacad8bcd66','./lib/core/Zend/Pdf/Filter/AsciiHex.php','6.3',0),('d0fb66f03eb3edc7806d8752f13ab6c1','./lib/core/Zend/Pdf/Filter/Compression.php','6.3',0),('8b184cad6d551ddcfa95a53b8e862bc5','./lib/core/Zend/Pdf/Filter/Compression/Flate.php','6.3',0),('a71c7859c63e5c6de93efb1283affdef','./lib/core/Zend/Pdf/Filter/Compression/Lzw.php','6.3',0),('13612337c5e1df2fd6ed0fd99cb4f263','./lib/core/Zend/Pdf/Filter/Interface.php','6.3',0),('1ba5571d7fe05f4b9e04da8d59187f94','./lib/core/Zend/Pdf/Filter/RunLength.php','6.3',0),('d00aaa125bff0285850df8213789f82f','./lib/core/Zend/Pdf/Font.php','6.3',0),('c8c58ee8db0869ca27a046aa52f72ec6','./lib/core/Zend/Pdf/Image.php','6.3',0),('a61869d35577270bc696523f6ebad5d3','./lib/core/Zend/Pdf/NameTree.php','6.3',0),('9be559c8a996678a2d6d05910111932d','./lib/core/Zend/Pdf/Outline.php','6.3',0),('c8efda56e55f86c963381b99702f4d8a','./lib/core/Zend/Pdf/Outline/Created.php','6.3',0),('a4fb4524eefd992e5a7461eef3e38af2','./lib/core/Zend/Pdf/Outline/Loaded.php','6.3',0),('1202e5659cae750eb9b5bec9ac9be55e','./lib/core/Zend/Pdf/Page.php','6.3',0),('5cb1f514fbe2c755fc1f67194c1354cf','./lib/core/Zend/Pdf/Parser.php','6.3',0),('6ba4754bf45d3c77ce806efae87d4567','./lib/core/Zend/Pdf/RecursivelyIteratableObjectsContainer.php','6.3',0),('536e748ac376c30927e2cad89fa9c356','./lib/core/Zend/Pdf/Resource.php','6.3',0),('632ea971cdb1458ae17374924f8ceffb','./lib/core/Zend/Pdf/Resource/Font.php','6.3',0),('155a2ed94e95a515d57016cd6b4dbd5e','./lib/core/Zend/Pdf/Resource/Font/CidFont.php','6.3',0),('1008e6ea22fc3586f2812a3d99c30a17','./lib/core/Zend/Pdf/Resource/Font/CidFont/TrueType.php','6.3',0),('e0db97f6a1c3f25242ab70d0052208d3','./lib/core/Zend/Pdf/Resource/Font/Extracted.php','6.3',0),('348fd8bb68f251bb22d5c100de7fb665','./lib/core/Zend/Pdf/Resource/Font/FontDescriptor.php','6.3',0),('8f8fb0882aebbf07f44c9395c35048bc','./lib/core/Zend/Pdf/Resource/Font/Simple.php','6.3',0),('a3efe306928939b2b3eec12db1bad995','./lib/core/Zend/Pdf/Resource/Font/Simple/Parsed.php','6.3',0),('9398ede0354156d547f0c0a4fbdd293b','./lib/core/Zend/Pdf/Resource/Font/Simple/Parsed/TrueType.php','6.3',0),('db6ebfd34e6c9306bfbe294fabf0cdf9','./lib/core/Zend/Pdf/Resource/Font/Simple/Standard.php','6.3',0),('9d291542404aee2b5f4726308a6bc3f5','./lib/core/Zend/Pdf/Resource/Font/Simple/Standard/Courier.php','6.3',0),('affbb86a18e0dd961bec2915af52704e','./lib/core/Zend/Pdf/Resource/Font/Simple/Standard/CourierBold.php','6.3',0),('6741d99f9b37e1acb01d9d135dc43586','./lib/core/Zend/Pdf/Resource/Font/Simple/Standard/CourierBoldOblique.php','6.3',0),('7071eeceb9885f452fbd4009e73ce2d0','./lib/core/Zend/Pdf/Resource/Font/Simple/Standard/CourierOblique.php','6.3',0),('15afeb80cbe6a76006a6ec310c4f85b3','./lib/core/Zend/Pdf/Resource/Font/Simple/Standard/Helvetica.php','6.3',0),('67a4361ac76d2d88280f96cae50e55b1','./lib/core/Zend/Pdf/Resource/Font/Simple/Standard/HelveticaBold.php','6.3',0),('ba89c3069481a179200ce949e17518fe','./lib/core/Zend/Pdf/Resource/Font/Simple/Standard/HelveticaBoldOblique.php','6.3',0),('9e268e04821e857a1605d9fd4f7fd371','./lib/core/Zend/Pdf/Resource/Font/Simple/Standard/HelveticaOblique.php','6.3',0),('7a66830eaac2174b8b3c9351cd26bbc5','./lib/core/Zend/Pdf/Resource/Font/Simple/Standard/Symbol.php','6.3',0),('9919f975d9ca81587fbd85589b69f886','./lib/core/Zend/Pdf/Resource/Font/Simple/Standard/TimesBold.php','6.3',0),('b38ad77f5ac78ce5e9d28a65446c09ff','./lib/core/Zend/Pdf/Resource/Font/Simple/Standard/TimesBoldItalic.php','6.3',0),('cf7308faa594563b34bd117338fa532f','./lib/core/Zend/Pdf/Resource/Font/Simple/Standard/TimesItalic.php','6.3',0),('ee868fa179b9ca7badd6463a4f8f5aaf','./lib/core/Zend/Pdf/Resource/Font/Simple/Standard/TimesRoman.php','6.3',0),('f26a036e31dc4f4afbd484fd3b192448','./lib/core/Zend/Pdf/Resource/Font/Simple/Standard/ZapfDingbats.php','6.3',0),('a17c514afe42fd8f5eb015bbe5394a4a','./lib/core/Zend/Pdf/Resource/Font/Type0.php','6.3',0),('17d66542551ce8d2b0df2ceab65c9fe5','./lib/core/Zend/Pdf/Resource/Image.php','6.3',0),('a9963662d921d2e98ce3c762b98c69e9','./lib/core/Zend/Pdf/Resource/Image/Jpeg.php','6.3',0),('5046b8d97cee342c43025f587bb3533d','./lib/core/Zend/Pdf/Resource/Image/Png.php','6.3',0),('1fc97cac6a6b2f6dbe911693933cad93','./lib/core/Zend/Pdf/Resource/Image/Tiff.php','6.3',0),('557a78077f11ae202120d9c1f34ca6d8','./lib/core/Zend/Pdf/Resource/ImageFactory.php','6.3',0),('7a028202bfd97fd51deaaca3ed4670ef','./lib/core/Zend/Pdf/StringParser.php','6.3',0),('3b49dcbc11bc825b72713443e16ae54a','./lib/core/Zend/Pdf/Style.php','6.3',0),('6e67923202be64f668e854612c69a85a','./lib/core/Zend/Pdf/Target.php','6.3',0),('31c7a7a110f6891082065433310d3ad8','./lib/core/Zend/Pdf/Trailer.php','6.3',0),('ca1f6da564ea4ed2a5f50820c3f73482','./lib/core/Zend/Pdf/Trailer/Generator.php','6.3',0),('9ea662ae840357d388b40331ba15df13','./lib/core/Zend/Pdf/Trailer/Keeper.php','6.3',0),('e88ae1205f4cb21433d4d0627ec944ad','./lib/core/Zend/Pdf/UpdateInfoContainer.php','6.3',0),('2512fb986242140b782b8b4a8a200a80','./lib/core/Zend/ProgressBar.php','6.3',0),('990efc830d988bb9eea966560d3acaf0','./lib/core/Zend/ProgressBar/Adapter.php','6.3',0),('f10c67464657009e65ba2bb5ac549b98','./lib/core/Zend/ProgressBar/Adapter/Console.php','6.3',0),('628e739fa5c8cea411ce5ec254d3d73c','./lib/core/Zend/ProgressBar/Adapter/Exception.php','6.3',0),('3942593e32ffa6a17c8830c3396115d1','./lib/core/Zend/ProgressBar/Adapter/JsPull.php','6.3',0),('d65d52125a12036eec778dac0a2e14d4','./lib/core/Zend/ProgressBar/Adapter/JsPush.php','6.3',0),('2da2ad6c90799426484e1296d2ff9adb','./lib/core/Zend/ProgressBar/Exception.php','6.3',0),('e26e365a975e0a0e34e1bf4814b7fa84','./lib/core/Zend/Queue.php','6.3',0),('837b92f4011061f402243f9337289f60','./lib/core/Zend/Queue/Adapter/Activemq.php','6.3',0),('e2a8907b7343d3a295f88568e04569aa','./lib/core/Zend/Queue/Adapter/AdapterAbstract.php','6.3',0),('70a4fdec1fe0fdd7fe58c5a7589d66e3','./lib/core/Zend/Queue/Adapter/AdapterInterface.php','6.3',0),('28294421a27b345f42036761c2190e62','./lib/core/Zend/Queue/Adapter/Array.php','6.3',0),('63f16b57dec4ce10428c0b76b2c40a49','./lib/core/Zend/Queue/Adapter/Db.php','6.3',0),('0749c96e5b2dbf7f6d4db30efa109151','./lib/core/Zend/Queue/Adapter/Db/Message.php','6.3',0),('cc738bb54b0862848658e511397f34ad','./lib/core/Zend/Queue/Adapter/Db/Queue.php','6.3',0),('9d30feeddc72afd65820b9f0fd31a7fb','./lib/core/Zend/Queue/Adapter/Memcacheq.php','6.3',0),('97bb945af2408392af3ecd0fcf355e34','./lib/core/Zend/Queue/Adapter/Null.php','6.3',0),('6f399fe3080dca525c2da02433181efa','./lib/core/Zend/Queue/Adapter/PlatformJobQueue.php','6.3',0),('9ed5b969bddbdd01c8b0f43e4087cf66','./lib/core/Zend/Queue/Exception.php','6.3',0),('eb1870bc57d1064760d16400cbfb7b25','./lib/core/Zend/Queue/Message.php','6.3',0),('ebff1a8e3c866f2ca80eb240ecd704fd','./lib/core/Zend/Queue/Message/Iterator.php','6.3',0),('ab74bd6192407d431ac5c50cabd5f0d0','./lib/core/Zend/Queue/Message/PlatformJob.php','6.3',0),('e6605a478b29bbbc8fb9ce5d6bde2266','./lib/core/Zend/Queue/Stomp/Client.php','6.3',0),('b000ee9d9a5db15236123cb2cef6bad7','./lib/core/Zend/Queue/Stomp/Client/Connection.php','6.3',0),('851371e9f2e4583ab73bf570a13b3a95','./lib/core/Zend/Queue/Stomp/Client/ConnectionInterface.php','6.3',0),('6e6ec2a261dbe31487eba20ed0f3d522','./lib/core/Zend/Queue/Stomp/Frame.php','6.3',0),('935c7488e415787f7d5712f16adc0b49','./lib/core/Zend/Queue/Stomp/FrameInterface.php','6.3',0),('fed7b983cbc14beb0993547c3dd87f32','./lib/core/Zend/Reflection/Class.php','6.3',0),('17ea8dfb03051d34db88fb4c0bd89399','./lib/core/Zend/Reflection/Docblock.php','6.3',0),('2b7a85aa193176bf3524d6e4948c9d08','./lib/core/Zend/Reflection/Docblock/Tag.php','6.3',0),('2ea05305f902062b0f2fc144c209ccb9','./lib/core/Zend/Reflection/Docblock/Tag/Param.php','6.3',0),('4bb22746528e89cf3091ed9ae171f9fb','./lib/core/Zend/Reflection/Docblock/Tag/Return.php','6.3',0),('b3abec846f209f24284b1e1477a44bd4','./lib/core/Zend/Reflection/Exception.php','6.3',0),('83a8b98f18e5b3cbe5ba7a26158140ce','./lib/core/Zend/Reflection/Extension.php','6.3',0),('7c3e433e08d59c6f9a10f7adf18a92b4','./lib/core/Zend/Reflection/File.php','6.3',0),('3b005dfc2ca8bfe136c19808e3ab21c7','./lib/core/Zend/Reflection/Function.php','6.3',0),('ebcf2b4e52b9dac9db1fd20c74e8c454','./lib/core/Zend/Reflection/Method.php','6.3',0),('6cfe4def79c4345ba137cbe07bea38f0','./lib/core/Zend/Reflection/Parameter.php','6.3',0),('5c799e1c7732e9e8f504c6ca9b9cde6e','./lib/core/Zend/Reflection/Property.php','6.3',0),('09fe3531076c5536fbbf607376730cd5','./lib/core/Zend/Registry.php','6.3',0),('278a9fabf54b1175721cd9225a10bdd0','./lib/core/Zend/Rest/Client.php','6.3',0),('18c60cea5d4d22bdeaec8f29bf443c43','./lib/core/Zend/Rest/Client/Exception.php','6.3',0),('8451ff363dfc37a7cee1eac727db97c9','./lib/core/Zend/Rest/Client/Result.php','6.3',0),('2e28867ca62824392c0863f63d2801cb','./lib/core/Zend/Rest/Client/Result/Exception.php','6.3',0),('143b41db4793d2f4260660a1f8ed3499','./lib/core/Zend/Rest/Controller.php','6.3',0),('30922b6968a7be3dde62748fd76ed37e','./lib/core/Zend/Rest/Exception.php','6.3',0),('e67ab8811433f7b8c592f963cbc4aa05','./lib/core/Zend/Rest/Route.php','6.3',0),('0fea0fcaa4665dad69a8ace5cc5dd2e5','./lib/core/Zend/Rest/Server.php','6.3',0),('63a42f2705b9db149235a6652e2307ce','./lib/core/Zend/Rest/Server/Exception.php','6.3',0),('1bdd7b4c21b1d87dea6aa35d222af39f','./lib/core/Zend/Search/Exception.php','6.3',0),('a45a0e1f16581fa006f0f6a215877c85','./lib/core/Zend/Search/Lucene.php','6.3',0),('2daf3dead82ac68a0d750ccdd942d7d3','./lib/core/Zend/Search/Lucene/Analysis/Analyzer.php','6.3',0),('a28d253e440199bb1a08793dfa8ca8bc','./lib/core/Zend/Search/Lucene/Analysis/Analyzer/Common.php','6.3',0),('2914833248d91f4dd43cfd0228e1aa7d','./lib/core/Zend/Search/Lucene/Analysis/Analyzer/Common/Text.php','6.3',0),('d7cfe8d0a2688e113c64b09a0c6d008b','./lib/core/Zend/Search/Lucene/Analysis/Analyzer/Common/Text/CaseInsensitive.php','6.3',0),('c679eeab217e442c7fa6277a241affc1','./lib/core/Zend/Search/Lucene/Analysis/Analyzer/Common/TextNum.php','6.3',0),('34bfa5e0ff9a906193e89d0f365afba2','./lib/core/Zend/Search/Lucene/Analysis/Analyzer/Common/TextNum/CaseInsensitive.php','6.3',0),('2dc1058043631eada4b7ec4f86190766','./lib/core/Zend/Search/Lucene/Analysis/Analyzer/Common/Utf8.php','6.3',0),('a426eb5094b823bdbfccb9429f506f80','./lib/core/Zend/Search/Lucene/Analysis/Analyzer/Common/Utf8/CaseInsensitive.php','6.3',0),('49d6cc4500464e93c65fac34ce6c13a2','./lib/core/Zend/Search/Lucene/Analysis/Analyzer/Common/Utf8Num.php','6.3',0),('14e8e750cb58c9f54a2c3a4e334b30d2','./lib/core/Zend/Search/Lucene/Analysis/Analyzer/Common/Utf8Num/CaseInsensitive.php','6.3',0),('f58966bd5d345e547da5cc7d609f639f','./lib/core/Zend/Search/Lucene/Analysis/Token.php','6.3',0),('3b365cd879088d7e1cfba69bf9c55526','./lib/core/Zend/Search/Lucene/Analysis/TokenFilter.php','6.3',0),('e499b4553e038c467501ecb8014dd78f','./lib/core/Zend/Search/Lucene/Analysis/TokenFilter/LowerCase.php','6.3',0),('0792e5bbf674b3cf77c97650834bdbb9','./lib/core/Zend/Search/Lucene/Analysis/TokenFilter/LowerCaseUtf8.php','6.3',0),('1b7564521d6e3e0e074fb2c387f72d8b','./lib/core/Zend/Search/Lucene/Analysis/TokenFilter/ShortWords.php','6.3',0),('3fa068ccf4d21617f62d9602e697fb56','./lib/core/Zend/Search/Lucene/Analysis/TokenFilter/StopWords.php','6.3',0),('6c40dff656b8fbf4c1640b8a562a4b8b','./lib/core/Zend/Search/Lucene/Document.php','6.3',0),('2970389b14104358e6b47f21180ada5b','./lib/core/Zend/Search/Lucene/Document/Docx.php','6.3',0),('c7e8c7a2c154d93da594d4cc1a8db3cf','./lib/core/Zend/Search/Lucene/Document/Exception.php','6.3',0),('b9c64401ca54e1de835473a4bd9ba98f','./lib/core/Zend/Search/Lucene/Document/Html.php','6.3',0),('1db25facbc3123db7c8bb0ca042fe965','./lib/core/Zend/Search/Lucene/Document/OpenXml.php','6.3',0),('b8ff4c755b5f52a9b8c0a800873e3e00','./lib/core/Zend/Search/Lucene/Document/Pptx.php','6.3',0),('754f08ae2c5decec65c28fb6e0ebbfd8','./lib/core/Zend/Search/Lucene/Document/Xlsx.php','6.3',0),('2d91f3e1b895097d48009a469b9f809f','./lib/core/Zend/Search/Lucene/Exception.php','6.3',0),('a7402883ea92f1bc7b1f3a958f988d9d','./lib/core/Zend/Search/Lucene/FSM.php','6.3',0),('e91940fe17d40b15c2160176a134f8c2','./lib/core/Zend/Search/Lucene/FSMAction.php','6.3',0),('e8ab9ef7d159f56b065ce6e456d0a951','./lib/core/Zend/Search/Lucene/Field.php','6.3',0),('2c26f2a02f9212d0e5da0b3fdbb0aa33','./lib/core/Zend/Search/Lucene/Index/DictionaryLoader.php','6.3',0),('1b9636cf3fb56511e2e072c869d74302','./lib/core/Zend/Search/Lucene/Index/DocsFilter.php','6.3',0),('9d2894953179586a21952e5917169b61','./lib/core/Zend/Search/Lucene/Index/FieldInfo.php','6.3',0),('2c2edd7489fa2854d2d50cdf9f5ae5bb','./lib/core/Zend/Search/Lucene/Index/SegmentInfo.php','6.3',0),('65fd2414f40f694b794a4febf9446933','./lib/core/Zend/Search/Lucene/Index/SegmentMerger.php','6.3',0),('32643bc91dfa4345b6188faefab731f3','./lib/core/Zend/Search/Lucene/Index/SegmentWriter.php','6.3',0),('8778b33ad9712ab93669fd28d9c72b2a','./lib/core/Zend/Search/Lucene/Index/SegmentWriter/DocumentWriter.php','6.3',0),('160e2548a12353118650ac7b344a5dd9','./lib/core/Zend/Search/Lucene/Index/SegmentWriter/StreamWriter.php','6.3',0),('681a3006597261d3955b7e297b9337e8','./lib/core/Zend/Search/Lucene/Index/Term.php','6.3',0),('511ac7aaf73a6728c6af0b92cc6983d2','./lib/core/Zend/Search/Lucene/Index/TermInfo.php','6.3',0),('ec08fa36c9052385b5f766b911ed0f97','./lib/core/Zend/Search/Lucene/Index/TermsPriorityQueue.php','6.3',0),('228d757bbf55baf46fc75d4aa92ef42f','./lib/core/Zend/Search/Lucene/Index/TermsStream/Interface.php','6.3',0),('de80219bb33202b5736b06ae85aee23d','./lib/core/Zend/Search/Lucene/Index/Writer.php','6.3',0),('6a86e39e0da709563c56794d387db9aa','./lib/core/Zend/Search/Lucene/Interface.php','6.3',0),('0132119c3f37b8f78b1723549194a37f','./lib/core/Zend/Search/Lucene/LockManager.php','6.3',0),('32b37399d1257429923a00b6c374b45d','./lib/core/Zend/Search/Lucene/MultiSearcher.php','6.3',0),('11cdd54d906d213ec9977a42713f39aa','./lib/core/Zend/Search/Lucene/PriorityQueue.php','6.3',0),('c0ec5cc35135efa294004c0def6dc452','./lib/core/Zend/Search/Lucene/Proxy.php','6.3',0),('2406aa01be041be5a149c0f05abe91da','./lib/core/Zend/Search/Lucene/Search/BooleanExpressionRecognizer.php','6.3',0),('9c2f205f0a4f152b24d055169e5972fc','./lib/core/Zend/Search/Lucene/Search/Highlighter/Default.php','6.3',0),('9f96f5286527cf84ec480e2e2d818c70','./lib/core/Zend/Search/Lucene/Search/Highlighter/Interface.php','6.3',0),('2195ddaca3f2db90a28e14e6fed3496e','./lib/core/Zend/Search/Lucene/Search/Query.php','6.3',0),('21a7cc88de5d59eda2d1830d7238c010','./lib/core/Zend/Search/Lucene/Search/Query/Boolean.php','6.3',0),('558b1070e9f823ed6bde43593c34e120','./lib/core/Zend/Search/Lucene/Search/Query/Empty.php','6.3',0),('2cf0af41571f5881b3eacc123c8da58a','./lib/core/Zend/Search/Lucene/Search/Query/Fuzzy.php','6.3',0),('c81b808e06867d562ca3b5f136ef7499','./lib/core/Zend/Search/Lucene/Search/Query/Insignificant.php','6.3',0),('7ccdebe3db8ec8788fa01a3dfc7db7b3','./lib/core/Zend/Search/Lucene/Search/Query/MultiTerm.php','6.3',0),('37605e6e02312d178eeb4c47149332fd','./lib/core/Zend/Search/Lucene/Search/Query/Phrase.php','6.3',0),('19dafc229fe00dd5eaa4da1ce7d6cf9e','./lib/core/Zend/Search/Lucene/Search/Query/Preprocessing.php','6.3',0),('aca9897e3f5095bc3621465120d582a2','./lib/core/Zend/Search/Lucene/Search/Query/Preprocessing/Fuzzy.php','6.3',0),('6b24f7ae3789e2e5a4411ffcf86fd048','./lib/core/Zend/Search/Lucene/Search/Query/Preprocessing/Phrase.php','6.3',0),('a32184003d550758990dbf17ee9d06ef','./lib/core/Zend/Search/Lucene/Search/Query/Preprocessing/Term.php','6.3',0),('384e8cfa08b3750d892c407dc1e50a1f','./lib/core/Zend/Search/Lucene/Search/Query/Range.php','6.3',0),('5a1b93deb560ef55a591204a94b9bd86','./lib/core/Zend/Search/Lucene/Search/Query/Term.php','6.3',0),('bf99e62e2cbbb1fa9167fde7750af4d6','./lib/core/Zend/Search/Lucene/Search/Query/Wildcard.php','6.3',0),('e6c714bc8ed58b2567a98bdaa3243473','./lib/core/Zend/Search/Lucene/Search/QueryEntry.php','6.3',0),('26736ed40347211ff24490d1f9fed5d4','./lib/core/Zend/Search/Lucene/Search/QueryEntry/Phrase.php','6.3',0),('465b55766f5a5fc994c5f19782baa5a6','./lib/core/Zend/Search/Lucene/Search/QueryEntry/Subquery.php','6.3',0),('5dc9ec52b8917f48733e7ad4d8418382','./lib/core/Zend/Search/Lucene/Search/QueryEntry/Term.php','6.3',0),('9026b974847bd8db5fe849f94ed39ec9','./lib/core/Zend/Search/Lucene/Search/QueryHit.php','6.3',0),('03ab3da1d8df5c4b1eea1606c837771b','./lib/core/Zend/Search/Lucene/Search/QueryLexer.php','6.3',0),('d9574468af74c960324e6b15612ddf0f','./lib/core/Zend/Search/Lucene/Search/QueryParser.php','6.3',0),('2f7e24cf0069f7f9fb486260bb43c951','./lib/core/Zend/Search/Lucene/Search/QueryParserContext.php','6.3',0),('7b5c45a35763705a33fbdd2afea0da57','./lib/core/Zend/Search/Lucene/Search/QueryParserException.php','6.3',0),('81205c4e5a296e3b9e86b9b2177a3f2b','./lib/core/Zend/Search/Lucene/Search/QueryToken.php','6.3',0),('079425dee452a764d3d94b24c0621cae','./lib/core/Zend/Search/Lucene/Search/Similarity.php','6.3',0),('b4e9aa3ea871b6ebcb83002b22f76022','./lib/core/Zend/Search/Lucene/Search/Similarity/Default.php','6.3',0),('5597f3d28d2742be273407ed9c5a359d','./lib/core/Zend/Search/Lucene/Search/Weight.php','6.3',0),('b494eff3c495ea3ab048d1b692d23599','./lib/core/Zend/Search/Lucene/Search/Weight/Boolean.php','6.3',0),('c7de7d083cd07ab1604472d25e146fc2','./lib/core/Zend/Search/Lucene/Search/Weight/Empty.php','6.3',0),('faeb0e3023e111d19135277389f21c66','./lib/core/Zend/Search/Lucene/Search/Weight/MultiTerm.php','6.3',0),('582061c35c6cad8faa0c03d153a0e359','./lib/core/Zend/Search/Lucene/Search/Weight/Phrase.php','6.3',0),('744ccac10d2091fbf660b2bf130dee80','./lib/core/Zend/Search/Lucene/Search/Weight/Term.php','6.3',0),('94417a2e722bd7032e0fd521c3e8b6e3','./lib/core/Zend/Search/Lucene/Storage/Directory.php','6.3',0),('dbaa9c2d06215bcf6792799b892ab5cb','./lib/core/Zend/Search/Lucene/Storage/Directory/Filesystem.php','6.3',0),('78fac7e63213aa5d022957e3b32f971c','./lib/core/Zend/Search/Lucene/Storage/File.php','6.3',0),('b5cf925608546dc7f08a37562aeb12af','./lib/core/Zend/Search/Lucene/Storage/File/Filesystem.php','6.3',0),('6f3653086083d3bd9bc828dfd7e5b331','./lib/core/Zend/Search/Lucene/Storage/File/Memory.php','6.3',0),('44e7be1925f31b16deb856bcb92dd23c','./lib/core/Zend/Search/Lucene/TermStreamsPriorityQueue.php','6.3',0),('3361ac4fea2b22e74861578aecb1c105','./lib/core/Zend/Serializer.php','6.3',0),('f9ecf60952c12747b6eb2844a19cbaaa','./lib/core/Zend/Serializer/Adapter/AdapterAbstract.php','6.3',0),('ff591d1abc4e6c1108f355115c43f482','./lib/core/Zend/Serializer/Adapter/AdapterInterface.php','6.3',0),('0c82ced439b6068724adfb27d429f61e','./lib/core/Zend/Serializer/Adapter/Amf0.php','6.3',0),('c21fc6c0f87a756533d13a0b5c3d2a5f','./lib/core/Zend/Serializer/Adapter/Amf3.php','6.3',0),('ae47b4624ffd196a8ec784daa5066721','./lib/core/Zend/Serializer/Adapter/Igbinary.php','6.3',0),('c864142e90655254bd0cd2384177067e','./lib/core/Zend/Serializer/Adapter/Json.php','6.3',0),('e8e1f76e7b012ea2dd50fde125471961','./lib/core/Zend/Serializer/Adapter/PhpCode.php','6.3',0),('b2a851e1fae80976542e8d23f5af23b2','./lib/core/Zend/Serializer/Adapter/PhpSerialize.php','6.3',0),('3ccbf585073900a8537b57c22835d45a','./lib/core/Zend/Serializer/Adapter/PythonPickle.php','6.3',0),('4a23835599ff7f96ae5559e93091f80c','./lib/core/Zend/Serializer/Adapter/Wddx.php','6.3',0),('e174b8da4cf7d7945eba4d315a030eaa','./lib/core/Zend/Serializer/Exception.php','6.3',0),('e6a0cc03ab8653d4530f9167241951d3','./lib/core/Zend/Server/Abstract.php','6.3',0),('eaa7f3d793475d6820787125000a4135','./lib/core/Zend/Server/Cache.php','6.3',0),('a680cd868ad1e0bd1c2daec1fc94cc92','./lib/core/Zend/Server/Definition.php','6.3',0),('78ef9d593251610aace9fc48591b19cc','./lib/core/Zend/Server/Exception.php','6.3',0),('3a2f664fff432e77d66b01b7d434401a','./lib/core/Zend/Server/Interface.php','6.3',0),('4f07019ca70945c0f53a0cf537d86d53','./lib/core/Zend/Server/Method/Callback.php','6.3',0),('406aaf858142ecab3ec5f56073f45991','./lib/core/Zend/Server/Method/Definition.php','6.3',0),('87d821dcf0ea16f891459a0c088ff129','./lib/core/Zend/Server/Method/Parameter.php','6.3',0),('8d9e2ff61ac902bd2123d16b23541454','./lib/core/Zend/Server/Method/Prototype.php','6.3',0),('1bc3aaf075a6e84b2a4ff62e3e9e2909','./lib/core/Zend/Server/Reflection.php','6.3',0),('77ecb1d9fd7c23513c9148d33c5376e2','./lib/core/Zend/Server/Reflection/Class.php','6.3',0),('251c35c31d5e7f944d3e025aa9c760c9','./lib/core/Zend/Server/Reflection/Exception.php','6.3',0),('a580e1786151cd5f3deb0efb20547f66','./lib/core/Zend/Server/Reflection/Function.php','6.3',0),('35c8b0bdae5af14d4e5f7e3a2f9c0266','./lib/core/Zend/Server/Reflection/Function/Abstract.php','6.3',0),('793ea29abc173bc5fac235472590400e','./lib/core/Zend/Server/Reflection/Method.php','6.3',0),('76f033882195d7860e62e83889e42f9a','./lib/core/Zend/Server/Reflection/Node.php','6.3',0),('52cdf615c0e94cafa9527aca841d6e2f','./lib/core/Zend/Server/Reflection/Parameter.php','6.3',0),('6b8cfb6ea1e97548c959a1eee60803ad','./lib/core/Zend/Server/Reflection/Prototype.php','6.3',0),('c69d0ec9e2de811938079493a8fd0951','./lib/core/Zend/Server/Reflection/ReturnValue.php','6.3',0),('00c05b511d238fac405bd1286e98a97d','./lib/core/Zend/Service/Abstract.php','6.3',0),('94ecad720931578685851cb057039282','./lib/core/Zend/Service/Akismet.php','6.3',0),('a773ef32ace1163c8b2f2e706702b298','./lib/core/Zend/Service/Amazon.php','6.3',0),('b48beae682d2978a48e63f045387bff5','./lib/core/Zend/Service/Amazon/Abstract.php','6.3',0),('60cac2da0708233a073e89b68aa1f1c9','./lib/core/Zend/Service/Amazon/Accessories.php','6.3',0),('9dc8a5bbc5ef9cb651270a52b5c1cc88','./lib/core/Zend/Service/Amazon/CustomerReview.php','6.3',0),('4935d17778e3fbf87932d010381070ac','./lib/core/Zend/Service/Amazon/Ec2.php','6.3',0),('7af891f84951194fa032e94f3a5d451c','./lib/core/Zend/Service/Amazon/Ec2/Abstract.php','6.3',0),('079229cdab36c8f9d60bde7215078c55','./lib/core/Zend/Service/Amazon/Ec2/Availabilityzones.php','6.3',0),('b3f275d9d86e51f6606b55cc3cfe76ca','./lib/core/Zend/Service/Amazon/Ec2/CloudWatch.php','6.3',0),('4ac560443e0be121d4fe61ebcc0f2c34','./lib/core/Zend/Service/Amazon/Ec2/Ebs.php','6.3',0),('99f41378ff6c4fac931adf13188c7607','./lib/core/Zend/Service/Amazon/Ec2/Elasticip.php','6.3',0),('32067a54e27d2701d2da02df41f69092','./lib/core/Zend/Service/Amazon/Ec2/Exception.php','6.3',0),('4e5df28120218643db552d709d701dfd','./lib/core/Zend/Service/Amazon/Ec2/Image.php','6.3',0),('4f7a3d02e178adbc67f21ff8a8904aaa','./lib/core/Zend/Service/Amazon/Ec2/Instance.php','6.3',0),('7c546e4b6bf378d3ded1567cad3aef77','./lib/core/Zend/Service/Amazon/Ec2/Instance/Reserved.php','6.3',0),('e40e95e23194734ac23d99b43befe6da','./lib/core/Zend/Service/Amazon/Ec2/Instance/Windows.php','6.3',0),('a0c9e75056fc3c46ebf8e0c8b1310f77','./lib/core/Zend/Service/Amazon/Ec2/Keypair.php','6.3',0),('e89baf99d5134f887bedfb7f403fa112','./lib/core/Zend/Service/Amazon/Ec2/Region.php','6.3',0),('86b21861acfc195ab93b360cde613416','./lib/core/Zend/Service/Amazon/Ec2/Response.php','6.3',0),('c0e41746b34e4669ac20e9d14618714b','./lib/core/Zend/Service/Amazon/Ec2/Securitygroups.php','6.3',0),('c3a63b5f8e947e40f8fe618253e870f1','./lib/core/Zend/Service/Amazon/EditorialReview.php','6.3',0),('717c954192faf4e24583bcbe3fb248df','./lib/core/Zend/Service/Amazon/Exception.php','6.3',0),('221d5acebdb9d7865aa143c1caf3d3c2','./lib/core/Zend/Service/Amazon/Image.php','6.3',0),('a153ee080b83c062feacd20a0775e0ba','./lib/core/Zend/Service/Amazon/Item.php','6.3',0),('830ea46a55efb777c3ce3b374f53cfc0','./lib/core/Zend/Service/Amazon/ListmaniaList.php','6.3',0),('6085587e89b917e7542474c13d43345f','./lib/core/Zend/Service/Amazon/Offer.php','6.3',0),('fcbcf755695f5371d2635f2e9419d76c','./lib/core/Zend/Service/Amazon/OfferSet.php','6.3',0),('1a2603b87395ee83e1712455f39c86a5','./lib/core/Zend/Service/Amazon/Query.php','6.3',0),('e04d74d587f72217c34c425c6cb75234','./lib/core/Zend/Service/Amazon/ResultSet.php','6.3',0),('7caccdf87dcb8ce0c17b87be52fa413d','./lib/core/Zend/Service/Amazon/S3.php','6.3',0),('4ef7a16803a9eed30fb78378aac0cc4f','./lib/core/Zend/Service/Amazon/S3/Exception.php','6.3',0),('946d77263daf4fa3ecf8e27be54f3035','./lib/core/Zend/Service/Amazon/S3/Stream.php','6.3',0),('d9c82fc39868c87e863ed991fb8623d8','./lib/core/Zend/Service/Amazon/SimilarProduct.php','6.3',0),('e4c30985f9d615c02159dace36f2f5f4','./lib/core/Zend/Service/Amazon/Sqs.php','6.3',0),('430b454b46b6c3b7273b6ae0b094f9f8','./lib/core/Zend/Service/Amazon/Sqs/Exception.php','6.3',0),('8caa2521df59fa492efaf01c050c4e82','./lib/core/Zend/Service/Audioscrobbler.php','6.3',0),('aca6275d6fcbf774bed92484d1ff8c59','./lib/core/Zend/Service/Delicious.php','6.3',0),('076ea6d2cc3b007e7e71e5e534f304d6','./lib/core/Zend/Service/Delicious/Exception.php','6.3',0),('4228f0d665250e03524cc513c078dd6c','./lib/core/Zend/Service/Delicious/Post.php','6.3',0),('095ee2208c911d996ccfde77af66968d','./lib/core/Zend/Service/Delicious/PostList.php','6.3',0),('8cab95ba24400ee4105fefe7ba8269e9','./lib/core/Zend/Service/Delicious/SimplePost.php','6.3',0),('6900a957c00319622b0548ee302515e9','./lib/core/Zend/Service/DeveloperGarden/BaseUserService.php','6.3',0),('f79170567edec47a6a090c365df5af2b','./lib/core/Zend/Service/DeveloperGarden/BaseUserService/AccountBalance.php','6.3',0),('d571330f652ef4137efb7cfcae12fc54','./lib/core/Zend/Service/DeveloperGarden/Client/ClientAbstract.php','6.3',0),('0e80392a4f8c6a79ab012188709b5e47','./lib/core/Zend/Service/DeveloperGarden/Client/Exception.php','6.3',0),('240b714909add3214fcfb75abb0c34a3','./lib/core/Zend/Service/DeveloperGarden/Client/Soap.php','6.3',0),('371c7d0992eeeb5b5488857b15637e2a','./lib/core/Zend/Service/DeveloperGarden/ConferenceCall.php','6.3',0),('1e9ce1d051d866d2801a7e8864d47bb9','./lib/core/Zend/Service/DeveloperGarden/ConferenceCall/ConferenceAccount.php','6.3',0),('d7fcc3790cabad7caf31512cb6c304a1','./lib/core/Zend/Service/DeveloperGarden/ConferenceCall/ConferenceDetail.php','6.3',0),('cdcd8ff0cb6250f3144fcc7cd4e27d88','./lib/core/Zend/Service/DeveloperGarden/ConferenceCall/ConferenceSchedule.php','6.3',0),('ff6a16ec6ca6358d76650e0c12a9fac3','./lib/core/Zend/Service/DeveloperGarden/ConferenceCall/Exception.php','6.3',0),('a8f6427ff83abfc48b10532046d09b21','./lib/core/Zend/Service/DeveloperGarden/ConferenceCall/Participant.php','6.3',0),('e50458cb45c8c1f5c61e0a825d654dc1','./lib/core/Zend/Service/DeveloperGarden/ConferenceCall/ParticipantDetail.php','6.3',0),('52fa182fffc34dec4d4a2a54cff00eb1','./lib/core/Zend/Service/DeveloperGarden/ConferenceCall/ParticipantStatus.php','6.3',0),('52f2fb165bd042fe36deba2389b1f12f','./lib/core/Zend/Service/DeveloperGarden/Credential.php','6.3',0),('192a2aed3ac53fb0ff173f1de9d6dab0','./lib/core/Zend/Service/DeveloperGarden/Exception.php','6.3',0),('6880175e73307909644632b263b9cf9e','./lib/core/Zend/Service/DeveloperGarden/IpLocation.php','6.3',0),('5231f61ad8641407f48ae5f643069646','./lib/core/Zend/Service/DeveloperGarden/IpLocation/IpAddress.php','6.3',0),('f2dd1d3ab46cb20488e6e14efd46e20e','./lib/core/Zend/Service/DeveloperGarden/LocalSearch.php','6.3',0),('a6814aef2183795d2364940eb585581f','./lib/core/Zend/Service/DeveloperGarden/LocalSearch/Exception.php','6.3',0),('450b51ff18e9f7196fdea0d33abbd6e9','./lib/core/Zend/Service/DeveloperGarden/LocalSearch/SearchParameters.php','6.3',0),('7d07a073630d20c14bc95492626041ac','./lib/core/Zend/Service/DeveloperGarden/Request/BaseUserService/ChangeQuotaPool.php','6.3',0),('bd2cbbac0468fda16f3f478fefb7ee7a','./lib/core/Zend/Service/DeveloperGarden/Request/BaseUserService/GetAccountBalance.php','6.3',0),('6c578c44163ba3743e9325fa0778d737','./lib/core/Zend/Service/DeveloperGarden/Request/BaseUserService/GetQuotaInformation.php','6.3',0),('da7c71b252e0690160f7f928c4406fcd','./lib/core/Zend/Service/DeveloperGarden/Request/ConferenceCall/AddConferenceTemplateParticipantRequest.php','6.3',0),('8048e1b1d3a4003291b6dde681064158','./lib/core/Zend/Service/DeveloperGarden/Request/ConferenceCall/CommitConferenceRequest.php','6.3',0),('5020d87de61090a7cb279f59619dc60d','./lib/core/Zend/Service/DeveloperGarden/Request/ConferenceCall/CreateConferenceRequest.php','6.3',0),('5837f30b9a23d373bdd8c543916175a5','./lib/core/Zend/Service/DeveloperGarden/Request/ConferenceCall/CreateConferenceTemplateRequest.php','6.3',0),('ddc0cb230ce23e38c6b8e14a027b611a','./lib/core/Zend/Service/DeveloperGarden/Request/ConferenceCall/GetConferenceListRequest.php','6.3',0),('da5b2413d39f7a765824de8dd0b1cb98','./lib/core/Zend/Service/DeveloperGarden/Request/ConferenceCall/GetConferenceStatusRequest.php','6.3',0),('76fe963480ae7103ea4e21ceb0a67707','./lib/core/Zend/Service/DeveloperGarden/Request/ConferenceCall/GetConferenceTemplateListRequest.php','6.3',0),('db6ae6651c3814cfe2ee983e7facaed6','./lib/core/Zend/Service/DeveloperGarden/Request/ConferenceCall/GetConferenceTemplateParticipantRequest.php','6.3',0),('bd2a3866ba9205baebc93d5f7babaf4e','./lib/core/Zend/Service/DeveloperGarden/Request/ConferenceCall/GetConferenceTemplateRequest.php','6.3',0),('ed4ddef71ee33dcfbfd25fb8f83a8e38','./lib/core/Zend/Service/DeveloperGarden/Request/ConferenceCall/GetParticipantStatusRequest.php','6.3',0),('0210fe811ecf339c537e60e626dde2de','./lib/core/Zend/Service/DeveloperGarden/Request/ConferenceCall/GetRunningConferenceRequest.php','6.3',0),('05eef85368e195cc41514fc410de0305','./lib/core/Zend/Service/DeveloperGarden/Request/ConferenceCall/NewParticipantRequest.php','6.3',0),('a4430e080df1fe9cb8a3183189ffe07f','./lib/core/Zend/Service/DeveloperGarden/Request/ConferenceCall/RemoveConferenceRequest.php','6.3',0),('c735badba8652cb040d615b0c2ae0bd6','./lib/core/Zend/Service/DeveloperGarden/Request/ConferenceCall/RemoveConferenceTemplateParticipantRequest.php','6.3',0),('5f8f7f920b8e5daf837d796479a2e8a2','./lib/core/Zend/Service/DeveloperGarden/Request/ConferenceCall/RemoveConferenceTemplateRequest.php','6.3',0),('8714795b75454166261a01bea8a241b8','./lib/core/Zend/Service/DeveloperGarden/Request/ConferenceCall/RemoveParticipantRequest.php','6.3',0),('0e6e5a49e51cdd2d85b3fd732dcb36fe','./lib/core/Zend/Service/DeveloperGarden/Request/ConferenceCall/UpdateConferenceRequest.php','6.3',0),('276a3ed14f6c9e4dbb9bd227c533fdec','./lib/core/Zend/Service/DeveloperGarden/Request/ConferenceCall/UpdateConferenceTemplateParticipantRequest.php','6.3',0),('ea62ef0727df57aea2fa4aa836bd7f92','./lib/core/Zend/Service/DeveloperGarden/Request/ConferenceCall/UpdateConferenceTemplateRequest.php','6.3',0),('d8ee02faa83c8ed6d11a351afdbdf776','./lib/core/Zend/Service/DeveloperGarden/Request/ConferenceCall/UpdateParticipantRequest.php','6.3',0),('a3faba2e413f06ed1beaf09da82be3d3','./lib/core/Zend/Service/DeveloperGarden/Request/Exception.php','6.3',0),('9f00a2214e5971c2ab1f51dcfc0c04ce','./lib/core/Zend/Service/DeveloperGarden/Request/IpLocation/LocateIPRequest.php','6.3',0),('9ae0ef2d57c1cbffec883dbd553d1c46','./lib/core/Zend/Service/DeveloperGarden/Request/LocalSearch/LocalSearchRequest.php','6.3',0),('9d105331eebf7b6a3307745181b9689e','./lib/core/Zend/Service/DeveloperGarden/Request/RequestAbstract.php','6.3',0),('f23af685ab0f2693e7beb44e852f0fb9','./lib/core/Zend/Service/DeveloperGarden/Request/SendSms/SendFlashSMS.php','6.3',0),('454dea2b2b80f51c0115b74e573eba80','./lib/core/Zend/Service/DeveloperGarden/Request/SendSms/SendSMS.php','6.3',0),('e1db39559ec0f9d9385d73ab2f104412','./lib/core/Zend/Service/DeveloperGarden/Request/SendSms/SendSmsAbstract.php','6.3',0),('fa028def1e2fd22c5a893b0c08abda6c','./lib/core/Zend/Service/DeveloperGarden/Request/SmsValidation/GetValidatedNumbers.php','6.3',0),('f950dc53904cf43a142107209207d1ac','./lib/core/Zend/Service/DeveloperGarden/Request/SmsValidation/Invalidate.php','6.3',0),('56a56375fb735a190c3f6db5b05d73e0','./lib/core/Zend/Service/DeveloperGarden/Request/SmsValidation/SendValidationKeyword.php','6.3',0),('40ab750e2318c8f520380fdb34c2c167','./lib/core/Zend/Service/DeveloperGarden/Request/SmsValidation/Validate.php','6.3',0),('e74b7a9b0a65810e3bc4f06dcd2c7627','./lib/core/Zend/Service/DeveloperGarden/Request/VoiceButler/CallStatus.php','6.3',0),('913237c6367c69dc00f5d76011ab0954','./lib/core/Zend/Service/DeveloperGarden/Request/VoiceButler/NewCall.php','6.3',0),('8a54c333f2e948bee7cf4055b65e8754','./lib/core/Zend/Service/DeveloperGarden/Request/VoiceButler/NewCallSequenced.php','6.3',0),('25df02ab66be021db1f8954f4507fae4','./lib/core/Zend/Service/DeveloperGarden/Request/VoiceButler/TearDownCall.php','6.3',0),('c3b4b180bc286aa81c63445b7d80241d','./lib/core/Zend/Service/DeveloperGarden/Request/VoiceButler/VoiceButlerAbstract.php','6.3',0),('f9894e99983f735b85703a454584e228','./lib/core/Zend/Service/DeveloperGarden/Response/BaseType.php','6.3',0),('edf633030a49bb1cef4dc051aab5d5c2','./lib/core/Zend/Service/DeveloperGarden/Response/BaseUserService/ChangeQuotaPoolResponse.php','6.3',0),('ce2ff0d6840c6df6f674ffc456905075','./lib/core/Zend/Service/DeveloperGarden/Response/BaseUserService/GetAccountBalanceResponse.php','6.3',0),('d736abc9a38f26bb4bea7cf0e62d7590','./lib/core/Zend/Service/DeveloperGarden/Response/BaseUserService/GetQuotaInformationResponse.php','6.3',0),('9c1528703a7c8099c3a4377616b188b0','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/AddConferenceTemplateParticipantResponse.php','6.3',0),('f3362980de5ae6ad8906c6c8b1db143c','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/AddConferenceTemplateParticipantResponseType.php','6.3',0),('ec8b62b719b81c36bbac09cd97c8439b','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/CCSResponseType.php','6.3',0),('b7f50c4181f7c5837a9a66c3b29fc759','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/CommitConferenceResponse.php','6.3',0),('fe257e184ba5a8bfd68330d1f6e99a3d','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/ConferenceCallAbstract.php','6.3',0),('15aecf7a8704e2342d61e19df444b84b','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/CreateConferenceResponse.php','6.3',0),('afb6f0417662f762a7a4ab3e5f232d40','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/CreateConferenceResponseType.php','6.3',0),('753e0ad572b6fdf57b8d2ca031687afd','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/CreateConferenceTemplateResponse.php','6.3',0),('50956c5126ae55ece14d2107672046f8','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/CreateConferenceTemplateResponseType.php','6.3',0),('8b267bde5bd4aaf51217f662acddbb8d','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/GetConferenceListResponse.php','6.3',0),('bca1a5f24daab755ec4ceb3cad3e44c0','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/GetConferenceListResponseType.php','6.3',0),('c9947d9847af2394bcc38e6b0393438c','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/GetConferenceStatusResponse.php','6.3',0),('5ba72b22db99bcc847940dc491a445bf','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/GetConferenceStatusResponseType.php','6.3',0),('794cf6a4c51c4d8c040a32619b4fd3ef','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/GetConferenceTemplateListResponse.php','6.3',0),('e9fc88fbfef08ef1db2aa6ab53d6f903','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/GetConferenceTemplateListResponseType.php','6.3',0),('137beedccd397770fe0d61523378f118','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/GetConferenceTemplateParticipantResponse.php','6.3',0),('be2a820240ed8c5b9fc0abc6e369bfe0','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/GetConferenceTemplateParticipantResponseType.php','6.3',0),('80b9a959492a3ac3f486be1c7964fd8b','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/GetConferenceTemplateResponse.php','6.3',0),('1cecf5e253a8a03964f76c5e25db277c','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/GetConferenceTemplateResponseType.php','6.3',0),('f4041b503bb2c3e6ab90e9bd3fa67018','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/GetParticipantStatusResponse.php','6.3',0),('0deee367dfa13bff35254d2c0f7211f1','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/GetParticipantStatusResponseType.php','6.3',0),('6c34f56877092ce7f7b6bdc5e8ea72ad','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/GetRunningConferenceResponse.php','6.3',0),('807dda43557876c4df9f734d35d14cc5','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/GetRunningConferenceResponseType.php','6.3',0),('2cd29631172a11e3742d11b3837fdd87','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/NewParticipantResponse.php','6.3',0),('afc90fb848c05a677cef1c65df6c7bd2','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/NewParticipantResponseType.php','6.3',0),('c7870b1d807421c0e1847fbbb0826bc7','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/RemoveConferenceResponse.php','6.3',0),('e3ab5bbec107955b3be7534124817f49','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/RemoveConferenceTemplateParticipantResponse.php','6.3',0),('e6c5c47fe6a0d5d5b85664a10d6819cc','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/RemoveConferenceTemplateResponse.php','6.3',0),('a8a4f105646147e09d050fc82381044d','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/RemoveParticipantResponse.php','6.3',0),('018de20ab4311c2876385ce973bb5653','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/UpdateConferenceResponse.php','6.3',0),('a5e24743784fb7ee0b683687614a1bb7','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/UpdateConferenceTemplateParticipantResponse.php','6.3',0),('785019ce160e28cc3fcf42a6364767c5','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/UpdateConferenceTemplateResponse.php','6.3',0),('1805836a54a379ef3bcc7feb32fa75e5','./lib/core/Zend/Service/DeveloperGarden/Response/ConferenceCall/UpdateParticipantResponse.php','6.3',0),('ab23ff0bdf40aa96846a880e12791693','./lib/core/Zend/Service/DeveloperGarden/Response/Exception.php','6.3',0),('80a58a5947625a0d48048586c49d333d','./lib/core/Zend/Service/DeveloperGarden/Response/IpLocation/CityType.php','6.3',0),('aa8cdf7f84027e454acd75aa22c59854','./lib/core/Zend/Service/DeveloperGarden/Response/IpLocation/GeoCoordinatesType.php','6.3',0),('fce87bffece51efe0c6750f023558a64','./lib/core/Zend/Service/DeveloperGarden/Response/IpLocation/IPAddressLocationType.php','6.3',0),('31197b35c59354b6b7153bbceced388a','./lib/core/Zend/Service/DeveloperGarden/Response/IpLocation/LocateIPResponse.php','6.3',0),('a9dc0dc854cb5bcd608ba3631430b5af','./lib/core/Zend/Service/DeveloperGarden/Response/IpLocation/LocateIPResponseType.php','6.3',0),('fabb838c040b06948e82d9335aa6eb66','./lib/core/Zend/Service/DeveloperGarden/Response/IpLocation/RegionType.php','6.3',0),('dfb9c8649fa86644bd4d9b9722d38487','./lib/core/Zend/Service/DeveloperGarden/Response/LocalSearch/LocalSearchResponse.php','6.3',0),('33606a2e4de3c3a6c211214a645b99da','./lib/core/Zend/Service/DeveloperGarden/Response/LocalSearch/LocalSearchResponseType.php','6.3',0),('965cf6bf9b7410914883689d9fc043b8','./lib/core/Zend/Service/DeveloperGarden/Response/ResponseAbstract.php','6.3',0),('ac2ba7e4b8e9484dc9671eab5b340990','./lib/core/Zend/Service/DeveloperGarden/Response/SecurityTokenServer/Exception.php','6.3',0),('28f3ca724df4f144443744f342782e5a','./lib/core/Zend/Service/DeveloperGarden/Response/SecurityTokenServer/GetTokensResponse.php','6.3',0),('983f5d4acbb407ba862fea42794d741e','./lib/core/Zend/Service/DeveloperGarden/Response/SecurityTokenServer/Interface.php','6.3',0),('a990bdebccfe13e10da0f318fff1f14e','./lib/core/Zend/Service/DeveloperGarden/Response/SecurityTokenServer/SecurityTokenResponse.php','6.3',0),('09034a943f3199e72066491aed03e743','./lib/core/Zend/Service/DeveloperGarden/Response/SendSms/SendFlashSMSResponse.php','6.3',0),('fab231b13a84409bba485ee625ab00da','./lib/core/Zend/Service/DeveloperGarden/Response/SendSms/SendSMSResponse.php','6.3',0),('889d69287af8510ae31bd4d2001564ac','./lib/core/Zend/Service/DeveloperGarden/Response/SendSms/SendSmsAbstract.php','6.3',0),('39d111caf76b170f87c84fd9be305858','./lib/core/Zend/Service/DeveloperGarden/Response/SmsValidation/GetValidatedNumbersResponse.php','6.3',0),('8d12b2e6340c83b0325477089be84d21','./lib/core/Zend/Service/DeveloperGarden/Response/SmsValidation/InvalidateResponse.php','6.3',0),('424a4ab705dd93bb1c1fc59bedad215f','./lib/core/Zend/Service/DeveloperGarden/Response/SmsValidation/SendValidationKeywordResponse.php','6.3',0),('faef959cefd7ae0fed39a13ebfd77b16','./lib/core/Zend/Service/DeveloperGarden/Response/SmsValidation/ValidateResponse.php','6.3',0),('510d2e69a557e3f600f3c123cc89bda8','./lib/core/Zend/Service/DeveloperGarden/Response/SmsValidation/ValidatedNumber.php','6.3',0),('e87cf471f19cc8a4fc834c9d97866105','./lib/core/Zend/Service/DeveloperGarden/Response/VoiceButler/CallStatus2Response.php','6.3',0),('cb7df332163b7b951051ca7c6a0edbba','./lib/core/Zend/Service/DeveloperGarden/Response/VoiceButler/CallStatusResponse.php','6.3',0),('11398ee757725a829df3347dc4952a31','./lib/core/Zend/Service/DeveloperGarden/Response/VoiceButler/NewCallResponse.php','6.3',0),('d413fbbc9fbdc9b35b3007ee26ff37a4','./lib/core/Zend/Service/DeveloperGarden/Response/VoiceButler/NewCallSequencedResponse.php','6.3',0),('75b36f03cfc6b4c7cea5cd7a50aee45d','./lib/core/Zend/Service/DeveloperGarden/Response/VoiceButler/TearDownCallResponse.php','6.3',0),('e2d49a0f4d41aa79f00e24e863673148','./lib/core/Zend/Service/DeveloperGarden/Response/VoiceButler/VoiceButlerAbstract.php','6.3',0),('d499648b596e38dac241600b1cf094af','./lib/core/Zend/Service/DeveloperGarden/SecurityTokenServer.php','6.3',0),('dbb2b085d5ee75ef7bc652d9912c63f3','./lib/core/Zend/Service/DeveloperGarden/SecurityTokenServer/Cache.php','6.3',0),('134436857cab15b4d2702f7e82c9a0e7','./lib/core/Zend/Service/DeveloperGarden/SendSms.php','6.3',0),('a971c852373b14c10f13be270e675a21','./lib/core/Zend/Service/DeveloperGarden/SmsValidation.php','6.3',0),('401024bfa338038d4d78ce7f4a183474','./lib/core/Zend/Service/DeveloperGarden/VoiceCall.php','6.3',0),('37d820aca89c90611dc52903f36ad39c','./lib/core/Zend/Service/Exception.php','6.3',0),('a2da516d816739bd8853637e793d7304','./lib/core/Zend/Service/Flickr.php','6.3',0),('30faef3a8c974028066b6adb74b6b0a3','./lib/core/Zend/Service/Flickr/Image.php','6.3',0),('f6b0f3eb8f4d7ceef77f3f69443e394c','./lib/core/Zend/Service/Flickr/Result.php','6.3',0),('04a14bd9666232c7dbe4ed1c28d36b21','./lib/core/Zend/Service/Flickr/ResultSet.php','6.3',0),('29a503f3b73dd220481c08037a8e3891','./lib/core/Zend/Service/LiveDocx.php','6.3',0),('7f452f15bedd7eec843025359c19b7a8','./lib/core/Zend/Service/LiveDocx/Exception.php','6.3',0),('d77ed35da09be95e66a0547466218ba8','./lib/core/Zend/Service/LiveDocx/MailMerge.php','6.3',0),('e8b537fcb62974fd0743d3f03dff3364','./lib/core/Zend/Service/Nirvanix.php','6.3',0),('2e0dd2133e2c1f3ad237fb9c23ef3551','./lib/core/Zend/Service/Nirvanix/Exception.php','6.3',0),('b3a3e21c50614969c3207e303a111001','./lib/core/Zend/Service/Nirvanix/Namespace/Base.php','6.3',0),('c45da1aa440452c5aa184d9565df5bdb','./lib/core/Zend/Service/Nirvanix/Namespace/Imfs.php','6.3',0),('d2819db1d2a66b8ae19f6e42e6c9b79d','./lib/core/Zend/Service/Nirvanix/Response.php','6.3',0),('a19f8d7b2268098b72b81c46920b1210','./lib/core/Zend/Service/ReCaptcha.php','6.3',0),('315dd5e7015020c1b90238c1236d443c','./lib/core/Zend/Service/ReCaptcha/Exception.php','6.3',0),('62725db726b316a279857904bb28d15e','./lib/core/Zend/Service/ReCaptcha/MailHide.php','6.3',0),('333076a70583e845ee7efabe87338b9d','./lib/core/Zend/Service/ReCaptcha/MailHide/Exception.php','6.3',0),('50744d69de2fa7f8bfaf3090dd5eb15d','./lib/core/Zend/Service/ReCaptcha/Response.php','6.3',0),('4ad0a10e8fb7704cc2f1f0deeabc5a2a','./lib/core/Zend/Service/Simpy.php','6.3',0),('82a9477b4af98ea18a0d0678840b5eab','./lib/core/Zend/Service/Simpy/Link.php','6.3',0),('0ccf829b971b06d1601001d18e7243b0','./lib/core/Zend/Service/Simpy/LinkQuery.php','6.3',0),('e510c1d0290a12c81cf3496a5784c731','./lib/core/Zend/Service/Simpy/LinkSet.php','6.3',0),('d3d7bada73e5180921a5a11ebf2250aa','./lib/core/Zend/Service/Simpy/Note.php','6.3',0),('8e2d5efdf5897406414bd23084f79890','./lib/core/Zend/Service/Simpy/NoteSet.php','6.3',0),('1908ae9d30075628dca765a2995ca8d7','./lib/core/Zend/Service/Simpy/Tag.php','6.3',0),('32cb662ea6cee92987cb6b1e2583310f','./lib/core/Zend/Service/Simpy/TagSet.php','6.3',0),('af9d983a3d5c552d90b4bf3f981f871b','./lib/core/Zend/Service/Simpy/Watchlist.php','6.3',0),('71db9a5ff5c8acfdfc826b36206cf8e5','./lib/core/Zend/Service/Simpy/WatchlistFilter.php','6.3',0),('5e71b85d94a056c5eaff1ae17c315497','./lib/core/Zend/Service/Simpy/WatchlistFilterSet.php','6.3',0),('b3b2856d5384dd27c8f31e59ce439164','./lib/core/Zend/Service/Simpy/WatchlistSet.php','6.3',0),('f7efb5592f1ab868068ad9112dad6ad9','./lib/core/Zend/Service/SlideShare.php','6.3',0),('8d2e362a370addf3938aa107e71eb71d','./lib/core/Zend/Service/SlideShare/Exception.php','6.3',0),('7e665e3db8e45ec0e0a7610ddbe3aba3','./lib/core/Zend/Service/SlideShare/SlideShow.php','6.3',0),('44af8ecb5761495a589e991c65fce169','./lib/core/Zend/Service/StrikeIron.php','6.3',0),('bbf7e6c1cf1c54e2c2dc7ee5deebd013','./lib/core/Zend/Service/StrikeIron/Base.php','6.3',0),('89f9167d6c69985c319a51588440eee5','./lib/core/Zend/Service/StrikeIron/Decorator.php','6.3',0),('502f85b37d502e32f573d68706a15177','./lib/core/Zend/Service/StrikeIron/Exception.php','6.3',0),('c24797e00389248de814f3a5c796ed88','./lib/core/Zend/Service/StrikeIron/SalesUseTaxBasic.php','6.3',0),('7c562d8c89b045d67f2b8805d41b405d','./lib/core/Zend/Service/StrikeIron/USAddressVerification.php','6.3',0),('be2529042951b82b5b0453ec105a6135','./lib/core/Zend/Service/StrikeIron/ZipCodeInfo.php','6.3',0),('3b836f1565321d4c5efd5d50ee001a6c','./lib/core/Zend/Service/Technorati.php','6.3',0),('9eb76bcc2652bbd91264e0818d9f3441','./lib/core/Zend/Service/Technorati/Author.php','6.3',0),('ab77c1f99b554a781ecf1812214e23d0','./lib/core/Zend/Service/Technorati/BlogInfoResult.php','6.3',0),('572793a2fe66e7c42a27a97a495fcb09','./lib/core/Zend/Service/Technorati/CosmosResult.php','6.3',0),('91679cb457b9d5b34a91c460f45b28a9','./lib/core/Zend/Service/Technorati/CosmosResultSet.php','6.3',0),('1c04d15fbb357c02695707cf833d135e','./lib/core/Zend/Service/Technorati/DailyCountsResult.php','6.3',0),('3e0eb6f658fe0f6b207d4c538e15752d','./lib/core/Zend/Service/Technorati/DailyCountsResultSet.php','6.3',0),('9aecfaf982fe9afe3d299a8e63976f94','./lib/core/Zend/Service/Technorati/Exception.php','6.3',0),('2e9ee065f1194c8fb77069659aee1d40','./lib/core/Zend/Service/Technorati/GetInfoResult.php','6.3',0),('aa36f067b7e31ce95c3a70225d25c8ce','./lib/core/Zend/Service/Technorati/KeyInfoResult.php','6.3',0),('2485286998b4feaedeeb1342799b6d24','./lib/core/Zend/Service/Technorati/Result.php','6.3',0),('6af6cb33f8e2dae7654236a1655e2f61','./lib/core/Zend/Service/Technorati/ResultSet.php','6.3',0),('4453fc8fda92e871245d8a90dc90fa22','./lib/core/Zend/Service/Technorati/SearchResult.php','6.3',0),('6f7f3f379260a8e8baf880652743a129','./lib/core/Zend/Service/Technorati/SearchResultSet.php','6.3',0),('6a347a6fd23179f37100993e66f0f4cd','./lib/core/Zend/Service/Technorati/TagResult.php','6.3',0),('36daa446dd6f57b40b8402cfaaa13359','./lib/core/Zend/Service/Technorati/TagResultSet.php','6.3',0),('dc68bd3be451933ad1d0d83b28e81ecb','./lib/core/Zend/Service/Technorati/TagsResult.php','6.3',0),('9dfc14684798f40853a93d27b0f2444a','./lib/core/Zend/Service/Technorati/TagsResultSet.php','6.3',0),('1b98640837de6928c376d4ad07bd6458','./lib/core/Zend/Service/Technorati/Utils.php','6.3',0),('5a29e8975eba03758daeca7588c214b0','./lib/core/Zend/Service/Technorati/Weblog.php','6.3',0),('5ee21d4ac09e9321cb5636c45a08d347','./lib/core/Zend/Service/Twitter.php','6.3',0),('00c9f4ea9ac561da9e2be4e1144351e2','./lib/core/Zend/Service/Twitter/Exception.php','6.3',0),('141b4479b9a41cc98ae0f814d53a61fb','./lib/core/Zend/Service/Twitter/Search.php','6.3',0),('7b5a79e4395e5da021fcf6bb068c1452','./lib/core/Zend/Service/WindowsAzure/Credentials/CredentialsAbstract.php','6.3',0),('14bbb29937ca79c16ec7a092d9e0105e','./lib/core/Zend/Service/WindowsAzure/Credentials/Exception.php','6.3',0),('c107b1c62c3e8eafc5add78fa9013d8f','./lib/core/Zend/Service/WindowsAzure/Credentials/SharedAccessSignature.php','6.3',0),('5281d4475de42311a51fc84db650fd6b','./lib/core/Zend/Service/WindowsAzure/Credentials/SharedKey.php','6.3',0),('543002f14adf2d8b6d4910d90eaf0a4f','./lib/core/Zend/Service/WindowsAzure/Credentials/SharedKeyLite.php','6.3',0),('135e943a06f94eace4f5f11fb6dcb788','./lib/core/Zend/Service/WindowsAzure/Diagnostics/ConfigurationDataSources.php','6.3',0),('ff5bb53e86f586a24f467276d4cc3d52','./lib/core/Zend/Service/WindowsAzure/Diagnostics/ConfigurationDiagnosticInfrastructureLogs.php','6.3',0),('41de0ec000a2af96b9483426c301b5ff','./lib/core/Zend/Service/WindowsAzure/Diagnostics/ConfigurationDirectories.php','6.3',0),('74cf2e2f5d1393590b02db06207f6a80','./lib/core/Zend/Service/WindowsAzure/Diagnostics/ConfigurationInstance.php','6.3',0),('b1efba8c0158139a2361cdc3477daf61','./lib/core/Zend/Service/WindowsAzure/Diagnostics/ConfigurationLogs.php','6.3',0),('eaa0c28b3cf3846abc311b2ca49ee216','./lib/core/Zend/Service/WindowsAzure/Diagnostics/ConfigurationObjectBaseAbstract.php','6.3',0),('ace4a6db3ca2a8b6f9587279cbd807d1','./lib/core/Zend/Service/WindowsAzure/Diagnostics/ConfigurationPerformanceCounters.php','6.3',0),('c9377f881633849296779eb040ba1fdb','./lib/core/Zend/Service/WindowsAzure/Diagnostics/ConfigurationWindowsEventLog.php','6.3',0),('5fe66ed19cdd7d00d6382fa0fb910b46','./lib/core/Zend/Service/WindowsAzure/Diagnostics/DirectoryConfigurationSubscription.php','6.3',0),('a85d21f8ab357ae9c241e0641a50dd87','./lib/core/Zend/Service/WindowsAzure/Diagnostics/Exception.php','6.3',0),('5f8f69903418a57da1ea1bed6a0fd4c3','./lib/core/Zend/Service/WindowsAzure/Diagnostics/LogLevel.php','6.3',0),('514c0302bbbe7ff60d6572f6f10ea2a5','./lib/core/Zend/Service/WindowsAzure/Diagnostics/Manager.php','6.3',0),('a97fb6aa6d8045bf322d4a67c889fbf0','./lib/core/Zend/Service/WindowsAzure/Diagnostics/PerformanceCounterSubscription.php','6.3',0),('9e097c2b774f4bdd89d68d71154e3404','./lib/core/Zend/Service/WindowsAzure/Exception.php','6.3',0),('3bfcff571276d3cf60f65f66936f2ceb','./lib/core/Zend/Service/WindowsAzure/RetryPolicy/Exception.php','6.3',0),('c4298cadaf91c235c766cd4b146602fd','./lib/core/Zend/Service/WindowsAzure/RetryPolicy/NoRetry.php','6.3',0),('81064e679c779d562c6837ffa722b52a','./lib/core/Zend/Service/WindowsAzure/RetryPolicy/RetryN.php','6.3',0),('aea7f27f83589f708b29b799fc1dee7b','./lib/core/Zend/Service/WindowsAzure/RetryPolicy/RetryPolicyAbstract.php','6.3',0),('f37a1f91a927406a87ffe6dbfc5a3886','./lib/core/Zend/Service/WindowsAzure/SessionHandler.php','6.3',0),('485ac9e844bbbfe5d6ccc9a8fa7b445f','./lib/core/Zend/Service/WindowsAzure/Storage.php','6.3',0),('8d8a197163149ad78ea3f7a5e4f6b8ba','./lib/core/Zend/Service/WindowsAzure/Storage/Batch.php','6.3',0),('962456dcb7e4766435c155b2c2225a00','./lib/core/Zend/Service/WindowsAzure/Storage/BatchStorageAbstract.php','6.3',0),('bfc3a00361d0401d4c81e2225b6fd36b','./lib/core/Zend/Service/WindowsAzure/Storage/Blob.php','6.3',0),('6c56791f0eba962405539cb8411ce592','./lib/core/Zend/Service/WindowsAzure/Storage/Blob/Stream.php','6.3',0),('260e84f18419364096fea0473192c2fa','./lib/core/Zend/Service/WindowsAzure/Storage/BlobContainer.php','6.3',0),('fce4b098bd18ae6fc5c4d8431baa211f','./lib/core/Zend/Service/WindowsAzure/Storage/BlobInstance.php','6.3',0),('15c42d999e695419601857484f8dbe78','./lib/core/Zend/Service/WindowsAzure/Storage/DynamicTableEntity.php','6.3',0),('037c3ffbc0a2320de8d998baf25c8b21','./lib/core/Zend/Service/WindowsAzure/Storage/LeaseInstance.php','6.3',0),('c6e70eb7161aa06e96c97ad96f29b3d7','./lib/core/Zend/Service/WindowsAzure/Storage/PageRegionInstance.php','6.3',0),('e6f7ff9a8feab388d3a30235e709488e','./lib/core/Zend/Service/WindowsAzure/Storage/Queue.php','6.3',0),('dde0f91ad06e7d778c6563caafd4347d','./lib/core/Zend/Service/WindowsAzure/Storage/QueueInstance.php','6.3',0),('c4ccb0b42a1beaab94104a62dbef0fa5','./lib/core/Zend/Service/WindowsAzure/Storage/QueueMessage.php','6.3',0),('ea0d116d79e0e3d8e7c484e0a29f0e7c','./lib/core/Zend/Service/WindowsAzure/Storage/SignedIdentifier.php','6.3',0),('d15c943d31f9a057ccd4f266b8efc71b','./lib/core/Zend/Service/WindowsAzure/Storage/StorageEntityAbstract.php','6.3',0),('4c690a895e76bd198e575d358f455874','./lib/core/Zend/Service/WindowsAzure/Storage/Table.php','6.3',0),('89e4ec57cab36b9e124af6d10ede289f','./lib/core/Zend/Service/WindowsAzure/Storage/TableEntity.php','6.3',0),('c32f6a4792a923e2e31ff89ad03170e1','./lib/core/Zend/Service/WindowsAzure/Storage/TableEntityQuery.php','6.3',0),('784f8129fbc2caa9881b59770c278077','./lib/core/Zend/Service/WindowsAzure/Storage/TableInstance.php','6.3',0),('24c704482c2a5642daecf12db12d31b6','./lib/core/Zend/Service/Yahoo.php','6.3',0),('d49bf997623965f20d4dde4f6718ad8d','./lib/core/Zend/Service/Yahoo/Image.php','6.3',0),('dd7251d80822b1b257ad181fc2115264','./lib/core/Zend/Service/Yahoo/ImageResult.php','6.3',0),('1eca2beca9e29f7b55fd79748a1cfffe','./lib/core/Zend/Service/Yahoo/ImageResultSet.php','6.3',0),('538810a52a442a2ce9560650d5871dd2','./lib/core/Zend/Service/Yahoo/InlinkDataResult.php','6.3',0),('dac974d2750cfaba8b7edfa8b26fad97','./lib/core/Zend/Service/Yahoo/InlinkDataResultSet.php','6.3',0),('112683666464a981187f84a3054be5c2','./lib/core/Zend/Service/Yahoo/LocalResult.php','6.3',0),('a9307948c6a3aea38ac2be2e4577c011','./lib/core/Zend/Service/Yahoo/LocalResultSet.php','6.3',0),('422cf0b460095ac48db2ffac8a1032ea','./lib/core/Zend/Service/Yahoo/NewsResult.php','6.3',0),('ee4b42114c08ee0e39a7e30bc4a019bb','./lib/core/Zend/Service/Yahoo/NewsResultSet.php','6.3',0),('9bd01b460aaa4b8a6538da989aaf09d5','./lib/core/Zend/Service/Yahoo/PageDataResult.php','6.3',0),('e75943ed4601bff4590935c5e3dfaf76','./lib/core/Zend/Service/Yahoo/PageDataResultSet.php','6.3',0),('a543088f981673be123dbb946d4665d6','./lib/core/Zend/Service/Yahoo/Result.php','6.3',0),('9dd4d6103172b3f0f998d481acebf440','./lib/core/Zend/Service/Yahoo/ResultSet.php','6.3',0),('95f819aae3b0b1988a73bec8d3059ff1','./lib/core/Zend/Service/Yahoo/VideoResult.php','6.3',0),('fecffae41064a572d5d2e16eaba60fdb','./lib/core/Zend/Service/Yahoo/VideoResultSet.php','6.3',0),('0b03a63a2783bd9f2018c406b58806c0','./lib/core/Zend/Service/Yahoo/WebResult.php','6.3',0),('236736ed297515f10fc78389d6f0894e','./lib/core/Zend/Service/Yahoo/WebResultSet.php','6.3',0),('481d6bd2db3349cd51e232f87f81625c','./lib/core/Zend/Session.php','6.3',0),('8e4cb1763461cee3d79dd44bc2ca722c','./lib/core/Zend/Session/Abstract.php','6.3',0),('737d42c53609cb14edaceef8444e669e','./lib/core/Zend/Session/Exception.php','6.3',0),('b91541042881d49d0ff05625ed335532','./lib/core/Zend/Session/Namespace.php','6.3',0),('ed2267f82180f2b7ae27b4de5870e41e','./lib/core/Zend/Session/SaveHandler/DbTable.php','6.3',0),('1a77441e53185b811cea53cf5169f87f','./lib/core/Zend/Session/SaveHandler/Exception.php','6.3',0),('cc09232a8f82370716ded605232208f7','./lib/core/Zend/Session/SaveHandler/Interface.php','6.3',0),('5293042fe951789c5920c0e5e033ab75','./lib/core/Zend/Session/Validator/Abstract.php','6.3',0),('3ae4046ec7a6b01d91eb255011b93479','./lib/core/Zend/Session/Validator/HttpUserAgent.php','6.3',0),('858a5bffe47a9814d0c00455e8faffba','./lib/core/Zend/Session/Validator/Interface.php','6.3',0),('c21c7124e66d06f0227b80312afb95b8','./lib/core/Zend/Soap/AutoDiscover.php','6.3',0),('2052a8991d28fb4e8e13122470e27615','./lib/core/Zend/Soap/AutoDiscover/Exception.php','6.3',0),('0d425ac76f4694e64f06be3efa1f798a','./lib/core/Zend/Soap/Client.php','6.3',0),('c25c2ce3de60b7234036a9f8dca955e2','./lib/core/Zend/Soap/Client/Common.php','6.3',0),('545c9afbb0c7c5f2712ac6bebe9042eb','./lib/core/Zend/Soap/Client/DotNet.php','6.3',0),('0bfa0dc6689fdfe53e505e6c509277c7','./lib/core/Zend/Soap/Client/Exception.php','6.3',0),('7d2f8be132b38fe56c7f26a649a0dd03','./lib/core/Zend/Soap/Client/Local.php','6.3',0),('340e7ac40bf0e75416af3b0955ce86ff','./lib/core/Zend/Soap/Server.php','6.3',0),('f12db6efd09b66e643ed87d1c21fb365','./lib/core/Zend/Soap/Server/Exception.php','6.3',0),('3452fff5864f825e0e41fc60557bd210','./lib/core/Zend/Soap/Wsdl.php','6.3',0),('c7241a68aa53e6778b75ffc5934b0b12','./lib/core/Zend/Soap/Wsdl/Exception.php','6.3',0),('2d7487a2f4ff412ddfe44c0378dfd3ce','./lib/core/Zend/Soap/Wsdl/Strategy/Abstract.php','6.3',0),('71e82a835540814ab715c325ef9e6e94','./lib/core/Zend/Soap/Wsdl/Strategy/AnyType.php','6.3',0),('eb94bd94db6b8ccd02805b482b89ec0d','./lib/core/Zend/Soap/Wsdl/Strategy/ArrayOfTypeComplex.php','6.3',0),('22f0a348a84c63b6802795671f6d3849','./lib/core/Zend/Soap/Wsdl/Strategy/ArrayOfTypeSequence.php','6.3',0),('e74f770322be26ad936087fb1a796749','./lib/core/Zend/Soap/Wsdl/Strategy/Composite.php','6.3',0),('344349bf8eaf8878cd928c6dd99fdc2b','./lib/core/Zend/Soap/Wsdl/Strategy/DefaultComplexType.php','6.3',0),('702212f635afa93e803b6d2c4c0c7c4d','./lib/core/Zend/Soap/Wsdl/Strategy/Interface.php','6.3',0),('7a3072ebde75a0192c1926c886ad6d55','./lib/core/Zend/Tag/Cloud.php','6.3',0),('1b5e2180c451c904ceb9081d84945da3','./lib/core/Zend/Tag/Cloud/Decorator/Cloud.php','6.3',0),('88e7e87191b98c446a97049b967b9c8b','./lib/core/Zend/Tag/Cloud/Decorator/Exception.php','6.3',0),('d4236d05875bf5fffebd8841e5af2586','./lib/core/Zend/Tag/Cloud/Decorator/HtmlCloud.php','6.3',0),('b7b63ec7db370f1e9bc326e6a4570958','./lib/core/Zend/Tag/Cloud/Decorator/HtmlTag.php','6.3',0),('0ad9cf33f140c791d8d5bc1bbad120ec','./lib/core/Zend/Tag/Cloud/Decorator/Tag.php','6.3',0),('66c8b59cc4a84c6288293c7a592f6f9d','./lib/core/Zend/Tag/Cloud/Exception.php','6.3',0),('513221794b2a8281a1047c4808c18250','./lib/core/Zend/Tag/Exception.php','6.3',0),('04325ef6b12293c0b521989140238792','./lib/core/Zend/Tag/Item.php','6.3',0),('ea7732d90f23cdaa08fd827264356302','./lib/core/Zend/Tag/ItemList.php','6.3',0),('1ede206cb622919b1c0ecfceff4d5743','./lib/core/Zend/Tag/Taggable.php','6.3',0),('22d970d401e64e73c180a4f2c2889989','./lib/core/Zend/Test/DbAdapter.php','6.3',0),('bb08680db935adf7c59f2ad37221eed9','./lib/core/Zend/Test/DbStatement.php','6.3',0),('ec188d9855e0343c1e7461bc0248713f','./lib/core/Zend/Test/PHPUnit/Constraint/DomQuery.php','6.3',0),('8fc1e757a8e23d10fc4a8b4180ef28be','./lib/core/Zend/Test/PHPUnit/Constraint/Exception.php','6.3',0),('2e9f62935d319307fc170331d64adf5c','./lib/core/Zend/Test/PHPUnit/Constraint/Redirect.php','6.3',0),('38888164e5514da0be7409deaa1e4889','./lib/core/Zend/Test/PHPUnit/Constraint/ResponseHeader.php','6.3',0),('4b94cf7c8eac0d931903e13cdc103fb5','./lib/core/Zend/Test/PHPUnit/ControllerTestCase.php','6.3',0),('2a3ff8abbc706f16b85c21bd71b8dcd0','./lib/core/Zend/Test/PHPUnit/DatabaseTestCase.php','6.3',0),('1b4aae2bd9ab1351f8c2686864176c05','./lib/core/Zend/Test/PHPUnit/Db/Connection.php','6.3',0),('30abdbef120c0a84a2cbdbe3bf4e9e22','./lib/core/Zend/Test/PHPUnit/Db/DataSet/DbRowset.php','6.3',0),('76acac2dcafcf60c3a1ff9c7007d26b0','./lib/core/Zend/Test/PHPUnit/Db/DataSet/DbTable.php','6.3',0),('009e4a60afc09751a369b44f8d32d0b4','./lib/core/Zend/Test/PHPUnit/Db/DataSet/DbTableDataSet.php','6.3',0),('9ad90b9f5315467326f1eb8f0e02bd23','./lib/core/Zend/Test/PHPUnit/Db/DataSet/QueryDataSet.php','6.3',0),('c5073e445caeb69c1f44b10a7ff4f175','./lib/core/Zend/Test/PHPUnit/Db/DataSet/QueryTable.php','6.3',0),('c42cb70c9f6f527bb3eee60b37ae005c','./lib/core/Zend/Test/PHPUnit/Db/Exception.php','6.3',0),('0003952fbb4d116b3d0df710f5700b01','./lib/core/Zend/Test/PHPUnit/Db/Metadata/Generic.php','6.3',0),('73c6e43ef12f3dec356846ba168be8b3','./lib/core/Zend/Test/PHPUnit/Db/Operation/DeleteAll.php','6.3',0),('19eea6dbac6d1bebc65c54081b1f6948','./lib/core/Zend/Test/PHPUnit/Db/Operation/Insert.php','6.3',0),('624544bc7bb433f78a0ea2c9d84e09f4','./lib/core/Zend/Test/PHPUnit/Db/Operation/Truncate.php','6.3',0),('29ad47bf26ba4897107f992f1f24a2b6','./lib/core/Zend/Test/PHPUnit/Db/SimpleTester.php','6.3',0),('9cdb0e370b0a6da48be3013ce4c10a1a','./lib/core/Zend/Text/Exception.php','6.3',0),('bfc0fd4e095e59cfa50d31a7d402368e','./lib/core/Zend/Text/Figlet.php','6.3',0),('5ceaabeef07ca4feec1e57b436f7e740','./lib/core/Zend/Text/Figlet/Exception.php','6.3',0),('6ffc336e65d476efe53a89041fc648d7','./lib/core/Zend/Text/MultiByte.php','6.3',0),('394772695e50c1ca58fdc1ddff9d1cba','./lib/core/Zend/Text/Table.php','6.3',0),('8ab599c439d0822287cb5171c965e282','./lib/core/Zend/Text/Table/Column.php','6.3',0),('56a31df4179a860403d2eb9c4fcfd453','./lib/core/Zend/Text/Table/Decorator/Ascii.php','6.3',0),('7f7c8778c43cba06f0ce06bb58932265','./lib/core/Zend/Text/Table/Decorator/Interface.php','6.3',0),('aed2dc343e41cbb6e6eba3cf1252b114','./lib/core/Zend/Text/Table/Decorator/Unicode.php','6.3',0),('3db35b46f5d6653691024c23214a77a9','./lib/core/Zend/Text/Table/Exception.php','6.3',0),('b69becce129de91e5d5aa3f56ff4b883','./lib/core/Zend/Text/Table/Row.php','6.3',0),('09c3441e8445edffb5d09e887c172771','./lib/core/Zend/TimeSync.php','6.3',0),('05fc2c458b70332dda65d1b4d985c1c9','./lib/core/Zend/TimeSync/Exception.php','6.3',0),('d48ad407099308b0e22f80367773c5c5','./lib/core/Zend/TimeSync/Ntp.php','6.3',0),('b00ecb292054540f2cca9a928c5b542a','./lib/core/Zend/TimeSync/Protocol.php','6.3',0),('67357b6909bc32d067eb9817f681fa62','./lib/core/Zend/TimeSync/Sntp.php','6.3',0),('a97fd0c9338ef0ea413664cd959b631b','./lib/core/Zend/Tool/Framework/Action/Base.php','6.3',0),('4653cb586564c43d5249dcc21c0da449','./lib/core/Zend/Tool/Framework/Action/Exception.php','6.3',0),('c5351b30eb1bf88190a2f168fd131814','./lib/core/Zend/Tool/Framework/Action/Interface.php','6.3',0),('9a7e22b58b8871de8b9858ee093ec6a1','./lib/core/Zend/Tool/Framework/Action/Repository.php','6.3',0),('7725e3aea04dc7283850b0f524995489','./lib/core/Zend/Tool/Framework/Client/Abstract.php','6.3',0),('a4800427949d93444332c99891e5a851','./lib/core/Zend/Tool/Framework/Client/Config.php','6.3',0),('c8cb11d9b591d931041deb21b3d3182b','./lib/core/Zend/Tool/Framework/Client/Console.php','6.3',0),('1abd010cc7b3934a490f9f0fa2293c89','./lib/core/Zend/Tool/Framework/Client/Console/ArgumentParser.php','6.3',0),('3c277d5b9119f120d0482e81a2050868','./lib/core/Zend/Tool/Framework/Client/Console/HelpSystem.php','6.3',0),('e5b1f7302b084bd13a8fd4e5846e3020','./lib/core/Zend/Tool/Framework/Client/Console/Manifest.php','6.3',0),('9c2a3ed239f93939ce98bd4a33187b5c','./lib/core/Zend/Tool/Framework/Client/Console/ResponseDecorator/AlignCenter.php','6.3',0),('ab547006764f54fcfd5066b8ffb8eb4e','./lib/core/Zend/Tool/Framework/Client/Console/ResponseDecorator/Blockize.php','6.3',0),('2a5e425652ef3783dbd4395a08301da6','./lib/core/Zend/Tool/Framework/Client/Console/ResponseDecorator/Colorizer.php','6.3',0),('329f2359b8ab66935cff6c501cd125a6','./lib/core/Zend/Tool/Framework/Client/Console/ResponseDecorator/Indention.php','6.3',0),('536e9356d2cc06693160262296be229e','./lib/core/Zend/Tool/Framework/Client/Exception.php','6.3',0),('852271a2217ec06ffc7a5b5ef112af25','./lib/core/Zend/Tool/Framework/Client/Interactive/InputHandler.php','6.3',0),('82d2f1f9279a2d7ff4362ce6b6d8157d','./lib/core/Zend/Tool/Framework/Client/Interactive/InputInterface.php','6.3',0),('c3a6fbeb3fc7982b109e591ea1e60583','./lib/core/Zend/Tool/Framework/Client/Interactive/InputRequest.php','6.3',0),('54d1d07df9f04ef3a641d369afa2e7cd','./lib/core/Zend/Tool/Framework/Client/Interactive/InputResponse.php','6.3',0),('601647b578c31aaf1a126e53fd2fa1c0','./lib/core/Zend/Tool/Framework/Client/Interactive/OutputInterface.php','6.3',0),('f3b9cbbe029dfed52410525e4b2fc0c2','./lib/core/Zend/Tool/Framework/Client/Manifest.php','6.3',0),('a89bc839e2aa04663fcc3254d33f04d5','./lib/core/Zend/Tool/Framework/Client/Request.php','6.3',0),('c989100a227e2290172b2bd0efcf4ef7','./lib/core/Zend/Tool/Framework/Client/Response.php','6.3',0),('efc2818e6e2450b7960928bf0939162f','./lib/core/Zend/Tool/Framework/Client/Response/ContentDecorator/Interface.php','6.3',0),('2fb1476f2feb1704748bbdf2b3e5dca5','./lib/core/Zend/Tool/Framework/Client/Response/ContentDecorator/Separator.php','6.3',0),('e249800eddb3ac1a3fb22e48651a6704','./lib/core/Zend/Tool/Framework/Client/Storage.php','6.3',0),('c88b828f7e8c87dfce10966ec146315f','./lib/core/Zend/Tool/Framework/Client/Storage/AdapterInterface.php','6.3',0),('ce383d2e0681b11da8ca6008cbc9e971','./lib/core/Zend/Tool/Framework/Client/Storage/Directory.php','6.3',0),('935753f4d5452e69e10cb4ee27c96c11','./lib/core/Zend/Tool/Framework/Exception.php','6.3',0),('f8d998f458b180f62b780edbb374494f','./lib/core/Zend/Tool/Framework/Loader/Abstract.php','6.3',0),('26e62f83312544447107b333cb6d9aa3','./lib/core/Zend/Tool/Framework/Loader/BasicLoader.php','6.3',0),('86180e5abe55fcb17fb1303ccc7b56ea','./lib/core/Zend/Tool/Framework/Loader/IncludePathLoader.php','6.3',0),('7dc579ae533df76f96bea8891466141a','./lib/core/Zend/Tool/Framework/Loader/IncludePathLoader/RecursiveFilterIterator.php','6.3',0),('6520db9a8deb3f8cc1f827c610d82bca','./lib/core/Zend/Tool/Framework/Loader/Interface.php','6.3',0),('d6bceb6ff846d50dbec490b001b6adbc','./lib/core/Zend/Tool/Framework/Manifest/ActionManifestable.php','6.3',0),('41f3964751e2172d6186b5f17a52e717','./lib/core/Zend/Tool/Framework/Manifest/Exception.php','6.3',0),('5d14a219bbd89099778fa1a5fd1eec3e','./lib/core/Zend/Tool/Framework/Manifest/Indexable.php','6.3',0),('3cf36f0cf9f5a9014afef3ec0a43fab7','./lib/core/Zend/Tool/Framework/Manifest/Interface.php','6.3',0),('91417317018faefcd037b0fb421e5e11','./lib/core/Zend/Tool/Framework/Manifest/MetadataManifestable.php','6.3',0),('cd219f9a1f6a8cbcd7489ceb9caed044','./lib/core/Zend/Tool/Framework/Manifest/ProviderManifestable.php','6.3',0),('29db59706e1ecf64bc19e12810afdd52','./lib/core/Zend/Tool/Framework/Manifest/Repository.php','6.3',0),('0367b91b1c9d15d98054436cb880c4b2','./lib/core/Zend/Tool/Framework/Metadata/Attributable.php','6.3',0),('70d5e613ba80d6316096b848b177ed9c','./lib/core/Zend/Tool/Framework/Metadata/Basic.php','6.3',0),('35201216f8293736081ad739c4dd8d38','./lib/core/Zend/Tool/Framework/Metadata/Dynamic.php','6.3',0),('d4ce89223385ff49ae76832442737e0f','./lib/core/Zend/Tool/Framework/Metadata/Interface.php','6.3',0),('33d72600842d7beba24884ddeccb31ba','./lib/core/Zend/Tool/Framework/Metadata/Tool.php','6.3',0),('9326912d7317322fe7b95533138ffb75','./lib/core/Zend/Tool/Framework/Provider/Abstract.php','6.3',0),('2c401859545144eee4eba1c9f2a8da11','./lib/core/Zend/Tool/Framework/Provider/DocblockManifestable.php','6.3',0),('712d717765e59333b9c37fe40a092c37','./lib/core/Zend/Tool/Framework/Provider/Exception.php','6.3',0),('f3ad8da3bd31feb9d05f84f3cea415ce','./lib/core/Zend/Tool/Framework/Provider/Interactable.php','6.3',0),('248c097239e80aa10eaef49998e9161b','./lib/core/Zend/Tool/Framework/Provider/Interface.php','6.3',0),('45f0852186ca83b17d097dd3665fd0d6','./lib/core/Zend/Tool/Framework/Provider/Pretendable.php','6.3',0),('36cb867a4a2d69b16ed9566bee51aa84','./lib/core/Zend/Tool/Framework/Provider/Repository.php','6.3',0),('cb1df77c5f19b7d862fa7af3d2983932','./lib/core/Zend/Tool/Framework/Provider/Signature.php','6.3',0),('9d0a9cbaeb6366c3a8ad31937d3d1051','./lib/core/Zend/Tool/Framework/Registry.php','6.3',0),('98b6357e03c949387e0d2a28b300eb55','./lib/core/Zend/Tool/Framework/Registry/EnabledInterface.php','6.3',0),('56332a6793fed02e21a6b9270513ec74','./lib/core/Zend/Tool/Framework/Registry/Exception.php','6.3',0),('a2251c667f6e869c4f3b3531d779d3c7','./lib/core/Zend/Tool/Framework/Registry/Interface.php','6.3',0),('9af2fc40330ae0b5b180230cb0be10eb','./lib/core/Zend/Tool/Framework/System/Action/Create.php','6.3',0),('46bf39a38259cec8b28e045b506f1989','./lib/core/Zend/Tool/Framework/System/Action/Delete.php','6.3',0),('2506720bbe0f2cc7855d65f3e22f1acd','./lib/core/Zend/Tool/Framework/System/Manifest.php','6.3',0),('820387a05af305cb5f491870131aadf4','./lib/core/Zend/Tool/Framework/System/Provider/Config.php','6.3',0),('1492ff3b2a0177182d3f5b4753a1d570','./lib/core/Zend/Tool/Framework/System/Provider/Manifest.php','6.3',0),('994a8092eb1eace329ecb983e6a9732f','./lib/core/Zend/Tool/Framework/System/Provider/Phpinfo.php','6.3',0),('8de7499e0eb61b50fa5a610c302b7e73','./lib/core/Zend/Tool/Framework/System/Provider/Version.php','6.3',0),('89dea35d9a3172d11d7dd42021f07608','./lib/core/Zend/Tool/Project/Context/Content/Engine.php','6.3',0),('233d1b1c79118ea6480f0c7f887abca3','./lib/core/Zend/Tool/Project/Context/Content/Engine/CodeGenerator.php','6.3',0),('eaf67f68d43d0c2dba1469f603106178','./lib/core/Zend/Tool/Project/Context/Content/Engine/Phtml.php','6.3',0),('7583ecc0c9a1da98e114cd882cd9ca43','./lib/core/Zend/Tool/Project/Context/Exception.php','6.3',0),('7abfcb988c855c47daef981fd5f6622c','./lib/core/Zend/Tool/Project/Context/Filesystem/Abstract.php','6.3',0),('b61d730b56f0310e5f2fb7decfe3b9e8','./lib/core/Zend/Tool/Project/Context/Filesystem/Directory.php','6.3',0),('32ca309ed029a81b916a46503eb66114','./lib/core/Zend/Tool/Project/Context/Filesystem/File.php','6.3',0),('6443631680875499260e6e04c5649b8e','./lib/core/Zend/Tool/Project/Context/Interface.php','6.3',0),('cb271533e4e12b943fbfdbf616bfcb12','./lib/core/Zend/Tool/Project/Context/Repository.php','6.3',0),('512834f2866a8e9989ce43df9080567d','./lib/core/Zend/Tool/Project/Context/System/Interface.php','6.3',0),('2c2accce4c4455b2dc2601aef7345232','./lib/core/Zend/Tool/Project/Context/System/NotOverwritable.php','6.3',0),('1a41536eb9a47ce008abb4ec5bebc7fa','./lib/core/Zend/Tool/Project/Context/System/ProjectDirectory.php','6.3',0),('14cc2ff8cf344f7ad25a7c906fa7b905','./lib/core/Zend/Tool/Project/Context/System/ProjectProfileFile.php','6.3',0),('67de0370a9226a65359c966ea208f3f2','./lib/core/Zend/Tool/Project/Context/System/ProjectProvidersDirectory.php','6.3',0),('776d892d1b1aa50bcf61d24bbb21113d','./lib/core/Zend/Tool/Project/Context/System/TopLevelRestrictable.php','6.3',0),('8dc9dcca47fd0a26cbb32c9296a798e3','./lib/core/Zend/Tool/Project/Context/Zf/AbstractClassFile.php','6.3',0),('9fb55f94dfd2f0660e90d929b0882b59','./lib/core/Zend/Tool/Project/Context/Zf/ActionMethod.php','6.3',0),('6fa575e4e6a27c3e500bbcfd9b3d483e','./lib/core/Zend/Tool/Project/Context/Zf/ApisDirectory.php','6.3',0),('aba0405a53deca65c78a916a9cdc0ffe','./lib/core/Zend/Tool/Project/Context/Zf/ApplicationConfigFile.php','6.3',0),('1f214d5f5711c1bf1330a6fcb3d0f3da','./lib/core/Zend/Tool/Project/Context/Zf/ApplicationDirectory.php','6.3',0),('d4926afa1b01cd1e148d4efe88f4ef2a','./lib/core/Zend/Tool/Project/Context/Zf/BootstrapFile.php','6.3',0),('d9c30eda01b5cd560b843ab2fe1c5871','./lib/core/Zend/Tool/Project/Context/Zf/CacheDirectory.php','6.3',0),('71401e9f8de4913e4d148bd438476680','./lib/core/Zend/Tool/Project/Context/Zf/ConfigFile.php','6.3',0),('049df518ec1ed92350365da766e85a7b','./lib/core/Zend/Tool/Project/Context/Zf/ConfigsDirectory.php','6.3',0),('75002f84e9cfe42492a4d12d360771f5','./lib/core/Zend/Tool/Project/Context/Zf/ControllerFile.php','6.3',0),('05e8f9c8514f52b9ca687841d59ee1be','./lib/core/Zend/Tool/Project/Context/Zf/ControllersDirectory.php','6.3',0),('0bccc2c158183d4af38233ffa52ddd0e','./lib/core/Zend/Tool/Project/Context/Zf/DataDirectory.php','6.3',0),('c6b16496f7bc9b1c1e2bbd4dd8142ca1','./lib/core/Zend/Tool/Project/Context/Zf/DbTableDirectory.php','6.3',0),('4bc96f74d9d24ac6df8966b66e36592c','./lib/core/Zend/Tool/Project/Context/Zf/DbTableFile.php','6.3',0),('3b25de6fb2d93f474ed49057f21df4f4','./lib/core/Zend/Tool/Project/Context/Zf/DocsDirectory.php','6.3',0),('935c01511dfbbd9401428910c59e16fb','./lib/core/Zend/Tool/Project/Context/Zf/FormFile.php','6.3',0),('e739e70742c9053e03b4b3ffe7108d0c','./lib/core/Zend/Tool/Project/Context/Zf/FormsDirectory.php','6.3',0),('67c7408388540618f4600904180768dc','./lib/core/Zend/Tool/Project/Context/Zf/HtaccessFile.php','6.3',0),('14ee29d51fcc87e8b0fa09715898097f','./lib/core/Zend/Tool/Project/Context/Zf/LayoutScriptFile.php','6.3',0),('148d676c5dfeda9757205bfc3182731b','./lib/core/Zend/Tool/Project/Context/Zf/LayoutScriptsDirectory.php','6.3',0),('4c62caa786f2dce600e274bb6cee3f37','./lib/core/Zend/Tool/Project/Context/Zf/LayoutsDirectory.php','6.3',0),('4695863d2f709dc6ad10f0b1f151f569','./lib/core/Zend/Tool/Project/Context/Zf/LibraryDirectory.php','6.3',0),('5b4c6d55720e143cfb86f9f89be40af4','./lib/core/Zend/Tool/Project/Context/Zf/LocalesDirectory.php','6.3',0),('58ed2614b9f84cc0ef8d7944a02e8d30','./lib/core/Zend/Tool/Project/Context/Zf/LogsDirectory.php','6.3',0),('128813a6bcb06217c4f0dc0ab74616d2','./lib/core/Zend/Tool/Project/Context/Zf/ModelFile.php','6.3',0),('717e663fa445327477d6a76447742d44','./lib/core/Zend/Tool/Project/Context/Zf/ModelsDirectory.php','6.3',0),('3ea316d8507b2c5aa76e91f412eb5d56','./lib/core/Zend/Tool/Project/Context/Zf/ModuleDirectory.php','6.3',0),('b91bdd18106213821c4081379628ee8f','./lib/core/Zend/Tool/Project/Context/Zf/ModulesDirectory.php','6.3',0),('94e8fcf8c38e0146bb954b3727bfd9cf','./lib/core/Zend/Tool/Project/Context/Zf/ProjectProviderFile.php','6.3',0),('07d0478090844411bc95006ce71c4f43','./lib/core/Zend/Tool/Project/Context/Zf/PublicDirectory.php','6.3',0),('81359ad56c74b520e0cfc12e54ef0a6a','./lib/core/Zend/Tool/Project/Context/Zf/PublicImagesDirectory.php','6.3',0),('a9c0dcd172f058b69d564c7f061e602e','./lib/core/Zend/Tool/Project/Context/Zf/PublicIndexFile.php','6.3',0),('612128a7b7c2da4be4ba2e68075f2971','./lib/core/Zend/Tool/Project/Context/Zf/PublicScriptsDirectory.php','6.3',0),('3259c26d46f3f79c8db720deadd28456','./lib/core/Zend/Tool/Project/Context/Zf/PublicStylesheetsDirectory.php','6.3',0),('c0e88995005b974e8c9dea42ca643e6f','./lib/core/Zend/Tool/Project/Context/Zf/SearchIndexesDirectory.php','6.3',0),('1099ecc53f6132e1cf7891431db154a1','./lib/core/Zend/Tool/Project/Context/Zf/SessionsDirectory.php','6.3',0),('7671d9519531f82710211628cb5c8196','./lib/core/Zend/Tool/Project/Context/Zf/TemporaryDirectory.php','6.3',0),('ed2b66814df9e55d08e7935d2033b0f7','./lib/core/Zend/Tool/Project/Context/Zf/TestApplicationBootstrapFile.php','6.3',0),('05cc1f7d6fee895f4ec1c25297f25956','./lib/core/Zend/Tool/Project/Context/Zf/TestApplicationControllerDirectory.php','6.3',0),('b86e83c5675c7673b462e8a72159d1ed','./lib/core/Zend/Tool/Project/Context/Zf/TestApplicationControllerFile.php','6.3',0),('2cd0fb2fb440dcea46fd54ad9bff3b85','./lib/core/Zend/Tool/Project/Context/Zf/TestApplicationDirectory.php','6.3',0),('d2942164a2526d208cc659cbf66ccfc3','./lib/core/Zend/Tool/Project/Context/Zf/TestLibraryBootstrapFile.php','6.3',0),('029980b1681415b92ba9e3bd7e6789f6','./lib/core/Zend/Tool/Project/Context/Zf/TestLibraryDirectory.php','6.3',0),('dd088e5a63357dfeb323223314ce3061','./lib/core/Zend/Tool/Project/Context/Zf/TestLibraryFile.php','6.3',0),('e28310e66ff8512aafe0a28e3d916d82','./lib/core/Zend/Tool/Project/Context/Zf/TestLibraryNamespaceDirectory.php','6.3',0),('e1b18feec37065b1726a5848f6d18758','./lib/core/Zend/Tool/Project/Context/Zf/TestPHPUnitConfigFile.php','6.3',0),('d0e8836edffc01b51957eac6e94fff5f','./lib/core/Zend/Tool/Project/Context/Zf/TestsDirectory.php','6.3',0),('51daf4c07df3ec7f5fca6315b6e9a67d','./lib/core/Zend/Tool/Project/Context/Zf/UploadsDirectory.php','6.3',0),('5806daaf4a394c6ee025401d27e5328f','./lib/core/Zend/Tool/Project/Context/Zf/ViewControllerScriptsDirectory.php','6.3',0),('0b72e1eef8be62ab96a8c72b00843efc','./lib/core/Zend/Tool/Project/Context/Zf/ViewFiltersDirectory.php','6.3',0),('46f557ed67845a579258a7045ecaaed8','./lib/core/Zend/Tool/Project/Context/Zf/ViewHelpersDirectory.php','6.3',0),('2f908bf549a48fdc9daa6337c46cde21','./lib/core/Zend/Tool/Project/Context/Zf/ViewScriptFile.php','6.3',0),('f3759f187caefeaa6de5fc8cd8836f7e','./lib/core/Zend/Tool/Project/Context/Zf/ViewScriptsDirectory.php','6.3',0),('60627142c6ba1664bc2fdb9edc36e462','./lib/core/Zend/Tool/Project/Context/Zf/ViewsDirectory.php','6.3',0),('550332e119180e21a666e70bc530eb61','./lib/core/Zend/Tool/Project/Context/Zf/ZfStandardLibraryDirectory.php','6.3',0),('424a6a847c5c2a30ee346be18b16391a','./lib/core/Zend/Tool/Project/Exception.php','6.3',0),('8024c9a801c3f62dd5add77405ba0658','./lib/core/Zend/Tool/Project/Profile.php','6.3',0),('8feae6afe350029f0942571616682ebf','./lib/core/Zend/Tool/Project/Profile/Exception.php','6.3',0),('ba7fcba10077c529824a1c5a78c47bee','./lib/core/Zend/Tool/Project/Profile/FileParser/Interface.php','6.3',0),('d42ff875157da4d9f7e9118fa0478937','./lib/core/Zend/Tool/Project/Profile/FileParser/Xml.php','6.3',0),('3fdceee5380da3bafa30139bfa5a38a4','./lib/core/Zend/Tool/Project/Profile/Iterator/ContextFilter.php','6.3',0),('fce2852b39a4887dd2e1f962b989caa2','./lib/core/Zend/Tool/Project/Profile/Iterator/EnabledResourceFilter.php','6.3',0),('3eb285801b9f2ad38b600185e2ffc90c','./lib/core/Zend/Tool/Project/Profile/Resource.php','6.3',0),('1cb3090e250497f1410e3fcc33309d53','./lib/core/Zend/Tool/Project/Profile/Resource/Container.php','6.3',0),('121d92f3a9c54ea8729058aab7a12029','./lib/core/Zend/Tool/Project/Profile/Resource/SearchConstraints.php','6.3',0),('3e70087983b2a0962302e7067eb63f2b','./lib/core/Zend/Tool/Project/Provider/Abstract.php','6.3',0),('3dbab27c40fecb642fdfef5cd03059f8','./lib/core/Zend/Tool/Project/Provider/Action.php','6.3',0),('e0198e23f607881146c2f678849c6c58','./lib/core/Zend/Tool/Project/Provider/Application.php','6.3',0),('ee595c8d467f835a8ef97f0fe1dffa66','./lib/core/Zend/Tool/Project/Provider/Controller.php','6.3',0),('aa469ae729feaa25564e578c82932d78','./lib/core/Zend/Tool/Project/Provider/DbAdapter.php','6.3',0),('a9431eed14ab36721590e1c1bf14636b','./lib/core/Zend/Tool/Project/Provider/DbTable.php','6.3',0),('0642890d31461e9bfdead31ea2f98fe4','./lib/core/Zend/Tool/Project/Provider/Exception.php','6.3',0),('b559797b5edf72d48e043318cf6cd4e0','./lib/core/Zend/Tool/Project/Provider/Form.php','6.3',0),('5c1ca084345820ee2b9c351d23f39acc','./lib/core/Zend/Tool/Project/Provider/Layout.php','6.3',0),('dc9d45e82bfd843c76f075306546ce87','./lib/core/Zend/Tool/Project/Provider/Manifest.php','6.3',0),('42c67c1c22494d0dcf2a00f47e0e072b','./lib/core/Zend/Tool/Project/Provider/Model.php','6.3',0),('a22307d3a23c194d7e8088c0f6c38142','./lib/core/Zend/Tool/Project/Provider/Module.php','6.3',0),('c3ee2a0ce00a1b0bf9d29b714898bb65','./lib/core/Zend/Tool/Project/Provider/Profile.php','6.3',0),('5282e56cd78211c16807230ff7c81c2c','./lib/core/Zend/Tool/Project/Provider/Project.php','6.3',0),('b1c7177b4073975243e85d87a01d22b2','./lib/core/Zend/Tool/Project/Provider/ProjectProvider.php','6.3',0),('dca871681d0c1b9c540845dbd8ae44d4','./lib/core/Zend/Tool/Project/Provider/Test.php','6.3',0),('f5cf6246c6143884ea82a04df23713a2','./lib/core/Zend/Tool/Project/Provider/View.php','6.3',0),('a005baeb17f2bbd91b6bc7769690f4db','./lib/core/Zend/Translate.php','6.3',0),('d2e7bf8a5d477bbaf2de951dac579d47','./lib/core/Zend/Translate/Adapter.php','6.3',0),('b4c0e9db35f6480e33d949190a23b046','./lib/core/Zend/Translate/Adapter/Array.php','6.3',0),('448caf087be76141248635d9d672dc22','./lib/core/Zend/Translate/Adapter/Csv.php','6.3',0),('6cefde06489dc5e8bfc69fabf0701c63','./lib/core/Zend/Translate/Adapter/Gettext.php','6.3',0),('3e4743c19ba04cd9e7f461f30b7e959f','./lib/core/Zend/Translate/Adapter/Ini.php','6.3',0),('d8f5ee599236c859a20fd52c563a3953','./lib/core/Zend/Translate/Adapter/Qt.php','6.3',0),('fea45d29dc9f3c349bb234910058c770','./lib/core/Zend/Translate/Adapter/Tbx.php','6.3',0),('cab3120e0f3d1668853c6a8050d60012','./lib/core/Zend/Translate/Adapter/Tmx.php','6.3',0),('14ab8dd67412d317af2785bd841b69d1','./lib/core/Zend/Translate/Adapter/Xliff.php','6.3',0),('9debfd9ddbefd0e0a9639545c1746b52','./lib/core/Zend/Translate/Adapter/XmlTm.php','6.3',0),('d6827fb3b5f2eb3eff291870fe7cfc49','./lib/core/Zend/Translate/Exception.php','6.3',0),('25fba25e256ac7d31dc9ebe5fc141330','./lib/core/Zend/Translate/Plural.php','6.3',0),('5fb4eecd3a37ee491840b7edda334b44','./lib/core/Zend/Uri.php','6.3',0),('82cb82c996e18d9fc6a90cab7130a707','./lib/core/Zend/Uri/Exception.php','6.3',0),('37392ab6fc7951f0f6d05beda4c47892','./lib/core/Zend/Uri/Http.php','6.3',0),('bc3ce015e069a3027801a624c1012806','./lib/core/Zend/Validate.php','6.3',0),('7852cc1305a1ba82d735d120b2242c37','./lib/core/Zend/Validate/Abstract.php','6.3',0),('b612dc5cf0a60f926b74bb1bcece282d','./lib/core/Zend/Validate/Alnum.php','6.3',0),('c028b2985ffcc7a1dcc70d5f6046bace','./lib/core/Zend/Validate/Alpha.php','6.3',0),('84352c17d34bb973c964fe1fa655b186','./lib/core/Zend/Validate/Barcode.php','6.3',0),('099c0b6376e77d3e1c60cf8885f7f912','./lib/core/Zend/Validate/Barcode/AdapterAbstract.php','6.3',0),('4999a78c3b69bb7415dcc86e87992fc5','./lib/core/Zend/Validate/Barcode/AdapterInterface.php','6.3',0),('52e7e65bf72c15f8986a0ad4481dd626','./lib/core/Zend/Validate/Barcode/Code25.php','6.3',0),('5c4711125a61c23d8b231ffe604cea8b','./lib/core/Zend/Validate/Barcode/Code25interleaved.php','6.3',0),('0a9475c12db0c36b53d44c0a00caff61','./lib/core/Zend/Validate/Barcode/Code39.php','6.3',0),('a45fdd778043b9c4ab2b4a137980a8ed','./lib/core/Zend/Validate/Barcode/Code39ext.php','6.3',0),('e70d5d4be8f8c7d495803cb2312b3aca','./lib/core/Zend/Validate/Barcode/Code93.php','6.3',0),('3256581edfb8143fcdbe3d3147fa1dd4','./lib/core/Zend/Validate/Barcode/Code93ext.php','6.3',0),('3fd961e1bbc1d7525a4d03a779a0c3c4','./lib/core/Zend/Validate/Barcode/Ean12.php','6.3',0),('55e7a6deec3d662696a7734891d36858','./lib/core/Zend/Validate/Barcode/Ean13.php','6.3',0),('6bc650112a466158ab316f90a7805a88','./lib/core/Zend/Validate/Barcode/Ean14.php','6.3',0),('594074e51dd15d27d80b24d5b1f2649b','./lib/core/Zend/Validate/Barcode/Ean18.php','6.3',0),('d5800933da4955cd94f5a6a18d25e726','./lib/core/Zend/Validate/Barcode/Ean2.php','6.3',0),('2005571fe9e20810ad7cbccceeea612b','./lib/core/Zend/Validate/Barcode/Ean5.php','6.3',0),('3f378afaf275a13d51fac263502a3025','./lib/core/Zend/Validate/Barcode/Ean8.php','6.3',0),('0dedc198fdce28be76c8eab3dd58ea47','./lib/core/Zend/Validate/Barcode/Gtin12.php','6.3',0),('33c9d6a233477191325fc7113a17e2f6','./lib/core/Zend/Validate/Barcode/Gtin13.php','6.3',0),('f83c9aef123916be2332f9bdae58e414','./lib/core/Zend/Validate/Barcode/Gtin14.php','6.3',0),('b414fcd0a32cf4589eab07a487167d69','./lib/core/Zend/Validate/Barcode/Identcode.php','6.3',0),('6eff994128fe2429ec5a95a75fe1b8ed','./lib/core/Zend/Validate/Barcode/Intelligentmail.php','6.3',0),('d28187dd32f857178e2b8e40aa5a96d5','./lib/core/Zend/Validate/Barcode/Issn.php','6.3',0),('4ff83a7bc2c0a1d32b3da88472a42a0e','./lib/core/Zend/Validate/Barcode/Itf14.php','6.3',0),('b081927dd826e470511a1ab03e7f7d5b','./lib/core/Zend/Validate/Barcode/Leitcode.php','6.3',0),('222c919f2d7500c20e19c09ba0f4cf0b','./lib/core/Zend/Validate/Barcode/Planet.php','6.3',0),('9c7b1ad31991f284cf180bba08901ec5','./lib/core/Zend/Validate/Barcode/Postnet.php','6.3',0),('fd78e9abddcfee7d4ff9f5ee869b285f','./lib/core/Zend/Validate/Barcode/Royalmail.php','6.3',0),('d3b52fb6713d4090532c3b5f11b23b44','./lib/core/Zend/Validate/Barcode/Sscc.php','6.3',0),('8e4bbef2364cbd3c494932d2c7a7226e','./lib/core/Zend/Validate/Barcode/Upca.php','6.3',0),('0882cf16c1ca4d65124c076efc3dbb94','./lib/core/Zend/Validate/Barcode/Upce.php','6.3',0),('bf661685fa6122ebdf5fe306ed3c1a97','./lib/core/Zend/Validate/Between.php','6.3',0),('e3a1c68b0feb265763e9aa361825c887','./lib/core/Zend/Validate/Callback.php','6.3',0),('ac430211b632a97ceafaeff7b4c58895','./lib/core/Zend/Validate/Ccnum.php','6.3',0),('ad3cffdbadcda5c5e33e7008bce97976','./lib/core/Zend/Validate/CreditCard.php','6.3',0),('078fdd519bff8eb3f61e3e4584e8d06b','./lib/core/Zend/Validate/Date.php','6.3',0),('348cc4baf57def1626dc2b0d7b1e79fa','./lib/core/Zend/Validate/Db/Abstract.php','6.3',0),('fbe87f1790773ee9dfca1a3971a89b18','./lib/core/Zend/Validate/Db/NoRecordExists.php','6.3',0),('e9f30dd16f6e84134125b903691cff16','./lib/core/Zend/Validate/Db/RecordExists.php','6.3',0),('126a74472c4930003d6971d1139ac37e','./lib/core/Zend/Validate/Digits.php','6.3',0),('5dd54f34dd62c0aa69588b0ab6d6d3e4','./lib/core/Zend/Validate/EmailAddress.php','6.3',0),('ca48effc7e8abdac94dc465ceda0da29','./lib/core/Zend/Validate/Exception.php','6.3',0),('bbc832f3af01a9ca8fd6dfc66d9823b5','./lib/core/Zend/Validate/File/Count.php','6.3',0),('dbfb49df6eeb416a2c85b67c73978ab0','./lib/core/Zend/Validate/File/Crc32.php','6.3',0),('17ad22b7cf83d937b972207586f669f2','./lib/core/Zend/Validate/File/ExcludeExtension.php','6.3',0),('5114d3498c35913c510efbd1fd28fe54','./lib/core/Zend/Validate/File/ExcludeMimeType.php','6.3',0),('b9a76268294633770d5bb1399837d525','./lib/core/Zend/Validate/File/Exists.php','6.3',0),('7f79f44c7b71afe3e79336da4063ef80','./lib/core/Zend/Validate/File/Extension.php','6.3',0),('022fd7c16d573390baf04b3acffdb269','./lib/core/Zend/Validate/File/FilesSize.php','6.3',0),('a3c59b58bf6054d7e323963a4dc1fec1','./lib/core/Zend/Validate/File/Hash.php','6.3',0),('9b196c876fb44886683f3c53ef40f131','./lib/core/Zend/Validate/File/ImageSize.php','6.3',0),('d5704711787b1357159bcd7831870d9b','./lib/core/Zend/Validate/File/IsCompressed.php','6.3',0),('6976f3836d95c904fd56772bd88383f4','./lib/core/Zend/Validate/File/IsImage.php','6.3',0),('777900907c4968c80679765138c924e9','./lib/core/Zend/Validate/File/Md5.php','6.3',0),('7e1046c5484a55d2ee7282ca05c4bc70','./lib/core/Zend/Validate/File/MimeType.php','6.3',0),('433a70c0f2de6337b3191112ede36f12','./lib/core/Zend/Validate/File/NotExists.php','6.3',0),('6adb1a011b262edd8c80fb80b188076e','./lib/core/Zend/Validate/File/Sha1.php','6.3',0),('49d4117187372969b56a2c3f5ed173bd','./lib/core/Zend/Validate/File/Size.php','6.3',0),('add06b71d34b0b5cf06e085a4c9d1c01','./lib/core/Zend/Validate/File/Upload.php','6.3',0),('4638766ac033b95531d56ede39289b70','./lib/core/Zend/Validate/File/WordCount.php','6.3',0),('c2ef8afeb1280b95a37c83e71ddc9d8f','./lib/core/Zend/Validate/Float.php','6.3',0),('447d858e6f63655c6075d8486685d455','./lib/core/Zend/Validate/GreaterThan.php','6.3',0),('875b1da3d9dd65a276ddd6c213ee36cf','./lib/core/Zend/Validate/Hex.php','6.3',0),('78b8de4a9c80bff85c64ed0d2a4ab6f4','./lib/core/Zend/Validate/Hostname.php','6.3',0),('24d4519c844b67dee73714ab71a47e34','./lib/core/Zend/Validate/Hostname/Biz.php','6.3',0),('019c30a8df10acda26c2955fd1202101','./lib/core/Zend/Validate/Hostname/Cn.php','6.3',0),('aade9f1dccda1d9f1dfcab37254e6703','./lib/core/Zend/Validate/Hostname/Com.php','6.3',0),('f788b032df94a303d3627bfe8e34a54a','./lib/core/Zend/Validate/Hostname/Jp.php','6.3',0),('bb2cdd960440cf1c978d5fb3f383e06f','./lib/core/Zend/Validate/Iban.php','6.3',0),('e9ce8a352b7bc4516dd779a30e376651','./lib/core/Zend/Validate/Identical.php','6.3',0),('06b92c4c456c70473473237b74af9887','./lib/core/Zend/Validate/InArray.php','6.3',0),('5f57ee207cf528ebc10fe472fc9f53a7','./lib/core/Zend/Validate/Int.php','6.3',0),('372653b08e9c264fe3e0228d4101ea56','./lib/core/Zend/Validate/Interface.php','6.3',0),('fc164e1ad37c638cc8a5c090b29c954c','./lib/core/Zend/Validate/Ip.php','6.3',0),('ef41ee5a7a5bc20a03a51ff18d1bc907','./lib/core/Zend/Validate/Isbn.php','6.3',0),('1078201412e6b407e04e5d92d52a5b65','./lib/core/Zend/Validate/LessThan.php','6.3',0),('cb3184d7afafbf8eceb18e5e308e1657','./lib/core/Zend/Validate/NotEmpty.php','6.3',0),('796a00f9dcb045b09de0088818102b67','./lib/core/Zend/Validate/PostCode.php','6.3',0),('5bf68c0cd8d009f48417580a63cde3cf','./lib/core/Zend/Validate/Regex.php','6.3',0),('71dd8696b336160b9456f6b041db2c85','./lib/core/Zend/Validate/Sitemap/Changefreq.php','6.3',0),('ea4a63765defa96feba58b04e25e07c2','./lib/core/Zend/Validate/Sitemap/Lastmod.php','6.3',0),('424d5b1696010fa99a8d4b480fe1eb51','./lib/core/Zend/Validate/Sitemap/Loc.php','6.3',0),('2fd6d1d835b731a0987bf8821d6f4bdd','./lib/core/Zend/Validate/Sitemap/Priority.php','6.3',0),('742197d6007d6fb071b1eefd5f885515','./lib/core/Zend/Validate/StringLength.php','6.3',0),('746ac45d7bdb21134b8799b65b4fd04e','./lib/core/Zend/Version.php','6.3',0),('6fdf96310c73d06b4179d3e2bb8f2dab','./lib/core/Zend/View.php','6.3',0),('bd9a92fbe9bf9457c798be340669653e','./lib/core/Zend/View/Abstract.php','6.3',0),('3ec30f950b9c3b57b8606943389ee04c','./lib/core/Zend/View/Exception.php','6.3',0),('02b823aeae5c32bec095b1814307971d','./lib/core/Zend/View/Helper/Abstract.php','6.3',0),('19a8f05ef8dec43ebe3ea9805ea5a309','./lib/core/Zend/View/Helper/Action.php','6.3',0),('387de7408cec274897c59f331ffc4458','./lib/core/Zend/View/Helper/BaseUrl.php','6.3',0),('b0d1383c17fe61c87616c2fd5250d950','./lib/core/Zend/View/Helper/Currency.php','6.3',0),('49c3d07896b7efb8695aab086d0128a2','./lib/core/Zend/View/Helper/Cycle.php','6.3',0),('0f4252d4021714678614ce30abb17618','./lib/core/Zend/View/Helper/DeclareVars.php','6.3',0),('876503f05f00e16749a9d11a9ad236b9','./lib/core/Zend/View/Helper/Doctype.php','6.3',0),('587135c86303fa0f2de8f0b9c46148fe','./lib/core/Zend/View/Helper/Fieldset.php','6.3',0),('979aa7198deee5e224cec665c8e600fe','./lib/core/Zend/View/Helper/Form.php','6.3',0),('2526cbebd304d2d63862a24050e284f4','./lib/core/Zend/View/Helper/FormButton.php','6.3',0),('d25309d9b72914b70d449630ad952abc','./lib/core/Zend/View/Helper/FormCheckbox.php','6.3',0),('206915817642a5089c821b07385d8a12','./lib/core/Zend/View/Helper/FormElement.php','6.3',0),('569ea93a4fcf13136dc89b8082644cee','./lib/core/Zend/View/Helper/FormErrors.php','6.3',0),('c3aad902b56ce7aace38b13f09759204','./lib/core/Zend/View/Helper/FormFile.php','6.3',0),('5115c0f1b6a3176c20236bdddd81c848','./lib/core/Zend/View/Helper/FormHidden.php','6.3',0),('c591143177dc1ad356afa96114f38903','./lib/core/Zend/View/Helper/FormImage.php','6.3',0),('58ee1ec7f2e4b0119fc22a6b8b2cd804','./lib/core/Zend/View/Helper/FormLabel.php','6.3',0),('4bce357b6c008866eb78549387657494','./lib/core/Zend/View/Helper/FormMultiCheckbox.php','6.3',0),('2b5ededab5883678de851f88d250c8af','./lib/core/Zend/View/Helper/FormNote.php','6.3',0),('4c95286aea9068eb72ea545527e6dbab','./lib/core/Zend/View/Helper/FormPassword.php','6.3',0),('9b936248ad64e252997577e8e3533068','./lib/core/Zend/View/Helper/FormRadio.php','6.3',0),('660d4d474a170de01c9edcee75dfd31c','./lib/core/Zend/View/Helper/FormReset.php','6.3',0),('07078e6b6a0e82847e4eef1090e432f5','./lib/core/Zend/View/Helper/FormSelect.php','6.3',0),('cbfd335b8936ce95c91b8cd278815eb2','./lib/core/Zend/View/Helper/FormSubmit.php','6.3',0),('4e0b3a5a8ad013d2e662d4c344b31941','./lib/core/Zend/View/Helper/FormText.php','6.3',0),('4a19c039f01db26ab88fc4627cd30adb','./lib/core/Zend/View/Helper/FormTextarea.php','6.3',0),('abe07782df2901b535777d46bdc1c3d4','./lib/core/Zend/View/Helper/HeadLink.php','6.3',0),('ae3d21bb05809f9af9306a85863f7482','./lib/core/Zend/View/Helper/HeadMeta.php','6.3',0),('2aef5e487f360d609fb3fd7f0083f4ce','./lib/core/Zend/View/Helper/HeadScript.php','6.3',0),('c7018244adea3d931ccf8d23b3aabbd1','./lib/core/Zend/View/Helper/HeadStyle.php','6.3',0),('32f3c5b077afa5ecffa28b0db088975b','./lib/core/Zend/View/Helper/HeadTitle.php','6.3',0),('c7494f157f51cec7d60bf164603c59ca','./lib/core/Zend/View/Helper/HtmlElement.php','6.3',0),('0cc7fcdb086045a0981eccab0f01e857','./lib/core/Zend/View/Helper/HtmlFlash.php','6.3',0),('f75596903edbd5d5160e758ad6e87b33','./lib/core/Zend/View/Helper/HtmlList.php','6.3',0),('864a0c147fe5345661e163619fbdf885','./lib/core/Zend/View/Helper/HtmlObject.php','6.3',0),('1af04531541870ebf32932bf5378b1e5','./lib/core/Zend/View/Helper/HtmlPage.php','6.3',0),('eb2a2969208dcd51b7daa42b37cae804','./lib/core/Zend/View/Helper/HtmlQuicktime.php','6.3',0),('339914a0f5eccf01949540454c093209','./lib/core/Zend/View/Helper/InlineScript.php','6.3',0),('f1a636c66a7135c40268ca31acbe5ead','./lib/core/Zend/View/Helper/Interface.php','6.3',0),('15b66bf5342e017cbcdddab614bfd7d8','./lib/core/Zend/View/Helper/Json.php','6.3',0),('05fe1bd2ef54e756342e90e0623f88e7','./lib/core/Zend/View/Helper/Layout.php','6.3',0),('b539abc88cafcd0dd3e41b6a90b02871','./lib/core/Zend/View/Helper/Navigation.php','6.3',0),('4a3d78ab6f26f30c5425d1673ff9dc0c','./lib/core/Zend/View/Helper/Navigation/Breadcrumbs.php','6.3',0),('5b676611f9a4ac5f9decc40fda810bdb','./lib/core/Zend/View/Helper/Navigation/Helper.php','6.3',0),('e18242ca38bd171b713f2c1507fe7f1f','./lib/core/Zend/View/Helper/Navigation/HelperAbstract.php','6.3',0),('2d82be7075a00e3ace02491c292c5039','./lib/core/Zend/View/Helper/Navigation/Links.php','6.3',0),('c89f1eb2ccb02226e802f5208a30c419','./lib/core/Zend/View/Helper/Navigation/Menu.php','6.3',0),('012ddaeb61d1b2abc5fbdacffd65ea52','./lib/core/Zend/View/Helper/Navigation/Sitemap.php','6.3',0),('adb96c5a074d36416c895d7bfdad1aae','./lib/core/Zend/View/Helper/PaginationControl.php','6.3',0),('c8c6721d9e83fdf9e9633c5a6038d132','./lib/core/Zend/View/Helper/Partial.php','6.3',0),('58917ebbe3af7ef2c416d3378e02f7f6','./lib/core/Zend/View/Helper/Partial/Exception.php','6.3',0),('9b51fef57b98c2bd0e01fcaa43f8de5c','./lib/core/Zend/View/Helper/PartialLoop.php','6.3',0),('c2631bdf4a35504f68c20ee9941623eb','./lib/core/Zend/View/Helper/Placeholder.php','6.3',0),('9483b78a0d11584ee62be6d3b03f753b','./lib/core/Zend/View/Helper/Placeholder/Container.php','6.3',0),('9cdd8fed6479c4d394264b89deb7ce45','./lib/core/Zend/View/Helper/Placeholder/Container/Abstract.php','6.3',0),('cdc9b17000eb6150c74908af3968954b','./lib/core/Zend/View/Helper/Placeholder/Container/Exception.php','6.3',0),('129b3d8d44cf849effac9c9ed8a75dec','./lib/core/Zend/View/Helper/Placeholder/Container/Standalone.php','6.3',0),('701f11b1a1361c264ec411cc7f102a66','./lib/core/Zend/View/Helper/Placeholder/Registry.php','6.3',0),('cb1b268821745843101fc4e2a77dc936','./lib/core/Zend/View/Helper/Placeholder/Registry/Exception.php','6.3',0),('a5489818a1a188a713b4d730f2168df8','./lib/core/Zend/View/Helper/RenderToPlaceholder.php','6.3',0),('995fb072346f33482be48bd208b8d857','./lib/core/Zend/View/Helper/ServerUrl.php','6.3',0),('3a6d25fb0b1016ea81e3ae1aebae3e76','./lib/core/Zend/View/Helper/Translate.php','6.3',0),('9f9972d88a3d3f67466ede8b2a761573','./lib/core/Zend/View/Helper/Url.php','6.3',0),('4ccf287c6bf53f008b424df20dbfbf0c','./lib/core/Zend/View/Interface.php','6.3',0),('9bb5882a9fd146a64c9013a1bc444242','./lib/core/Zend/View/Stream.php','6.3',0),('d90547f9095c0a59efd361f105c2561e','./lib/core/Zend/Wildfire/Channel/HttpHeaders.php','6.3',0),('add66f57e51c6aef7073085714e00554','./lib/core/Zend/Wildfire/Channel/Interface.php','6.3',0),('97c5e11c6d98e9213fcedf158d15cac2','./lib/core/Zend/Wildfire/Exception.php','6.3',0),('99a26c9014712489fdd5ccc54b6e8a59','./lib/core/Zend/Wildfire/Plugin/FirePhp.php','6.3',0),('462dc66fc851207379f768bb419d346e','./lib/core/Zend/Wildfire/Plugin/FirePhp/Message.php','6.3',0),('fb2c7c05bbb738b0439219acc77f38fa','./lib/core/Zend/Wildfire/Plugin/FirePhp/TableMessage.php','6.3',0),('7cd6a75dce7aa8966b7851b4bdf56404','./lib/core/Zend/Wildfire/Plugin/Interface.php','6.3',0),('47ddad3d953826b69c82da898e6d78a0','./lib/core/Zend/Wildfire/Protocol/JsonStream.php','6.3',0),('5b2e398aeec53ba67abb164592415ea2','./lib/core/Zend/XmlRpc/Client.php','6.3',0),('04bb6b94b1cc9c50fb4d8fc99c940a4c','./lib/core/Zend/XmlRpc/Client/Exception.php','6.3',0),('e6acc10374aed7de814c6cde1ac1cc7c','./lib/core/Zend/XmlRpc/Client/FaultException.php','6.3',0),('49c5e7e619f0fb3c0577daf4c4274a46','./lib/core/Zend/XmlRpc/Client/HttpException.php','6.3',0),('d27f2a02b10a3d8a7e26177296d39129','./lib/core/Zend/XmlRpc/Client/IntrospectException.php','6.3',0),('feb66e2db05c637911c3fb2e90d449ec','./lib/core/Zend/XmlRpc/Client/ServerIntrospection.php','6.3',0),('75042802c778e936c3eaf3367dd2dbe3','./lib/core/Zend/XmlRpc/Client/ServerProxy.php','6.3',0),('c56f38bbe2ad9d2a4d49246fc8ea1f23','./lib/core/Zend/XmlRpc/Exception.php','6.3',0),('ae13975bd26f52e1237a0b242c0a0317','./lib/core/Zend/XmlRpc/Fault.php','6.3',0),('a35d9246856315a808f771bbf058fc8d','./lib/core/Zend/XmlRpc/Generator/DomDocument.php','6.3',0),('1c4197aa1a470eb947e86c8ea058d3e2','./lib/core/Zend/XmlRpc/Generator/GeneratorAbstract.php','6.3',0),('504892509545bd04d4bbd8d362cf2500','./lib/core/Zend/XmlRpc/Generator/XmlWriter.php','6.3',0),('a93a7c5e39b3fca174564e266ed9d476','./lib/core/Zend/XmlRpc/Request.php','6.3',0),('f41db12b813877636552de58383e5511','./lib/core/Zend/XmlRpc/Request/Http.php','6.3',0),('e42d41ec937fad3a3711940d08da7027','./lib/core/Zend/XmlRpc/Request/Stdin.php','6.3',0),('79e984e22a284150d2cf56001b596585','./lib/core/Zend/XmlRpc/Response.php','6.3',0),('4cd41dc647e3921b1388751b1b4213fb','./lib/core/Zend/XmlRpc/Response/Http.php','6.3',0),('bd4c881927df41c5a62c6070df0b203c','./lib/core/Zend/XmlRpc/Server.php','6.3',0),('7e3abc9c7d1f2847997cbd702a2b5a74','./lib/core/Zend/XmlRpc/Server/Cache.php','6.3',0),('82e85f3cdb0cd6592aca9e4d1c7b95b6','./lib/core/Zend/XmlRpc/Server/Exception.php','6.3',0),('55fbf77e0e0df1ad741d7979d993a8b7','./lib/core/Zend/XmlRpc/Server/Fault.php','6.3',0),('885411621e5436dd261efd50741e6b8f','./lib/core/Zend/XmlRpc/Server/System.php','6.3',0),('3b2c95e1962241211ba11f0e9a7ca2d3','./lib/core/Zend/XmlRpc/Value.php','6.3',0),('26d27f0db194f9d67801da34473097cc','./lib/core/Zend/XmlRpc/Value/Array.php','6.3',0),('e231003e4f5b3d643f92b600a8c64243','./lib/core/Zend/XmlRpc/Value/Base64.php','6.3',0),('36f68a8ca53a4435a8dfbaddcb77f7e5','./lib/core/Zend/XmlRpc/Value/BigInteger.php','6.3',0),('80deb53520b5bd433c2c92bb9abd6595','./lib/core/Zend/XmlRpc/Value/Boolean.php','6.3',0),('19fcd80c7c65cfa799b18a4473e00309','./lib/core/Zend/XmlRpc/Value/Collection.php','6.3',0),('eaab77f8bc8b57945d1e024d1815a890','./lib/core/Zend/XmlRpc/Value/DateTime.php','6.3',0),('d05550075f9bf20ceca59ba4188cf396','./lib/core/Zend/XmlRpc/Value/Double.php','6.3',0),('7a8aeb05c6723d47ffffd62a34bc198b','./lib/core/Zend/XmlRpc/Value/Exception.php','6.3',0),('c0c1463bfc0653111a8058991f875883','./lib/core/Zend/XmlRpc/Value/Integer.php','6.3',0),('31f9808f44824d3cca15034ff584bc80','./lib/core/Zend/XmlRpc/Value/Nil.php','6.3',0),('2a271c81c7ed19712abb96d9f291750d','./lib/core/Zend/XmlRpc/Value/Scalar.php','6.3',0),('beeb7b6b6c834f2fd632839412f20c69','./lib/core/Zend/XmlRpc/Value/String.php','6.3',0),('263ce2420284e5cef59d4836038360d7','./lib/core/Zend/XmlRpc/Value/Struct.php','6.3',0),('8e23bd7928470d8e1953e85962377231','./lib/credits/creditslib.php','6.3',0),('14a73e7b9426d68ed04ab0b06fe3fdcc','./lib/csslib.php','6.3',0),('f574268db6df276549e45d54bf5a9f16','./lib/db/tiki_registration_fields.php','6.3',0),('b8611179e20a63ec7aa516e1d67e6afc','./lib/dcs/dcslib.php','6.3',0),('33e4986197b72e13e6fe138902fd6bae','./lib/dcs/index.php','6.3',0),('68564b3804c0c934fdd646fe28a1c904','./lib/debug/debug-command_dmsg.php','6.3',0),('acdbbd5e464cca761e9c324c195f29fb','./lib/debug/debug-command_features.php','6.3',0),('3c0435d6d2cfb60cad4cf579f0bcd0a6','./lib/debug/debug-command_perm.php','6.3',0),('e6a70403e8ba048744d2403957026a47','./lib/debug/debug-command_print.php','6.3',0),('2ba33a2669f44e27a55f8841104077e8','./lib/debug/debug-command_slist.php','6.3',0),('b666041c596d9b4718f1f2fb79ad54e0','./lib/debug/debug-command_sprint.php','6.3',0),('98b978f02af3c1bb502b4ff3ce074090','./lib/debug/debug-command_sql.php','6.3',0),('3275975484ced6ef9408cb560cea856d','./lib/debug/debug-command_test.php','6.3',0),('ae266fc6071422be8b0a985798f18833','./lib/debug/debug-command_tikitables.php','6.3',0),('d0b798aa94856dedf728f116989ca889','./lib/debug/debug-command_watch.php','6.3',0),('e3ecc1a4cb768b48f2bc62957520323d','./lib/debug/debugger-common.php','6.3',0),('afbceafef2b05bad3f381b3fb9b5fd62','./lib/debug/debugger-ext.php','6.3',0),('6ee9bbd21cc585b9c0fa78c839e72eb4','./lib/debug/debugger.php','6.3',0),('33e4986197b72e13e6fe138902fd6bae','./lib/debug/index.php','6.3',0),('25bc45b9cb924184722553f02b6d9597','./lib/diff.php','6.3',0),('f2c08b5b17fe4ceba024b8e66ca6ade0','./lib/diff/Diff.php','6.3',0),('464086fb6b7576d7ce752be4f5d177ac','./lib/diff/Renderer.php','6.3',0),('8ffd6249be791f63c6bce63a563de04a','./lib/diff/difflib.php','6.3',0),('fa49f2acb7fedb37e8924c3b5a041979','./lib/diff/renderer_bytes.php','6.3',0),('2cb0b0005118d4ca713010e11563bae8','./lib/diff/renderer_character.php','6.3',0),('badb3b8be30cbffa27f2c155f39bbff8','./lib/diff/renderer_character_inline.php','6.3',0),('c78390e85d7317ce831a18d4cac6624c','./lib/diff/renderer_htmldiff.php','6.3',0),('6cff82a6662af64c0f82aebfae05faf7','./lib/diff/renderer_inline.php','6.3',0),('8c20e72915184331ada3e71ff7ae16e6','./lib/diff/renderer_sidebyside.php','6.3',0),('7c7975f98b60087bdb26e29889ae193b','./lib/diff/renderer_unified.php','6.3',0),('04c40bede8af735a71c80581f120dd69','./lib/directory/dirlib.php','6.3',0),('33e4986197b72e13e6fe138902fd6bae','./lib/directory/index.php','6.3',0),('633e7217258969195dc6fdbd21760e13','./lib/encoding/lib-encoding.php','6.3',0),('b411c591893029f949138f53e0fd560e','./lib/equation/class.latexrender.php','6.3',0),('c531fb56f9a0118ca56eeefd1b28e569','./lib/equation/pictures/index.php','6.3',0),('c531fb56f9a0118ca56eeefd1b28e569','./lib/equation/tmp/index.php','6.3',0),('33e4986197b72e13e6fe138902fd6bae','./lib/events/index.php','6.3',0),('b7a2b84d7a316a7855ef8491f0aed36e','./lib/ezcomponents/Base/src/base.php','6.3',0),('4cbf7efc1654c118c1ab4013da584ea2','./lib/ezcomponents/Base/src/exceptions/autoload.php','6.3',0),('26ae1c2a3243187d8b281a33e28ab388','./lib/ezcomponents/Base/src/exceptions/double_class_repository_prefix.php','6.3',0),('1b1d2ccf1d83e9f2126ce6d423ad4a06','./lib/ezcomponents/Base/src/exceptions/exception.php','6.3',0),('d9b8d14dcddd1453d36025842a915c88','./lib/ezcomponents/Base/src/exceptions/extension_not_found.php','6.3',0),('83889a8ded5df760a1184a44e64beb08','./lib/ezcomponents/Base/src/exceptions/file_exception.php','6.3',0),('2a2d0e89497bd188477d43f5a87701d8','./lib/ezcomponents/Base/src/exceptions/file_io.php','6.3',0),('cee70f6094d8e6a1da052f3b2e9913ab','./lib/ezcomponents/Base/src/exceptions/file_not_found.php','6.3',0),('249cdcf29b1fc357587301d1a8f8a25f','./lib/ezcomponents/Base/src/exceptions/file_permission.php','6.3',0),('f914328c784c38af9dcb71d6fdbbac42','./lib/ezcomponents/Base/src/exceptions/functionality_not_supported.php','6.3',0),('9ae4f81ab15f52153132439840096a47','./lib/ezcomponents/Base/src/exceptions/init_callback_configured.php','6.3',0),('f4f5f5d9599ea1cdde2929e4dbbcbdbe','./lib/ezcomponents/Base/src/exceptions/invalid_callback_class.php','6.3',0),('416b95f88e0480547b51340afef5d647','./lib/ezcomponents/Base/src/exceptions/invalid_parent_class.php','6.3',0),('e6147c51e29536df0683a49aeab920e8','./lib/ezcomponents/Base/src/exceptions/property_not_found.php','6.3',0),('58e2f2dc39f347b59a1afc957a8cdfcd','./lib/ezcomponents/Base/src/exceptions/property_permission.php','6.3',0),('8b95e40352468ff28126fc02abc8a9b6','./lib/ezcomponents/Base/src/exceptions/setting_not_found.php','6.3',0),('a9dd91058d170afb1728619c7b848504','./lib/ezcomponents/Base/src/exceptions/setting_value.php','6.3',0),('ba9fd1b76372a61fdf21788fb57652e3','./lib/ezcomponents/Base/src/exceptions/value.php','6.3',0),('990f3ff806a9b5e7b11d172d8dd98462','./lib/ezcomponents/Base/src/exceptions/whatever.php','6.3',0),('88d0e047b97d85c99114583aa103c745','./lib/ezcomponents/Base/src/ezc_bootstrap.php','6.3',0),('6fd930e0989b4f0ab940d7bfd6f41c90','./lib/ezcomponents/Base/src/features.php','6.3',0),('dbe0d8855229df798919b9b1d3f84373','./lib/ezcomponents/Base/src/file.php','6.3',0),('0ccaeea1d41417f464914cebb064b7d7','./lib/ezcomponents/Base/src/init.php','6.3',0),('dc2ea8522a7c06d5b3569a43ff536e7e','./lib/ezcomponents/Base/src/interfaces/configuration_initializer.php','6.3',0),('9f7c4a9cb5cf5c9647f7a827ebe9e435','./lib/ezcomponents/Base/src/interfaces/exportable.php','6.3',0),('916e40d5c700ab2888c01e4ebf587dcc','./lib/ezcomponents/Base/src/interfaces/persistable.php','6.3',0),('a6c718b782e8c23497183a11ab1e8954','./lib/ezcomponents/Base/src/metadata.php','6.3',0),('71fc5b479b6d8aa27103a16a29a715ea','./lib/ezcomponents/Base/src/metadata/pear.php','6.3',0),('988bce2474a73cf18bad85a2fb9112cf','./lib/ezcomponents/Base/src/metadata/tarball.php','6.3',0),('89b149eb5eddf69c1424fd9883d51382','./lib/ezcomponents/Base/src/options.php','6.3',0),('cb22067aa3adbf0152698040c6194ff8','./lib/ezcomponents/Base/src/options/autoload.php','6.3',0),('d817afdeef8ee0d02e1cebddfc8915e5','./lib/ezcomponents/Base/src/struct.php','6.3',0),('23efc7803de088935e856b72e0ee8bea','./lib/ezcomponents/Base/src/structs/file_find_context.php','6.3',0),('6dd22392400103056ced0bac2769197c','./lib/ezcomponents/Base/src/structs/repository_directory.php','6.3',0),('dbbba46bc534577999f3971c7fda1eae','./lib/ezcomponents/Webdav/src/auth/digest_base.php','6.3',0),('6e61d4cd1bf08940dd86b91313294bc4','./lib/ezcomponents/Webdav/src/backends/file.php','6.3',0),('9cf98aea51acaf612eee4469b92f5971','./lib/ezcomponents/Webdav/src/backends/memory.php','6.3',0),('c73022cb42e95a79dc5981b4fe1b6086','./lib/ezcomponents/Webdav/src/backends/simple.php','6.3',0),('fe930996f8b5ea3512989cc85c781b7d','./lib/ezcomponents/Webdav/src/exceptions/bad_request.php','6.3',0),('82df786e0fab0f3ccd8afc3761ccf848','./lib/ezcomponents/Webdav/src/exceptions/broken_base_uri.php','6.3',0),('d6a1a08df2c29db7f75f6504af7bd57a','./lib/ezcomponents/Webdav/src/exceptions/broken_request_uri.php','6.3',0),('48efeb87bb3aee76b7420b36887f10a1','./lib/ezcomponents/Webdav/src/exceptions/broken_storage_exception.php','6.3',0),('82d95040de2593163d799d0279dd241b','./lib/ezcomponents/Webdav/src/exceptions/exception.php','6.3',0),('dedabf1621f9075cafaaba15b035c6ef','./lib/ezcomponents/Webdav/src/exceptions/headers_not_validated.php','6.3',0),('52bc981c06ca59701637e7dd09245640','./lib/ezcomponents/Webdav/src/exceptions/inconsistency.php','6.3',0),('ccc785b8a470a71ae9bad4fe8e8fcc59','./lib/ezcomponents/Webdav/src/exceptions/invalid_callback.php','6.3',0),('9f0571cfb21daeb144f1dec6bc40aa82','./lib/ezcomponents/Webdav/src/exceptions/invalid_header.php','6.3',0),('861200956e9201663bf4e6a2ef26f34c','./lib/ezcomponents/Webdav/src/exceptions/invalid_hook.php','6.3',0),('d41edbfec03f3c0cfd3b8ea7a86d13db','./lib/ezcomponents/Webdav/src/exceptions/invalid_request_body.php','6.3',0),('7b075273d11f9a59010eb2569ccb1241','./lib/ezcomponents/Webdav/src/exceptions/invalid_request_method.php','6.3',0),('4855547605213fea0b8130a224278940','./lib/ezcomponents/Webdav/src/exceptions/invalid_xml.php','6.3',0),('830936f4db10abebb0a314c7d03dafc2','./lib/ezcomponents/Webdav/src/exceptions/missing_header.php','6.3',0),('8bcdaa41a2c000c8c7e6e0b54c64e476','./lib/ezcomponents/Webdav/src/exceptions/missing_transport_configuration.php','6.3',0),('31fc76643d36155e33962225b6391260','./lib/ezcomponents/Webdav/src/exceptions/misssing_server_variable.php','6.3',0),('504cbac8cdfdaad3b5f599bdbc309d51','./lib/ezcomponents/Webdav/src/exceptions/no_transport_handler.php','6.3',0),('04c04e11e9eb575ebdd2c9ecdc709a3c','./lib/ezcomponents/Webdav/src/exceptions/plugin_precondition_failed.php','6.3',0),('7feae72231457dd5079d3fb196c83539','./lib/ezcomponents/Webdav/src/exceptions/request_not_supported.php','6.3',0),('af0e76256df237536b05ccf48ba0fd69','./lib/ezcomponents/Webdav/src/exceptions/unknown_header.php','6.3',0),('973accc3fef0ed43b45df3b405fb3f2e','./lib/ezcomponents/Webdav/src/interfaces/anonymous_authenticator.php','6.3',0),('bdb24d8c0a6e686c4264a7a04abe7010','./lib/ezcomponents/Webdav/src/interfaces/authorizer.php','6.3',0),('3db5aa3b6ed841e4ce7d6909d048baa4','./lib/ezcomponents/Webdav/src/interfaces/backend.php','6.3',0),('db51a02d1e72349fb80685f91a3a523b','./lib/ezcomponents/Webdav/src/interfaces/backend/change.php','6.3',0),('85a21771d65c25eb8b6e54e9e08f8671','./lib/ezcomponents/Webdav/src/interfaces/backend/make_collection.php','6.3',0),('f91c9dd93352e463aab3a6402930ea0c','./lib/ezcomponents/Webdav/src/interfaces/backend/put.php','6.3',0),('e2e65bc13dc42e02034457ffe9afeb22','./lib/ezcomponents/Webdav/src/interfaces/basic_authenticator.php','6.3',0),('e9c9aea9f54d75f745c7ee2288ecdf08','./lib/ezcomponents/Webdav/src/interfaces/digest_authenticator.php','6.3',0),('66f7e92685b1176465ffc447afb1d7e1','./lib/ezcomponents/Webdav/src/interfaces/infrastructure_base.php','6.3',0),('57874de055c41b26b5fd121627657890','./lib/ezcomponents/Webdav/src/interfaces/path_factory.php','6.3',0),('4e7ea0180ad509668ef9fd03fd63ff88','./lib/ezcomponents/Webdav/src/interfaces/property.php','6.3',0),('225dd47348431b411a7a6042b2997488','./lib/ezcomponents/Webdav/src/interfaces/property_live.php','6.3',0),('51f300d0a6ea9015b04db7e5f0462858','./lib/ezcomponents/Webdav/src/interfaces/property_storage.php','6.3',0),('245680eb491990b06b01cb3fa14cc22f','./lib/ezcomponents/Webdav/src/interfaces/request.php','6.3',0),('d83cb624a7b588267c6784c4d2f2547f','./lib/ezcomponents/Webdav/src/interfaces/response.php','6.3',0),('e38b3e8562f3b66ef54c2bbd9f09ddb2','./lib/ezcomponents/Webdav/src/namespace_registry.php','6.3',0),('5272333b847ef4f6bf1a0a257810bfd4','./lib/ezcomponents/Webdav/src/options/backend_file_options.php','6.3',0),('884dd869807968a559bb7db7719a4857','./lib/ezcomponents/Webdav/src/options/backend_memory_options.php','6.3',0),('4e46bb0280aeca8bfa9e8d72d8b7598f','./lib/ezcomponents/Webdav/src/options/server.php','6.3',0),('b4ba199ba6ddb438f58403287abca098','./lib/ezcomponents/Webdav/src/path_factories/automatic.php','6.3',0),('5bd5ce1e0fc00e93ba76ca37c8846d90','./lib/ezcomponents/Webdav/src/path_factories/basic.php','6.3',0),('64eec6b03fb1bf9786486801f8b2e657','./lib/ezcomponents/Webdav/src/plugin_configuration.php','6.3',0),('80d1c7ee702c016c5d88e559ffd265bb','./lib/ezcomponents/Webdav/src/plugin_parameters.php','6.3',0),('15524717be099f042be036f1882103f6','./lib/ezcomponents/Webdav/src/plugin_registry.php','6.3',0),('1a972c6b0983577f50ce2da5b1dd69fd','./lib/ezcomponents/Webdav/src/plugins/lock/administration/purger.php','6.3',0),('dcbd2779fd890ffbea22524c775955d7','./lib/ezcomponents/Webdav/src/plugins/lock/administrator.php','6.3',0),('9d5019d6d14547e8e0af055b259f78a5','./lib/ezcomponents/Webdav/src/plugins/lock/check_observers/lock.php','6.3',0),('1c10aff2bc21a21f967cca59e14685b1','./lib/ezcomponents/Webdav/src/plugins/lock/check_observers/lock_refresh.php','6.3',0),('79355bce9b90dc170bddd85cfc37444a','./lib/ezcomponents/Webdav/src/plugins/lock/check_observers/multiple.php','6.3',0),('7085b0b9c4eeb958a5f62ef692cac9cc','./lib/ezcomponents/Webdav/src/plugins/lock/check_observers/path_collector.php','6.3',0),('c4508868caebe014a9b147f757a971fa','./lib/ezcomponents/Webdav/src/plugins/lock/check_observers/property_collector.php','6.3',0),('01eeeae08fd69a1f8b52bd83f1654d5e','./lib/ezcomponents/Webdav/src/plugins/lock/config.php','6.3',0),('684b808389ee4f4e37ce88ce3f8e618e','./lib/ezcomponents/Webdav/src/plugins/lock/exceptions/access_denied.php','6.3',0),('6443251ec258899ecd0082a2ef74b28b','./lib/ezcomponents/Webdav/src/plugins/lock/exceptions/administration.php','6.3',0),('6b76bbbfa3d7942b95711f8f9cc386d0','./lib/ezcomponents/Webdav/src/plugins/lock/handlers/copy.php','6.3',0),('724c4329821b258131fa9648dbd8734b','./lib/ezcomponents/Webdav/src/plugins/lock/handlers/delete.php','6.3',0),('16a70c293c288ed60fc782641ada37d3','./lib/ezcomponents/Webdav/src/plugins/lock/handlers/lock.php','6.3',0),('9a4460de9fa8185df466740f4e92c994','./lib/ezcomponents/Webdav/src/plugins/lock/handlers/mkcol.php','6.3',0),('e58ea32e7ace16e50b892f4325a637f6','./lib/ezcomponents/Webdav/src/plugins/lock/handlers/move.php','6.3',0),('119d1e9de8890328ef844912eb101dfd','./lib/ezcomponents/Webdav/src/plugins/lock/handlers/options.php','6.3',0),('9a53ed8d60226ec9747654e185938f91','./lib/ezcomponents/Webdav/src/plugins/lock/handlers/propfind.php','6.3',0),('6ac9e773b9f1647cfc2ef404cb278212','./lib/ezcomponents/Webdav/src/plugins/lock/handlers/proppatch.php','6.3',0),('2a26c1a43bfa67f935dcde0acc195425','./lib/ezcomponents/Webdav/src/plugins/lock/handlers/put.php','6.3',0),('4fa5e235090e943e1fe72ed34d087fdd','./lib/ezcomponents/Webdav/src/plugins/lock/handlers/unlock.php','6.3',0),('3ae91a216fa972d6d8490657b372ba35','./lib/ezcomponents/Webdav/src/plugins/lock/header/if_header_condition.php','6.3',0),('4d6e98439d883d9da4e1602459c3b1fd','./lib/ezcomponents/Webdav/src/plugins/lock/header/if_header_list_item.php','6.3',0),('9d29cc84ddec09596c724349c21b42be','./lib/ezcomponents/Webdav/src/plugins/lock/header/if_header_no_tag_list.php','6.3',0),('71b3a8f042238868fda55ad8928a546a','./lib/ezcomponents/Webdav/src/plugins/lock/header/if_header_tagged_list.php','6.3',0),('8c4133614ba7ed84e5ec31260c75bf82','./lib/ezcomponents/Webdav/src/plugins/lock/header_handler.php','6.3',0),('172225dcb0441e52af9fd901b48c5329','./lib/ezcomponents/Webdav/src/plugins/lock/interfaces/check_observer.php','6.3',0),('704ac29ed4a77aa154e0c269c0d5981e','./lib/ezcomponents/Webdav/src/plugins/lock/interfaces/handler.php','6.3',0),('8d98c19ab6e182128fd28d521ce4130e','./lib/ezcomponents/Webdav/src/plugins/lock/interfaces/if_header_list.php','6.3',0),('be0e6df23025797998524c2b309a67ab','./lib/ezcomponents/Webdav/src/plugins/lock/interfaces/lock_authorizer.php','6.3',0),('06c8e4581efdc477a4042ff9a255fa11','./lib/ezcomponents/Webdav/src/plugins/lock/interfaces/lock_backend.php','6.3',0),('bfb659ac37eef6bea327d90577828238','./lib/ezcomponents/Webdav/src/plugins/lock/main.php','6.3',0),('7b7dd666a7cd20aa85bd93ab97425056','./lib/ezcomponents/Webdav/src/plugins/lock/options.php','6.3',0),('54f6056a1fc92d2fb44e4e3a6ecf7f93','./lib/ezcomponents/Webdav/src/plugins/lock/properties/lockdiscovery.php','6.3',0),('9bd2c1484a8d6a839fc91483ad58dca5','./lib/ezcomponents/Webdav/src/plugins/lock/properties/lockdiscovery_activelock.php','6.3',0),('9091c4f38f1d0abe99e8fd017d6ef616','./lib/ezcomponents/Webdav/src/plugins/lock/properties/supportedlock.php','6.3',0),('2ba2db8cb1a9bf7f14011f0f5c6c5d29','./lib/ezcomponents/Webdav/src/plugins/lock/properties/supportedlock_lockentry.php','6.3',0),('cf52e94506602ccc65c7f32b52e2f82a','./lib/ezcomponents/Webdav/src/plugins/lock/property_handler.php','6.3',0),('68c527464242b3171042d7d49c8fc738','./lib/ezcomponents/Webdav/src/plugins/lock/requests/content/lock_info.php','6.3',0),('efa1ab20fcc9336b13f9f91bdec340b9','./lib/ezcomponents/Webdav/src/plugins/lock/requests/lock.php','6.3',0),('075b8bb55dd98ddab6bf02564dd8a4c6','./lib/ezcomponents/Webdav/src/plugins/lock/requests/unlock.php','6.3',0),('6d96519c0d4deb7bfe21422e73672373','./lib/ezcomponents/Webdav/src/plugins/lock/responses/lock.php','6.3',0),('6c8a1f404d597d43ab4e994acf6e750c','./lib/ezcomponents/Webdav/src/plugins/lock/responses/unlock.php','6.3',0),('c91403c93a0d1b0ddf697c269c9ea1b4','./lib/ezcomponents/Webdav/src/plugins/lock/structs/lock_check_info.php','6.3',0),('d506a2efaa4ef4a05332cac367ed21f1','./lib/ezcomponents/Webdav/src/plugins/lock/tools.php','6.3',0),('f0030f65e1b98f57ba50f5a8c668d233','./lib/ezcomponents/Webdav/src/plugins/lock/transport.php','6.3',0),('c714ad050c910706d42e1b159920df29','./lib/ezcomponents/Webdav/src/properties/creationdate.php','6.3',0),('60f8f178abee9a319efd37049cebf7cf','./lib/ezcomponents/Webdav/src/properties/dead.php','6.3',0),('8cdba0da3efee1da92e480e33ce6da64','./lib/ezcomponents/Webdav/src/properties/displayname.php','6.3',0),('b1ac65a5b8036265638a86c1a24fc661','./lib/ezcomponents/Webdav/src/properties/getcontentlanguage.php','6.3',0),('92661cd4a295cdb1bd9d1d0fc606c95d','./lib/ezcomponents/Webdav/src/properties/getcontentlength.php','6.3',0),('b8a684426348ed8a24f10606ece01644','./lib/ezcomponents/Webdav/src/properties/getcontenttype.php','6.3',0),('6bfb310f9457ccc192c8027be9e9e125','./lib/ezcomponents/Webdav/src/properties/getetag.php','6.3',0),('c51742382d3d5dd42d9d4ee1fe06881f','./lib/ezcomponents/Webdav/src/properties/getlastmodified.php','6.3',0),('4dff6720f010ac327ccdf113437634c9','./lib/ezcomponents/Webdav/src/properties/resourcetype.php','6.3',0),('2eecab5841f43b98d51a5c0f36e576f7','./lib/ezcomponents/Webdav/src/properties/source.php','6.3',0),('d7e55c1123af455e5241c9a40515857b','./lib/ezcomponents/Webdav/src/properties/source_link.php','6.3',0),('fda46f8493597f7b7352d09b9bae2f1e','./lib/ezcomponents/Webdav/src/property_storages/basic.php','6.3',0),('d4d69f56ea00e06edcc41c59b1505139','./lib/ezcomponents/Webdav/src/property_storages/flagged.php','6.3',0),('70465b9f0ed7d67a0548a6d232b366a6','./lib/ezcomponents/Webdav/src/requests/content/property_behaviour.php','6.3',0),('d2657707312ba986304f412c1b8850a8','./lib/ezcomponents/Webdav/src/requests/copy.php','6.3',0),('47574a72dfe1100bc10909d488e74459','./lib/ezcomponents/Webdav/src/requests/delete.php','6.3',0),('0dc59a57c68deceb03a7adb3ffb3f22b','./lib/ezcomponents/Webdav/src/requests/get.php','6.3',0),('f2ad9814731c12230170dccf6b3e8547','./lib/ezcomponents/Webdav/src/requests/head.php','6.3',0),('4399337eabe91530b3fc25ea5167be29','./lib/ezcomponents/Webdav/src/requests/mkcol.php','6.3',0),('597747207a35c55e703b055ed35828b2','./lib/ezcomponents/Webdav/src/requests/move.php','6.3',0),('c1fc994bcdfa38e990d66a085fdfff0d','./lib/ezcomponents/Webdav/src/requests/options.php','6.3',0),('76a4e75c7dff470de4baea70098b6dbd','./lib/ezcomponents/Webdav/src/requests/propfind.php','6.3',0),('b70c1fe2ad870b258a6a7343acee65cf','./lib/ezcomponents/Webdav/src/requests/proppatch.php','6.3',0),('08148a30084d3fb49c94783131ab2227','./lib/ezcomponents/Webdav/src/requests/put.php','6.3',0),('79d319435f62282a93645f2df6732313','./lib/ezcomponents/Webdav/src/responses/copy.php','6.3',0),('7d9f62f3b7fae03d73fd7033fcb7c216','./lib/ezcomponents/Webdav/src/responses/delete.php','6.3',0),('c434fcc0a0840493a948938ddbe9b2aa','./lib/ezcomponents/Webdav/src/responses/error.php','6.3',0),('99dd03620e1bd621eaa07e6d6530ef83','./lib/ezcomponents/Webdav/src/responses/get_collection.php','6.3',0),('4fa86c6f3683d264f595e7f5e7c975a5','./lib/ezcomponents/Webdav/src/responses/get_resource.php','6.3',0),('14b7b05447d089eb90e21256d343f40e','./lib/ezcomponents/Webdav/src/responses/head.php','6.3',0),('536f44c058f30077b1b8c89654b96758','./lib/ezcomponents/Webdav/src/responses/mkcol.php','6.3',0),('536dceb5e7fcb960428ed687cac82579','./lib/ezcomponents/Webdav/src/responses/move.php','6.3',0),('b98a6d40632742ae438e6b1bcce92d66','./lib/ezcomponents/Webdav/src/responses/multistatus.php','6.3',0),('eed3d790ac1d28d1f7e21916f25f7161','./lib/ezcomponents/Webdav/src/responses/options.php','6.3',0),('6ecf6fe6a96f9d9bc0403c88954a20d3','./lib/ezcomponents/Webdav/src/responses/propfind.php','6.3',0),('fe012f80f261d17ef352481ebc52fd83','./lib/ezcomponents/Webdav/src/responses/proppatch.php','6.3',0),('d4f318bd3476ac67e40ca3dab94d45c9','./lib/ezcomponents/Webdav/src/responses/propstat.php','6.3',0),('b75052cdcb724acd938a515e21017c7d','./lib/ezcomponents/Webdav/src/responses/put.php','6.3',0),('6a7ff96ed52cc08fd8561eca0d277cb0','./lib/ezcomponents/Webdav/src/server.php','6.3',0),('1f2edb19cfc9e0e46e76491b410f5ab4','./lib/ezcomponents/Webdav/src/server_configuration.php','6.3',0),('9dbc2c14d98b591d3de6f5eca32dec6e','./lib/ezcomponents/Webdav/src/server_configuration_manager.php','6.3',0),('6d1b84d304b0d8c55183d1e59355d904','./lib/ezcomponents/Webdav/src/structs/anonymous_auth.php','6.3',0),('e86942bc352d7808765f19230b194483','./lib/ezcomponents/Webdav/src/structs/auth.php','6.3',0),('4903a84fc6e82512141be1235706f256','./lib/ezcomponents/Webdav/src/structs/basic_auth.php','6.3',0),('4d3683631daf4c850ecebb3b3a640b3d','./lib/ezcomponents/Webdav/src/structs/collection.php','6.3',0),('1988424cbe33a8cb42e92af213ccc0f4','./lib/ezcomponents/Webdav/src/structs/digest_auth.php','6.3',0),('9e3b226f28a69e530050cf4c8dbc3f99','./lib/ezcomponents/Webdav/src/structs/display_information.php','6.3',0),('dbb8e8ebff2f42d08428792a67e9c066','./lib/ezcomponents/Webdav/src/structs/display_information_empty.php','6.3',0),('1b909caa108e43e36ed25f579399ae6c','./lib/ezcomponents/Webdav/src/structs/display_information_string.php','6.3',0),('01a879cc5b4d10efea24859cc175a9cd','./lib/ezcomponents/Webdav/src/structs/display_information_xml.php','6.3',0),('3732e76642148ec2a6b66a8f430214db','./lib/ezcomponents/Webdav/src/structs/output_result.php','6.3',0),('760da9dc5ced84d3f1ebbcc1055e0ba9','./lib/ezcomponents/Webdav/src/structs/potential_uri_content.php','6.3',0),('1cd387e2e7614461060bca8ea64c8fbf','./lib/ezcomponents/Webdav/src/structs/resource.php','6.3',0),('8a1aa0e0f1948be6b397178758197d23','./lib/ezcomponents/Webdav/src/tools/date_time.php','6.3',0),('0e067cf315de769be063f6b2dceb961d','./lib/ezcomponents/Webdav/src/tools/xml.php','6.3',0),('0ae2f25bd580c8bb97de7debcd68ecac','./lib/ezcomponents/Webdav/src/transport.php','6.3',0),('d7ef8646a61b2b2cac68606c627ca52f','./lib/ezcomponents/Webdav/src/transports/header_handler.php','6.3',0),('ffe0b0bb88bd82d998dbf68594c0dc9a','./lib/ezcomponents/Webdav/src/transports/konqueror.php','6.3',0),('49a947d3ba4cf8cf56f57f12ee09883e','./lib/ezcomponents/Webdav/src/transports/microsoft.php','6.3',0),('af32cc1650875220dc8c31b65ebf9728','./lib/ezcomponents/Webdav/src/transports/nautilus.php','6.3',0),('239f894f48da12da9b80560263196b79','./lib/ezcomponents/Webdav/src/transports/property_handler.php','6.3',0),('70e9bbc17ee4b3ccd6826afaa8d86a6b','./lib/ezcomponents/Webdav/src/transports/property_handlers/nautilus.php','6.3',0),('f95a0357cca0dee2450504a3c41d4629','./lib/ezcomponents/autoload/archive_autoload.php','6.3',0),('00f7562c9522b7637aaa0ecc6ba0dcb0','./lib/ezcomponents/autoload/authentication_autoload.php','6.3',0),('5364fa6dca8817f0ceff679158a0f067','./lib/ezcomponents/autoload/authentication_database_autoload.php','6.3',0),('09a35c52d39f404c03c0c82b450797c7','./lib/ezcomponents/autoload/authentication_openid_autoload.php','6.3',0),('bf570452286a6c882531370b75ef4ed5','./lib/ezcomponents/autoload/base_autoload.php','6.3',0),('20d26ec748ee696aa784ddeb9f06fdd8','./lib/ezcomponents/autoload/cache_autoload.php','6.3',0),('4af64a4507c1b291b2dc106d38b46d40','./lib/ezcomponents/autoload/configuration_autoload.php','6.3',0),('a5d0832dc9a28b1b83e377ec2f72503c','./lib/ezcomponents/autoload/console_autoload.php','6.3',0),('73a7b9b4ddea40f2347a4c46ebfef3a2','./lib/ezcomponents/autoload/db_autoload.php','6.3',0),('37f5dc6540ae880ac374048ad25a9294','./lib/ezcomponents/autoload/db_schema_autoload.php','6.3',0),('2177e01756de4cdca0fe27dc18aa112f','./lib/ezcomponents/autoload/debug_autoload.php','6.3',0),('1102848ade7f32b7d74f42f3d42b4858','./lib/ezcomponents/autoload/document_autoload.php','6.3',0),('bf8516a926ecc597cd8509736c976eaa','./lib/ezcomponents/autoload/execution_autoload.php','6.3',0),('86464fbee265d8fa2822b455468f764a','./lib/ezcomponents/autoload/feed_autoload.php','6.3',0),('6f5a826d9e4ac53914069ecf9599c90e','./lib/ezcomponents/autoload/file_autoload.php','6.3',0),('78d7284b5971c62aa3fa35a12b029e14','./lib/ezcomponents/autoload/graph_autoload.php','6.3',0),('72e9f9c691b92c6e93badfaac5fe4017','./lib/ezcomponents/autoload/graph_database_autoload.php','6.3',0),('6cc7423b6b915da941fbdec0b13ef892','./lib/ezcomponents/autoload/image_analyzer_autoload.php','6.3',0),('e8b0d8583b3b8e47b5f2ea5c294a0651','./lib/ezcomponents/autoload/image_autoload.php','6.3',0),('661d5e127e2a0d8bb7898c5d4fa96ba2','./lib/ezcomponents/autoload/input_autoload.php','6.3',0),('bb41230715cec43e1e72aecc52fd12f1','./lib/ezcomponents/autoload/log_autoload.php','6.3',0),('1b4bfa497bbd7ebcdec6cd1430dd6a60','./lib/ezcomponents/autoload/log_database_autoload.php','6.3',0),('6dbe02d339136d8df88b7ee4dd1041e7','./lib/ezcomponents/autoload/mail_autoload.php','6.3',0),('90a946c742e353ab22ec8d9e77d87587','./lib/ezcomponents/autoload/mvc_authentication_autoload.php','6.3',0),('2a161c2b72691b5c1ead54b2421dd88a','./lib/ezcomponents/autoload/mvc_autoload.php','6.3',0),('4feb5f31690fa3b94ec11bda0307d29e','./lib/ezcomponents/autoload/mvc_feed_autoload.php','6.3',0),('beddc47f3adc6037963ff5f71c24ff81','./lib/ezcomponents/autoload/mvc_mail_autoload.php','6.3',0),('ed5f63f8ac193043c5e7ac06a758ded3','./lib/ezcomponents/autoload/mvc_template_autoload.php','6.3',0),('5eeb5074530d8d0f2597706340604dab','./lib/ezcomponents/autoload/persistent_autoload.php','6.3',0),('eb73d8e3129ef6cf1500aef3b2de5875','./lib/ezcomponents/autoload/persistent_object_autoload.php','6.3',0),('70eac6f6d887362e5b333b9f21168fa7','./lib/ezcomponents/autoload/php_generator_autoload.php','6.3',0),('832f735ed4b5633a36e3013d5a294ecf','./lib/ezcomponents/autoload/query_autoload.php','6.3',0),('dc2a45723997b951790aaa64136e8c1a','./lib/ezcomponents/autoload/search_autoload.php','6.3',0),('33192a67c4c0258b85486a5a6d8c3f30','./lib/ezcomponents/autoload/signal_autoload.php','6.3',0),('cfe189120bf283d7726d8ce223eabc53','./lib/ezcomponents/autoload/system_autoload.php','6.3',0),('c91d9e25afe234ddb4c9952534fa6f17','./lib/ezcomponents/autoload/template_autoload.php','6.3',0),('804357179e87b7f37adad072263b4d95','./lib/ezcomponents/autoload/template_translation_autoload.php','6.3',0),('fcbc954a4201df85601732231ccecdee','./lib/ezcomponents/autoload/translation_autoload.php','6.3',0),('fc2f2feda01cc12e339439ff2b5a5f2b','./lib/ezcomponents/autoload/translation_cache_autoload.php','6.3',0),('73f085967be188b28e8614dd71249fd9','./lib/ezcomponents/autoload/tree_autoload.php','6.3',0),('8c72b5d763344cf9d9c42760e93c4f9f','./lib/ezcomponents/autoload/tree_db_autoload.php','6.3',0),('84a75e863000b38168dbc1fbaf108b0a','./lib/ezcomponents/autoload/tree_persistent_autoload.php','6.3',0),('d912ca8c067cfcdfe31f899f27a77062','./lib/ezcomponents/autoload/url_autoload.php','6.3',0),('ebe8aa0ec54fef4bd249e6e585fd30a9','./lib/ezcomponents/autoload/webdav_autoload.php','6.3',0),('82101ee70e29cee07ae36d7669baaa4e','./lib/ezcomponents/autoload/workflow_autoload.php','6.3',0),('5df743c8eab40a4b24ceb07ac97b8ff7','./lib/ezcomponents/autoload/workflow_database_autoload.php','6.3',0),('4bddc4c9d00146f9276af09c7a3348e2','./lib/ezcomponents/autoload/workflow_event_autoload.php','6.3',0),('9907206a271e1ed5205b77a50466418d','./lib/ezcomponents/autoload/workflow_signal_autoload.php','6.3',0),('f56878c8f7023ce9b7a927279099aeb3','./lib/faqs/faqlib.php','6.3',0),('33e4986197b72e13e6fe138902fd6bae','./lib/faqs/index.php','6.3',0),('ea9e89f412f783d8ae93c1c2fe764363','./lib/featured_links/flinkslib.php','6.3',0),('33e4986197b72e13e6fe138902fd6bae','./lib/featured_links/index.php','6.3',0),('0bc2a17e3b09f4581a081f832d75d132','./lib/filegals/filegallib.php','6.3',0),('33e4986197b72e13e6fe138902fd6bae','./lib/filegals/index.php','6.3',0),('197ce4b441a3dfd64efe4c227d352682','./lib/filegals/max_upload_size.php','6.3',0),('98c1f84123d96006e62c1c1af377a900','./lib/freetag/freetaglib.php','6.3',0),('33e4986197b72e13e6fe138902fd6bae','./lib/freetag/index.php','6.3',0),('313e2cd484c4dd1247b33a5955bbcd1e','./lib/geo/geolib.php','6.3',0),('c3d0ee3c2f26cbf1b7930fbe6595bd53','./lib/graph-engine/abstract.gridbased.php','6.3',0),('4fe9a6f3c5409a827474d61b242147a4','./lib/graph-engine/core.php','6.3',0),('877fc663e125fc799cb8f925e31db1d2','./lib/graph-engine/gd.php','6.3',0),('62427bdd1af48f765608e6bbe157711e','./lib/graph-engine/graph.bar.php','6.3',0),('22edc0026d6d1b0b212d872d8b3aa933','./lib/graph-engine/graph.multiline.php','6.3',0),('3d8b354418d5a8fdba5a38dace5a2aa0','./lib/graph-engine/graph.pie.php','6.3',0),('4a85796b8801243e740896e03f2ed596','./lib/graph-engine/pdflib.php','6.3',0),('a4eda3d7819fe761b9ea727709fdc73a','./lib/graph-engine/ps.php','6.3',0),('c4f4acc37343c96e5ea4ab916bd8df26','./lib/groupalert/groupalertlib.php','6.3',0),('2f5044f2dbd33f6163535e0d9cf81fd5','./lib/groupalert/index.php','6.3',0),('57ab800c2326b97e4180869497db4a56','./lib/hawhaw/hawimconv.php','6.3',0),('60a8d6e1ce91b481519bf1e8ac40e8e9','./lib/hawhaw/hawtikilib.php','6.3',0),('2f5044f2dbd33f6163535e0d9cf81fd5','./lib/hawhaw/index.php','6.3',0),('6023549d266bb97139577c2aff67968a','./lib/headerlib.php','6.3',0),('ee9eb9bb229a33572e01203d9229e4e5','./lib/hotwords/hotwordlib.php','6.3',0),('2f5044f2dbd33f6163535e0d9cf81fd5','./lib/hotwords/index.php','6.3',0),('0f06af2a34a2eed6f6f09118ce5c880b','./lib/htmlpages/htmlpageslib.php','6.3',0),('2f5044f2dbd33f6163535e0d9cf81fd5','./lib/htmlpages/index.php','6.3',0),('2f5044f2dbd33f6163535e0d9cf81fd5','./lib/htmlparser/index.php','6.3',0),('121138ace27ad07ba9589a13e6a9d43f','./lib/htmlparser/rebuildgrammar.php','6.3',0),('0f6dba2689f471c382240c8d2d7892ba','./lib/htmlpurifier/HTMLPurifier.auto.php','6.3',0),('4bb70e5ba6b06a23b8416cc0e59254bb','./lib/htmlpurifier/HTMLPurifier.autoload.php','6.3',0),('f09594e7a7db5826b4b3aef3b9f874ed','./lib/htmlpurifier/HTMLPurifier.func.php','6.3',0),('5ea7321cb792b6425775e24b81e12d56','./lib/htmlpurifier/HTMLPurifier.includes.php','6.3',0),('25043ef5e632f88e8d5c825a8516a1cc','./lib/htmlpurifier/HTMLPurifier.kses.php','6.3',0),('5a6eedd494dd20c8579e2a9d39809d5b','./lib/htmlpurifier/HTMLPurifier.path.php','6.3',0),('f384581fa2c10f31d115bc05c857680b','./lib/htmlpurifier/HTMLPurifier.php','6.3',0),('34df6fbfe768a7d18c661b1ebc52ce23','./lib/htmlpurifier/HTMLPurifier.safe-includes.php','6.3',0),('5b1067853574bae62d9cd70370ff10af','./lib/htmlpurifier/HTMLPurifier/AttrCollections.php','6.3',0),('b510f76fa16d0a3298c6d7b468a6494c','./lib/htmlpurifier/HTMLPurifier/AttrDef.php','6.3',0),('6caf3a641704cee2aeb15b4eb1c287c9','./lib/htmlpurifier/HTMLPurifier/AttrDef/CSS.php','6.3',0),('f0232cc2a7573418b8ebe5efcf108c46','./lib/htmlpurifier/HTMLPurifier/AttrDef/CSS/AlphaValue.php','6.3',0),('8a16f12cb9b9f6d941b7a82f1c40862c','./lib/htmlpurifier/HTMLPurifier/AttrDef/CSS/Background.php','6.3',0),('f2f45d74040f109cd09580b5cb3de1c4','./lib/htmlpurifier/HTMLPurifier/AttrDef/CSS/BackgroundPosition.php','6.3',0),('0301346329aae91bae8924c90d3d4688','./lib/htmlpurifier/HTMLPurifier/AttrDef/CSS/Border.php','6.3',0),('4bd2e4e9cd6e71ca7a6cb5e62700b380','./lib/htmlpurifier/HTMLPurifier/AttrDef/CSS/Color.php','6.3',0),('ac75113a9cbfe6bfe8d3afe36444f272','./lib/htmlpurifier/HTMLPurifier/AttrDef/CSS/Composite.php','6.3',0),('a112e7c263f001b9ac062ea64201cccd','./lib/htmlpurifier/HTMLPurifier/AttrDef/CSS/DenyElementDecorator.php','6.3',0),('54e42fbf58fe9c70ef082d6a8f8be821','./lib/htmlpurifier/HTMLPurifier/AttrDef/CSS/Filter.php','6.3',0),('c14c12936339b03f24e9b50cd5273450','./lib/htmlpurifier/HTMLPurifier/AttrDef/CSS/Font.php','6.3',0),('5e0d75bb85e3d83c28a9b8d944bbd1c1','./lib/htmlpurifier/HTMLPurifier/AttrDef/CSS/FontFamily.php','6.3',0),('9a9a4ef13940096bbe18037d54cb056f','./lib/htmlpurifier/HTMLPurifier/AttrDef/CSS/ImportantDecorator.php','6.3',0),('6774b03e0b29672961ad4fba15c25787','./lib/htmlpurifier/HTMLPurifier/AttrDef/CSS/Length.php','6.3',0),('3d888cc157a4ea616dc1e94dd5f1c21e','./lib/htmlpurifier/HTMLPurifier/AttrDef/CSS/ListStyle.php','6.3',0),('2c4560cf0dd700ae39c0a553140ffd1b','./lib/htmlpurifier/HTMLPurifier/AttrDef/CSS/Multiple.php','6.3',0),('0f1f03450117004aabb529c43f154334','./lib/htmlpurifier/HTMLPurifier/AttrDef/CSS/Number.php','6.3',0),('10afadc403e14974645b3e1c17f83adb','./lib/htmlpurifier/HTMLPurifier/AttrDef/CSS/Percentage.php','6.3',0),('54f6f27a44bdb66d6197a46ba89213e8','./lib/htmlpurifier/HTMLPurifier/AttrDef/CSS/TextDecoration.php','6.3',0),('bfb426e22d4d764adfca7bdfadec7ca6','./lib/htmlpurifier/HTMLPurifier/AttrDef/CSS/URI.php','6.3',0),('1a11be0015a161c2a11d6c51305f45fa','./lib/htmlpurifier/HTMLPurifier/AttrDef/Enum.php','6.3',0),('c579b5a145c447f1880c7bc6d3db774c','./lib/htmlpurifier/HTMLPurifier/AttrDef/HTML/Bool.php','6.3',0),('fa319109d0c0e5989a24f550c884c1b5','./lib/htmlpurifier/HTMLPurifier/AttrDef/HTML/Class.php','6.3',0),('ed699f61359c5d7ab046d248253e5d9e','./lib/htmlpurifier/HTMLPurifier/AttrDef/HTML/Color.php','6.3',0),('96026f3e8ffdc70e533f306e63322923','./lib/htmlpurifier/HTMLPurifier/AttrDef/HTML/FrameTarget.php','6.3',0),('bd36cb0c65c586c2d1dff7a44a4bf0dc','./lib/htmlpurifier/HTMLPurifier/AttrDef/HTML/ID.php','6.3',0),('a38926a6e784e67d5cd7e9d657802214','./lib/htmlpurifier/HTMLPurifier/AttrDef/HTML/Length.php','6.3',0),('ed11d4126e34e45fd127650a45f0ee56','./lib/htmlpurifier/HTMLPurifier/AttrDef/HTML/LinkTypes.php','6.3',0),('122498f21ff87dcab5ec8f1dfb51d39c','./lib/htmlpurifier/HTMLPurifier/AttrDef/HTML/MultiLength.php','6.3',0),('8face464a844799e3aab2e9f4f918868','./lib/htmlpurifier/HTMLPurifier/AttrDef/HTML/Nmtokens.php','6.3',0),('95962e03883b9a84496487a1f8af5da3','./lib/htmlpurifier/HTMLPurifier/AttrDef/HTML/Pixels.php','6.3',0),('f57bc53b7c7a29b0c4324e0ad2039c2a','./lib/htmlpurifier/HTMLPurifier/AttrDef/Integer.php','6.3',0),('04a72938e4c07553d9a18ae6649cd90f','./lib/htmlpurifier/HTMLPurifier/AttrDef/Lang.php','6.3',0),('8fcf6999bbd3f2cd9d3780182d91be7d','./lib/htmlpurifier/HTMLPurifier/AttrDef/Switch.php','6.3',0),('0ad9dcd58ce4f104006b59a9df51802a','./lib/htmlpurifier/HTMLPurifier/AttrDef/Text.php','6.3',0),('05afd73beee5b644bc49790b7a0dde0f','./lib/htmlpurifier/HTMLPurifier/AttrDef/URI.php','6.3',0),('958e3072379737950b8ce0f6823ac8eb','./lib/htmlpurifier/HTMLPurifier/AttrDef/URI/Email.php','6.3',0),('cebebf0d99b63ecd2072f37e69055b6c','./lib/htmlpurifier/HTMLPurifier/AttrDef/URI/Email/SimpleCheck.php','6.3',0),('38b3ca8b1c3522fbbd27bce785bc58ab','./lib/htmlpurifier/HTMLPurifier/AttrDef/URI/Host.php','6.3',0),('da52096d6feb81bd8a40f9d5ed439139','./lib/htmlpurifier/HTMLPurifier/AttrDef/URI/IPv4.php','6.3',0),('44004a19ee045f386993905c84600d61','./lib/htmlpurifier/HTMLPurifier/AttrDef/URI/IPv6.php','6.3',0),('18870fa532d982a78f20d00e93b6ba3e','./lib/htmlpurifier/HTMLPurifier/AttrTransform.php','6.3',0),('1decd9fa8e0777811024260549d29aaa','./lib/htmlpurifier/HTMLPurifier/AttrTransform/Background.php','6.3',0),('3e6afa73230fc31d74eb382bd42bb18a','./lib/htmlpurifier/HTMLPurifier/AttrTransform/BdoDir.php','6.3',0),('ec7f74671186c8e5e93a381cce6470fa','./lib/htmlpurifier/HTMLPurifier/AttrTransform/BgColor.php','6.3',0),('b7d7e4d45de29fc50eefdc97e760e6d5','./lib/htmlpurifier/HTMLPurifier/AttrTransform/BoolToCSS.php','6.3',0),('faca234a22422d5cf69ca7068145eac8','./lib/htmlpurifier/HTMLPurifier/AttrTransform/Border.php','6.3',0),('f1f2fb8deb98f319592e4f55545facee','./lib/htmlpurifier/HTMLPurifier/AttrTransform/EnumToCSS.php','6.3',0),('7d035d518336aec5b4dfa7e8d2958652','./lib/htmlpurifier/HTMLPurifier/AttrTransform/ImgRequired.php','6.3',0),('107148ff2b640ff7afbfc59e638812f5','./lib/htmlpurifier/HTMLPurifier/AttrTransform/ImgSpace.php','6.3',0),('a0ee62ef96c7ac5c6add36ef47f9ba47','./lib/htmlpurifier/HTMLPurifier/AttrTransform/Input.php','6.3',0),('17dd8373c191efd5c95bfe5fb79ed8fe','./lib/htmlpurifier/HTMLPurifier/AttrTransform/Lang.php','6.3',0),('0c9bfa9cdc93cff8714b237e854f4595','./lib/htmlpurifier/HTMLPurifier/AttrTransform/Length.php','6.3',0),('563026acbdd46b682f91cdfea1103ce8','./lib/htmlpurifier/HTMLPurifier/AttrTransform/Name.php','6.3',0),('03c2f1e68d493f53430c42d4c8806166','./lib/htmlpurifier/HTMLPurifier/AttrTransform/NameSync.php','6.3',0),('c9814258f610f4cbc17b6a511289b329','./lib/htmlpurifier/HTMLPurifier/AttrTransform/SafeEmbed.php','6.3',0),('6575e1225807af9eb79e3c005b028591','./lib/htmlpurifier/HTMLPurifier/AttrTransform/SafeObject.php','6.3',0),('0487ce94b8018c59b3320adc96711850','./lib/htmlpurifier/HTMLPurifier/AttrTransform/SafeParam.php','6.3',0),('aeeb086b76d4bcb87d8a36a61b7ca644','./lib/htmlpurifier/HTMLPurifier/AttrTransform/ScriptRequired.php','6.3',0),('45c48b09a03a9abef719748ce27c4728','./lib/htmlpurifier/HTMLPurifier/AttrTransform/Textarea.php','6.3',0),('b1ba10c4bcd37a7f5e9a6c97a81b18c8','./lib/htmlpurifier/HTMLPurifier/AttrTypes.php','6.3',0),('53aebf76f83099026c95c03844ecf39b','./lib/htmlpurifier/HTMLPurifier/AttrValidator.php','6.3',0),('de2d3205b26e42deaa94d8d74e3692c4','./lib/htmlpurifier/HTMLPurifier/Bootstrap.php','6.3',0),('0ae05faa7955f058b220e058a8660224','./lib/htmlpurifier/HTMLPurifier/CSSDefinition.php','6.3',0),('281eaa00a5e3ff98b611b5ebca97bcb0','./lib/htmlpurifier/HTMLPurifier/ChildDef.php','6.3',0),('3c557d08cadb051c7e1711376da3acb8','./lib/htmlpurifier/HTMLPurifier/ChildDef/Chameleon.php','6.3',0),('13c44a1aaf1ab1b25744758cd1831b4f','./lib/htmlpurifier/HTMLPurifier/ChildDef/Custom.php','6.3',0),('22f2d339fcb60c536e651f80f03f7c82','./lib/htmlpurifier/HTMLPurifier/ChildDef/Empty.php','6.3',0),('6b324d68260f872dc1a9312608af70bf','./lib/htmlpurifier/HTMLPurifier/ChildDef/Optional.php','6.3',0),('682f8da336f2a1dad1cd7880d4848076','./lib/htmlpurifier/HTMLPurifier/ChildDef/Required.php','6.3',0),('538d675731b05c7483ec31e1ae55ca4a','./lib/htmlpurifier/HTMLPurifier/ChildDef/StrictBlockquote.php','6.3',0),('98c3856ffede2c519fa703dee541fc01','./lib/htmlpurifier/HTMLPurifier/ChildDef/Table.php','6.3',0),('d5ff68e24c52b5dc66a0bdf120dea42a','./lib/htmlpurifier/HTMLPurifier/Config.php','6.3',0),('37ccb7351a8bcc8c49bba3c2d312996d','./lib/htmlpurifier/HTMLPurifier/ConfigSchema.php','6.3',0),('a9d77f36c69fcdeeaffdddccf53b1aea','./lib/htmlpurifier/HTMLPurifier/ConfigSchema/Builder/ConfigSchema.php','6.3',0),('2f3ef23752e2cb399fea85c3368b2d47','./lib/htmlpurifier/HTMLPurifier/ConfigSchema/Builder/Xml.php','6.3',0),('31bf3afba867409fdf11f75eaa3725fd','./lib/htmlpurifier/HTMLPurifier/ConfigSchema/Exception.php','6.3',0),('16ec96e01b7a93a75f6c0d27a3044d2c','./lib/htmlpurifier/HTMLPurifier/ConfigSchema/Interchange.php','6.3',0),('3b11731a184f921ad82632a4d5ca8ea3','./lib/htmlpurifier/HTMLPurifier/ConfigSchema/Interchange/Directive.php','6.3',0),('b67c7f7562c9eac082a960b3be9f5f1f','./lib/htmlpurifier/HTMLPurifier/ConfigSchema/Interchange/Id.php','6.3',0),('2da487ed0053dd17f8f4c13a7b3cf04d','./lib/htmlpurifier/HTMLPurifier/ConfigSchema/InterchangeBuilder.php','6.3',0),('d9327f8aaab4fdc364107d0779310b3b','./lib/htmlpurifier/HTMLPurifier/ConfigSchema/Validator.php','6.3',0),('9a57bfdb6b774679e2f5593d4c67d7f5','./lib/htmlpurifier/HTMLPurifier/ConfigSchema/ValidatorAtom.php','6.3',0),('1bd2243d0d7b68504723ebc5dddd0ea2','./lib/htmlpurifier/HTMLPurifier/ContentSets.php','6.3',0),('c1ed36707d08237daa646b3b8eeb30a4','./lib/htmlpurifier/HTMLPurifier/Context.php','6.3',0),('a188cbe72b81f021578b989d1566f0b3','./lib/htmlpurifier/HTMLPurifier/Definition.php','6.3',0),('db24b53bab53b8ffa40b197e06078fe4','./lib/htmlpurifier/HTMLPurifier/DefinitionCache.php','6.3',0),('f185adab8aad39c577d9d4900ed61b81','./lib/htmlpurifier/HTMLPurifier/DefinitionCache/Decorator.php','6.3',0),('31e3ea9d5988c5a1ae3f369ddccbfead','./lib/htmlpurifier/HTMLPurifier/DefinitionCache/Decorator/Cleanup.php','6.3',0),('8acd4ef5453cc2c25612a665f46ca836','./lib/htmlpurifier/HTMLPurifier/DefinitionCache/Decorator/Memory.php','6.3',0),('e27dfb4700f20a6ccd1ab8e498ce0ac6','./lib/htmlpurifier/HTMLPurifier/DefinitionCache/Null.php','6.3',0),('d63b0aeacf255afb75982a14f1dd0daf','./lib/htmlpurifier/HTMLPurifier/DefinitionCache/Serializer.php','6.3',0),('1df8a4f27f64b5473b41e4666f787c6d','./lib/htmlpurifier/HTMLPurifier/DefinitionCacheFactory.php','6.3',0),('512fcd900313924eb7902442186a06cc','./lib/htmlpurifier/HTMLPurifier/Doctype.php','6.3',0),('0ab0a6b2a7d358ab8532d897e8bfe729','./lib/htmlpurifier/HTMLPurifier/DoctypeRegistry.php','6.3',0),('ef70ab52db10c8ec6adb270fe46f8f6d','./lib/htmlpurifier/HTMLPurifier/ElementDef.php','6.3',0),('fc3fee6ae7b5cfa04ce2c4ba8699a98b','./lib/htmlpurifier/HTMLPurifier/Encoder.php','6.3',0),('1ebc1f6db1134f98ba757d16bec67d0a','./lib/htmlpurifier/HTMLPurifier/EntityLookup.php','6.3',0),('85a29be7cf7434024284aeb333659c0b','./lib/htmlpurifier/HTMLPurifier/EntityParser.php','6.3',0),('5aee849a4ef4f610cd383752697f6966','./lib/htmlpurifier/HTMLPurifier/ErrorCollector.php','6.3',0),('3cc9e13fb56fb8816bd478e46522a926','./lib/htmlpurifier/HTMLPurifier/ErrorStruct.php','6.3',0),('6549f2e00060fd671149191f1e94eaf3','./lib/htmlpurifier/HTMLPurifier/Exception.php','6.3',0),('33181bbe7f6e7e839796e73d4d2a790d','./lib/htmlpurifier/HTMLPurifier/Filter.php','6.3',0),('739249b8ed7c1e1ff906931b13d477f6','./lib/htmlpurifier/HTMLPurifier/Filter/ExtractStyleBlocks.php','6.3',0),('92324458027c0e4bb3bce76361312080','./lib/htmlpurifier/HTMLPurifier/Filter/YouTube.php','6.3',0),('69341e24127fb66dbd32d47290e41776','./lib/htmlpurifier/HTMLPurifier/Generator.php','6.3',0),('15ac6baf303f0dd62e692b368571da6a','./lib/htmlpurifier/HTMLPurifier/HTMLDefinition.php','6.3',0),('9cbb7c9019e68203ca205eff77a61fe5','./lib/htmlpurifier/HTMLPurifier/HTMLModule.php','6.3',0),('e129432b77bb64fdc290d13987c45596','./lib/htmlpurifier/HTMLPurifier/HTMLModule/Bdo.php','6.3',0),('381c8ba0950e07c6c82c42a642385800','./lib/htmlpurifier/HTMLPurifier/HTMLModule/CommonAttributes.php','6.3',0),('5475ee52a8791d170b841cd6ad905094','./lib/htmlpurifier/HTMLPurifier/HTMLModule/Edit.php','6.3',0),('73153b86492552a9fbb88340c770963f','./lib/htmlpurifier/HTMLPurifier/HTMLModule/Forms.php','6.3',0),('bb4790cbd4a68e90a2d1fb8b820d7147','./lib/htmlpurifier/HTMLPurifier/HTMLModule/Hypertext.php','6.3',0),('911df038afaefbc0f662a3d6fa8d9554','./lib/htmlpurifier/HTMLPurifier/HTMLModule/Image.php','6.3',0),('e36d4f596bd85f285d243013495c8dcb','./lib/htmlpurifier/HTMLPurifier/HTMLModule/Legacy.php','6.3',0),('273050404a01f635e470d05538438813','./lib/htmlpurifier/HTMLPurifier/HTMLModule/List.php','6.3',0),('9765121a41a8e2a372a65c6bd3b32789','./lib/htmlpurifier/HTMLPurifier/HTMLModule/Name.php','6.3',0),('24b18ff07b334f19fc8c1e5f184d2570','./lib/htmlpurifier/HTMLPurifier/HTMLModule/NonXMLCommonAttributes.php','6.3',0),('a7cca883348645c6a77ec7db0932a610','./lib/htmlpurifier/HTMLPurifier/HTMLModule/Object.php','6.3',0),('e503304a642c6786f6a11eb3ead87ddd','./lib/htmlpurifier/HTMLPurifier/HTMLModule/Presentation.php','6.3',0),('aae031812e9fbe29dff05f23e1b4cda5','./lib/htmlpurifier/HTMLPurifier/HTMLModule/Proprietary.php','6.3',0),('c87f9de5628a72270943de5496d36ddf','./lib/htmlpurifier/HTMLPurifier/HTMLModule/Ruby.php','6.3',0),('6b1194cb01892e9bec3dab35854b5b52','./lib/htmlpurifier/HTMLPurifier/HTMLModule/SafeEmbed.php','6.3',0),('dcd3afaa3b67376b9ed66a21ee3e97dc','./lib/htmlpurifier/HTMLPurifier/HTMLModule/SafeObject.php','6.3',0),('074b0eb6b6c34a1992ab65aa67e29a35','./lib/htmlpurifier/HTMLPurifier/HTMLModule/Scripting.php','6.3',0),('4770bf322cefdc9b155d9faf2851e21f','./lib/htmlpurifier/HTMLPurifier/HTMLModule/StyleAttribute.php','6.3',0),('7d6e6c2595498da192d69006c46d769d','./lib/htmlpurifier/HTMLPurifier/HTMLModule/Tables.php','6.3',0),('ad4c41177390713e568bdd96848e37f5','./lib/htmlpurifier/HTMLPurifier/HTMLModule/Target.php','6.3',0),('65b57e9b356a4d13b6f0c65dfcd337dd','./lib/htmlpurifier/HTMLPurifier/HTMLModule/Text.php','6.3',0),('4837b4cb0776cc1af14a21c1b877e078','./lib/htmlpurifier/HTMLPurifier/HTMLModule/Tidy.php','6.3',0),('f6bed98e1a7ebae0e09764956bdac4f2','./lib/htmlpurifier/HTMLPurifier/HTMLModule/Tidy/Name.php','6.3',0),('9c41c71abf36d63efe2df29832ec065a','./lib/htmlpurifier/HTMLPurifier/HTMLModule/Tidy/Proprietary.php','6.3',0),('5215ba83a8f645d50077b748ab344b8a','./lib/htmlpurifier/HTMLPurifier/HTMLModule/Tidy/Strict.php','6.3',0),('a00c39ef28493892552b3f3e452cf992','./lib/htmlpurifier/HTMLPurifier/HTMLModule/Tidy/Transitional.php','6.3',0),('7f514a82cfd85b03d712274b5d249954','./lib/htmlpurifier/HTMLPurifier/HTMLModule/Tidy/XHTML.php','6.3',0),('cbdf3deab781644fcc25dde08b441727','./lib/htmlpurifier/HTMLPurifier/HTMLModule/Tidy/XHTMLAndHTML4.php','6.3',0),('4927a47ebe2721507baaddf7f66da265','./lib/htmlpurifier/HTMLPurifier/HTMLModule/XMLCommonAttributes.php','6.3',0),('b3fe48fa29465d75928b5a2917d4ba30','./lib/htmlpurifier/HTMLPurifier/HTMLModuleManager.php','6.3',0),('41e2004626f0e87d894ad091f91f6554','./lib/htmlpurifier/HTMLPurifier/IDAccumulator.php','6.3',0),('9f1d4fac7ab8e8ba0a94a13cdfb5c644','./lib/htmlpurifier/HTMLPurifier/Injector.php','6.3',0),('8e0e9c2d101e48d8ab7eae9ef3b8e503','./lib/htmlpurifier/HTMLPurifier/Injector/AutoParagraph.php','6.3',0),('e0ba2c64ec1ff45452069ea4a61194c8','./lib/htmlpurifier/HTMLPurifier/Injector/DisplayLinkURI.php','6.3',0),('a205c290b398a25a7f4b76a5401e54c4','./lib/htmlpurifier/HTMLPurifier/Injector/Linkify.php','6.3',0),('dbfe4673baeefc27fb505c867d56c5d4','./lib/htmlpurifier/HTMLPurifier/Injector/PurifierLinkify.php','6.3',0),('f6216052673d05748b26bfcbd51689f7','./lib/htmlpurifier/HTMLPurifier/Injector/RemoveEmpty.php','6.3',0),('29da73b24cb7b03d0bd80d105e56401a','./lib/htmlpurifier/HTMLPurifier/Injector/RemoveSpansWithoutAttributes.php','6.3',0),('f34138e894be0e555fe120540db7cb5c','./lib/htmlpurifier/HTMLPurifier/Injector/SafeObject.php','6.3',0),('34c9de227562f8967141cbf9f565c289','./lib/htmlpurifier/HTMLPurifier/Language.php','6.3',0),('f645558786c86be0b603b7cfc82f7e12','./lib/htmlpurifier/HTMLPurifier/Language/classes/en-x-test.php','6.3',0),('c1ea035c3a68aee24f6d4c264ee79d6b','./lib/htmlpurifier/HTMLPurifier/Language/messages/en-x-test.php','6.3',0),('146f1c2d41e1fdf85f334a05a0dd41ca','./lib/htmlpurifier/HTMLPurifier/Language/messages/en-x-testmini.php','6.3',0),('b9df8f809000af10f96b93ead76e0b64','./lib/htmlpurifier/HTMLPurifier/Language/messages/en.php','6.3',0),('58a26316f701ac79ca439ce4d874b9d3','./lib/htmlpurifier/HTMLPurifier/LanguageFactory.php','6.3',0),('39382c387dc2a7dac903c2b63849a9a6','./lib/htmlpurifier/HTMLPurifier/Length.php','6.3',0),('bffc543fc088a7d16b6a7642715d0399','./lib/htmlpurifier/HTMLPurifier/Lexer.php','6.3',0),('461417b2a89ff805874fb3200edecc3a','./lib/htmlpurifier/HTMLPurifier/Lexer/DOMLex.php','6.3',0),('a2936a1f2b528d9f055312d05f96712b','./lib/htmlpurifier/HTMLPurifier/Lexer/DirectLex.php','6.3',0),('952281bcdb7bca94a6a69bb0fcb6a475','./lib/htmlpurifier/HTMLPurifier/Lexer/PEARSax3.php','6.3',0),('fe014dc9d00bc84352578e9183917d24','./lib/htmlpurifier/HTMLPurifier/Lexer/PH5P.php','6.3',0),('4d14a6fa6959c5c6993391b9946b57fe','./lib/htmlpurifier/HTMLPurifier/PercentEncoder.php','6.3',0),('530db343c69ec3d4ba27e09e4b837903','./lib/htmlpurifier/HTMLPurifier/Printer.php','6.3',0),('d1d09c86a9c81b526bbd44c847344b6d','./lib/htmlpurifier/HTMLPurifier/Printer/CSSDefinition.php','6.3',0),('512c6d0717c3fcb0bb0997594cdf7f3f','./lib/htmlpurifier/HTMLPurifier/Printer/ConfigForm.php','6.3',0),('a46e55a618e944c96bbd09e5cfcf8cc1','./lib/htmlpurifier/HTMLPurifier/Printer/HTMLDefinition.php','6.3',0),('319d75a5f8e6bbc8c644056a68a4aaec','./lib/htmlpurifier/HTMLPurifier/PropertyList.php','6.3',0),('d17e7d5f8bc24cfc07f97aa7b014c4cd','./lib/htmlpurifier/HTMLPurifier/PropertyListIterator.php','6.3',0),('05823f704d950d3a9debbd3784e4aaea','./lib/htmlpurifier/HTMLPurifier/Strategy.php','6.3',0),('55d2b2fd0577ebdcbbbf1312f4e6eb6e','./lib/htmlpurifier/HTMLPurifier/Strategy/Composite.php','6.3',0),('0324f1ab3397cb1544a51257994f576a','./lib/htmlpurifier/HTMLPurifier/Strategy/Core.php','6.3',0),('48272af4271d1d6cc193052d9a175222','./lib/htmlpurifier/HTMLPurifier/Strategy/FixNesting.php','6.3',0),('94cb598c1605a4c8524278cb01fb15ef','./lib/htmlpurifier/HTMLPurifier/Strategy/MakeWellFormed.php','6.3',0),('6c6dbc3f24bccf2fdbfdbe9fe0912653','./lib/htmlpurifier/HTMLPurifier/Strategy/RemoveForeignElements.php','6.3',0),('3e085d73ce91a3d38f3017b112d07a0d','./lib/htmlpurifier/HTMLPurifier/Strategy/ValidateAttributes.php','6.3',0),('934cbbd131e387f9e2cf0921e0c88936','./lib/htmlpurifier/HTMLPurifier/StringHash.php','6.3',0),('d2040cbc74c4ce31449d127719bcc6cb','./lib/htmlpurifier/HTMLPurifier/StringHashParser.php','6.3',0),('3516a182bdf938206958c01134604b23','./lib/htmlpurifier/HTMLPurifier/TagTransform.php','6.3',0),('a8e11a0600b535514f7d790fcb0e008e','./lib/htmlpurifier/HTMLPurifier/TagTransform/Font.php','6.3',0),('5e45fd1e8d10be6b9f4da28c765532ee','./lib/htmlpurifier/HTMLPurifier/TagTransform/Simple.php','6.3',0),('cebdc28d8a702d0d2dfceb8c27196812','./lib/htmlpurifier/HTMLPurifier/Token.php','6.3',0),('0a93e4fcea3cf8114eec37914806e54f','./lib/htmlpurifier/HTMLPurifier/Token/Comment.php','6.3',0),('b38096253b7361aa606beabbd361e744','./lib/htmlpurifier/HTMLPurifier/Token/Empty.php','6.3',0),('6dc6cdb4e980b6ffb9bb18ae73236ca9','./lib/htmlpurifier/HTMLPurifier/Token/End.php','6.3',0),('abb859525c52a506e5f58c309431f3ca','./lib/htmlpurifier/HTMLPurifier/Token/Start.php','6.3',0),('21a3ed284d9cded0eba7e6910192f92b','./lib/htmlpurifier/HTMLPurifier/Token/Tag.php','6.3',0),('a1ee2cf2a31f87fe63b5702ff82ed9ba','./lib/htmlpurifier/HTMLPurifier/Token/Text.php','6.3',0),('ed32af45fe9dba652840c42075a7cdf3','./lib/htmlpurifier/HTMLPurifier/TokenFactory.php','6.3',0),('b150e8e19a71f29c19d7fdff69b4fd3d','./lib/htmlpurifier/HTMLPurifier/URI.php','6.3',0),('549903c3c3bfa86d91d3c2e2c8e065db','./lib/htmlpurifier/HTMLPurifier/URIDefinition.php','6.3',0),('62112e5c17a05698309321ea85935061','./lib/htmlpurifier/HTMLPurifier/URIFilter.php','6.3',0),('9df1553f001cd2e5e574be075396a575','./lib/htmlpurifier/HTMLPurifier/URIFilter/DisableExternal.php','6.3',0),('f75e2069424d0b4f60988b1e8344cde8','./lib/htmlpurifier/HTMLPurifier/URIFilter/DisableExternalResources.php','6.3',0),('d00b0e8fb4e37dfee67edba835f7668b','./lib/htmlpurifier/HTMLPurifier/URIFilter/DisableResources.php','6.3',0),('a520831064417a45e03fd669b0f8256c','./lib/htmlpurifier/HTMLPurifier/URIFilter/HostBlacklist.php','6.3',0),('f60d09064deb7203990b68895c6c8d66','./lib/htmlpurifier/HTMLPurifier/URIFilter/MakeAbsolute.php','6.3',0),('af92dd990abc627653f029dca94ed2d2','./lib/htmlpurifier/HTMLPurifier/URIFilter/Munge.php','6.3',0),('d52d2040f01112af0e00f8b9bac38267','./lib/htmlpurifier/HTMLPurifier/URIParser.php','6.3',0),('4122f8aeaf11cc424c9a720c07ba0724','./lib/htmlpurifier/HTMLPurifier/URIScheme.php','6.3',0),('4fed8f905a32b2089e1795b4189e86b1','./lib/htmlpurifier/HTMLPurifier/URIScheme/data.php','6.3',0),('45f3452087fdb7f090f2ea6f700bfb61','./lib/htmlpurifier/HTMLPurifier/URIScheme/file.php','6.3',0),('18245d29655347bfb39c3342476a2d96','./lib/htmlpurifier/HTMLPurifier/URIScheme/ftp.php','6.3',0),('9e58f88917c4cbc385ba52c20c78e832','./lib/htmlpurifier/HTMLPurifier/URIScheme/http.php','6.3',0),('add878b1199b2907f31135e89baebc12','./lib/htmlpurifier/HTMLPurifier/URIScheme/https.php','6.3',0),('b847abc08adc931880036bcddde2362a','./lib/htmlpurifier/HTMLPurifier/URIScheme/mailto.php','6.3',0),('2187e2b929cf26764e2a4acb24beaf46','./lib/htmlpurifier/HTMLPurifier/URIScheme/news.php','6.3',0),('dc9834550ddfe8edfc4a7c55bf32c05b','./lib/htmlpurifier/HTMLPurifier/URIScheme/nntp.php','6.3',0),('dbcd0c8ef8f54df0bf8945d5a61b2a9c','./lib/htmlpurifier/HTMLPurifier/URISchemeRegistry.php','6.3',0),('9dcddc344c2d6d44698479dead8beead','./lib/htmlpurifier/HTMLPurifier/UnitConverter.php','6.3',0),('629508f0959354d4ebd99c527e704036','./lib/htmlpurifier/HTMLPurifier/VarParser.php','6.3',0),('9ba5084965a3167605535ee579f8cc96','./lib/htmlpurifier/HTMLPurifier/VarParser/Flexible.php','6.3',0),('faa91653d527c5229b49253658ca80dd','./lib/htmlpurifier/HTMLPurifier/VarParser/Native.php','6.3',0),('8b1819c0ed397d313e5c76b062e6264d','./lib/htmlpurifier/HTMLPurifier/VarParserException.php','6.3',0),('c2498efdcdd50cb46a6a53d8abeba338','./lib/htmlpurifier_tiki/HTMLPurifier.tiki.php','6.3',0),('4a2ec2d295f30771b34bf894c8ca94a5','./lib/ical/File.php','6.3',0),('c92fb6fc121018c1ea4c2ae361592a12','./lib/ical/iCal.php','6.3',0),('59d547833f170a95bc7d8a571a4dc9c0','./lib/ical/iCal/Alarm.php','6.3',0),('523545ac0a87829fc490d02fd42bd3ee','./lib/ical/iCal/Attendee.php','6.3',0),('edcdfe3019ce1a84b61192b58e07b4f7','./lib/ical/iCal/BaseComponent.php','6.3',0),('8799f9590504176afc40518b9d05e521','./lib/ical/iCal/Component.php','6.3',0),('917ba74b83cb902993b4b178c1b86cec','./lib/ical/iCal/ContentLine.php','6.3',0),('f7ef1a1badab10d08050418888747afe','./lib/ical/iCal/Event.php','6.3',0),('430b322227b59156ec47f04c313fd3a9','./lib/ical/iCal/ExceptionRule.php','6.3',0),('f3caedd97ae3252a28c56a4b6259abca','./lib/ical/iCal/FreeBusy.php','6.3',0),('3dcf6827f0ffa5184190a8958425250f','./lib/ical/iCal/Parameter.php','6.3',0),('1cdef9ed1c3732b2d3ad07c6e9a08c7e','./lib/ical/iCal/Parser/iCalendar.php','6.3',0),('1f7bd6dbecd2de068460185c27c2e3ea','./lib/ical/iCal/Property.php','6.3',0),('f0824cd2730d3c02094a8b49d7c518d7','./lib/ical/iCal/Recurrence.php','6.3',0),('91aa1a2592999cbc1a1a438a7d0fd416','./lib/ical/iCal/TimeZone.php','6.3',0),('242b1039ddd1e7c449e1399d27926508','./lib/ical/iCal/ToDo.php','6.3',0),('f024723f3cef8eab6e405581639d2b1b','./lib/ical/iCal/ValueDataType.php','6.3',0),('4da7ed041aae67a7f065a1237c663c96','./lib/ical/iCal/iCalendar.php','6.3',0),('2f5044f2dbd33f6163535e0d9cf81fd5','./lib/iepngfix/index.php','6.3',0),('2ce5cff7d16430213469ccc7a646fad3','./lib/imagegals/imagegallib.php','6.3',0),('2f5044f2dbd33f6163535e0d9cf81fd5','./lib/imagegals/index.php','6.3',0),('35c956ff0349e577f6da02ef92f6a8a3','./lib/images/abstract.php','6.3',0),('fdac895206f371cfd49fba3b1fdcf2f5','./lib/images/gd.php','6.3',0),('859db2064409f3a595f0d870b9be29eb','./lib/images/images.php','6.3',0),('a41572aaf9b2feedd6ec9600a5fc7972','./lib/images/imagick_new.php','6.3',0),('f632f1ce44a92456d92bf6f1ced0908c','./lib/images/imagick_old.php','6.3',0),('60e201f0085a583d8653c4d0ec6aa9c7','./lib/importer/index.php','6.3',0),('46ab8ea7ab151a6a2b8889d771850f1b','./lib/importer/tikiimporter.php','6.3',0),('be2d7aba5bd006a7db0710fde5283456','./lib/importer/tikiimporter_wiki.php','6.3',0),('435dc1a925b1e972a14fe6d3c64dee60','./lib/importer/tikiimporter_wiki_mediawiki.php','6.3',0),('68c58b8d31c664ada50848c62fe4c5cc','./lib/importerlib.php','6.3',0),('43244840acbae7db64ac794c8548e2eb','./lib/index.php','6.3',0),('2f5044f2dbd33f6163535e0d9cf81fd5','./lib/init/index.php','6.3',0),('fb1d366ed1de4181b93f50307be53368','./lib/init/initlib.php','6.3',0),('fafa38b95a517b4ae6f96d54eeddf84b','./lib/init/setup_inc.php','6.3',0),('e5cd3057442f9baad15531aa30c0abdb','./lib/init/smarty.php','6.3',0),('dcec806c104d16998a702ebb03c7b3ad','./lib/init/tra.php','6.3',0),('2f5044f2dbd33f6163535e0d9cf81fd5','./lib/integrator/index.php','6.3',0),('7a32ead7b3d961c4a47174c8bb48341d','./lib/integrator/integrator.php','6.3',0),('86f40c7ed9048c43e7a27f408340699a','./lib/jquery/index.php','6.3',0),('0a2925cd5b10851e3fa00df4eabf342c','./lib/jquery/jquery-validate/demo/captcha/image_req.php','6.3',0),('d2e7da76fa449b46eeabeb39e6f9d26b','./lib/jquery/jquery-validate/demo/captcha/images/image.php','6.3',0),('1d95a555255e2913d6b54c62b7998856','./lib/jquery/jquery-validate/demo/captcha/index.php','6.3',0),('0000ba60ecf39509092327d1966a4668','./lib/jquery/jquery-validate/demo/captcha/newsession.php','6.3',0),('afef8cf46165b79b9135e055afd84675','./lib/jquery/jquery-validate/demo/captcha/process.php','6.3',0),('64f4719ca5757ecf1604c2a165fa3814','./lib/jquery/jquery-validate/demo/captcha/rand.php','6.3',0),('c37704e6d34221253074ce7b1050235b','./lib/jquery/jquery-validate/demo/form.php','6.3',0),('55e7c5ea429c9b2f79e789482b9d9293','./lib/jquery/jquery-validate/demo/marketo/emails.php','6.3',0),('bc661d41bb89e2dac11f64d1563470fc','./lib/jquery/jquery-validate/demo/milk/emails.php','6.3',0),('e0289bb5aed9b478f4ecae868cd7d2c4','./lib/jquery/jquery-validate/demo/milk/users.php','6.3',0),('2f5044f2dbd33f6163535e0d9cf81fd5','./lib/jquery_tiki/index.php','6.3',0),('a9ac64b886281754bfc9d45f1910961f','./lib/jscalendar/calendar.php','6.3',0),('9d0844ef5c0656eb7f1e5cdbc2a66f71','./lib/jscalendar/index.php','6.3',0),('ac8cc76b231f4b698b503aa44e93feea','./lib/jscalendar/lang/index.php','6.3',0),('5d804c3a21bc12d8d7bc87f56589174d','./lib/language/Language.php','6.3',0),('3d2ad91989926451164000bdd0ad27a8','./lib/language/index.php','6.3',0),('2f5044f2dbd33f6163535e0d9cf81fd5','./lib/live_support/index.php','6.3',0),('7f1f05f442280b1fe8e7aef4a6ee2406','./lib/live_support/lsadminlib.php','6.3',0),('7dc70fd66a0c69bb7bb16b7638c68b26','./lib/live_support/lslib.php','6.3',0),('b34df45e260d2af1a34f37aa75ea2ce6','./lib/logs/logslib.php','6.3',0),('3ffff652c01e84b9948a0bc45e5147f7','./lib/mail/maillib.php','6.3',0),('b8a6b8ff4b74725503bf73e4c4a732c1','./lib/mail/mimelib.php','6.3',0),('2f5044f2dbd33f6163535e0d9cf81fd5','./lib/mailin/index.php','6.3',0),('790ebc4cdded8229cebc5337d2544ca6','./lib/mailin/mailinlib.php','6.3',0),('2f5044f2dbd33f6163535e0d9cf81fd5','./lib/map/index.php','6.3',0),('2babbf9e948fb02538e420b3ba5a73b0','./lib/map/map_query.php','6.3',0),('dbfff4b6937001279c77b5cafd1c3d13','./lib/map/maplib.php','6.3',0),('3ebcdd4b0bcc56610705f49a33500480','./lib/map/usermap.php','6.3',0),('2f5044f2dbd33f6163535e0d9cf81fd5','./lib/menubuilder/index.php','6.3',0),('e7e64923be40756dffde7c57b2bbe21d','./lib/menubuilder/menulib.php','6.3',0),('2f5044f2dbd33f6163535e0d9cf81fd5','./lib/messu/index.php','6.3',0),('07747372d158b46e00d7b3bf67b4e320','./lib/messu/messulib.php','6.3',0),('12889627e601ec262ecb05b5fd92fb3a','./lib/metrics/input-validation.php','6.3',0),('b9491b5db9301e59aab9c9fc87733e51','./lib/metrics/metricslib.php','6.3',0),('2f5044f2dbd33f6163535e0d9cf81fd5','./lib/mime/index.php','6.3',0),('fc8c2accc51e5410ab1ffcb66e720554','./lib/mime/mimeextensions.php','6.3',0),('af09c39382433c056e67353ff41614a5','./lib/mime/mimelib.php','6.3',0),('f9dcd5639bd39c078b066de68b0c4a2d','./lib/mime/mimetypes.php','6.3',0),('2f5044f2dbd33f6163535e0d9cf81fd5','./lib/minical/index.php','6.3',0),('75cc747568371c78fb9a5182a0e6f768','./lib/minical/minicallib.php','6.3',0),('2d4e82e74cda50d628dbff45b6fe2077','./lib/minify/JSMin.php','6.3',0),('2f5044f2dbd33f6163535e0d9cf81fd5','./lib/mods/index.php','6.3',0),('3209001c5e74c76c877246c81e73d76b','./lib/mods/modslib.php','6.3',0),('2f5044f2dbd33f6163535e0d9cf81fd5','./lib/modules/index.php','6.3',0),('d3e4c0be5d6814a754b9f8309bed58e0','./lib/modules/modlib.php','6.3',0),('e4fc81335f73d794069279c807fa83de','./lib/multilingual/multilinguallib.php','6.3',0),('2f5044f2dbd33f6163535e0d9cf81fd5','./lib/newsletters/index.php','6.3',0),('1a99df78399629a797992c31e479933a','./lib/newsletters/nllib.php','6.3',0),('ee5b765a91f9c2c8054647a246cad199','./lib/notepad/index.php','6.3',0),('72135d264134789f45b9cc2e11c8b647','./lib/notepad/notepadlib.php','6.3',0),('ee5b765a91f9c2c8054647a246cad199','./lib/notifications/index.php','6.3',0),('14a2f9670a55641acc05db7de5f18d22','./lib/notifications/notificationemaillib.php','6.3',0),('c7e601059a1ae2edc37242379c30e8ae','./lib/notifications/notificationlib.php','6.3',0),('b27aa06cb10ad19f76cf811c328928fc','./lib/objectlib.php','6.3',0),('dfde3f69b1da0138ba9f5d61cabf5e0b','./lib/ointegratelib.php','6.3',0),('be9b1f2f34bec896ac88f4b8b8a88dd5','./lib/payment/behavior/execute_datachannel.php','6.3',0),('f51488c19f8611c8f9cdc4baca3ad686','./lib/payment/behavior/extend_membership.php','6.3',0),('ee5b765a91f9c2c8054647a246cad199','./lib/payment/behavior/index.php','6.3',0),('06280442f62cc973fcb0bf83d74bcc87','./lib/payment/behavior/perform_trade.php','6.3',0),('b960b30112db82b468adc94956450e3a','./lib/payment/behavior/sample.php','6.3',0),('3bdba76afe2900b8952c55e01a1bf98f','./lib/payment/cartlib.php','6.3',0),('75d3f2ce0952fefe07d1b48395a212e9','./lib/payment/cclitelib.php','6.3',0),('435cab6ce9319fc2d8a2d10f0c6c3b6a','./lib/payment/creditspaylib.php','6.3',0),('6ee4ed5336044b29e4497ef1d1c8611b','./lib/payment/discountlib.php','6.3',0),('ee5b765a91f9c2c8054647a246cad199','./lib/payment/index.php','6.3',0),('fad9fa942986040cf4c1d5cba4bf8ee9','./lib/payment/paymentlib.php','6.3',0),('632a81f745ab64245a90c053c0a09cb8','./lib/payment/paypallib.php','6.3',0),('1daa6eacb23c2ec1d4d648aa8b7230d0','./lib/pclzip/pclzip.lib.php','6.3',0),('bfa58c2fd15133e0da278a14cd24fba3','./lib/pdflib.php','6.3',0),('499b6f496d51eaaf108dd753583c2181','./lib/pear/Auth.php','6.3',0),('3985c28bc1393d54d659e0131c2d9c86','./lib/pear/Auth/Anonymous.php','6.3',0),('30d3ab2654455baf49d7afd63504c4c7','./lib/pear/Auth/Auth.php','6.3',0),('8ade2c7140187609cefbc28ad80f5487','./lib/pear/Auth/Container.php','6.3',0),('c711bf32449e8f041a7068588caa1cd3','./lib/pear/Auth/Container/Array.php','6.3',0),('79297cf2eba1f87544d5d5ba6549534c','./lib/pear/Auth/Container/DB.php','6.3',0),('e18bdb1b11cbcb2f827fef2948329c9b','./lib/pear/Auth/Container/DBLite.php','6.3',0),('e6e24dd0ac2cb4cb47e5e1a741679523','./lib/pear/Auth/Container/File.php','6.3',0),('d3d10c5fae0c53f7bd7cbe1732130caf','./lib/pear/Auth/Container/IMAP.php','6.3',0),('894af4f7050ca3cb9bf6f93bece2bd96','./lib/pear/Auth/Container/KADM5.php','6.3',0),('c857d9d00787830cf570cec348c4af5d','./lib/pear/Auth/Container/LDAP.php','6.3',0),('f1c1d23f619be87d8cb2c4193b74263c','./lib/pear/Auth/Container/MDB.php','6.3',0),('e41e8391a572e5a43dadc48750263f96','./lib/pear/Auth/Container/MDB2.php','6.3',0),('9308fde5956866dc28c9f57836cbe31d','./lib/pear/Auth/Container/Multiple.php','6.3',0),('d34e1e007fdf33d48daa2a233cd24bcb','./lib/pear/Auth/Container/PEAR.php','6.3',0),('aff6bc374dc4a011d49b9f5488bedf33','./lib/pear/Auth/Container/POP3.php','6.3',0),('50816605e84106d6f317c1e527ff475d','./lib/pear/Auth/Container/RADIUS.php','6.3',0),('101ac05314daf7587a120f52e80544bb','./lib/pear/Auth/Container/SAP.php','6.3',0),('f4f90ff8a5fcedafb8ecab4f66a6b502','./lib/pear/Auth/Container/SMBPasswd.php','6.3',0),('afae816a40ff82c22ceaf502972d2198','./lib/pear/Auth/Container/SOAP.php','6.3',0),('884e2e191a7e669596fd4502e28f2a5b','./lib/pear/Auth/Container/SOAP5.php','6.3',0),('33910da0f7c935a82f62c99c5f12df9b','./lib/pear/Auth/Container/index.php','6.3',0),('3cb99259da67c049a2a2f23e0dbef399','./lib/pear/Auth/Container/vpopmail.php','6.3',0),('7bc924a4c87b768e011b924371cbb9a5','./lib/pear/Auth/Controller.php','6.3',0),('adfa3a887bf82f31dc53e627bfd5fd06','./lib/pear/Auth/Frontend/Html.php','6.3',0),('05d93b592e620e9ce63082a1d71f6276','./lib/pear/Auth/OpenID.php','6.3',0),('e62ab05454a8c588b938c5d3e6a5c871','./lib/pear/Auth/OpenID/AX.php','6.3',0),('884c741cf1c6608a73b6abaf98d5c8b3','./lib/pear/Auth/OpenID/Association.php','6.3',0),('bea9dc354f8ae949687257e11c86092d','./lib/pear/Auth/OpenID/BigMath.php','6.3',0),('473faf1e4204f3c9d2a296e79dca976b','./lib/pear/Auth/OpenID/Consumer.php','6.3',0),('548c42f31707b078a7bd13b06f561fcd','./lib/pear/Auth/OpenID/CryptUtil.php','6.3',0),('3c6a5aac6895cfd513e8910ff1b00e29','./lib/pear/Auth/OpenID/DatabaseConnection.php','6.3',0),('0f2f44acef865ba11718e66f8d8935ba','./lib/pear/Auth/OpenID/DiffieHellman.php','6.3',0),('cb5e129f160df12ce476b635ba877555','./lib/pear/Auth/OpenID/Discover.php','6.3',0),('01ade53e6fd1c8ea9823691ce170b03b','./lib/pear/Auth/OpenID/DumbStore.php','6.3',0),('02abdee76a075990fd66269c4f8fd916','./lib/pear/Auth/OpenID/Extension.php','6.3',0),('50c5bf0e299d21059c275d7525718384','./lib/pear/Auth/OpenID/FileStore.php','6.3',0),('d2b5855f40918887894475ea2d8f157e','./lib/pear/Auth/OpenID/HMAC.php','6.3',0),('9fcc9f8550ac9a0a46b41e9aa9c3a84d','./lib/pear/Auth/OpenID/Interface.php','6.3',0),('fc2a5ec5baaaa9cfcfbc821f1fd13277','./lib/pear/Auth/OpenID/KVForm.php','6.3',0),('282c860f53a189d05b9148893e09fa9e','./lib/pear/Auth/OpenID/MemcachedStore.php','6.3',0),('84db31561ac227b41b627075e433e6a6','./lib/pear/Auth/OpenID/Message.php','6.3',0),('b2b1e84c83882b510ffb93ed32e20b47','./lib/pear/Auth/OpenID/MySQLStore.php','6.3',0),('54f0dc85dd34719bd6d7c46543b6e406','./lib/pear/Auth/OpenID/Nonce.php','6.3',0),('ecf127c350eb64f016d8aa68171e2e53','./lib/pear/Auth/OpenID/PAPE.php','6.3',0),('7c62d83a8a241de4fcb26e45fff6ce5f','./lib/pear/Auth/OpenID/Parse.php','6.3',0),('702b40955fc5bd3b6ca0a8270216131b','./lib/pear/Auth/OpenID/PostgreSQLStore.php','6.3',0),('e427fe88d409a85752182e6bb15312e8','./lib/pear/Auth/OpenID/SQLStore.php','6.3',0),('fb1f8f0a59559bea07ddf5affde37e84','./lib/pear/Auth/OpenID/SQLiteStore.php','6.3',0),('7d7aaec465aee1c7a287da6cdbf59ffe','./lib/pear/Auth/OpenID/SReg.php','6.3',0),('eb8db9e3297f2c54a1f95aa5c22b27b3','./lib/pear/Auth/OpenID/Server.php','6.3',0),('2e95e7c0ae872b2c9cf1243baf664804','./lib/pear/Auth/OpenID/ServerRequest.php','6.3',0),('1d7136a7e2f97daa1661687aa9cd6bd2','./lib/pear/Auth/OpenID/TrustRoot.php','6.3',0),('d8583b6e66842979c9553342b814398e','./lib/pear/Auth/OpenID/URINorm.php','6.3',0),('2520c568c4b8b8039bd9b1b62e2931ab','./lib/pear/Auth/Yadis/HTTPFetcher.php','6.3',0),('9574a219afa71fe329d0199451b292ab','./lib/pear/Auth/Yadis/Manager.php','6.3',0),('7396878abc1a59a941d09800ac89b4ce','./lib/pear/Auth/Yadis/Misc.php','6.3',0),('002f85996f7e83f4a8b7661521f9366c','./lib/pear/Auth/Yadis/ParanoidHTTPFetcher.php','6.3',0),('b0bb707efb3802fa5604e584451ca115','./lib/pear/Auth/Yadis/ParseHTML.php','6.3',0),('46bf22fcd87ed857597bff777c10fa32','./lib/pear/Auth/Yadis/PlainHTTPFetcher.php','6.3',0),('e115b77a652261f6e6bbe7032d4bb2e1','./lib/pear/Auth/Yadis/XML.php','6.3',0),('0cb02172211216b0d83a2248f5207dd3','./lib/pear/Auth/Yadis/XRDS.php','6.3',0),('f7ede2ab410b35ffef76a23bac0d74e8','./lib/pear/Auth/Yadis/XRI.php','6.3',0),('f741827d1c6f95232693d2c979365118','./lib/pear/Auth/Yadis/XRIRes.php','6.3',0),('c74a057f6a5318dc5f190e9bc128badb','./lib/pear/Auth/Yadis/Yadis.php','6.3',0),('4d4bc7c2de4681cd75360631211dc40d','./lib/pear/Auth/index.php','6.3',0),('6d7a3bbf0eb55a80246ff4bc14595fe2','./lib/pear/DB.php','6.3',0),('57c701ab89afc55ac9274cd538e000e6','./lib/pear/DB/common.php','6.3',0),('a7f83d56dee82ae547c4b387e8034489','./lib/pear/DB/dbase.php','6.3',0),('161b10ffc11613ec9f7335adf22f5dd5','./lib/pear/DB/fbsql.php','6.3',0),('b7245e08a2f9c5e5b7740344fbc49c17','./lib/pear/DB/ibase.php','6.3',0),('ad9b54a4a07cddb535e2b64f7071b2fe','./lib/pear/DB/ifx.php','6.3',0),('599ec7b47d5776ad86d673d68543b77a','./lib/pear/DB/index.php','6.3',0),('98f00fc645792cd17aa8460b9c8a3c5a','./lib/pear/DB/msql.php','6.3',0),('5c95bfc6f7e77328618be4b593968e77','./lib/pear/DB/mssql.php','6.3',0),('d9e005512d97a284606728a9ebf83023','./lib/pear/DB/mysql.php','6.3',0),('1c1f610eaf9522fefb35386526791694','./lib/pear/DB/mysqli.php','6.3',0),('f7a7ed84a1edd49689478b67e0f810ed','./lib/pear/DB/oci8.php','6.3',0),('6e8cafdb5e3f9921bf30c55269975e3f','./lib/pear/DB/odbc.php','6.3',0),('72936ad98acaaaa832ab365ea115ec65','./lib/pear/DB/pgsql.php','6.3',0),('88feb3cd91cfa1117ad93d02269e6db9','./lib/pear/DB/sqlite.php','6.3',0),('da9d3699416092800f793dd4b5c890c7','./lib/pear/DB/storage.php','6.3',0),('c16ec31559bc5b31f103ee05de419f21','./lib/pear/DB/sybase.php','6.3',0),('1cc354629c288264f173ccda409d2ac9','./lib/pear/Date.php','6.3',0),('964b8b39f4c3e1503569c4d9a1452eed','./lib/pear/Date/Calc.php','6.3',0),('50b8aa1a54b07d5a4b605a17c6b74f81','./lib/pear/Date/Human.php','6.3',0),('0220d004cca04814a956c2fcc8a782ce','./lib/pear/Date/Span.php','6.3',0),('96eb161963b4d46342b080b314f13184','./lib/pear/Date/TimeZone.php','6.3',0),('4389b90e1ba556489f6186622f956061','./lib/pear/Date/index.php','6.3',0),('ae3e4163f4904ea74ecbe17941d74665','./lib/pear/HTTP/Request.php','6.3',0),('0b2bf6bf9907a505efc2acd9a34eebf6','./lib/pear/HTTP/Request/Listener.php','6.3',0),('de450b9058b371a96c9f922038f5a792','./lib/pear/HTTP/WebDAV/Client.php','6.3',0),('74f0cdfc398cb31e265aae2a66db3145','./lib/pear/HTTP/WebDAV/Client/Stream.php','6.3',0),('0dd723a09b26b627e96fd7cd9d239f57','./lib/pear/HTTP/WebDAV/Tools/_parse_lock_response.php','6.3',0),('ee6aec5b54f662b35c23be417a9048c0','./lib/pear/HTTP/WebDAV/Tools/_parse_propfind_response.php','6.3',0),('5ed44b6098295fc780017de9cd7c4d50','./lib/pear/HTTP/index.php','6.3',0),('61cc6abf15352da27fdc3f9bfee866c3','./lib/pear/Minify/CSS.php','6.3',0),('d04c1bf2884fc47dc7f67b3ee388dc9e','./lib/pear/Minify/CSS/Compressor.php','6.3',0),('1690637f25c8a69f56ba6f999567384c','./lib/pear/Minify/CSS/UriRewriter.php','6.3',0),('86bab05265083b57935503bdd735ce74','./lib/pear/Minify/CommentPreserver.php','6.3',0),('521bd5b60f22ba235274041b1dc87faa','./lib/pear/Net/DIME.php','6.3',0),('2e9880aef8741aef23f8acd88a1acb67','./lib/pear/Net/DNS.php','6.3',0),('7238e08ac04cd35c47a217b45d5ce8fc','./lib/pear/Net/DNS/Header.php','6.3',0),('3f3803ecb2a410ab7f88226162a5cbea','./lib/pear/Net/DNS/Packet.php','6.3',0),('827da26a4cf935f0f6187d174f5c5b51','./lib/pear/Net/DNS/Question.php','6.3',0),('06b3afb7418733bc2f221711fade0b33','./lib/pear/Net/DNS/RR.php','6.3',0),('819fc601210233bd4029a499dda7c5cb','./lib/pear/Net/DNS/RR/A.php','6.3',0),('863bf97a5f81c47e59fab41853bddd89','./lib/pear/Net/DNS/RR/AAAA.php','6.3',0),('d1c763d1a8b8b1bf380048aba9efb11c','./lib/pear/Net/DNS/RR/CNAME.php','6.3',0),('5a73b193fc6ae8f40f893fe2e5386f8d','./lib/pear/Net/DNS/RR/HINFO.php','6.3',0),('e8a44f5f773f8f3990dbb62ed21962f4','./lib/pear/Net/DNS/RR/MX.php','6.3',0),('06f17b6ffa43dbfe6811846341a5a1a2','./lib/pear/Net/DNS/RR/NAPTR.php','6.3',0),('800e54de5985038962c21ffa8f88c420','./lib/pear/Net/DNS/RR/NS.php','6.3',0),('e47fce5f277e3e977793388d1564f9b9','./lib/pear/Net/DNS/RR/PTR.php','6.3',0),('aee3fc814e718590d1cfe4f5295e4a29','./lib/pear/Net/DNS/RR/SOA.php','6.3',0),('c9aedf777c33388ba25b4dbff5148d17','./lib/pear/Net/DNS/RR/SRV.php','6.3',0),('8ff08c29b6137da0c14544770917b708','./lib/pear/Net/DNS/RR/TSIG.php','6.3',0),('a68c4cbee7d724de4a9cd80784b16829','./lib/pear/Net/DNS/RR/TXT.php','6.3',0),('bddc375c1a7dc4050153fc032ac53de0','./lib/pear/Net/DNS/Resolver.php','6.3',0),('2f6fc5b6e4a4cd7bff8345c4c78e6c9b','./lib/pear/Net/LDAP2.php','6.3',0),('e490ca69dad964882663b6530c819661','./lib/pear/Net/LDAP2/Entry.php','6.3',0),('d2f1e326ccb87e5cceb0ef353a849d21','./lib/pear/Net/LDAP2/Filter.php','6.3',0),('e7d6bdb64b3228b1648739ce547a7261','./lib/pear/Net/LDAP2/LDIF.php','6.3',0),('8f2565242c1e271cc3302b1c024d8160','./lib/pear/Net/LDAP2/RootDSE.php','6.3',0),('5047524cd0bb1742c92f2f65457b2f9f','./lib/pear/Net/LDAP2/Schema.php','6.3',0),('39b4749e4082c91f7f8a00cad2052986','./lib/pear/Net/LDAP2/SchemaCache.interface.php','6.3',0),('029bb8ceb590caceeb1e2358269ffe1c','./lib/pear/Net/LDAP2/Search.php','6.3',0),('45d913bc56b264a72c1fb05bafba8ade','./lib/pear/Net/LDAP2/SimpleFileSchemaCache.php','6.3',0),('8d3bfff262f22ac4e1638de8b0ce8d16','./lib/pear/Net/LDAP2/Util.php','6.3',0),('0b9af8aca1d784cb4d273f7adcef5103','./lib/pear/Net/Ping.php','6.3',0),('932f5fa83613be28fdb8f2b9dc145ca3','./lib/pear/Net/Socket.php','6.3',0),('8a660a166aaa895befada60e66a47dd3','./lib/pear/Net/URL.php','6.3',0),('462e156e69059a600e133d510a9cdb30','./lib/pear/Net/index.php','6.3',0),('7142b3a399864f7dff990ada5620692e','./lib/pear/OS/Guess.php','6.3',0),('ee1c4c31c269c5872a18dab3a9061f28','./lib/pear/PEAR.php','6.3',0),('7fdd9dd2d0d4072db9267582df40ee9c','./lib/pear/PEAR/Builder.php','6.3',0),('e8c96da49c2251aa05754c3cf97b4d4d','./lib/pear/PEAR/ChannelFile.php','6.3',0),('a23a0e1d528a56a382d6aa4bf131fcb5','./lib/pear/PEAR/ChannelFile/Parser.php','6.3',0),('821fc55dcd0ca199d3a9da2655716177','./lib/pear/PEAR/Command.php','6.3',0),('8154f1baca43e41781cd3bbe094230a8','./lib/pear/PEAR/Command/Auth.php','6.3',0),('2af3d1912b4b6aef6bf17db5e01f257e','./lib/pear/PEAR/Command/Build.php','6.3',0),('1e7a7f9174b9788e168c6ca450609419','./lib/pear/PEAR/Command/Channels.php','6.3',0),('89f1dc80f28544a23c4eb05ce67ccf46','./lib/pear/PEAR/Command/Common.php','6.3',0),('5ee8c85828686b560594569ee1263238','./lib/pear/PEAR/Command/Config.php','6.3',0),('db756b987329301db8bef71d41bdb48e','./lib/pear/PEAR/Command/Install.php','6.3',0),('b1c6d624fa98d7f95948e1bca76c46b5','./lib/pear/PEAR/Command/Mirror.php','6.3',0),('20e1853f1f61436d38b5304e544abb44','./lib/pear/PEAR/Command/Package.php','6.3',0),('ace988de7f48ad07ef5954f7cb386dc1','./lib/pear/PEAR/Command/Pickle.php','6.3',0),('1eb7e236f43aa186a2979fcebf76902d','./lib/pear/PEAR/Command/Registry.php','6.3',0),('92c785a64da88610daaee2ddff951d10','./lib/pear/PEAR/Command/Remote.php','6.3',0),('8f94c1b9b79cdbacb38cc408f726526e','./lib/pear/PEAR/Command/Test.php','6.3',0),('f796f0cd05c7ab1e2ede3ad9673de69c','./lib/pear/PEAR/Common.php','6.3',0),('44f546c33394fe782243cb967a68b88f','./lib/pear/PEAR/Config.php','6.3',0),('e10614808889be3f2fdece6e3f9e73d4','./lib/pear/PEAR/Dependency.php','6.3',0),('9662d182660c16690afc7f26a42a142a','./lib/pear/PEAR/Dependency2.php','6.3',0),('02f1d96789cbecfe3e7e241eda2aa2b7','./lib/pear/PEAR/DependencyDB.php','6.3',0),('44bbe7bae0b00a305b989e2830d3bee7','./lib/pear/PEAR/Downloader.php','6.3',0),('06cb3419355e23ad6c654e8279cb1166','./lib/pear/PEAR/Downloader/Package.php','6.3',0),('af4a520ca55d91bd3891ed1295b27f86','./lib/pear/PEAR/ErrorStack.php','6.3',0),('4b66dc7bf749ab902b6efb71efda14cf','./lib/pear/PEAR/Exception.php','6.3',0),('1238cf62eefe73ce8bb955e2a56b513c','./lib/pear/PEAR/FixPHP5PEARWarnings.php','6.3',0),('8d1177902650a7e91d1ae61f231b9f2f','./lib/pear/PEAR/Frontend.php','6.3',0),('a72e6bcd759841310337ddc17e816132','./lib/pear/PEAR/Frontend/CLI.php','6.3',0),('c8695b29af6a0d75ebc197cc0d6bddad','./lib/pear/PEAR/Installer.php','6.3',0),('4bd494bb370a2418b8072ec732ca92ad','./lib/pear/PEAR/Installer/Role.php','6.3',0),('3fb2045c4328ba0f0791e6c46aabce8a','./lib/pear/PEAR/Installer/Role/Cfg.php','6.3',0),('b92412d192b39de87fd3cfb356215e26','./lib/pear/PEAR/Installer/Role/Common.php','6.3',0),('da4e5d80a37dd53618f8f25de266a6c0','./lib/pear/PEAR/Installer/Role/Data.php','6.3',0),('8ce6b8da0c801cbd30288db459e34f6d','./lib/pear/PEAR/Installer/Role/Doc.php','6.3',0),('eb4558eda00f0b77956491e5dd14bf6b','./lib/pear/PEAR/Installer/Role/Ext.php','6.3',0),('02c809b8a0b3aa221b7085cb609b4183','./lib/pear/PEAR/Installer/Role/Php.php','6.3',0),('f835735b01aa530010bcaab3b47b0fa3','./lib/pear/PEAR/Installer/Role/Script.php','6.3',0),('712a2d00271b4d522d09abd0a83da6b6','./lib/pear/PEAR/Installer/Role/Src.php','6.3',0),('6309ac78005d025586019ffc73c5aeee','./lib/pear/PEAR/Installer/Role/Test.php','6.3',0),('953179037c360a500af806463926b55a','./lib/pear/PEAR/Installer/Role/Www.php','6.3',0),('46a2cde16cd2d8d1f029c3ed3ff3071a','./lib/pear/PEAR/PackageFile.php','6.3',0),('ad49e95616e4d34dbcdca0fec3f09d6a','./lib/pear/PEAR/PackageFile/Generator/v1.php','6.3',0),('2706cd6b18e56994aa948f3ef545f883','./lib/pear/PEAR/PackageFile/Generator/v2.php','6.3',0),('b3b9c15673f360fd8084c4b5c801049d','./lib/pear/PEAR/PackageFile/Parser/v1.php','6.3',0),('f3d9e7e03eb8e9581b1c96025f8bd626','./lib/pear/PEAR/PackageFile/Parser/v2.php','6.3',0),('7a7cfa88daa047fa63355ad5892b5fc8','./lib/pear/PEAR/PackageFile/v1.php','6.3',0),('e2293366617a7b206dee7ed3c1ac4f76','./lib/pear/PEAR/PackageFile/v2.php','6.3',0),('50ceec8455585a285b671febd2884dc3','./lib/pear/PEAR/PackageFile/v2/Validator.php','6.3',0),('21d9d8a12f2a3d1cb80baeee4d8ff7a9','./lib/pear/PEAR/PackageFile/v2/rw.php','6.3',0),('9571d777d12418a53c76c3e70b8194ba','./lib/pear/PEAR/Packager.php','6.3',0),('009a23c4df085c17e56d0740f0f0fb27','./lib/pear/PEAR/REST.php','6.3',0),('567358fbdc324552abc8858fbb55b645','./lib/pear/PEAR/REST/10.php','6.3',0),('c76624762ee35b50391e8aa3e9c4b45e','./lib/pear/PEAR/REST/11.php','6.3',0),('71c615d8545733f39a3cd02b197d011b','./lib/pear/PEAR/REST/13.php','6.3',0),('7f3ca8a7b3ca7e499b20ee48244a309e','./lib/pear/PEAR/Registry.php','6.3',0),('9f2dbbfe5eed5033dd807e48fad7162d','./lib/pear/PEAR/Remote.php','6.3',0),('f53a213649c373b0353592f35188503c','./lib/pear/PEAR/RunTest.php','6.3',0),('a4adcafc692b67d889aacfc8e0e3849b','./lib/pear/PEAR/Task/Common.php','6.3',0),('c79bcbb936b967cd9615739781b285dd','./lib/pear/PEAR/Task/Postinstallscript.php','6.3',0),('7ba6ec8d585a22be3a504bb6776c09be','./lib/pear/PEAR/Task/Postinstallscript/rw.php','6.3',0),('60b86b2961f5ddd5dbbcea9d56f49154','./lib/pear/PEAR/Task/Replace.php','6.3',0),('5ab6db56d93fcf61e0ea6cac02d44337','./lib/pear/PEAR/Task/Replace/rw.php','6.3',0),('4bb56d233b5dd2e735cb6862213b55e4','./lib/pear/PEAR/Task/Unixeol.php','6.3',0),('8e8da9a75829f78bc2bb7752ae60a5ef','./lib/pear/PEAR/Task/Unixeol/rw.php','6.3',0),('173189090bc2cfee89e2e0247ff3eaa6','./lib/pear/PEAR/Task/Windowseol.php','6.3',0),('fe5ab3da07067d9def9cf99a3c3cd90c','./lib/pear/PEAR/Task/Windowseol/rw.php','6.3',0),('a9ccad4012c2aff3072ea3a500125f86','./lib/pear/PEAR/Validate.php','6.3',0),('ecb89be0247b7911d7437ee1a00e1a7c','./lib/pear/PEAR/Validator/PECL.php','6.3',0),('829568582dfa0feddd47644014a67ebf','./lib/pear/PEAR/XMLParser.php','6.3',0),('1e11406b251d05d191d0467b3388eb86','./lib/pear/Services/JSON.php','6.3',0),('63b47fcfd7b1996577cbb321b6851711','./lib/pear/System.php','6.3',0),('7787d81566cb7342ffcb126a750b990a','./lib/pear/Text/Wiki.php','6.3',0),('2399ccd2fed0de6387e770470d63ca29','./lib/pear/Text/Wiki/Default.php','6.3',0),('726d81dce9dc4dac168d1c758e138738','./lib/pear/Text/Wiki/Mediawiki.php','6.3',0),('c3dd1415981633e868494f13984259e5','./lib/pear/Text/Wiki/Parse.php','6.3',0),('fa4d0dd619696699ad029cae14332eef','./lib/pear/Text/Wiki/Parse/Default/Anchor.php','6.3',0),('b1cc529c6db9121300a64d874bb21fb4','./lib/pear/Text/Wiki/Parse/Default/Blockquote.php','6.3',0),('1dde8ffd06301b9c82137d160c08b29c','./lib/pear/Text/Wiki/Parse/Default/Bold.php','6.3',0),('67aa3d50ab34a755b6c0e726d0a60c3f','./lib/pear/Text/Wiki/Parse/Default/Break.php','6.3',0),('142ae6e1d86ddc41d25f67d5a28d74c1','./lib/pear/Text/Wiki/Parse/Default/Center.php','6.3',0),('19fa671a5461501b042652a2129e4c4e','./lib/pear/Text/Wiki/Parse/Default/Code.php','6.3',0),('7281cf18d8d681d93bd16c080c01af17','./lib/pear/Text/Wiki/Parse/Default/Colortext.php','6.3',0),('c6ae3583eaff43230c07e1151a4f3b9f','./lib/pear/Text/Wiki/Parse/Default/Deflist.php','6.3',0),('9f6468c4ba51e603cc9f1acf901f925c','./lib/pear/Text/Wiki/Parse/Default/Delimiter.php','6.3',0),('ec5ef03de5cc155559afb6f0722ba779','./lib/pear/Text/Wiki/Parse/Default/Embed.php','6.3',0),('5c2d85066e03b2c74d49dd8a419df30a','./lib/pear/Text/Wiki/Parse/Default/Emphasis.php','6.3',0),('bccff7ca36e2afc33cfdd23699d3aa6f','./lib/pear/Text/Wiki/Parse/Default/Freelink.php','6.3',0),('96ebbed3ed6d610544f42e5e2620d687','./lib/pear/Text/Wiki/Parse/Default/Function.php','6.3',0),('407bad7cd535a595e56bddde34f206ca','./lib/pear/Text/Wiki/Parse/Default/Heading.php','6.3',0),('124bac15d98249133c7e374078ce9e47','./lib/pear/Text/Wiki/Parse/Default/Horiz.php','6.3',0),('baec74d247a84b27c136a3f2f8ed2808','./lib/pear/Text/Wiki/Parse/Default/Html.php','6.3',0),('b73201e9a37bbcbd5cb190614573600c','./lib/pear/Text/Wiki/Parse/Default/Image.php','6.3',0),('0c69ea1cd9993e80a914fe327e89eafa','./lib/pear/Text/Wiki/Parse/Default/Include.php','6.3',0),('7e5bdd2c68fb20f78ca476439f6bfab7','./lib/pear/Text/Wiki/Parse/Default/Interwiki.php','6.3',0),('1025a334b448174b516a09ee43e4f1b8','./lib/pear/Text/Wiki/Parse/Default/Italic.php','6.3',0),('368ef9977d64a96f28ccd6b3a030dc35','./lib/pear/Text/Wiki/Parse/Default/List.php','6.3',0),('935a79ce5f404b7b83d95dcee9ed41ef','./lib/pear/Text/Wiki/Parse/Default/Newline.php','6.3',0),('4a02efe2160d11ec462c2fb4227ecd0d','./lib/pear/Text/Wiki/Parse/Default/Paragraph.php','6.3',0),('17cef3ba74b9b4918b657683129fe87a','./lib/pear/Text/Wiki/Parse/Default/Phplookup.php','6.3',0),('8846c3f3304ea992edc539154a2a2781','./lib/pear/Text/Wiki/Parse/Default/Prefilter.php','6.3',0),('42d8aa3a43ae7554ac36f4205b10d446','./lib/pear/Text/Wiki/Parse/Default/Raw.php','6.3',0),('cc2fad29b9ec288f0849e8278d099fef','./lib/pear/Text/Wiki/Parse/Default/Revise.php','6.3',0),('f2e1eb63f755995035c57a8accf1af54','./lib/pear/Text/Wiki/Parse/Default/Smiley.php','6.3',0),('3829886dacd927724cd069d92615728b','./lib/pear/Text/Wiki/Parse/Default/Strong.php','6.3',0),('bdd5c9a8485d122cd75be4720c61886c','./lib/pear/Text/Wiki/Parse/Default/Subscript.php','6.3',0),('aaf24e97b909f5b5b46bf633bea4178b','./lib/pear/Text/Wiki/Parse/Default/Superscript.php','6.3',0),('a44f170f00b9eaa319f6f9c5ca7ebf8c','./lib/pear/Text/Wiki/Parse/Default/Table.php','6.3',0),('6622bf5f950928c43d0f9644ffbb93db','./lib/pear/Text/Wiki/Parse/Default/Tighten.php','6.3',0),('f6ad066d9edd83bdc42ec6c62f5e8b0e','./lib/pear/Text/Wiki/Parse/Default/Toc.php','6.3',0),('c04e6a512abc844399583c2c24ba9bc2','./lib/pear/Text/Wiki/Parse/Default/Tt.php','6.3',0),('9c1b8d06abecc8c0b536826dda1da4f0','./lib/pear/Text/Wiki/Parse/Default/Underline.php','6.3',0),('183148d3dcd28cfecac8a0646cd5a2e3','./lib/pear/Text/Wiki/Parse/Default/Url.php','6.3',0),('e4a8f4384643931422c959e92fe9a117','./lib/pear/Text/Wiki/Parse/Default/Wikilink.php','6.3',0),('ff72a42439e31bf7270244659fa6d4ad','./lib/pear/Text/Wiki/Parse/Mediawiki/Break.php','6.3',0),('87b8c59283e2881fdb9460114ea092a3','./lib/pear/Text/Wiki/Parse/Mediawiki/Code.php','6.3',0),('b6a450142f6e4732ed10170f166ce76e','./lib/pear/Text/Wiki/Parse/Mediawiki/Comment.php','6.3',0),('90d2a899c45fe104a6b5405ccef90d90','./lib/pear/Text/Wiki/Parse/Mediawiki/Deflist.php','6.3',0),('6a9b7255c69f7dc08c7d687e78133bc8','./lib/pear/Text/Wiki/Parse/Mediawiki/Emphasis.php','6.3',0),('80652a58ce5c8d2b31cf598ae3fd3621','./lib/pear/Text/Wiki/Parse/Mediawiki/Heading.php','6.3',0),('5b46541e8bab0766c21b25592f05be17','./lib/pear/Text/Wiki/Parse/Mediawiki/List.php','6.3',0),('55e466e84a30e62447ee7ac847292594','./lib/pear/Text/Wiki/Parse/Mediawiki/Newline.php','6.3',0),('28f397cd31f0203883feec26e7b1abca','./lib/pear/Text/Wiki/Parse/Mediawiki/Preformatted.php','6.3',0),('f50c2a3a7dc4fb63b01eca070387b870','./lib/pear/Text/Wiki/Parse/Mediawiki/Raw.php','6.3',0),('9c8113434bdb139258001313a01e03c1','./lib/pear/Text/Wiki/Parse/Mediawiki/Redirect.php','6.3',0),('9cc5d5f5f03543170a8e523fe57288f5','./lib/pear/Text/Wiki/Parse/Mediawiki/Subscript.php','6.3',0),('b0c8046635e60af04e44cdb0f23a3843','./lib/pear/Text/Wiki/Parse/Mediawiki/Superscript.php','6.3',0),('84a42b1197763ce6fce33ced8c1d84ec','./lib/pear/Text/Wiki/Parse/Mediawiki/Table.php','6.3',0),('2234a9e8664d22f6b1f56c88b62b1ae0','./lib/pear/Text/Wiki/Parse/Mediawiki/Tt.php','6.3',0),('17c1480143a2559436ee60f7dcafffd3','./lib/pear/Text/Wiki/Parse/Mediawiki/Url.php','6.3',0),('eab780b585b7d33d13c05f999548de4e','./lib/pear/Text/Wiki/Parse/Mediawiki/Wikilink.php','6.3',0),('456c5ee6635bed2a5452f7aaa2373b65','./lib/pear/Text/Wiki/Render.php','6.3',0),('0967f512492ad4995b272ef101101b23','./lib/pear/Text/Wiki/Render/Tiki.php','6.3',0),('9714e69c9fa2da32eb8f29367a993582','./lib/pear/Text/Wiki/Render/Tiki/Anchor.php','6.3',0),('aaf2b0ba1fafe86f780b68a005a99f3d','./lib/pear/Text/Wiki/Render/Tiki/Blockquote.php','6.3',0),('c559e687414a19d804e9dfdcdef0f325','./lib/pear/Text/Wiki/Render/Tiki/Bold.php','6.3',0),('f07fc5f729f31e7db24367f4e3e4f318','./lib/pear/Text/Wiki/Render/Tiki/Box.php','6.3',0),('7051a857370e556c43ab6afe552864ad','./lib/pear/Text/Wiki/Render/Tiki/Break.php','6.3',0),('bf3d0f02367f520a8b97767337ae1393','./lib/pear/Text/Wiki/Render/Tiki/Center.php','6.3',0),('9e9799b1942353efc8b5b8986a801a65','./lib/pear/Text/Wiki/Render/Tiki/Code.php','6.3',0),('25bf40ee91b1e44e4f40aa6740c63cfd','./lib/pear/Text/Wiki/Render/Tiki/Colortext.php','6.3',0),('ed7365c4d6231997810b9f4e4005b33e','./lib/pear/Text/Wiki/Render/Tiki/Deflist.php','6.3',0),('db2ac931322be2984d237faa699e2bf1','./lib/pear/Text/Wiki/Render/Tiki/Delimiter.php','6.3',0),('caf86ec6efca23e668f20f2535655646','./lib/pear/Text/Wiki/Render/Tiki/Embed.php','6.3',0),('abbbb5a6963be619093ef2e3bf645e9d','./lib/pear/Text/Wiki/Render/Tiki/Emphasis.php','6.3',0),('9f79db9b148e5deeda98fec6e0c26e02','./lib/pear/Text/Wiki/Render/Tiki/Freelink.php','6.3',0),('4e04d5dfa534b2fb97b6f0fc71794461','./lib/pear/Text/Wiki/Render/Tiki/Function.php','6.3',0),('76bc7d5262d745900a4a2f59fe451920','./lib/pear/Text/Wiki/Render/Tiki/Heading.php','6.3',0),('b1e2afe854e5ea9f65a7249c08ec66a1','./lib/pear/Text/Wiki/Render/Tiki/Horiz.php','6.3',0),('3875ba86827984244008eb8f654bb4b4','./lib/pear/Text/Wiki/Render/Tiki/Html.php','6.3',0),('ccfd4aa02681daf44d09f5f1840e8ea3','./lib/pear/Text/Wiki/Render/Tiki/Image.php','6.3',0),('62f780b833bf82057c1ac64d69f4d727','./lib/pear/Text/Wiki/Render/Tiki/Include.php','6.3',0),('385591aa1714db3c290c7d9683275914','./lib/pear/Text/Wiki/Render/Tiki/Interwiki.php','6.3',0),('f057022ae6c1bb6348bdc3e72c8c20e4','./lib/pear/Text/Wiki/Render/Tiki/Italic.php','6.3',0),('c6e25882004e683972c00e1ffb250baf','./lib/pear/Text/Wiki/Render/Tiki/List.php','6.3',0),('e4391e07a87c9853d894d4f5d00e1f59','./lib/pear/Text/Wiki/Render/Tiki/Newline.php','6.3',0),('1d461a273eb6ee0eb94e6c20ccc17a61','./lib/pear/Text/Wiki/Render/Tiki/Paragraph.php','6.3',0),('24dac39027cc2a47355631b9e11c0210','./lib/pear/Text/Wiki/Render/Tiki/Phplookup.php','6.3',0),('bde2f22c759db291cc9b906f3c2e98be','./lib/pear/Text/Wiki/Render/Tiki/Prefilter.php','6.3',0),('be7f430bd5d611fb82dd9da6cc1dfc6a','./lib/pear/Text/Wiki/Render/Tiki/Preformatted.php','6.3',0),('3d2221b4887de35aec3dfe8243ad364b','./lib/pear/Text/Wiki/Render/Tiki/Raw.php','6.3',0),('a32009f3c2b0fd0d68e61ec138367ac1','./lib/pear/Text/Wiki/Render/Tiki/Redirect.php','6.3',0),('011cee9815fe659e55223d5aed08f3a6','./lib/pear/Text/Wiki/Render/Tiki/Revise.php','6.3',0),('d8c5a69b5f8fd0a81bf116ff07979c9e','./lib/pear/Text/Wiki/Render/Tiki/Strong.php','6.3',0),('37693332c42fa2f65b97a7eb627a2797','./lib/pear/Text/Wiki/Render/Tiki/Subscript.php','6.3',0),('cd5d893b9434b375e4d4fd5eb83775e4','./lib/pear/Text/Wiki/Render/Tiki/Superscript.php','6.3',0),('26cd169ae69891b7c10c0e0991933d2e','./lib/pear/Text/Wiki/Render/Tiki/Table.php','6.3',0),('6afbede158cb6c4f66843f681232bd65','./lib/pear/Text/Wiki/Render/Tiki/Tighten.php','6.3',0),('45eb9bcd7c9f2146bc6604501c7b4670','./lib/pear/Text/Wiki/Render/Tiki/Toc.php','6.3',0),('f0b9830e7675c010e7981ce6b43de773','./lib/pear/Text/Wiki/Render/Tiki/Tt.php','6.3',0),('38542123cafbf123ce8bef34ac3ca1d2','./lib/pear/Text/Wiki/Render/Tiki/Underline.php','6.3',0),('8af96a8556219fda316400f1e11c1441','./lib/pear/Text/Wiki/Render/Tiki/Url.php','6.3',0),('4a29d61bb9728131cf19eefd7ab0a3b9','./lib/pear/Text/Wiki/Render/Tiki/Wikilink.php','6.3',0),('496e76223279ebaf8f5c88c38d6da13b','./lib/pear/Text/Wiki/Tiki.php','6.3',0),('a259129574a6074b806ae36ececa3f88','./lib/pear/XML/Dump.php','6.3',0),('809edbab489c1b42f7ed21fd9ff7fcfe','./lib/pear/XML/RPC.php','6.3',0),('fb6d0f2d949d46834e9174379a913d89','./lib/pear/XML/Server.php','6.3',0),('c13c44306fec6a6c6c0d435d490b0584','./lib/pear/XML/index.php','6.3',0),('b675448fcc1ea31cea4db8c4169bcb1c','./lib/pear/XML_Parser/Parser.php','6.3',0),('461bfbb139507776329bc957e1c1069b','./lib/pear/XML_Parser/Parser/Simple.php','6.3',0),('16c00cd2cc29cc4e815897e0fdf99bcc','./lib/pear/XML_Parser/examples/xml_parser_file.php','6.3',0),('4640f4e41a20df8f36314443aaa6cd10','./lib/pear/XML_Parser/examples/xml_parser_funcmode.php','6.3',0),('4dbd6fe63e22370d306df173c79b269c','./lib/pear/XML_Parser/examples/xml_parser_handler.php','6.3',0),('a48097891c44d4287aa0f2e6c8362fac','./lib/pear/XML_Parser/examples/xml_parser_simple1.php','6.3',0),('e808267e22f328016975fe22813ecd96','./lib/pear/XML_Parser/examples/xml_parser_simple2.php','6.3',0),('5193261625e5c50d913b9b46a617c819','./lib/pear/XML_Parser/examples/xml_parser_simple_handler.php','6.3',0),('c5b77f8b27c26414528eb8b7b52538ae','./lib/pear/index.php','6.3',0),('204fb09b1a0eaf3daca7dfe189e3a400','./lib/perspectivelib.php','6.3',0),('c6d66197d6cf17c51b8b0e9cc351492b','./lib/phpcas/CAS.php','6.3',0),('26fbe36c8d383bfd116b625d87804b2a','./lib/phpcas/CAS/PGTStorage/pgt-file.php','6.3',0),('d816519b8bfa2714061efb5bb72848bd','./lib/phpcas/CAS/PGTStorage/pgt-main.php','6.3',0),('90b2346bdecfee11a4d766056e19cc81','./lib/phpcas/CAS/client.php','6.3',0),('5d5b545ffd7310c9de5110d58b19162e','./lib/phpcas/CAS/domxml-php4-to-php5.php','6.3',0),('0c9d3153be1cd5797d551bdc68700cb1','./lib/phpcas/CAS/languages/catalan.php','6.3',0),('bc09a9df04cef13254ae57f3a274f0df','./lib/phpcas/CAS/languages/english.php','6.3',0),('474958e64bd7b119842ba73fdfe7443d','./lib/phpcas/CAS/languages/french.php','6.3',0),('1135952ce25e181ad89c05843314c4b0','./lib/phpcas/CAS/languages/german.php','6.3',0),('487febf7b7a9d12e46b8352ed7f2f5b9','./lib/phpcas/CAS/languages/greek.php','6.3',0),('2217adf20780daea3d41b9c9c678246f','./lib/phpcas/CAS/languages/japanese.php','6.3',0),('f0c462c22a96622ced80a4b5dd954d09','./lib/phpcas/CAS/languages/languages.php','6.3',0),('734a4d32b5f27017c775d2ed0b6ce2a3','./lib/phpcas/CAS/languages/spanish.php','6.3',0),('54ecc8fcfc35272d60eaca57d37ac6bc','./lib/phplayers/DUMPS/index.php','6.3',0),('ef3ee036d8c2d5321b8a0f10481b340d','./lib/phplayers/LOGOS/index.php','6.3',0),('e498bdac4e103231ef7b84b3fa3da35c','./lib/phplayers/THEMES/index.php','6.3',0),('4f28ea56403c896fd6c3ab4ba621bd03','./lib/phplayers/demo.php','6.3',0),('87e0e947cb5e62754ba622c3b432fa54','./lib/phplayers/example-db-hormenu.php','6.3',0),('a9b55f7a72d62b948a791c1e591b5c5a','./lib/phplayers/example-db-treemenu.notshown.php','6.3',0),('5129d3c8e90317a46a23badbac9213ae','./lib/phplayers/example-db-treemenu.php','6.3',0),('378d07ee3867009aa09cb21b8821d5c6','./lib/phplayers/example-dbtofile.php','6.3',0),('151adaeff20616da3e7fe265bf934401','./lib/phplayers/example-filetodb.php','6.3',0),('858c85a048a271fcab244b08ac2c18ba','./lib/phplayers/example-frame-body.php','6.3',0),('09985b56d0e1797c214714ce62b1eddd','./lib/phplayers/example-frame-treemenu.php','6.3',0),('b13a94adcb32441f087f939922540975','./lib/phplayers/example-hormenu-old.php','6.3',0),('50c56d66056419d0960ecff608c229d3','./lib/phplayers/example-hormenu.php','6.3',0),('a424914f5ee4bb4879a028fb2dd94263','./lib/phplayers/example-hormenu_and_treemenu.php','6.3',0),('66071cfb25f071853c8db083d43a2f2f','./lib/phplayers/example-hormenu_and_vermenu.php','6.3',0),('ddeda807ddb26e9958b1dfef92e208f4','./lib/phplayers/example-horplainmenu.php','6.3',0),('b69323dad5891e243b0be1cc5a12fd1f','./lib/phplayers/example-layersmenus_and_treemenus.php','6.3',0),('e9d02f69b11d57f8c7c70f64e2248423','./lib/phplayers/example-phptreemenu.php','6.3',0),('12913d34b4a9689f43c1f5f1c894af89','./lib/phplayers/example-see-through.php','6.3',0),('51ebcdd826c431d585213c247311494e','./lib/phplayers/example-treemenu.php','6.3',0),('343e21f12601450c7c3ca1062728d523','./lib/phplayers/example-two_treemenus.php','6.3',0),('c82d03970c6643a47223be479eeaca2e','./lib/phplayers/example-vermenu.php','6.3',0),('4fd713af5150521a6c683c7fe45795c7','./lib/phplayers/example-verplainmenu.php','6.3',0),('fb2e2588536cbfceda875c9ca438d676','./lib/phplayers/images/index.php','6.3',0),('e47b03c660307b523eb894025efa2184','./lib/phplayers/index.php','6.3',0),('8bb1c2e2f077f31bb5b0b113037ce639','./lib/phplayers/lib/PHPLIB.php','6.3',0),('9a6dd12248357d6013d9029e1fb1c3e9','./lib/phplayers/lib/index.php','6.3',0),('ad2848e382b6b2bb510f51a4d7b52034','./lib/phplayers/lib/layersmenu-browser_detection.php','6.3',0),('26a0752ac401d311357e0c92a885bfa9','./lib/phplayers/lib/layersmenu-common.inc.php','6.3',0),('dafd894557ca2019130450793fd0bc65','./lib/phplayers/lib/layersmenu-process.inc.php','6.3',0),('06367b5497e0dcca3cc782d6d49635c9','./lib/phplayers/lib/layersmenu.inc.php','6.3',0),('3542444e91554d4bcd24a04375ef6288','./lib/phplayers/lib/phptreemenu.inc.php','6.3',0),('250e9cbce90feae16a31acf43c61f5f6','./lib/phplayers/lib/plainmenu.inc.php','6.3',0),('50510ac722f9d256a9acc623ec1f1fb6','./lib/phplayers/lib/treemenu.inc.php','6.3',0),('9746a635105e5657c3fdee49eed95a6c','./lib/phplayers/libjs/index.php','6.3',0),('594613b891934ad88b5bed6dca11f8bd','./lib/phplayers/phplayersindex.php','6.3',0),('1f83a4fd59c1922f1fb2339fbd419668','./lib/phplayers/templates/index.php','6.3',0),('ed992489afa5429771fdcfc8943a7799','./lib/phplayers_tiki/index.php','6.3',0),('ed992489afa5429771fdcfc8943a7799','./lib/phplayers_tiki/lib/index.php','6.3',0),('aaec7fe456e61a89bc6dcd4b50d4b681','./lib/phplayers_tiki/lib/layersmenu-common.inc.php','6.3',0),('31aaf2fa234f67788923a61ff5abb850','./lib/phplayers_tiki/templates/index.php','6.3',0),('db5c623785f02d8edfb19ca4d3234ca7','./lib/phplayers_tiki/tiki-phplayers.php','6.3',0),('43bbb2eeaae6b401e750d4210e4657b5','./lib/polls/index.php','6.3',0),('31e9357a64c65e54d4278181a3388073','./lib/polls/polllib.php','6.3',0),('2f0812efa1635de53ab72dcfcd1348e4','./lib/polls/polllib_shared.php','6.3',0),('f8d82e2b6ffb8fe1f5b305185e1a794f','./lib/prefs/ajax.php','6.3',0),('5f96082e146c898bf1715f3e5998ab5f','./lib/prefs/allowmsg.php','6.3',0),('7b0e631d443f9b186ef1283ac5b3e61c','./lib/prefs/art.php','6.3',0),('fe3096cbcd4818c81bd8ee3687f98e72','./lib/prefs/article.php','6.3',0),('fef33ce933774e158ca54d1b2839697a','./lib/prefs/articles.php','6.3',0),('379e4a79901f361c093c0662c0e97b96','./lib/prefs/auth.php','6.3',0),('7648c1e3bc55a1700c6b25bd01a3266d','./lib/prefs/available.php','6.3',0),('c509eaca8a5d220f728ac0d42a04d537','./lib/prefs/bigbluebutton.php','6.3',0),('07b0f603a991062e0e38ff723e4c8afa','./lib/prefs/blog.php','6.3',0),('b54a049b972e698ae14ba2c00781cd5b','./lib/prefs/blogues.php','6.3',0),('795a3a61d8861f46a9edf0305cbd5d6f','./lib/prefs/bot.php','6.3',0),('256daca6ce1f6a98c78f7b236cea5b48','./lib/prefs/box.php','6.3',0),('4d1661ad30ece0996625184f1927e67b','./lib/prefs/calendar.php','6.3',0),('36465a7c8a75e52381d6a189ba0ef400','./lib/prefs/captcha.php','6.3',0),('6fc351b08e98168884a4d7c59d907109','./lib/prefs/cas.php','6.3',0),('7089fd157c39cfa4c908e1313684a577','./lib/prefs/categories.php','6.3',0),('bc39ab757c4d173a76e64e874de0aff5','./lib/prefs/category.php','6.3',0),('44ecac2a2621ec99657bf7b224b564f6','./lib/prefs/categorypath.php','6.3',0),('995d6991bf1d52398f72849baa09ddf3','./lib/prefs/center.php','6.3',0),('c1f6f46a5cc32a0237ef5acbce468f3d','./lib/prefs/change.php','6.3',0),('d8702188edb084ab79b873a87a282876','./lib/prefs/comments.php','6.3',0),('e33f8b907cfca831b6634d59e19b355a','./lib/prefs/contact.php','6.3',0),('d60cda7300cd3e771aea6488d6775a96','./lib/prefs/cookie.php','6.3',0),('796d644fa5570000bd18283a98581ebe','./lib/prefs/count.php','6.3',0),('1ed2148c34035b92f9b7747eaa8642c3','./lib/prefs/default.php','6.3',0),('bd7f7fbbfde44142a5eaac60687ab28b','./lib/prefs/desactive.php','6.3',0),('9dafc3ecacd8c8a6ad85bf1a0891317b','./lib/prefs/direct.php','6.3',0),('a34ef23823e5074b56fe439906a1235e','./lib/prefs/directory.php','6.3',0),('8625c50f65ccf1a6f718119451d1c1f8','./lib/prefs/display.php','6.3',0),('b772c4c1d33e9612b8803f5b53a84b4c','./lib/prefs/email.php','6.3',0),('9bf060c6c30e53569b87f7a5e864cc7f','./lib/prefs/error.php','6.3',0),('05166e4502e339cfcafddf1474f8f581','./lib/prefs/faq.php','6.3',0),('9c5047d18067c6767ca138e66b56e7d2','./lib/prefs/faqs.php','6.3',0),('0813d07219ed2cf689fafa9e88c72c52','./lib/prefs/feature.php','6.3',0),('bffdddee8302f09ea8b3f09464d0a7e3','./lib/prefs/feed.php','6.3',0),('167d46ec71f8e45f807285540ea535f8','./lib/prefs/fgal.php','6.3',0),('932dd86ca933d81043a4940ebf971b4e','./lib/prefs/file.php','6.3',0),('204fec8885097001b366221d2990f0ab','./lib/prefs/footer.php','6.3',0),('d8ad80487d4edea1ba658a8166d9e1ca','./lib/prefs/forum.php','6.3',0),('8711c631491e62f4b5fa1fcf662b9caa','./lib/prefs/forums.php','6.3',0),('e1b4f9c2634a1db912f8592072b588c8','./lib/prefs/freetags.php','6.3',0),('8988fc07117aaf5a124d395fb1fb1312','./lib/prefs/generate.php','6.3',0),('0a3b97e866d08e1dc4638e34f2ebc5ad','./lib/prefs/global.php','6.3',0),('f4b52203da004d4c4c1bb8b7ec7d925e','./lib/prefs/gmap.php','6.3',0),('f97383f89a154fe224c283f3a560a3b3','./lib/prefs/header.php','6.3',0),('ffc9ff2ba6edaa10049764e4a5f44efa','./lib/prefs/highlight.php','6.3',0),('3c358dd041868efc4c7186e14b0e4ca5','./lib/prefs/home.php','6.3',0),('4083518d1cfdcd71833795ec31c6f5ca','./lib/prefs/http.php','6.3',0),('7438a6375e87e3ca1b8474327fce31c5','./lib/prefs/https.php','6.3',0),('754ba34b92b40fdaec64dd6c32eb784b','./lib/prefs/iepngfix.php','6.3',0),('b27cdfda3e2e4d4eeba6d79a6d806169','./lib/prefs/javascript.php','6.3',0),('6d1e0cc8826dfd68c444a4d274129a2f','./lib/prefs/jquery.php','6.3',0),('f67ad67c0f2d747d0877774936d58e2a','./lib/prefs/keep.php','6.3',0),('b9a30ba52da429b76a8c07c0e6e26c0a','./lib/prefs/lang.php','6.3',0),('6e8a8f023c841e945e435fd8b9fb5d83','./lib/prefs/language.php','6.3',0),('f0adde2124e4abbcfba95b460ba7c605','./lib/prefs/layout.php','6.3',0),('3f7176f01c6363c414cf6e05c18855b3','./lib/prefs/ldap.php','6.3',0),('833d858b0b91a2860234254133570a4c','./lib/prefs/load.php','6.3',0),('466fe3d03ec4ec8410af7745eb636234','./lib/prefs/log.php','6.3',0),('a176e3cc6d89f588d8eb6aa1aa18082a','./lib/prefs/login.php','6.3',0),('6a43f4af993aa7adf304d63539048032','./lib/prefs/long.php','6.3',0),('8852c6a4f319c21a217397c45efc513d','./lib/prefs/lowercase.php','6.3',0),('14e64a402764b479be0d9800252b1976','./lib/prefs/mail.php','6.3',0),('4923aedcccce9dd3a4041c9acf105e38','./lib/prefs/main.php','6.3',0),('5165d0c7347ff81e114768b3528c1b34','./lib/prefs/map.php','6.3',0),('ed8924568b8292775cb8049e19fcd9c6','./lib/prefs/max.php','6.3',0),('15d3c36e119b088cf29385fb1e2f84f9','./lib/prefs/memcache.php','6.3',0),('2474e6c15fad2f28cf7a562efe29e35a','./lib/prefs/menus.php','6.3',0),('5c1ceba4080dd9856a27ce2a82965773','./lib/prefs/messu.php','6.3',0),('61b5deecc3d367e3425fc04b74350c3d','./lib/prefs/metatag.php','6.3',0),('0376b19ca17fcbb6a688e9e0d395f175','./lib/prefs/metrics.php','6.3',0),('a7169779dbc679564629fcbecc725b0e','./lib/prefs/middle.php','6.3',0),('9d40873b57e0de8c5fe023791528e89d','./lib/prefs/min.php','6.3',0),('2fda6b6a043f09bcbfba28c8ae9ad5c0','./lib/prefs/morelikethis.php','6.3',0),('e254954491257683fe1784a8b760a896','./lib/prefs/multidomain.php','6.3',0),('4146012ab3ae8fea0878ad57f21ae249','./lib/prefs/nextprev.php','6.3',0),('bc8015e3516dd7c1a12c7f98b2a248c5','./lib/prefs/page.php','6.3',0),('31b8ee87f011ebb7500c35e45cb38ce9','./lib/prefs/pagination.php','6.3',0),('d6b5f327ce528a7dcd8b93c4f7941604','./lib/prefs/pam.php','6.3',0),('e7f9fa35e19825c00b2989f5b3dc16cf','./lib/prefs/pass.php','6.3',0),('3d6f0319aa0ad3dca09b57ffe6b847be','./lib/prefs/payment.php','6.3',0),('adc3be6d03f7333513fa0b6e6e82a8f4','./lib/prefs/permission.php','6.3',0),('91e6e99dfdda4dc008d2d0c5228c6119','./lib/prefs/poll.php','6.3',0),('13beb031647b37edf4949a4c2342703d','./lib/prefs/print.php','6.3',0),('c4f9cc986a4bbe7f860b64aaab4cede2','./lib/prefs/proxy.php','6.3',0),('1dc30a49c2cf2b8f5b1e27ba50c02e5e','./lib/prefs/quantify.php','6.3',0),('b2a1890e0b8c5c798ab407eabd5857fe','./lib/prefs/rating.php','6.3',0),('abacb381bd8f3c37ea0d10be449c4622','./lib/prefs/recaptcha.php','6.3',0),('e4fbaa1bbb5ecad4808c4bfba02f0417','./lib/prefs/record.php','6.3',0),('5def21d33817ef03f296f3c055ecabe5','./lib/prefs/restrict.php','6.3',0),('84aba087c6fe3ae570aa5ee831d08edd','./lib/prefs/search.php','6.3',0),('d6ae9457972a6815c7b8cbeccde3eeb8','./lib/prefs/section.php','6.3',0),('a0bedf972f986258c9f238e1e0b4166a','./lib/prefs/sender.php','6.3',0),('a887f802a8b7fa150f6a65b69416a7e8','./lib/prefs/server.php','6.3',0),('d8265b48e91c0b3d0d115c55722375d9','./lib/prefs/session.php','6.3',0),('f2e86ae0970f3c9a4ff3a4b922680bc0','./lib/prefs/shib.php','6.3',0),('fff9d3414d26707fc479d972b5875c57','./lib/prefs/shipping.php','6.3',0),('2e3b053a4372484bfc294b093c0c3e69','./lib/prefs/short.php','6.3',0),('5ecac912886614e54b8bcefe02fa2098','./lib/prefs/show.php','6.3',0),('c9d7e5ddda46ad340a8dfc9c94c222cd','./lib/prefs/site.php','6.3',0),('3cf27154d9969f4bb3249489c5dd05b8','./lib/prefs/sitead.php','6.3',0),('9b4157104051b8b27f3ed001500debe1','./lib/prefs/sitelogo.php','6.3',0),('36a6bb3b5a6dd6b7106e100e742dc92a','./lib/prefs/sitemycode.php','6.3',0),('274d9a16603a0d1924cb093b888acad9','./lib/prefs/slide.php','6.3',0),('b7cff650bff8f215b191664f3747c618','./lib/prefs/smarty.php','6.3',0),('38bf008095d2519cd60f030bdca0a953','./lib/prefs/socialnetworks.php','6.3',0),('46862b7ecbbe38331a78c0457da84286','./lib/prefs/style.php','6.3',0),('0ac1e40883857596689a7f2d6a60e6d0','./lib/prefs/tiki.php','6.3',0),('3f0be65d5b64f2dfcfe28478c32eaff3','./lib/prefs/tracker.php','6.3',0),('a1356271441db8c66405c372a0f4180a','./lib/prefs/unsuccessful.php','6.3',0),('d7ae0e722bbbf6a509343cb3aebc624c','./lib/prefs/url.php','6.3',0),('4269424579ba1672985604cda38fc0cd','./lib/prefs/use.php','6.3',0),('47991a149684a55edcfdbf388047632f','./lib/prefs/user.php','6.3',0),('30632dd18f64e06b5615bb877031c594','./lib/prefs/username.php','6.3',0),('6ad8ac7424443ee69c58f2fadf5bc551','./lib/prefs/users.php','6.3',0),('7a675bf1f11b5f4f105e85906d45cfb6','./lib/prefs/validator.php','6.3',0),('afb421384c7874287cb3e7e7f7ee586c','./lib/prefs/w.php','6.3',0),('146b26b5e2f5319fbfdf6ef45e9155f7','./lib/prefs/warn.php','6.3',0),('e9b7670a54779bc4751e403d1d2edc7d','./lib/prefs/watershed.php','6.3',0),('9dc80532693e371b013dd431c74b78eb','./lib/prefs/webmail.php','6.3',0),('975cebce96e33cd5e75df1ef84e7edbf','./lib/prefs/wiki.php','6.3',0),('b94e921f4d81d0751cc5d37f3b90ee6d','./lib/prefs/wikiapproval.php','6.3',0),('a2583da0d1106592ed2354bf345ae1bf','./lib/prefs/wikiplugin.php','6.3',0),('a415f2a18f5f0698dc46af728aa5b1ea','./lib/prefs/wikiplugininline.php','6.3',0),('4dc752d3c476d86dd58e86eefab017a8','./lib/prefs/wysiwyg.php','6.3',0),('cbd0114bc7942a1dfc428584bcc4246e','./lib/prefs/zend.php','6.3',0),('ad90bf8154af82111e9d2e5641756ed0','./lib/prefslib.php','6.3',0),('f23531f55065806d5735458179d12636','./lib/profilelib/channellib.php','6.3',0),('f9da1320c8f3517942460c821aeb942e','./lib/profilelib/installlib.php','6.3',0),('4fdc33b3320e1a59df806e4d7ad98038','./lib/profilelib/listlib.php','6.3',0),('9a0aa04860c683c4ca3446a7f1ef7891','./lib/profilelib/profilelib.php','6.3',0),('63d95da20d0f1dd89a3dd16c5d82794a','./lib/quizzes/index.php','6.3',0),('7f560fd0d1e9af4c57a57ced19e3e963','./lib/quizzes/quizlib.php','6.3',0),('63d95da20d0f1dd89a3dd16c5d82794a','./lib/rankings/index.php','6.3',0),('ef01f60576d76bc0ffb5dedda32cec29','./lib/rankings/ranklib.php','6.3',0),('cbf2c3d15a7ce3a8af18696c1621277c','./lib/rating/configlib.php','6.3',0),('e87a2ba8c13776d7fac5f8d7e3cd0161','./lib/rating/formula/ArticleInfo.php','6.3',0),('8d0b5e323a022fe7a33c39c6b4305caf','./lib/rating/formula/Attribute.php','6.3',0),('fb9d13c9a3065f26a2639ddf72a9aa06','./lib/rating/formula/RatingAverage.php','6.3',0),('7a1ce1921f7077232e191b0c75b33942','./lib/rating/formula/RatingSum.php','6.3',0),('04b8e7549e038f7efb750298d67b0137','./lib/rating/ratinglib.php','6.3',0),('63d95da20d0f1dd89a3dd16c5d82794a','./lib/refererstats/index.php','6.3',0),('eed96bca01ac2588b5253eaa71a09fc2','./lib/refererstats/refererlib.php','6.3',0),('63d95da20d0f1dd89a3dd16c5d82794a','./lib/registration/index.php','6.3',0),('38fd53dccb5e0e3e502433960a7d7602','./lib/registration/registrationlib.php','6.3',0),('8993c9d2add58c18b1ed35637325fe57','./lib/reportslib.php','6.3',0),('63d95da20d0f1dd89a3dd16c5d82794a','./lib/rss/index.php','6.3',0),('d2d4a7ed4441d94577fd6acb128912cf','./lib/rss/rsslib.php','6.3',0),('3272f03e800914438fe1e9bbd674f9c0','./lib/score/events.php','6.3',0),('63d95da20d0f1dd89a3dd16c5d82794a','./lib/score/index.php','6.3',0),('d05a915f916669ea41aa4ebec74d0d3a','./lib/score/scorelib.php','6.3',0),('63d95da20d0f1dd89a3dd16c5d82794a','./lib/search/index.php','6.3',0),('e56271ca55ccfee223787a6bd8f1eee6','./lib/search/refresh-functions.php','6.3',0),('37f2b0aa474cc74935deff818ef7877e','./lib/search/refresh.php','6.3',0),('f46896d19a9c4d92709bb35765cdb5c9','./lib/search/searchlib-mysql.php','6.3',0),('fe7a10cc82207d8c47843d6120ee4b4e','./lib/search/searchlib-tiki.php','6.3',0),('f148f114e9041f92b21b0a86065f30a1','./lib/search/searchstatslib.php','6.3',0),('cc08abeb8a026ca6ce377b0cc9c27bce','./lib/setup/absolute_urls.php','6.3',0),('8625c6f2b0aa2a8fe66a4f99cb95de4f','./lib/setup/babelfish.php','6.3',0),('51029328d9c1e0fdad83f4e7f3fe408e','./lib/setup/breadcrumb.php','6.3',0),('50bd4ee809e645b7c504aedae6a50934','./lib/setup/categories.php','6.3',0),('0145d43be80c21706b446bfdb4449fe4','./lib/setup/challenge.php','6.3',0),('fd4ce187136cd07b124de70078e604f7','./lib/setup/comments_zone.php','6.3',0),('e44940655945cfd34e2ae63bb595b14c','./lib/setup/compat.php','6.3',0),('d5ea28816ae752c613bc58e6b373eb33','./lib/setup/cookies.php','6.3',0),('94e60daf8d4f2ff0501c2fa09a148610','./lib/setup/credits.php','6.3',0),('108576c28acb5bd0ad7ddd47c057ecd0','./lib/setup/default_homepage.php','6.3',0),('bad6d9c4e6765c80c64d33a155202dc8','./lib/setup/dynamic_variables.php','6.3',0),('44993699e3f63407ed5b5de320958950','./lib/setup/editmode.php','6.3',0),('3d1ec21f44f17a17f160bf08fac29568','./lib/setup/error_reporting.php','6.3',0),('d3e9cda7aa8f799a670edd7a7c6e6dc8','./lib/setup/freetags.php','6.3',0),('78a048399bb1b741b1ad1dff6994d493','./lib/setup/fullscreen.php','6.3',0),('f7c3492d16c44089e61eb39780d87378','./lib/setup/integrator.php','6.3',0),('06531a867e7412be09b00fc0be23d892','./lib/setup/js_detect.php','6.3',0),('cda7ac41936e73479cbf960ae056b4b3','./lib/setup/language.php','6.3',0),('f4aade0b5931cbb233a4aefb9b35bf06','./lib/setup/last_update.php','6.3',0),('2744bfcc2e7ef3431673b068d4ccfa8c','./lib/setup/live_support.php','6.3',0),('f975a25a9f73fc2626090732a978e2a3','./lib/setup/load_threshold.php','6.3',0),('488b6bf292b6a69ea6189ab002315346','./lib/setup/mailin.php','6.3',0),('2095e8f52089075da360d35169cc82bc','./lib/setup/openid.php','6.3',0),('53ad10cb4955564cc3a207afcd32c194','./lib/setup/output_compression.php','6.3',0),('1be6447e1432ff79f74ac9a402094b1a','./lib/setup/patches.php','6.3',0),('5919940f3a70fd63ff1c5c289a539bf7','./lib/setup/perms.php','6.3',0),('dd99e1f645e39fc290950fc31031d960','./lib/setup/phplayers.php','6.3',0),('00b275e70bbdec8b34963a5de040af09','./lib/setup/polls.php','6.3',0),('a649968ec9fb3b4ddd5addb01ee780a1','./lib/setup/prefs.php','6.3',0),('3ae7b40f103fbbffb122a15f4f2e3d8b','./lib/setup/sections.php','6.3',0),('6032875f1b03453886d94fba9b25c477','./lib/setup/site_closed.php','6.3',0),('d32de6ab76d240f40f9b75fb7c10eba7','./lib/setup/stats.php','6.3',0),('e071c709ecf23b4f984f61e9d325c9e5','./lib/setup/theme.php','6.3',0),('46410c15606a10078d5f482014c52079','./lib/setup/third_party.php','6.3',0),('6aec7dcc44b617dcb04b4c2c5718e01c','./lib/setup/tikisetup.class.php','6.3',0),('f6c87a166ca9cca1043aaf3747b2afee','./lib/setup/timer.class.php','6.3',0),('37c5b32a1401dde276f025844024d203','./lib/setup/twversion.class.php','6.3',0),('9dc0443ec2083b07c1240ea740242550','./lib/setup/user_prefs.php','6.3',0),('efc64d8d46f65d90c0f19d7fbd7046df','./lib/setup/userlevels.php','6.3',0),('74ee64bd7971a49e56ae9989a11d65ef','./lib/setup/usermenu.php','6.3',0),('081bf2c1658ae6dd94026fafdf9ac31a','./lib/setup/wiki.php','6.3',0),('323c0638785e7b6a213245efcbbab754','./lib/sharelib.php','6.3',0),('a5307940f95b663ab0df477198554bc5','./lib/sheet/conf/config.inc.php','6.3',0),('c531fb56f9a0118ca56eeefd1b28e569','./lib/sheet/excel/index.php','6.3',0),('e5da7d2025c7545b00f3f9a9624ee9ed','./lib/sheet/excel/reader.php','6.3',0),('c8e6a0ac30bda8ba1e280f76f7de5392','./lib/sheet/excel/reader_ole.php','6.3',0),('74cb1b95daa8554eaec7f3b0d9ad11b4','./lib/sheet/excel/writer.php','6.3',0),('e994568d4069f4b3b94fcb74cb16b1f8','./lib/sheet/excel/writer/biffwriter.php','6.3',0),('218d96dc0ea61588169734c1908fd2b3','./lib/sheet/excel/writer/format.php','6.3',0),('c531fb56f9a0118ca56eeefd1b28e569','./lib/sheet/excel/writer/index.php','6.3',0),('773f04af29738732a8a9299f87839a3c','./lib/sheet/excel/writer/parser.php','6.3',0),('a989f1109c974c3b1b7501ca443150f9','./lib/sheet/excel/writer/validator.php','6.3',0),('2312980c14ae64cec1ceb934769e8a83','./lib/sheet/excel/writer/workbook.php','6.3',0),('2f6899d384aa8e6e8c5dac1b5da312ca','./lib/sheet/excel/writer/worksheet.php','6.3',0),('f1e13b693d60ddfefa9904908571029e','./lib/sheet/grid.php','6.3',0),('7f99b8e8a0ad7b1e18a90a8ba7c36df8','./lib/sheet/include/core/APIC.php','6.3',0),('0938520399b9f3f5d8a42313e7720152','./lib/sheet/include/core/APIClass.php','6.3',0),('0f157dff47846b6d797667616f6849b6','./lib/sheet/include/core/APIClassRegistry.php','6.3',0),('d2894659a5ff55f191231206eb1e74e9','./lib/sheet/include/core/ErrorManager.php','6.3',0),('074f5be6ebf9b162ee0df64b725044b6','./lib/sheet/include/core/Object.php','6.3',0),('95577e56508ffd91313edb41383a2a14','./lib/sheet/include/org/apicnet/io/File.php','6.3',0),('a58cc99a5ea672213350869ff5795325','./lib/sheet/include/org/apicnet/io/OOo/OOoCalc.php','6.3',0),('208dfd20cf828e4a905e364f07c91254','./lib/sheet/include/org/apicnet/io/OOo/OOoDoc.php','6.3',0),('2f12c041b11c010c3dbf62e48e9486d7','./lib/sheet/include/org/apicnet/io/OOo/OOoManifest.php','6.3',0),('c0c003cebffa1eb4bb042218e0cc42cc','./lib/sheet/include/org/apicnet/io/OOo/OOoMeta.php','6.3',0),('f88b34e1d082f2c50baed5f5539724bc','./lib/sheet/include/org/apicnet/io/OOo/OOoMime.php','6.3',0),('c2255097ba5d8be547f27a75ea3cc759','./lib/sheet/include/org/apicnet/io/OOo/OOoStyle.php','6.3',0),('615edefc619e55fc9158b3f0cb88e2bc','./lib/sheet/include/org/apicnet/io/OOo/OOoUtil.php','6.3',0),('5530027ed19904acacdf0d3285dbc815','./lib/sheet/include/org/apicnet/io/OOo/OOoWriter.php','6.3',0),('a15823430bac2467c9a88d2e23b34d3b','./lib/sheet/include/org/apicnet/io/OOo/absOOo.php','6.3',0),('d41d8cd98f00b204e9800998ecf8427e','./lib/sheet/include/org/apicnet/io/OOo/objOOo/OOoCadre.php','6.3',0),('6ca0d0b684e5d2ddbdc603e98f06d4d3','./lib/sheet/include/org/apicnet/io/OOo/objOOo/OOoImg.php','6.3',0),('99d14a3aef06ba752f07d32aad117fc5','./lib/sheet/include/org/apicnet/io/OOo/objOOo/OOoTable.php','6.3',0),('f7f90d07d9f7aca289cde3a54c4bb932','./lib/sheet/include/org/apicnet/io/OOo/objOOo/OOoText.php','6.3',0),('99d46bfea2396c121483022197f6ec62','./lib/sheet/include/org/apicnet/io/archive/CZip.php','6.3',0),('e1ff35c678ee51b45844705eeb6a2281','./lib/sheet/include/org/apicnet/io/cdir.php','6.3',0),('ec98b6f8876b7c9e0529ffcb2d6f6b99','./lib/sheet/include/org/apicnet/util/HTTPHeader.php','6.3',0),('b6a3f7dd8bed723cb13bee72d10aba6d','./lib/sheet/include/org/apicnet/util/StringBuffer.php','6.3',0),('c531fb56f9a0118ca56eeefd1b28e569','./lib/sheet/index.php','6.3',0),('0cae85f19f9a4471511392cedbbb2b2d','./lib/sheet/ole.php','6.3',0),('c531fb56f9a0118ca56eeefd1b28e569','./lib/sheet/ole/index.php','6.3',0),('67c73c695c14238d4e4bfb0075cf58ae','./lib/sheet/ole/pps.php','6.3',0),('3d0b5c3ae7426eb0e682a12ae56d839f','./lib/sheet/ole/pps/file.php','6.3',0),('c531fb56f9a0118ca56eeefd1b28e569','./lib/sheet/ole/pps/index.php','6.3',0),('8eec7c610389e3c179cd230516ba07c1','./lib/sheet/ole/pps/root.php','6.3',0),('fd00e1587a8949352fee0f604a0c784a','./lib/shipping/provider_fedex.php','6.3',0),('07e0190bc81ec9772e8b2683bc5c1619','./lib/shipping/provider_ups.php','6.3',0),('1f1643a22524c41cf779fe7bd86d2ec9','./lib/shipping/shippinglib.php','6.3',0),('63d95da20d0f1dd89a3dd16c5d82794a','./lib/shoutbox/index.php','6.3',0),('0d9f590417fc9e3a48ef2193dc44dfe0','./lib/shoutbox/shoutboxlib.php','6.3',0),('2e485e1b32262c35974c079dd7701d32','./lib/smarty/demo/index.php','6.3',0),('dd507b29d51e897ee66d1f4b54442a5d','./lib/smarty/index.php','6.3',0),('8005e0d072190dd3a3c5d8d9e7ded373','./lib/smarty/libs/Config_File.class.php','6.3',0),('4f280d0817540872d15dca8b10fa5df6','./lib/smarty/libs/Smarty.class.php','6.3',0),('79d2d22090e76c555149a34a2bf23abd','./lib/smarty/libs/Smarty_Compiler.class.php','6.3',0),('c98832bd718c94629c732b5d4c2980cb','./lib/smarty/libs/internals/core.assemble_plugin_filepath.php','6.3',0),('4c2dd142c1c59e101b2f60cfc7a7cdc2','./lib/smarty/libs/internals/core.assign_smarty_interface.php','6.3',0),('a12f6e4653dc814369202e0ed57206b0','./lib/smarty/libs/internals/core.create_dir_structure.php','6.3',0),('297b9baf349e7f32e8e815612e823e3c','./lib/smarty/libs/internals/core.display_debug_console.php','6.3',0),('ba78ea6d4112d4325b00e4b8101497c6','./lib/smarty/libs/internals/core.get_include_path.php','6.3',0),('72eb40e8367f77f0bd251e15a5bd4f5f','./lib/smarty/libs/internals/core.get_microtime.php','6.3',0),('e0fccd538d6f0ed8915d39cc2f9dd860','./lib/smarty/libs/internals/core.get_php_resource.php','6.3',0),('7ea83dd65e64bc0bc893d44096ec61e0','./lib/smarty/libs/internals/core.is_secure.php','6.3',0),('83e22de7a251fef6a033769b35989bf6','./lib/smarty/libs/internals/core.is_trusted.php','6.3',0),('d60028c542ec06749cd2d381bc07d0c2','./lib/smarty/libs/internals/core.load_plugins.php','6.3',0),('08d531fb688eed7253b316b11436e512','./lib/smarty/libs/internals/core.load_resource_plugin.php','6.3',0),('2a846ebfec89211b7090149052374059','./lib/smarty/libs/internals/core.process_cached_inserts.php','6.3',0),('95e1308976578925f2e57b1aa8d716bf','./lib/smarty/libs/internals/core.process_compiled_include.php','6.3',0),('e7de28f374768f8b319687a34e226c80','./lib/smarty/libs/internals/core.read_cache_file.php','6.3',0),('8834d9e9a8aa8473244d74096638b5c2','./lib/smarty/libs/internals/core.rm_auto.php','6.3',0),('08209df8f3113b0d8322bcac3b5e055b','./lib/smarty/libs/internals/core.rmdir.php','6.3',0),('f6452eb1f0f65cf3b07634228ea4c938','./lib/smarty/libs/internals/core.run_insert_handler.php','6.3',0),('0d87e492eb18ec8b4fa492f2ac34c163','./lib/smarty/libs/internals/core.smarty_include_php.php','6.3',0),('a000f4e24379b7dcc05603b2ad91c789','./lib/smarty/libs/internals/core.write_cache_file.php','6.3',0),('ff7944e8092eaf7c2ee97d865df29788','./lib/smarty/libs/internals/core.write_compiled_include.php','6.3',0),('caa79e832d4587991606dd9a0988c852','./lib/smarty/libs/internals/core.write_compiled_resource.php','6.3',0),('23f99e19895028592cff61325b6ed0b1','./lib/smarty/libs/internals/core.write_file.php','6.3',0),('f4e1cc15997ff132066f5e4e09e92054','./lib/smarty/libs/plugins/block.textformat.php','6.3',0),('b4f1eb6f5a8cde9dbec9f5fb1ccb108c','./lib/smarty/libs/plugins/compiler.assign.php','6.3',0),('0abdfebfea185a7b1a727d9546e244be','./lib/smarty/libs/plugins/function.assign_debug_info.php','6.3',0),('fa6466c59cab6333c64ac270dd6c53b1','./lib/smarty/libs/plugins/function.config_load.php','6.3',0),('9531e844efd007c593dadd6173cb0bbd','./lib/smarty/libs/plugins/function.counter.php','6.3',0),('db7b2e51bd5e26f93032929dcb2d531b','./lib/smarty/libs/plugins/function.cycle.php','6.3',0),('4963d564da17a2578fc5f56d9c53e7bc','./lib/smarty/libs/plugins/function.debug.php','6.3',0),('3fedd0e2a4c285200c12fe6427bc2739','./lib/smarty/libs/plugins/function.eval.php','6.3',0),('51259f99b6554fa1a6a60013a5e7880a','./lib/smarty/libs/plugins/function.fetch.php','6.3',0),('a05460918e36fd9ef66d955754868a3e','./lib/smarty/libs/plugins/function.html_checkboxes.php','6.3',0),('de11daabe07795fe4229b8d0185489dd','./lib/smarty/libs/plugins/function.html_image.php','6.3',0),('b634076ab0424a5b8310ff733c5615a6','./lib/smarty/libs/plugins/function.html_options.php','6.3',0),('6a00315efe8f8202823ade3bf3e6e513','./lib/smarty/libs/plugins/function.html_radios.php','6.3',0),('ad1d200bf750d98379cfc5507eac681d','./lib/smarty/libs/plugins/function.html_select_date.php','6.3',0),('ac7c160c72b293e6509840a5aba9a429','./lib/smarty/libs/plugins/function.html_select_time.php','6.3',0),('d7ade8af24efeb33f852bef185004521','./lib/smarty/libs/plugins/function.html_table.php','6.3',0),('03b5b66b3c6221c34b0d27c030dc7b60','./lib/smarty/libs/plugins/function.mailto.php','6.3',0),('6cfac881d33e586406551b19296d8154','./lib/smarty/libs/plugins/function.math.php','6.3',0),('1e8b78080d08a386ba297c0dbb7c3a7b','./lib/smarty/libs/plugins/function.popup.php','6.3',0),('b2353a42807535109e1f037c0d51f19c','./lib/smarty/libs/plugins/function.popup_init.php','6.3',0),('70f58c49c5bd2851be11a3d67a92d2a4','./lib/smarty/libs/plugins/modifier.capitalize.php','6.3',0),('9dbc6c2d6d78165d9d0ffae481509b6a','./lib/smarty/libs/plugins/modifier.cat.php','6.3',0),('91694b84f8b86aa551ff49ced16dbd11','./lib/smarty/libs/plugins/modifier.count_characters.php','6.3',0),('c64e0f47b6435424a7bf9647eed06c1e','./lib/smarty/libs/plugins/modifier.count_paragraphs.php','6.3',0),('c22e43e96e6ecd34cc18bc5235d59337','./lib/smarty/libs/plugins/modifier.count_sentences.php','6.3',0),('073467c9ea7434647bb9ff27fe09183b','./lib/smarty/libs/plugins/modifier.count_words.php','6.3',0),('5d57183abba166f670d0b8649086f516','./lib/smarty/libs/plugins/modifier.date_format.php','6.3',0),('083998f71b350e0f2bea5b46477680c2','./lib/smarty/libs/plugins/modifier.debug_print_var.php','6.3',0),('11c16bd6f7dde6d576d7f93433652925','./lib/smarty/libs/plugins/modifier.default.php','6.3',0),('3bd0b2464f2fe8e2688da39079d84190','./lib/smarty/libs/plugins/modifier.escape.php','6.3',0),('ea1f5db88c00e850c3968e434eadb074','./lib/smarty/libs/plugins/modifier.indent.php','6.3',0),('5520933762ceac07d49e658c52587279','./lib/smarty/libs/plugins/modifier.lower.php','6.3',0),('1d16b98e8ec34aac69f0827fab1dc999','./lib/smarty/libs/plugins/modifier.nl2br.php','6.3',0),('f3ae42b7cb1bb85e22084c5d94ccb420','./lib/smarty/libs/plugins/modifier.regex_replace.php','6.3',0),('b7d144b301a878c3015f9ba96b1922c6','./lib/smarty/libs/plugins/modifier.replace.php','6.3',0),('66993120ab60306acd278a327c5af448','./lib/smarty/libs/plugins/modifier.spacify.php','6.3',0),('401048107fc62eecf175d2a0ab997161','./lib/smarty/libs/plugins/modifier.string_format.php','6.3',0),('b1281f77297db8c1e50bc1fd883ebd78','./lib/smarty/libs/plugins/modifier.strip.php','6.3',0),('481144a581e2d56a2182add2e09c5641','./lib/smarty/libs/plugins/modifier.strip_tags.php','6.3',0),('da35c3d0a2dfc9ea11c32b3a10246aa7','./lib/smarty/libs/plugins/modifier.truncate.php','6.3',0),('0ef0e9784273f5d5384f34ad303bd15e','./lib/smarty/libs/plugins/modifier.upper.php','6.3',0),('b80bdf801ac29e3aa4662a0428b676e4','./lib/smarty/libs/plugins/modifier.wordwrap.php','6.3',0),('ac1de570fd1361b24090ffce22b218e0','./lib/smarty/libs/plugins/outputfilter.trimwhitespace.php','6.3',0),('2f7221015323ba27d2ed5ae20450fa0d','./lib/smarty/libs/plugins/shared.escape_special_chars.php','6.3',0),('29ffe6553da8fda72147a12273105e10','./lib/smarty/libs/plugins/shared.make_timestamp.php','6.3',0),('58112074797eb30123fb5f6e2465d61e','./lib/smarty/unit_test/config.php','6.3',0),('2420634cf218db4740ed816ca33654b1','./lib/smarty/unit_test/smarty_unit_test.php','6.3',0),('756cf0c254cc69dc65a5adbab01be1c3','./lib/smarty/unit_test/smarty_unit_test_gui.php','6.3',0),('d62292f1b1fc7ad607687ba9f4bed56b','./lib/smarty/unit_test/test_cases.php','6.3',0),('f89a2fd3706d833a0c2a460a54828a64','./lib/smarty_tiki/block.add_help.php','6.3',0),('58a87e78a140e91f90523605b7753713','./lib/smarty_tiki/block.ajax_href.php','6.3',0),('56608842250b9d685cc0c4c27ce446ad','./lib/smarty_tiki/block.compact.php','6.3',0),('e42f5cd9b1e923f8e6f4445a3335653f','./lib/smarty_tiki/block.display.php','6.3',0),('6041b4ab19f0dc006872ef81f6a370b9','./lib/smarty_tiki/block.itemfield.php','6.3',0),('cfca04c98210c3f2e8ef32a9a85ce02a','./lib/smarty_tiki/block.jq.php','6.3',0),('245954c7474e47d5b7619e0f16a0c70c','./lib/smarty_tiki/block.modules_list.php','6.3',0),('0fda5c0f66f724ed41a3aa6b01bf76ba','./lib/smarty_tiki/block.pagination_links.php','6.3',0),('c96cbe75d4563c670742835570136213','./lib/smarty_tiki/block.permission.php','6.3',0),('8df8c903ad014a5b4ff08e28875e975b','./lib/smarty_tiki/block.popup_link.php','6.3',0),('ae40c890db868c155d082c7a3e9c3239','./lib/smarty_tiki/block.remarksbox.php','6.3',0),('0cb018f01e2721475b1c53e38c446e86','./lib/smarty_tiki/block.repeat.php','6.3',0),('f122a3d87fdc84f9318db1c5ed299751','./lib/smarty_tiki/block.self_link.php','6.3',0),('cb0a5b3c870f4d175f36d15b3bf855f8','./lib/smarty_tiki/block.sortlinks.php','6.3',0),('fdb63be1aa1ed6276577ea09530aa146','./lib/smarty_tiki/block.tab.php','6.3',0),('8c043b23be37ebba8d201a1a45582671','./lib/smarty_tiki/block.tabset.php','6.3',0),('208cb53101c487acd10604518af3481a','./lib/smarty_tiki/block.textarea.php','6.3',0),('bc5250b05b8551f1245a78287b068665','./lib/smarty_tiki/block.tikimodule.php','6.3',0),('72d93c23891b16a1da69c2b217b0594c','./lib/smarty_tiki/block.title.php','6.3',0),('f34d864cb36d88857d89ece58c27420e','./lib/smarty_tiki/block.tr.php','6.3',0),('d5c94c7bf43983aca5e0984ebaba08c7','./lib/smarty_tiki/block.translation.php','6.3',0),('aa81264a8f6c971b707776688dcdb38f','./lib/smarty_tiki/block.wiki.php','6.3',0),('00cf6d4f224ac741bcb948f55d10f58c','./lib/smarty_tiki/block.wikiplugin.php','6.3',0),('027e59c70f446cd84e9f566efb8d9a43','./lib/smarty_tiki/compiler.assign.php','6.3',0),('9350853e6b9fad47444ab30207e9f2f8','./lib/smarty_tiki/compiler.assign_content.php','6.3',0),('e5b242ba55c485419e0fec3395767c24','./lib/smarty_tiki/function.article.php','6.3',0),('77a3c8a2151bc779f6f6f89e5e99a86e','./lib/smarty_tiki/function.banner.php','6.3',0),('0e6aac77fbe66ca98fffe2729c76e6bb','./lib/smarty_tiki/function.breadcrumbs.php','6.3',0),('43f02d69194931a9f3b27efc66504eb5','./lib/smarty_tiki/function.button.php','6.3',0),('f1a947010c013fff4cfafc1c4c9f9594','./lib/smarty_tiki/function.categoryName.php','6.3',0),('35ab027914467b15f6bf533410023079','./lib/smarty_tiki/function.content.php','6.3',0),('ce74d16b1681d892c51767883abb452f','./lib/smarty_tiki/function.cookie.php','6.3',0),('0d1383d88d8361e5edcec7a57b1c0ee0','./lib/smarty_tiki/function.cookie_jar.php','6.3',0),('a29448e903026c61c12e65a1373de7dd','./lib/smarty_tiki/function.count.php','6.3',0),('6045ad9748a4c7bb1d191d67455bd877','./lib/smarty_tiki/function.debugger.php','6.3',0),('018cb6ec95e9c1ce1e76508a972b9420','./lib/smarty_tiki/function.ed.php','6.3',0),('4bece319c23ce097ff5288bfbbcb23d9','./lib/smarty_tiki/function.elapsed.php','6.3',0),('2c784013861edbb6ff9dc610cbed1c2e','./lib/smarty_tiki/function.fgal_browse.php','6.3',0),('225c11ce813f17e99fc6290af9c8f91d','./lib/smarty_tiki/function.filegal_manager_url.php','6.3',0),('9b87a4eb876d73f51fdeb0e05c2e3ef5','./lib/smarty_tiki/function.fileinfo.php','6.3',0),('7007c946ef920a7bf508b094d2b7c958','./lib/smarty_tiki/function.gallery.php','6.3',0),('0e2dd8e94461ee986d4cdb8b885fc117','./lib/smarty_tiki/function.help.php','6.3',0),('4dd2e74f7941a19033f23bd332e0bacb','./lib/smarty_tiki/function.helplink.php','6.3',0),('fe70aeb0ea59382c3a5a376185fba34c','./lib/smarty_tiki/function.html_body_attributes.php','6.3',0),('77a95513e23912a49da358861736a7ba','./lib/smarty_tiki/function.html_select_date.php','6.3',0),('54239d31a4ef5f6f7bee84c6aecc9238','./lib/smarty_tiki/function.html_select_duration.php','6.3',0),('4065db32671228b832fd287ba4e28de9','./lib/smarty_tiki/function.html_select_time.php','6.3',0),('2654b39f748f292e3b02232e1fc756f0','./lib/smarty_tiki/function.icon.php','6.3',0),('ecea4279720b1d20db8dd3e860a05eaf','./lib/smarty_tiki/function.initials_filter_links.php','6.3',0),('98f92c9f63ec20b9d1d11b46ccf08e48','./lib/smarty_tiki/function.interactivetranslation.php','6.3',0),('6951d1a66819c55c74517373b07a93bd','./lib/smarty_tiki/function.js_maxlength.php','6.3',0),('5844cb955d0f2e62abd90c4ec4a84bdb','./lib/smarty_tiki/function.jscalendar.php','6.3',0),('1d7617870fc0744c6c72d95670a3a172','./lib/smarty_tiki/function.jspopup.php','6.3',0),('4dbfa5750b6263d739b6f7de6019a0ec','./lib/smarty_tiki/function.listfilter.php','6.3',0),('9caf5fddd8c2ee9f06fe1a100c4f8278','./lib/smarty_tiki/function.memusage.php','6.3',0),('c499ff56c941c20b336d545f4fcdc254','./lib/smarty_tiki/function.menu.php','6.3',0),('7b2b200b10b1220ad1c8b35fe868f315','./lib/smarty_tiki/function.metric.php','6.3',0),('384811c38bf5e5a8df56e9fcecad1092','./lib/smarty_tiki/function.obj_in_cat.php','6.3',0),('18fee0526924e0fd66fdd5d13c9b045d','./lib/smarty_tiki/function.object_link.php','6.3',0),('876fdbd300fe188c6330fc4e649f2e4b','./lib/smarty_tiki/function.payment.php','6.3',0),('d090001297a8d2767c0c1eb829ff7a28','./lib/smarty_tiki/function.phplayers.php','6.3',0),('b4e8670bf6ea948b766f9c10c226e180','./lib/smarty_tiki/function.poll.php','6.3',0),('5c5d92226e3aa0a21bfa983f9a590297','./lib/smarty_tiki/function.popup.php','6.3',0),('2e2d3337b86b9711ebd303980dce330b','./lib/smarty_tiki/function.preference.php','6.3',0),('05cd5e0a66350ed0d78d0ff19362d8a1','./lib/smarty_tiki/function.query.php','6.3',0),('a26d568531d160f35b303b7b06875657','./lib/smarty_tiki/function.quotabar.php','6.3',0),('5c81c5596f6650a63a13f98d1a804bf0','./lib/smarty_tiki/function.rating.php','6.3',0),('6d846c20e12f427bcc61edd64d9c4b49','./lib/smarty_tiki/function.rcontent.php','6.3',0),('e7c7efe1088c0298d601a6c4e3ae0134','./lib/smarty_tiki/function.redirect.php','6.3',0),('8b0bfbcb08975ed2acd3556d56ff8f7a','./lib/smarty_tiki/function.reindex_file_pixel.php','6.3',0),('bd24f87f8c53aeed1f303b602483a195','./lib/smarty_tiki/function.rss.php','6.3',0),('429606b59c1c09107c0710d90d98baf4','./lib/smarty_tiki/function.sameurl.php','6.3',0),('51967c000aa434bb33e68ca10651e11e','./lib/smarty_tiki/function.sefurl.php','6.3',0),('a9392cfcde17444baec5a124ccf2dc24','./lib/smarty_tiki/function.select_all.php','6.3',0),('e13b6e20f31baf1b7341a69ccb82dcf7','./lib/smarty_tiki/function.set.php','6.3',0),('743bc63256f813839af574f63c58c25d','./lib/smarty_tiki/function.show_help.php','6.3',0),('b1533140cb48d162fad70a41fb18a2e2','./lib/smarty_tiki/function.show_sort.php','6.3',0),('572ebb5c144d06c22974150118f1b3e5','./lib/smarty_tiki/function.thumb.php','6.3',0),('3f067e41ec343891855634d602d4c138','./lib/smarty_tiki/function.ticket.php','6.3',0),('15e26f67be2aaedaf3d0143a31b3d7d9','./lib/smarty_tiki/function.toolbars.php','6.3',0),('d838966b90f59f2a97e29c635de69aea','./lib/smarty_tiki/function.tree.php','6.3',0),('6559688d0b5b952417c30aa971404c83','./lib/smarty_tiki/function.treetable.php','6.3',0),('e1b44cf6ea06d4de55799b95767e1862','./lib/smarty_tiki/function.user_selector.php','6.3',0),('ff7cc94cfe4a7b551aec5433650ea518','./lib/smarty_tiki/function.var_dump.php','6.3',0),('f1f5bf13a6299e1f6e292285d0d356c0','./lib/smarty_tiki/function.wikistructure.php','6.3',0),('064f506d52c794e02d967fad4faba812','./lib/smarty_tiki/function.xajax_response.php','6.3',0),('9b850953d8984882913ae2ccdc2c118e','./lib/smarty_tiki/index.php','6.3',0),('f294737b05fa979bdc4934b0c52329f7','./lib/smarty_tiki/modifier.adjust.php','6.3',0),('437f30625f4ec5201b8ba0bccc475ac7','./lib/smarty_tiki/modifier.avatarize.php','6.3',0),('dd0cc9b132e7023c5861f5d3e4ec9ca6','./lib/smarty_tiki/modifier.compactisodate.php','6.3',0),('da4b8144f6f530e520f4f6babcb15b51','./lib/smarty_tiki/modifier.countryflag.php','6.3',0),('cd22d177c8122e4fca3cf9b4de425b34','./lib/smarty_tiki/modifier.dbg.php','6.3',0),('7e6f78ef124fddb6acfe38e90466665a','./lib/smarty_tiki/modifier.div.php','6.3',0),('58210bb02ab3246681e9326363dc88cf','./lib/smarty_tiki/modifier.duration.php','6.3',0),('638ea5a860da8cba097b508ec66f496b','./lib/smarty_tiki/modifier.duration_short.php','6.3',0),('331c5be075ac95ea71e15ba612dea368','./lib/smarty_tiki/modifier.escape.php','6.3',0),('eee275c3f775046f2167d6d48109e6ea','./lib/smarty_tiki/modifier.how_many_user_inscriptions.php','6.3',0),('754d4221eeb1f5685fa8ae1d4351a957','./lib/smarty_tiki/modifier.htmldecode.php','6.3',0),('41cb6846f38c549928f79a1744e71bdf','./lib/smarty_tiki/modifier.iconify.php','6.3',0),('f2d9660c1e935aaaa13c041ad93d30cc','./lib/smarty_tiki/modifier.isodate.php','6.3',0),('21999d6e0d62e0472c62e897ca284a96','./lib/smarty_tiki/modifier.kbsize.php','6.3',0),('56a9e825fcab1e6a5e9530c7c921accd','./lib/smarty_tiki/modifier.langname.php','6.3',0),('b164a998eed2895db9ff3a2bfabe536a','./lib/smarty_tiki/modifier.lcfirst.php','6.3',0),('42cfa406838dff65e2939dd4719c8d36','./lib/smarty_tiki/modifier.max_user_inscriptions.php','6.3',0),('ca93f0abd44388ebe5b539542119ad49','./lib/smarty_tiki/modifier.money_format.php','6.3',0),('f433faea91c66b73c6a9e177855cf5f0','./lib/smarty_tiki/modifier.nlbr.php','6.3',0),('3bd2c64a8540a9a64453f348615ced6d','./lib/smarty_tiki/modifier.number_format.php','6.3',0),('c9fe5f526a9b5c5710a0c0f66326badb','./lib/smarty_tiki/modifier.pagename.php','6.3',0),('d45031416442b3fddcf452fb95b3f00c','./lib/smarty_tiki/modifier.percent.php','6.3',0),('44ee286971035e320723e01874d56085','./lib/smarty_tiki/modifier.quoted.php','6.3',0),('994ea4ff57936933be6d3560b7d51e22','./lib/smarty_tiki/modifier.sefurl.php','6.3',0),('ae892a276efbfaff7eeb0d883efd55e5','./lib/smarty_tiki/modifier.simplewiki.php','6.3',0),('e740d794b15cb709a13de756456daf84','./lib/smarty_tiki/modifier.star.php','6.3',0),('3ee90228898bae741e59bbe3c3f3b7fe','./lib/smarty_tiki/modifier.stringfix.php','6.3',0),('8b04e8567d21568819b891c69bd69002','./lib/smarty_tiki/modifier.substring.php','6.3',0),('ce807ef2c2e5965a4f2ef6a55943b873','./lib/smarty_tiki/modifier.tasklink.php','6.3',0),('3b4397827b5e51d95fb514c443d23952','./lib/smarty_tiki/modifier.tiki_date_format.php','6.3',0),('e0c7a720e1d7f521fce00b1170086ddc','./lib/smarty_tiki/modifier.tiki_long_date.php','6.3',0),('f433cda8243018467866b8522aa6e689','./lib/smarty_tiki/modifier.tiki_long_datetime.php','6.3',0),('2040aa4b5f664b79cef1d8f3d12db3d2','./lib/smarty_tiki/modifier.tiki_long_time.php','6.3',0),('00eea3f6faff6e6c6817384e7eca6846','./lib/smarty_tiki/modifier.tiki_short_date.php','6.3',0),('2f5ad08a337304f33b3d797e5c894ab3','./lib/smarty_tiki/modifier.tiki_short_datetime.php','6.3',0),('300012ac6677bacca0d12cc946801603','./lib/smarty_tiki/modifier.tiki_short_time.php','6.3',0),('54e3aa4b2e0bf02597d4f46a19207642','./lib/smarty_tiki/modifier.times.php','6.3',0),('eee37d6ab675736fd9df26590be85f1d','./lib/smarty_tiki/modifier.tr_if.php','6.3',0),('1e4e8dddada4b8926e4b1c221dd951cc','./lib/smarty_tiki/modifier.truex.php','6.3',0),('2f8993077837c2b4be0d6f86d351910d','./lib/smarty_tiki/modifier.truncate.php','6.3',0),('cd9d72c6783eebf18c14be6c1bab3063','./lib/smarty_tiki/modifier.userlink.php','6.3',0),('5458e0d7904973b34297d555ab9d72ae','./lib/smarty_tiki/modifier.username.php','6.3',0),('3dd7e5d09b92e477f2743539eaf2529a','./lib/smarty_tiki/modifier.utf8unicode.php','6.3',0),('f49f9c8b2bc695c6d4fe0b0d402bc4fe','./lib/smarty_tiki/modifier.virtual_path.php','6.3',0),('d3764ae3dc2d496515b4ff0a5be26210','./lib/smarty_tiki/modifier.yesno.php','6.3',0),('6c3b46276e1f47e5ee54e5d8a6351b8a','./lib/smarty_tiki/outputfilter.highlight.php','6.3',0),('a1fb69c163dad1dc975b44c9e6ea69d7','./lib/smarty_tiki/outputfilter.ticket.php','6.3',0),('172b6ade36754b407fa2020a335131eb','./lib/smarty_tiki/prefilter.jq.php','6.3',0),('64a7c618f8ee344dc6f9bbc0ac2d4b1b','./lib/smarty_tiki/prefilter.log_tpl.php','6.3',0),('d9d259be003634e223f7d7f6c89b5ec4','./lib/smarty_tiki/prefilter.tr.php','6.3',0),('7c69ca995509e592521dea606c5b26b7','./lib/smarty_tiki/resource.style.php','6.3',0),('272ddaa99b8d7d249a3826bdd81ce2f6','./lib/smarty_tiki/resource.wiki.php','6.3',0),('17778d18078f147ef8bfb4eec35ecf78','./lib/socialnetworkslib.php','6.3',0),('6994a8dfccef3a32445d930323ce076c','./lib/stats/index.php','6.3',0),('0e2464c41ad07f94f5b9634ff3d8292c','./lib/stats/statslib.php','6.3',0),('6994a8dfccef3a32445d930323ce076c','./lib/structures/index.php','6.3',0),('1e657a1fc18e792ea7065be309d3d71c','./lib/structures/structlib.php','6.3',0),('6994a8dfccef3a32445d930323ce076c','./lib/surveys/index.php','6.3',0),('7d6f5607cfa214380874d8617c7e70a2','./lib/surveys/surveylib.php','6.3',0),('6994a8dfccef3a32445d930323ce076c','./lib/taglines/index.php','6.3',0),('938250911fd02ee7f4e03bcf000edd09','./lib/taglines/taglinelib.php','6.3',0),('501357faef2762b6bdfa944716cca43b','./lib/tail/index.php','6.3',0),('e38cdfab0a5d67f3c0debf6d4cab7da6','./lib/tar.class.php','6.3',0),('6994a8dfccef3a32445d930323ce076c','./lib/tasks/index.php','6.3',0),('328e940155a8c498f3c1fb6c4dc74eec','./lib/tasks/tasklib.php','6.3',0),('6994a8dfccef3a32445d930323ce076c','./lib/templates/index.php','6.3',0),('5d14ad43703983b9d543ab16bd07b106','./lib/templates/templateslib.php','6.3',0),('6893ee9cfff7497d103af8f298687434','./lib/test/AcceptanceTests/AllTests.php','6.3',0),('00620c25c5b082739ec7da2014d6aac6','./lib/test/AcceptanceTests/CollaborativeMultilingualTerminologyTest.php','6.3',0),('881638253c3bd15b3ebcd536ce6023b3','./lib/test/AcceptanceTests/ListPagesTest.php','6.3',0),('727f83aa8bddd9fd925814ee11ba9f1a','./lib/test/AcceptanceTests/MultilingualTest.php','6.3',0),('c0faf37a36d98d9b7d406895bf264de2','./lib/test/AcceptanceTests/MultilinguallibTest.php','6.3',0),('d84cf9367915b7098e3b9b3dad1776c9','./lib/test/AcceptanceTests/SearchTest.php','6.3',0),('d89c03a0994ca5121f7063f9431b9901','./lib/test/AcceptanceTests/TikiLibrariesAccessTest.php','6.3',0),('e8437ea77ad140d2d0e178741d0596c5','./lib/test/AcceptanceTests/utils/create_dump_db_file.php','6.3',0),('2f0ddd0a61cc5d4da0db8c5e83463d55','./lib/test/AcceptanceTests/utils/restore_db_dump.php','6.3',0),('2011b49313e2ce5000f118a9e3dbda20','./lib/test/AcceptanceTests/utils/upgrade_test_database_dump_file.php','6.3',0),('f2021004e9e4ddbb189ce118d820e562','./lib/test/AllTestsAcceptance.php','6.3',0),('47d0d44408975c42924d6c057bdac08a','./lib/test/Calendar/DateTest.php','6.3',0),('3eef0f62e0164f743316f0131da831f2','./lib/test/Calendar/index.php','6.3',0),('d14314d4f64ed5150214a8a187cd128d','./lib/test/TikiAcceptanceTestDBRestorer.php','6.3',0),('4dad28ac72a86edcbd7a028a51f844f0','./lib/test/TikiLib/WikiParserTest.php','6.3',0),('e9c5501d414d955c9afab6c0e8188061','./lib/test/TikiSeleniumTestCase.php','6.3',0),('ebf60cba9008670c1fc2508b5f88762e','./lib/test/TikiTestCase.php','6.3',0),('5cb48100522ad08084e3f6302d4c6a1c','./lib/test/attributes/AttributeTest.php','6.3',0),('db5fc0f7f40eea39b659f1b8929198dc','./lib/test/attributes/RelationTest.php','6.3',0),('67b668c1375346a175beb011a17bb374','./lib/test/auth/AuthTokensTest.php','6.3',0),('7ea2c92a9b9217eb33c163b17b19dd3a','./lib/test/auth/MembershipTest.php','6.3',0),('e129fe9793beb24133b6844d76e76930','./lib/test/bootstrap.php','6.3',0),('43582194de52b49e9174410281891d94','./lib/test/core/Category/ManipulatorTest.php','6.3',0),('bdf4375587d2b17d56afe4f642731be1','./lib/test/core/DeclFilter/BaseTest.php','6.3',0),('60dacf7aae626a0750d9bee2f0dc4be7','./lib/test/core/DeclFilter/CatchAllFilterTest.php','6.3',0),('3ce96654c6028ef26e2c7759fae300e2','./lib/test/core/DeclFilter/CatchAllUnsetTest.php','6.3',0),('cd60b0c081255ec5e334903c0a425a86','./lib/test/core/DeclFilter/ConfigureTest.php','6.3',0),('754866bca4ac9f926880781d2efdb16c','./lib/test/core/DeclFilter/KeyPatternFilterTest.php','6.3',0),('8b7029f1926e38e6a2f32a9a88f5c50e','./lib/test/core/DeclFilter/KeyPatternUnsetTest.php','6.3',0),('adcdc58618d6c7ada8e75655fd9795e4','./lib/test/core/DeclFilter/StaticKeyFilterTest.php','6.3',0),('1a736f4675711f8388a5f1461dab19dc','./lib/test/core/DeclFilter/StaticKeyUnsetTest.php','6.3',0),('591f398feecccc27aedfd79d5b4035e8','./lib/test/core/JitFilter/AccessTest.php','6.3',0),('eedf46c98823cb96ccd9ec523791659f','./lib/test/core/JitFilter/FilterTest.php','6.3',0),('bab31b0ed50794aa2dd3e15e4f360799','./lib/test/core/JitFilter/IteratorTest.php','6.3',0),('ea54d514dbde69fab8781555cafb900a','./lib/test/core/Math/Formula/DummyFunction/FortyTwo.php','6.3',0),('223ce320453f566ee7a9ff00f0218205','./lib/test/core/Math/Formula/DummyFunction/Testop.php','6.3',0),('50010b3b2b22c8b63872d35d38dda409','./lib/test/core/Math/Formula/ElementTest.php','6.3',0),('e60b260e08d87c48766504d2797a18e1','./lib/test/core/Math/Formula/ParserTest.php','6.3',0),('e996a9d2e62e3ddafc9d85c6b782fb78','./lib/test/core/Math/Formula/RunnerTest.php','6.3',0),('05f448c3485282c8665133224662acbc','./lib/test/core/Math/Formula/TokenizerTest.php','6.3',0),('2ca04ad626fdfca3f766c5d35528e46c','./lib/test/core/Multilingual/Aligner/BilingualAlignerTest.php','6.3',0),('7fd17ae6539ed0aa33cc2508b107a0d9','./lib/test/core/Multilingual/Aligner/SentenceAlignmentsTest.php','6.3',0),('bfb8fbbff9df17ec4841efdf5e76a163','./lib/test/core/Multilingual/Aligner/SentenceSegmentorTest.php','6.3',0),('3c03b5394936b58ad7a5ebe7f4ea75e4','./lib/test/core/Multilingual/Aligner/ShortestPathFinderTest.php','6.3',0),('53719b334fce388137abb3daa223d3d2','./lib/test/core/Multilingual/Aligner/UpdatePagesTest.php','6.3',0),('a80579d8c247fc58765e51cfba4d7b6f','./lib/test/core/Multilingual/MachineTranslation/GoogleTranslateWrapperTest.php','6.3',0),('312a59909a3025f46eebbab64c749657','./lib/test/core/Perms/AccessorTest.php','6.3',0),('1ea8da9d55889dffbe3fd3c0fe3175b4','./lib/test/core/Perms/ApplierTest.php','6.3',0),('bfa42e6774379787c2c303c31629bf9e','./lib/test/core/Perms/BaseTest.php','6.3',0),('18d9b1ec8147e70caa55c93a1558d80d','./lib/test/core/Perms/Check/AlternateTest.php','6.3',0),('8be2a00d431c6c39aae670af875604d8','./lib/test/core/Perms/Check/CreatorTest.php','6.3',0),('a8ab9c5bf661a46149d2985b3a2da45c','./lib/test/core/Perms/Check/DirectTest.php','6.3',0),('def943cb587dc9aaffc6b0aefe6653d4','./lib/test/core/Perms/Check/IndirectTest.php','6.3',0),('68a64c058f65fa547d31fca7a2ece5ad','./lib/test/core/Perms/CheckSequenceTest.php','6.3',0),('eb758918a008e81cd15ec1ebf3f1d263','./lib/test/core/Perms/MixedTest.php','6.3',0),('bacb172c831f5ef2eaae66b106fd0cf6','./lib/test/core/Perms/Reflection/FactoryTest.php','6.3',0),('a8c3dba7d26b5201637b657a3fed524c','./lib/test/core/Perms/Reflection/PermissionComparatorTest.php','6.3',0),('d30ac72358b8a3868181f56c81521fea','./lib/test/core/Perms/Reflection/PermissionSetTest.php','6.3',0),('be21a3cf0380e5a2676a7fb2681762dd','./lib/test/core/Perms/Reflection/QuickTest.php','6.3',0),('e26accc43e1cc16f4fc173251d53aec8','./lib/test/core/Perms/Resolver/DefaultTest.php','6.3',0),('9de3b7a65856a36076ac737beec19b94','./lib/test/core/Perms/Resolver/StaticTest.php','6.3',0),('742a7a19408c68c3c881138a13c3baee','./lib/test/core/Perms/ResolverFactory/CategoryFactoryTest.php','6.3',0),('1d3e4257c1a2b41673f052c64ebdde16','./lib/test/core/Perms/ResolverFactory/GlobalFactoryTest.php','6.3',0),('83fd157fc5b80a81888b27bb78cd2dfa','./lib/test/core/Perms/ResolverFactory/ObjectFactoryTest.php','6.3',0),('8954d3c2013064d03575938d253a325d','./lib/test/core/Perms/ResolverFactory/TestFactoryTest.php','6.3',0),('544e061d7783d60ebaac4b64bd661cfb','./lib/test/core/TikiFilter/CallbackTest.php','6.3',0),('f3b53e13852c9f7b34af09625576d5d4','./lib/test/core/TikiFilter/MapTest.php','6.3',0),('74629be2af2923eadbd2b30d1e568660','./lib/test/core/TikiFilter/WordTest.php','6.3',0),('f90a8f023fa2bee979b951a63d9fe813','./lib/test/core/TikiFilter/XssTest.php','6.3',0),('522409cdb9bb7da05421b239e4609955','./lib/test/core/Transition/AtLeastTest.php','6.3',0),('23c8923433fcfe2ef88ab49c83fb13ef','./lib/test/core/Transition/AtMostTest.php','6.3',0),('f6b400a45f41565e8139f041cf96c700','./lib/test/core/Transition/BasicTest.php','6.3',0),('d9ee9d2e8f31cd04ca421404d669f4d1','./lib/test/core/WikiParser/OutputLinkTest.php','6.3',0),('f1d03066b8f2b875af3afbdab1b2dfe5','./lib/test/core/WikiParser/PluginArgumentParserTest.php','6.3',0),('c09b7afd7f21bc7dbad6076679e7a49f','./lib/test/core/WikiParser/PluginMatcherTest.php','6.3',0),('c183c4e7854493499c9822fbe1cf7127','./lib/test/core/WikiParser/PluginOutputTest.php','6.3',0),('96f8267b02c9d0fd36961b7997dfc0f4','./lib/test/core/WikiParser/PluginParserTest.php','6.3',0),('9ae80e080ee0e6daca3e24f97d378982','./lib/test/core/WikiParser/PluginRepositoryTest.php','6.3',0),('001aba33039748009e415c257d9b8786','./lib/test/core/WikiParser/wikiplugin_foo.php','6.3',0),('e29c55f494363eb5c6d9bffe1e04fd5e','./lib/test/core/bootstrap.php','6.3',0),('f9d263d97327ef640e5926a43955f5e6','./lib/test/core/include_non_autoload_compatible_classes.php','6.3',0),('2956d116b3f936c320299b867b037194','./lib/test/freetag/FreetagTest.php','6.3',0),('c30ebc985f0532712e387ad680356cc5','./lib/test/freetag/index.php','6.3',0),('aa128010913e70ead96bc35501c66837','./lib/test/importer/TikiImporterTest.php','6.3',0),('624c47dc3c929c0be1bfde461c936e1c','./lib/test/importer/TikiImporterWikiMediawikiTest.php','6.3',0),('13959ee8fd65ee24691fd74ae430d1ed','./lib/test/importer/TikiImporterWikiTest.php','6.3',0),('f123b850e2213ac7224a06205365fcb1','./lib/test/importer/fixtures/index.php','6.3',0),('da046856ba43157294d69fe35f841f04','./lib/test/importer/fixtures/mediawiki_page_as_array.php','6.3',0),('47a363ac1ed84e2be029bd0efd726794','./lib/test/importer/index.php','6.3',0),('1a8552eb28f6a62b6e808ec70349b335','./lib/test/importer/tikiimporter_testcase.php','6.3',0),('709f659fa552407e4e64ed232e114a69','./lib/test/index.php','6.3',0),('7432afbdf61e908729769ddbb41c2860','./lib/test/language/LanguageTest.php','6.3',0),('f40161b7ada34cf5bff59183e1dfa679','./lib/test/language/fixtures/custom.php','6.3',0),('66ea2adc2f9f9f2ea83beaa6a2da771a','./lib/test/language/fixtures/index.php','6.3',0),('5a16a6c4ecbee90560bb8e7320847b7a','./lib/test/language/fixtures/language_invalid.php','6.3',0),('4ddcce0acad2a21e53c8a5646f0f0189','./lib/test/language/fixtures/language_modif.php','6.3',0),('49c40c615add43c31f3fcba6a739b798','./lib/test/language/fixtures/language_orig.php','6.3',0),('66ea2adc2f9f9f2ea83beaa6a2da771a','./lib/test/language/index.php','6.3',0),('1fbf171fe363e07fa90c0c86636862b9','./lib/test/payment/CartTest.php','6.3',0),('5adefeeeb86b95aa719907ef22b082d4','./lib/test/rating/AggregationTest.php','6.3',0),('f4c0c9e03a8829d75fb601c64291a05e','./lib/test/rating/RegisterVoteTest.php','6.3',0),('78d6e3774eac6aa31d1371da54f12a19','./lib/test/shipping/ShippingTest.php','6.3',0),('a1c8e0f3b6bb3f38643a1e3d7c4fa437','./lib/test/smarty_tiki/ModifierDurationTest.php','6.3',0),('4dac6e443dcbee40839b5cf3b449277f','./lib/test/smarty_tiki/index.php','6.3',0),('6994a8dfccef3a32445d930323ce076c','./lib/themecontrol/index.php','6.3',0),('b93d9a5d8f3129b091d9eaee753c902d','./lib/themecontrol/tcontrol.php','6.3',0),('f877c8df2dd7d36ddcc43fb92ada0fce','./lib/tiki-dynamic-js.php','6.3',0),('28b99f45fe08659df59220596ff93128','./lib/tikiaccesslib.php','6.3',0),('7e08df01b915bc381307e8578cfeebd6','./lib/tikidate-pear-date.php','6.3',0),('1b9b521a8f166c0b7336e44af41ede15','./lib/tikidate-php5.php','6.3',0),('a4a6fd9c486e99e25cef5f24c89d3888','./lib/tikidate.php','6.3',0),('c531fb56f9a0118ca56eeefd1b28e569','./lib/tikihelp/css/index.php','6.3',0),('c531fb56f9a0118ca56eeefd1b28e569','./lib/tikihelp/icons/index.php','6.3',0),('6994a8dfccef3a32445d930323ce076c','./lib/tikihelp/index.php','6.3',0),('c531fb56f9a0118ca56eeefd1b28e569','./lib/tikihelp/js/index.php','6.3',0),('c531fb56f9a0118ca56eeefd1b28e569','./lib/tikihelp/menu/index.php','6.3',0),('7910ee064aa6a423383ccddb4e2d5971','./lib/tikihelplib.php','6.3',0),('426529b183586dcda382f92a2f462ffd','./lib/tikilib.php','6.3',0),('49028c6bfe55fe1fdfd3ec4bbf89c994','./lib/tikisession-adodb.php','6.3',0),('a541a1c9886915c7b8956198df08366d','./lib/tikisession-memcache.php','6.3',0),('5edbc7d4bde68627dc1d08b65ea01995','./lib/tikisession-pdo.php','6.3',0),('34af4444d5adaa290ddc3908c8fa46a8','./lib/tikiticketlib.php','6.3',0),('4a67251b091409c87cb3c0e0ecf80a49','./lib/todolib.php','6.3',0),('207496f98195c5ae532cbc884931f812','./lib/toolbars/index.php','6.3',0),('f6b34ee91a9238bd47f53d50def2de81','./lib/toolbars/toolbarslib.php','6.3',0),('207496f98195c5ae532cbc884931f812','./lib/trackers/index.php','6.3',0),('b678e6ad3e3fa2d176b07e4bccbb0ce7','./lib/trackers/trackerlib.php','6.3',0),('739b8640f7b5c1ba61a55ff7604f33b0','./lib/transitionlib.php','6.3',0),('504c9262c69f246b658d283a8d98e090','./lib/tree/categ_admin_tree.php','6.3',0),('a1c804bb1851b16e7a6b08939618f3d9','./lib/tree/categ_browse_tree.php','6.3',0),('860103152b21216991f765252bf8c5b9','./lib/tree/categ_picker_tree.php','6.3',0),('207496f98195c5ae532cbc884931f812','./lib/tree/index.php','6.3',0),('c199dbac9714e9488d0ca6aa60812a4b','./lib/tree/tree.php','6.3',0),('71574687bc1c2a97b62c2e85ab774402','./lib/userfiles/index.php','6.3',0),('f52b2e2c5265468f3b69b36ca6e4cbb2','./lib/userfiles/userfileslib.php','6.3',0),('71574687bc1c2a97b62c2e85ab774402','./lib/usermenu/index.php','6.3',0),('6d66c49bb132f786df56998d90925443','./lib/usermenu/usermenulib.php','6.3',0),('71574687bc1c2a97b62c2e85ab774402','./lib/usermodules/index.php','6.3',0),('c4973eb6a2ffe5587dcd71fa712d25ee','./lib/usermodules/usermoduleslib.php','6.3',0),('71574687bc1c2a97b62c2e85ab774402','./lib/userprefs/index.php','6.3',0),('a97b8a2e48c68efa18f08383555d8660','./lib/userprefs/scrambleEmail.php','6.3',0),('4d579b03bfa83ec825d2e7df4046e3a0','./lib/userprefs/userprefslib.php','6.3',0),('dbe1ca74e675b28c72a14e5432452fda','./lib/userslib.php','6.3',0),('91dc57113591a10ce75030d95f3d1c33','./lib/validators/validator_distinct.php','6.3',0),('3d599329489da041dccdddadba89fadd','./lib/validators/validator_password.php','6.3',0),('4a57348d2e7a6803a7619da79efcbb1b','./lib/validators/validator_regex.php','6.3',0),('a694c856c87bd81cbe74534373c2a9d6','./lib/validators/validator_username.php','6.3',0),('78fd0134527b88add073124c827b8f29','./lib/validatorslib.php','6.3',0),('cea319b3d0f92d512044f0231da3bc10','./lib/videogals/KalturaClient.php','6.3',0),('6468f94457263d4973f009c90b30c467','./lib/videogals/KalturaClientBase.php','6.3',0),('72e6ce3a58c14b87498583ae67b4e59e','./lib/videogals/videogallib.php','6.3',0),('440194a4f692ea196fe09b1911b7e213','./lib/videogals/watershedlib.php','6.3',0),('a5980754a2d99440d8c0afbbcdc6773a','./lib/webdav/webdavlib.php','6.3',0),('4bc342943544b274bbce25d7cc5b321c','./lib/webmail/class.rc4crypt.php','6.3',0),('8c3db1fd2fe3f19a9f91dacf2fdecbfb','./lib/webmail/contactlib.php','6.3',0),('ffc3b2f6dd3283434eac1a98f33b3b54','./lib/webmail/decodemessage.php','6.3',0),('cdb456806fac7ebb1b4795fe1a909cc6','./lib/webmail/example.1.php','6.3',0),('aa858939e0343a76b48cfbf03a5c2a0e','./lib/webmail/htmlMimeMail.php','6.3',0),('b184d03ce8864382effe63168692d673','./lib/webmail/index.php','6.3',0),('2199806e1fe69a09e62cccf5674e7558','./lib/webmail/mail.php','6.3',0),('cf5b7499896ea2caf3467aa583b32cc5','./lib/webmail/mimeDecode.php','6.3',0),('91991b2cc6d3abacfd4171ac2d1b68b2','./lib/webmail/net_pop3.php','6.3',0),('0c896e7d796df2b28f111989d741f54c','./lib/webmail/tikimaillib.php','6.3',0),('973068cf9c817954fad9280ad03567ca','./lib/webmail/webmaillib.php','6.3',0),('9def0a61375daf46abc3e45d3c1b59ea','./lib/webservicelib.php','6.3',0),('b2da60e1503476889cfe5bf124c0ec14','./lib/wiki-plugins/index.php','6.3',0),('4f3f1cb168161f8eadfcd0ac46bb0b25','./lib/wiki-plugins/wikiplugin_addtocart.php','6.3',0),('b70f19c1863c927aabfb5236dbabde8a','./lib/wiki-plugins/wikiplugin_addtogooglecal.php','6.3',0),('a28273c5853acda6c13d7c93c5be0e95','./lib/wiki-plugins/wikiplugin_agentinfo.php','6.3',0),('03051454d4846069190944ddd1d07a79','./lib/wiki-plugins/wikiplugin_alink.php','6.3',0),('5fcb3a3fc3c6af93b8d65500eda101ff','./lib/wiki-plugins/wikiplugin_aname.php','6.3',0),('34ccab84f375c3d304dbc4ad86e8ce3a','./lib/wiki-plugins/wikiplugin_annotation.php','6.3',0),('a87a6bd1490f446123eeb05335d0bc06','./lib/wiki-plugins/wikiplugin_archivebuilder.php','6.3',0),('f30f30af38131f649793b399376a1b0c','./lib/wiki-plugins/wikiplugin_article.php','6.3',0),('9adc01b11a713a01eadca802f182c6df','./lib/wiki-plugins/wikiplugin_articles.php','6.3',0),('eaddc5923e5c7f7eb7e7744cc8107f3d','./lib/wiki-plugins/wikiplugin_attach.php','6.3',0),('f944ec940151aebbd13d075d03245a3a','./lib/wiki-plugins/wikiplugin_attributes.php','6.3',0),('0587c353b2f331f0045c8128c618d4ca','./lib/wiki-plugins/wikiplugin_author.php','6.3',0),('d7984c6c5c9ab7f921557ba3e5ce676f','./lib/wiki-plugins/wikiplugin_avatar.php','6.3',0),('a1c036eb560571a477dbc4966b5d0a01','./lib/wiki-plugins/wikiplugin_back.php','6.3',0),('654e75966de910ea97c17320d37d5ee7','./lib/wiki-plugins/wikiplugin_backlinks.php','6.3',0),('cf864a9b70ab638ca3d0f63c251a6fd6','./lib/wiki-plugins/wikiplugin_banner.php','6.3',0),('8af328686b3f344098359a5a2e579285','./lib/wiki-plugins/wikiplugin_bigbluebutton.php','6.3',0),('e15e7e86bf3c21bccb0d91ac2f3daba0','./lib/wiki-plugins/wikiplugin_bliptv.php','6.3',0),('fa55d997f570f3b2eb2750a45b40a1da','./lib/wiki-plugins/wikiplugin_bloglist.php','6.3',0),('5d7a788965a3e895ef2513fe1b3c65db','./lib/wiki-plugins/wikiplugin_box.php','6.3',0),('4939d87c2d16651153e893b9f80d6239','./lib/wiki-plugins/wikiplugin_button.php','6.3',0),('631ad9ae6ad7e07a06a30eb74ae66828','./lib/wiki-plugins/wikiplugin_calendar.php','6.3',0),('20228eee2783b4cd789a66f4d5dd036b','./lib/wiki-plugins/wikiplugin_category.php','6.3',0),('98d077e24fcdc55c359368c7c20f24ea','./lib/wiki-plugins/wikiplugin_catorphans.php','6.3',0),('ffd9569cac9d8c2a2781e6f9c5b1d9b2','./lib/wiki-plugins/wikiplugin_catpath.php','6.3',0),('aeefd5caa62b32e610b4d5f6ebc97db7','./lib/wiki-plugins/wikiplugin_cclite.php','6.3',0),('4fc3f8e630900d3c64d165f45fac9253','./lib/wiki-plugins/wikiplugin_center.php','6.3',0),('88474c4c3f8490e6abd0de68104f8aa8','./lib/wiki-plugins/wikiplugin_chart.php','6.3',0),('7ee3d9707c1d4abebad4ea7b658b192d','./lib/wiki-plugins/wikiplugin_code.php','6.3',0),('29834c900c6d40b175075f8e180f55ac','./lib/wiki-plugins/wikiplugin_colorbox.php','6.3',0),('ccee98a5a96a9fb6ad8909ff94099714','./lib/wiki-plugins/wikiplugin_content.php','6.3',0),('a2670cb3faf1adb6c1af006906beaf38','./lib/wiki-plugins/wikiplugin_cookie.php','6.3',0),('5536cc35363af379e16611e1c4ae9cf1','./lib/wiki-plugins/wikiplugin_copyright.php','6.3',0),('1b153e8f9d17be873b69b820b95fc1cf','./lib/wiki-plugins/wikiplugin_countdown.php','6.3',0),('699c243519e0f800380a48a71812baeb','./lib/wiki-plugins/wikiplugin_datachannel.php','6.3',0),('82a49b6aaaf4acda5b1ba4f0764b2984','./lib/wiki-plugins/wikiplugin_dbreport.php','6.3',0),('211e49974364a282a93f61b8aa36b685','./lib/wiki-plugins/wikiplugin_div.php','6.3',0),('46b3be0d66dfbf14927e3da3371dff07','./lib/wiki-plugins/wikiplugin_dl.php','6.3',0),('0970cf66d32c8336ac0e8c90477b607b','./lib/wiki-plugins/wikiplugin_equation.php','6.3',0),('691fa0df28cefa8f6699c9de63ac57e2','./lib/wiki-plugins/wikiplugin_events.php','6.3',0),('8788dd340de4679ae8723684ac3ab7ef','./lib/wiki-plugins/wikiplugin_fade.php','6.3',0),('e374ae4bf2f48b24a4beb1a1b118ae5a','./lib/wiki-plugins/wikiplugin_fancylist.php','6.3',0),('747b351a3ec155db5a5e95698e3a4ca6','./lib/wiki-plugins/wikiplugin_fancytable.php','6.3',0),('f727be4cb85c39ea718c139ff7671e6c','./lib/wiki-plugins/wikiplugin_file.php','6.3',0),('54573291e7eadef5634f182e8492e2bb','./lib/wiki-plugins/wikiplugin_files.php','6.3',0),('fa12b9f50e96939b20288ad817f208c4','./lib/wiki-plugins/wikiplugin_flash.php','6.3',0),('ff3dc40a37f303c185ece2ff199d8e4e','./lib/wiki-plugins/wikiplugin_footnote.php','6.3',0),('74cf9137ba4d7252347a88faea62404c','./lib/wiki-plugins/wikiplugin_footnotearea.php','6.3',0),('cacd3b3ca29625ba9616fc489540d4f4','./lib/wiki-plugins/wikiplugin_freetagged.php','6.3',0),('59fd6a424584b216e70895aea69860d6','./lib/wiki-plugins/wikiplugin_ftp.php','6.3',0),('36b6599cf0aae4d26fa840d5069492f2','./lib/wiki-plugins/wikiplugin_gauge.php','6.3',0),('139d269d13313f36120b846e0ab61ee6','./lib/wiki-plugins/wikiplugin_googleanalytics.php','6.3',0),('816b7f1add4a436e5b14f6b8e60d3dab','./lib/wiki-plugins/wikiplugin_googledoc.php','6.3',0),('60fdd1af09e4515f6a52b6d213810dee','./lib/wiki-plugins/wikiplugin_googlemap.php','6.3',0),('0f30f76f054581361956207f09cf631a','./lib/wiki-plugins/wikiplugin_group.php','6.3',0),('5fc75eda6440a0162ddc4e88b20835cf','./lib/wiki-plugins/wikiplugin_grouplist.php','6.3',0),('af42da125b19fe1d96355e2e1b9cfbcf','./lib/wiki-plugins/wikiplugin_groupmailcore.php','6.3',0),('21382b544cd1fa6a3e4294c57aff7f2a','./lib/wiki-plugins/wikiplugin_groupstat.php','6.3',0),('295a236e081d8c09480d54d75118c8cc','./lib/wiki-plugins/wikiplugin_html.php','6.3',0),('a99868d5ba8aebc7404234aa79f948d3','./lib/wiki-plugins/wikiplugin_iframe.php','6.3',0),('449824c0fbe02626d6091b9e03fc5131','./lib/wiki-plugins/wikiplugin_img.php','6.3',0),('32c0603ef05e5f9b2aa28febc9288b8c','./lib/wiki-plugins/wikiplugin_include.php','6.3',0),('c92e45f3b8901bc5020d1ecbe4f4aa1e','./lib/wiki-plugins/wikiplugin_invite.php','6.3',0),('025057d86b2f4a780177ab5f0a0ad4b4','./lib/wiki-plugins/wikiplugin_jabber.php','6.3',0),('8d3bbd6053b3efa41f2d2792202917c6','./lib/wiki-plugins/wikiplugin_jq.php','6.3',0),('0c7573020f2f3cd32393d03bbc477626','./lib/wiki-plugins/wikiplugin_js.php','6.3',0),('78decf6d5be78bbc6dc787cb8e3c8df0','./lib/wiki-plugins/wikiplugin_kaltura.php','6.3',0),('891706c05f55b6f959a12a6df641d3d6','./lib/wiki-plugins/wikiplugin_lang.php','6.3',0),('461a63de4d1fc8dac7d2297e43cda742','./lib/wiki-plugins/wikiplugin_lastmod.php','6.3',0),('706501bf8fa0582bcc0ebd3362c798cf','./lib/wiki-plugins/wikiplugin_listpages.php','6.3',0),('6a349fee2a94246ee1b29b85a195d393','./lib/wiki-plugins/wikiplugin_lsdir.php','6.3',0),('8f66fb6662d16749c8b629f81bc169d8','./lib/wiki-plugins/wikiplugin_mail.php','6.3',0),('d2eea55e322b1f436e9a06d9a64a9ee8','./lib/wiki-plugins/wikiplugin_map.php','6.3',0),('01515fb66c594c96ae5dffd54ab64df3','./lib/wiki-plugins/wikiplugin_mcalendar.php','6.3',0),('a02cd53cf546449551613c74e967105a','./lib/wiki-plugins/wikiplugin_mediaplayer.php','6.3',0),('a9cacae514de1f0f52c70a31d9b0f99a','./lib/wiki-plugins/wikiplugin_memberlist.php','6.3',0),('9d44d4dcf4fcb62379cb5fbeec5fd3f2','./lib/wiki-plugins/wikiplugin_memberpayment.php','6.3',0),('1dd750b8d306bb376e84c880a62cea20','./lib/wiki-plugins/wikiplugin_miniquiz.php','6.3',0),('9f0e4901ba8c1e4f5b9b68e14c081cc7','./lib/wiki-plugins/wikiplugin_module.php','6.3',0),('16883f8ee46de93ab94458c4af737de4','./lib/wiki-plugins/wikiplugin_mono.php','6.3',0),('69c83557d100d7a3f9770b9e4559e5d0','./lib/wiki-plugins/wikiplugin_mouseover.php','6.3',0),('4b9f1053a617a8b876e1dae595ca2327','./lib/wiki-plugins/wikiplugin_mwtable.php','6.3',0),('155598559dec17fcf31e3b3b7c67d139','./lib/wiki-plugins/wikiplugin_myspace.php','6.3',0),('dd3153c707873cbff4ad0b2410400c63','./lib/wiki-plugins/wikiplugin_objecthits.php','6.3',0),('e81d3c3c24920c52b4cfc014c452384e','./lib/wiki-plugins/wikiplugin_payment.php','6.3',0),('185ddd3de0d75258992030a6ee2cb5ee','./lib/wiki-plugins/wikiplugin_perm.php','6.3',0),('fcd9ee571bc1b4de1d5d805c1c1e1ca0','./lib/wiki-plugins/wikiplugin_pluginmanager.php','6.3',0),('a5ff412e4effdd657eac9efd04234c0b','./lib/wiki-plugins/wikiplugin_poll.php','6.3',0),('9bc9f3355276b5781d769fa0aa8faa5f','./lib/wiki-plugins/wikiplugin_profile.php','6.3',0),('905ec7a852d89aea651f756e5cb80631','./lib/wiki-plugins/wikiplugin_proposal.php','6.3',0),('c084c237f21af6127b1a89974c212d4a','./lib/wiki-plugins/wikiplugin_quote.php','6.3',0),('994ebea8bf87855ecc8d8cdfce366f46','./lib/wiki-plugins/wikiplugin_randominclude.php','6.3',0),('ae929f88218bade65e4596740a50c60b','./lib/wiki-plugins/wikiplugin_rcontent.php','6.3',0),('d39304bf0aa75691482f36faf4a539ad','./lib/wiki-plugins/wikiplugin_realnamelist.php','6.3',0),('0bfb28b4da3ede13683f2192d427458a','./lib/wiki-plugins/wikiplugin_redirect.php','6.3',0),('f221883a671e984dfd5c59d48946cc40','./lib/wiki-plugins/wikiplugin_regex.php','6.3',0),('0490ce819ecee1aeef943589c76a83a5','./lib/wiki-plugins/wikiplugin_remarksbox.php','6.3',0),('710ef00afbddf8b6693696f9b9f12faf','./lib/wiki-plugins/wikiplugin_rss.php','6.3',0),('e997d20784404e2d346f7428cd00f863','./lib/wiki-plugins/wikiplugin_scroll.php','6.3',0),('b38e724f6a846d41a02392fb8ca3fb7d','./lib/wiki-plugins/wikiplugin_sf.php','6.3',0),('9100758dc6bff2a7eb82cc3c4542eea8','./lib/wiki-plugins/wikiplugin_sharethis.php','6.3',0),('d7492d0d76ab9826bf5e0e3eca4e108b','./lib/wiki-plugins/wikiplugin_sheet.php','6.3',0),('f8ebf664ab1aeeb2273f2c3c152ed0ee','./lib/wiki-plugins/wikiplugin_showpages.php','6.3',0),('df5563572a2d1a8fa181a9f4c5017acb','./lib/wiki-plugins/wikiplugin_skype.php','6.3',0),('828758ee2345fe69f9738c441a54bd91','./lib/wiki-plugins/wikiplugin_smarty.php','6.3',0),('05b0288cb7912d7a47d47ab8032b219d','./lib/wiki-plugins/wikiplugin_snarf.php','6.3',0),('a3eda96336fb8b2a0583f7d670b65087','./lib/wiki-plugins/wikiplugin_sort.php','6.3',0),('b9595ce9803b52f963e14fa1beed676d','./lib/wiki-plugins/wikiplugin_split.php','6.3',0),('71a3692deebf693a984d605184fa6a14','./lib/wiki-plugins/wikiplugin_sql.php','6.3',0),('6d9b96857c860262fd7f3bcb52470c81','./lib/wiki-plugins/wikiplugin_stat.php','6.3',0),('270208040394974028d717f2e571232c','./lib/wiki-plugins/wikiplugin_sub.php','6.3',0),('20b3cafcb1c6d24764f6348d523dcf1c','./lib/wiki-plugins/wikiplugin_subscribegroup.php','6.3',0),('2cdc56fb7b26c80db7cd2d2fab886dbb','./lib/wiki-plugins/wikiplugin_subscribegroups.php','6.3',0),('fa7ed633f57ea663460cc48fbe0f70cf','./lib/wiki-plugins/wikiplugin_subscribenewsletter.php','6.3',0),('bff9d86c5086b8ed68e64a71678053c9','./lib/wiki-plugins/wikiplugin_sup.php','6.3',0),('525bf61b00577758a13deb06ceea450c','./lib/wiki-plugins/wikiplugin_survey.php','6.3',0),('1e351452a78d1a995b42512b5c6e91b9','./lib/wiki-plugins/wikiplugin_tabs.php','6.3',0),('cf4c6216fc0c663a02bd34abfc92db37','./lib/wiki-plugins/wikiplugin_tag.php','6.3',0),('265de5ece731bf6c4840f720f7bd402a','./lib/wiki-plugins/wikiplugin_titlesearch.php','6.3',0),('7236084c564f511906091a37329f7532','./lib/wiki-plugins/wikiplugin_toc.php','6.3',0),('8734bee35b3643809d766a0438ccf740','./lib/wiki-plugins/wikiplugin_topfriends.php','6.3',0),('078c513b51c1460d93ae39d519d7ff66','./lib/wiki-plugins/wikiplugin_tr.php','6.3',0),('07841464aabe2ad8fe064dd5e2fa2a3c','./lib/wiki-plugins/wikiplugin_tracker.php','6.3',0),('3a66c164a7773b513f41948a3ab8f01f','./lib/wiki-plugins/wikiplugin_trackercomments.php','6.3',0),('7570d36694c516fb1c2201528d9bc6ee','./lib/wiki-plugins/wikiplugin_trackerfilter.php','6.3',0),('9d2402d22c154cf77ad64f086154212f','./lib/wiki-plugins/wikiplugin_trackeritemfield.php','6.3',0),('d9e7181a657a7be45ac99ff8ca95d248','./lib/wiki-plugins/wikiplugin_trackerlist.php','6.3',0),('3d3cc64e43f5b3e1e37757dded908385','./lib/wiki-plugins/wikiplugin_trackerprefill.php','6.3',0),('25168aad0cae2f7300025083d41a18a1','./lib/wiki-plugins/wikiplugin_trackerstat.php','6.3',0),('c59a5c17d0300df54cc36bf062b07094','./lib/wiki-plugins/wikiplugin_trackertimeline.php','6.3',0),('e723f0fd12d95ee3c26ce6509064a350','./lib/wiki-plugins/wikiplugin_trade.php','6.3',0),('acd3243923abfba6a4bab32f30e4531c','./lib/wiki-plugins/wikiplugin_transclude.php','6.3',0),('6a53843904ff9e13a3ccac357a24b793','./lib/wiki-plugins/wikiplugin_translated.php','6.3',0),('44d36836e1928cbbb0c0099659c242a7','./lib/wiki-plugins/wikiplugin_usercount.php','6.3',0),('9a0808bd3b6d5c4235749ffffea9ba09','./lib/wiki-plugins/wikiplugin_userlink.php','6.3',0),('3d1bba43f1ff83771bdd26f9d7161542','./lib/wiki-plugins/wikiplugin_userlist.php','6.3',0),('f4ca9ddb9a1889e9a47b6aa00154dc0b','./lib/wiki-plugins/wikiplugin_userpref.php','6.3',0),('c7db3b5decb6026e4d4765dc4d4c1854','./lib/wiki-plugins/wikiplugin_versions.php','6.3',0),('c58809dfe3ada5a83c71563e896e5375','./lib/wiki-plugins/wikiplugin_vimeo.php','6.3',0),('a55f434337b11932656abd12aea11486','./lib/wiki-plugins/wikiplugin_vote.php','6.3',0),('fe4d1c4d7f7bcac99753d657fe322263','./lib/wiki-plugins/wikiplugin_wantedpages.php','6.3',0),('aaafeccb40242b9576a3f3878b52d8ea','./lib/wiki-plugins/wikiplugin_watershed.php','6.3',0),('5f78bd5ec88cd78430f5478c18a249db','./lib/wiki-plugins/wikiplugin_webservice.php','6.3',0),('3600f5ef47e13671352f0bdf52d1bd19','./lib/wiki-plugins/wikiplugin_youtube.php','6.3',0),('8ed5a6c28cccc03c423f0b86584e0da1','./lib/wiki/editlib.php','6.3',0),('0faa61f7748b2056bf8fe85f028caf0a','./lib/wiki/exportlib.php','6.3',0),('d941d4e98966f4d86b053a1e7231aba0','./lib/wiki/histlib.php','6.3',0),('bc571bd32f625fcdcb17264ffa91a65a','./lib/wiki/index.php','6.3',0),('da4c2227c39092809963ce8d6d4fd4d8','./lib/wiki/pluginslib.php','6.3',0),('0b61117c28eaf7147a91f9c4014a87e1','./lib/wiki/quantifylib.php','6.3',0),('1d4dacd1c94a15e137e40c4a8516a2e9','./lib/wiki/renderlib.php','6.3',0),('41169e8fb285ba308e892c48f6489333','./lib/wiki/semanticlib.php','6.3',0),('7b2f5c207a79027f8b3c462922920be5','./lib/wiki/wiki-ajax.php','6.3',0),('495bcd21f2b2c55fa0aca22df5d04104','./lib/wiki/wikilib.php','6.3',0),('041fd6d2c61cbdcd22070e13f024bf16','./lib/wiki/xmllib.php','6.3',0),('71574687bc1c2a97b62c2e85ab774402','./lib/x/index.php','6.3',0),('b80b0d00ebbbcd938465808668e68d2c','./lib/ziplib.php','6.3',0),('7084464a0e81b3a73e6fad255f935537','./list-file_backlinks_ajax.php','6.3',0),('a45a30be6c61d6e014cfa4f4caca7ada','./list-tracker_field_values_ajax.php','6.3',0),('baeddfa6e56d464bcd67451c5c2561cb','./maps/index.php','6.3',0),('1be12c6da9908177dbdce5f86156a444','./messu-archive.php','6.3',0),('7fa2ea3231ca6df3f47ae340b8f26921','./messu-broadcast.php','6.3',0),('5cccaf1fdfe4c16dc85bf51b65d14c48','./messu-compose.php','6.3',0),('83b656885a14dc056b27e14018550310','./messu-mailbox.php','6.3',0),('406e4f6dea6d63d5a39097467f6db553','./messu-read.php','6.3',0),('66bba374dad646960485cc36b6207cdb','./messu-read_archive.php','6.3',0),('ffcbedb94fe131f309dbfabde4b58043','./messu-read_sent.php','6.3',0),('9df994935c1b647b7b580e71746af246','./messu-sent.php','6.3',0),('a06dada183a28ce88a99aa67a4fcf916','./metrics-tab.php','6.3',0),('bd64ede4284c7ce0c39708df04bdbc75','./modsadm.php','6.3',0),('3189384977cbbb5b0e7c0f5e715e5fac','./modules/cache/index.php','6.3',0),('9d4ec89a67cbdd3cd9ec8b71ebd288b8','./modules/index.php','6.3',0),('98822e6607ebd504525f924bd52e43a2','./modules/mod-func-action_calendar.php','6.3',0),('24112abc790d29bb23a4e0411a1a4820','./modules/mod-func-action_similarcontent.php','6.3',0),('c9fc8c6c2050c81edbe5197a3ab0594a','./modules/mod-func-adsense.php','6.3',0),('5620f7de4dbdbced0bd2e0b1591d8b45','./modules/mod-func-article_archives.php','6.3',0),('7acdadbba87e52fb2c95a0cda171a3b6','./modules/mod-func-article_topics.php','6.3',0),('578947a97c0b9eee51570a1cb92c0fb7','./modules/mod-func-articles.php','6.3',0),('09c79676f5efd91ae8e933c366537363','./modules/mod-func-assistant.php','6.3',0),('abbb2bc0b426cef0da8c999db417adbf','./modules/mod-func-blog_last_comments.php','6.3',0),('5b55048658c8cdaa5c8bafae0cc87e94','./modules/mod-func-breadcrumb.php','6.3',0),('d5263b6c4e35a8f431ddbc0d4398fedd','./modules/mod-func-calendar_new.php','6.3',0),('6ae49354c3b9d82e985674c99cf81156','./modules/mod-func-cart.php','6.3',0),('78d2e1bdb25d55dbbf278c80750477ef','./modules/mod-func-categories.php','6.3',0),('99bd4222b51f07ae2f96ddfb6e2b50b6','./modules/mod-func-category_transition.php','6.3',0),('d236326fb52a4d392dd09140fbf4c3d8','./modules/mod-func-change_category.php','6.3',0),('77974cd7ed521024a1c08b26578da18d','./modules/mod-func-comm_received_objects.php','6.3',0),('5729f0df08ce871b6e293c7bc52dd1e2','./modules/mod-func-credits.php','6.3',0),('44b5591e523936ee9c981d98d967cbc5','./modules/mod-func-directory_last_sites.php','6.3',0),('e493060f47e01116b8ce1b096d604ff7','./modules/mod-func-directory_stats.php','6.3',0),('bc9d3d23b5aba5f545a5c48da5468e34','./modules/mod-func-directory_top_sites.php','6.3',0),('5c03b2d4a178aabf8e75f8757ddacb29','./modules/mod-func-featured_links.php','6.3',0),('708ff28c180f52e1fdacc1083aacbb99','./modules/mod-func-file_galleries.php','6.3',0),('4ccb47741aaa52f829cd548e27340d86','./modules/mod-func-forums_best_voted_topics.php','6.3',0),('e771f5802b24779bdcc988c84e560c68','./modules/mod-func-forums_last_posts.php','6.3',0),('79c8fca472a76efcd7548f42875468d9','./modules/mod-func-forums_most_commented_forums.php','6.3',0),('90b5a72bbd722770e07b386796f7c10c','./modules/mod-func-forums_most_read_topics.php','6.3',0),('e1ed8de41ef2fd3b2f5e496eb96df361','./modules/mod-func-forums_most_visited_forums.php','6.3',0),('d61a9c2c6ac5846b76bcd41941881d55','./modules/mod-func-freetag.php','6.3',0),('03206f9bd318705804fdf84a06035cb7','./modules/mod-func-freetags_current.php','6.3',0),('90efda7121ad81369cabebce66b0d168','./modules/mod-func-freetags_morelikethis.php','6.3',0),('52e05a022b2a9b2ec5abb4955e1a16ec','./modules/mod-func-freetags_most_popular.php','6.3',0),('6d9d1941590180c3b5b181b1aa269e41','./modules/mod-func-freetags_prefered.php','6.3',0),('ad11b8ff921feb3e8d55e343d51388e1','./modules/mod-func-google.php','6.3',0),('7a097c61e539e21f68bc3cc4724029a5','./modules/mod-func-groups_emulation.php','6.3',0),('2fb1472a0624aa665d3f34af16d41d3e','./modules/mod-func-last_actions.php','6.3',0),('d3dd55247f0e1b402cac03ec4061810f','./modules/mod-func-last_blog_posts.php','6.3',0),('8062306182b0d3df589c1ffc91853261','./modules/mod-func-last_category_objects.php','6.3',0),('b21297156875d8289f2666f075c528d8','./modules/mod-func-last_created_blogs.php','6.3',0),('567581aab61bab810e617ab195e63009','./modules/mod-func-last_created_faqs.php','6.3',0),('2d26c0d8268446f03f8425fa1e7c8029','./modules/mod-func-last_created_quizzes.php','6.3',0),('ff69aa53bb21bdcf8e14909eab5abb0d','./modules/mod-func-last_file_galleries.php','6.3',0),('e2a5410b2c287a7cfcf415fa7e4ac748','./modules/mod-func-last_files.php','6.3',0),('166c21e381b1043f061fd5015266e988','./modules/mod-func-last_image_galleries.php','6.3',0),('efd10c3ac16380063ddc05805a09d20a','./modules/mod-func-last_images.php','6.3',0),('6f904b5412897033709de0de9c68199a','./modules/mod-func-last_modif_events.php','6.3',0),('0030e9b695ab2f2075db3d9c8e668e2d','./modules/mod-func-last_modif_pages.php','6.3',0),('e0dc8da250f64d66c34ae15b27ea15f8','./modules/mod-func-last_modified_blogs.php','6.3',0),('0d7681fb6af76cba29d7b725d4f37fc2','./modules/mod-func-last_podcasts.php','6.3',0),('513156c3dca3be2050d88af713bfdbfd','./modules/mod-func-last_submissions.php','6.3',0),('45b6103c20c5b7c7848caf3cb0bf97fc','./modules/mod-func-last_tracker_comments.php','6.3',0),('ba37020d8569869962426bf7e585100f','./modules/mod-func-last_tracker_items.php','6.3',0),('c12293e3479f1fd0594a488365c2ddcb','./modules/mod-func-last_validated_faq_questions.php','6.3',0),('beacac638adf1f23af088809b02f444b','./modules/mod-func-last_visitors.php','6.3',0),('9b85618f768c684e2d34d372e5719e0a','./modules/mod-func-live_support.php','6.3',0),('f5e5fab46b231b65ce9da19343dc1305','./modules/mod-func-login_box.php','6.3',0),('4380a6afbc943a6c6d6cd21431378c12','./modules/mod-func-logo.php','6.3',0),('544876f3f4cbafadb084df262398b973','./modules/mod-func-menupage.php','6.3',0),('d3acb07a8bbf8298ecbbce149a21bcb6','./modules/mod-func-menustructure.php','6.3',0),('bb0911211598194c97e8757f3fc9b667','./modules/mod-func-messages_unread_messages.php','6.3',0),('adcad33b3418e5e1bc1fcad21be12a14','./modules/mod-func-minichat.php','6.3',0),('62860952da6d597350e037a3d208f708','./modules/mod-func-months_links.php','6.3',0),('6c77559f6a5627152c9cbdf78b18465b','./modules/mod-func-most_commented.php','6.3',0),('b8904e7f7a9b0a513b2dd49cd19799ef','./modules/mod-func-num_submissions.php','6.3',0),('cd78d68695c15a636aaae7a0d430e3ed','./modules/mod-func-old_articles.php','6.3',0),('384d1dc389fac3c2b29bc23b29a2547e','./modules/mod-func-perspective.php','6.3',0),('d60eebd749257335defa4a0f66182e79','./modules/mod-func-quick_edit.php','6.3',0),('a5bfe3cccc282c13cf6602073aa3abbd','./modules/mod-func-random_images.php','6.3',0),('848531bbd5e0677d7e24a1eeee09fb63','./modules/mod-func-random_pages.php','6.3',0),('299be0a65e5a3f1b5d4843381511f5b2','./modules/mod-func-register.php','6.3',0),('167a1a10a33d0dd85a6551565d1f6cef','./modules/mod-func-rsslist.php','6.3',0),('ea303376d62b411892dac1bd25af68d8','./modules/mod-func-search.php','6.3',0),('3a932b6077b2d39871e4f3d3cdfb38bd','./modules/mod-func-search_box.php','6.3',0),('01bbb11e281e6cb8fda0ca7796af5238','./modules/mod-func-search_wiki_page.php','6.3',0),('c317159c6c44c75f204fe11b7fa96343','./modules/mod-func-semantic_links.php','6.3',0),('b4d8561382cf1881eec1ba843c00df91','./modules/mod-func-shoutbox.php','6.3',0),('507ac16651fa04501f293bd36178987b','./modules/mod-func-since_last_visit.php','6.3',0),('362fc7870d921cf8a850d67d51069579','./modules/mod-func-since_last_visit_new.php','6.3',0),('5ad60567d3242823226db4350ab57cb5','./modules/mod-func-switch_lang.php','6.3',0),('085ec898e2dfcd62e83dbc2f858b35f4','./modules/mod-func-switch_theme.php','6.3',0),('60811ed4e7918334c6f3aeb259d012fe','./modules/mod-func-terminology.php','6.3',0),('fb95ce83bc24ced74218ebc0373e7ad0','./modules/mod-func-tikitests.php','6.3',0),('1d2049fe6f585381418bd90c8ea8b47a','./modules/mod-func-top_active_blogs.php','6.3',0),('25d3555e5dcaf1989b590e40a900c67e','./modules/mod-func-top_articles.php','6.3',0),('c18f8cb0494c68025b7402d3a044fc73','./modules/mod-func-top_file_galleries.php','6.3',0),('724b2b00f604f4abe889c90cdf39a4e9','./modules/mod-func-top_files.php','6.3',0),('90dcb4a44387586c6b043a6f8924ee47','./modules/mod-func-top_forum_posters.php','6.3',0),('68d19fdd4598b184473e10a09605ffeb','./modules/mod-func-top_image_galleries.php','6.3',0),('ddd5143ff167b22763bc3c262a5b0395','./modules/mod-func-top_images.php','6.3',0),('1da3bf8ef2bad798b7104bfb5037799e','./modules/mod-func-top_objects.php','6.3',0),('4f4bad06a70ff1d20c045c68673eb38a','./modules/mod-func-top_pages.php','6.3',0),('3f62d7a39bbe09c0cba1189ba323e54c','./modules/mod-func-top_quizzes.php','6.3',0),('90f67216b2b1a5e36af6a102e159c75b','./modules/mod-func-top_visited_blogs.php','6.3',0),('707eaeb1996fcd808453d05f5d74d477','./modules/mod-func-top_visited_faqs.php','6.3',0),('43d4131f3cab3523b90bc2bfe42e65a8','./modules/mod-func-trackerhelp.php','6.3',0),('5924560fc9b41611eff07056b8542b67','./modules/mod-func-translation.php','6.3',0),('7ee7941135f61cda56e1eecf17613557','./modules/mod-func-upcoming_events.php','6.3',0),('91c610bc7837b0fc107bb765cb3fc4b1','./modules/mod-func-user_blogs.php','6.3',0),('decfd787b08d339e66d461a54fec1089','./modules/mod-func-user_bookmarks.php','6.3',0),('434f7ce12a3128eb6fddd28c3105d1b9','./modules/mod-func-user_image_galleries.php','6.3',0),('31482a33f9fb3adc70753008c8f8dcfb','./modules/mod-func-user_pages.php','6.3',0),('6cecbcdf3a3f9a1f9e11b0cbde338484','./modules/mod-func-user_tasks.php','6.3',0),('22f84ed1ec726ea73a5ceb9fd98a24a0','./modules/mod-func-user_tasks_public.php','6.3',0),('2d1db122099cc1191efd4e8d590027b0','./modules/mod-func-usergroup_tracker.php','6.3',0),('0a8941a42b18e2de1e1e217d48f94879','./modules/mod-func-users_rank.php','6.3',0),('1924e87effaf63b7278ced2c7f8c6c95','./modules/mod-func-webmail_inbox.php','6.3',0),('09e84f324e3710b460e35c0898fa3988','./modules/mod-func-whats_related.php','6.3',0),('5edcbdb7dd30b126ede2714bf8a43e2c','./modules/mod-func-who_is_there.php','6.3',0),('a88525a95d777bc0ff9a9cdabfb52440','./modules/mod-func-wiki_last_comments.php','6.3',0),('5b28a43a690869627b2f3d0602bdc814','./modules/mod-func-youtube.php','6.3',0),('98738f3deeba32f69a81df8adaf935c7','./modules/mod-last_youtube_playlist_videos.php','6.3',0),('8411ede2790c92f4882e94e06b0fc878','./plugins_help.php','6.3',0),('f63f045ccab830805127809ee34c51f2','./poll_categorize.php','6.3',0),('4f4e5aa9b7943fcc522f15a02686757d','./received_article_image.php','6.3',0),('d313f289b0f1440f3b01b1de12eb1a8e','./reindex_file.php','6.3',0),('10f85a491ded291473d50ecaac36a4a0','./remote.php','6.3',0),('a87a3b77a270c3fd24704209fd103886','./select_banner.php','6.3',0),('6388953476c0f191fb736e35aa5fcacb','./show_image.php','6.3',0),('e1d1a3852bac3e8098580e0eb853e4a4','./snarf_ajax.php','6.3',0),('46217584886905c1feaf95ccb0519a29','./styles/BiDi/index.php','6.3',0),('565af1d5927618041bb8485857694aae','./styles/abse/index.php','6.3',0),('fc212a2a3f873ae2a73753343aac6012','./styles/arcturus/options/amette/index.php','6.3',0),('fc212a2a3f873ae2a73753343aac6012','./styles/arcturus/options/geo/index.php','6.3',0),('fc212a2a3f873ae2a73753343aac6012','./styles/arcturus/options/index.php','6.3',0),('fc212a2a3f873ae2a73753343aac6012','./styles/arcturus/options/jalist/index.php','6.3',0),('fc212a2a3f873ae2a73753343aac6012','./styles/arcturus/options/matrix/index.php','6.3',0),('fc212a2a3f873ae2a73753343aac6012','./styles/arcturus/options/simple/index.php','6.3',0),('fc212a2a3f873ae2a73753343aac6012','./styles/arcturus/options/smartiki/index.php','6.3',0),('fc212a2a3f873ae2a73753343aac6012','./styles/arcturus/options/trollparty/index.php','6.3',0),('565af1d5927618041bb8485857694aae','./styles/business/index.php','6.3',0),('dff294b40371a6fd9dd5a10a10e4d0a1','./styles/business/options/index.php','6.3',0),('46217584886905c1feaf95ccb0519a29','./styles/coelesce/index.php','6.3',0),('ad3398c32c387093060d8da3031906b0','./styles/coelesce/options/index.php','6.3',0),('46217584886905c1feaf95ccb0519a29','./styles/darkroom/index.php','6.3',0),('565af1d5927618041bb8485857694aae','./styles/darkshine/index.php','6.3',0),('565af1d5927618041bb8485857694aae','./styles/eatlon/index.php','6.3',0),('46217584886905c1feaf95ccb0519a29','./styles/feb12/index.php','6.3',0),('ad3398c32c387093060d8da3031906b0','./styles/feb12/options/index.php','6.3',0),('565af1d5927618041bb8485857694aae','./styles/fivealive/index.php','6.3',0),('417e844fccc9a948492c1f81963fd121','./styles/fivealive/options/akebi/index.php','6.3',0),('417e844fccc9a948492c1f81963fd121','./styles/fivealive/options/blueberry/index.php','6.3',0),('417e844fccc9a948492c1f81963fd121','./styles/fivealive/options/grape/index.php','6.3',0),('6502e9901534575f66544df8b9825a8b','./styles/fivealive/options/index.php','6.3',0),('417e844fccc9a948492c1f81963fd121','./styles/fivealive/options/kiwi/index.php','6.3',0),('417e844fccc9a948492c1f81963fd121','./styles/fivealive/options/lemon/index.php','6.3',0),('417e844fccc9a948492c1f81963fd121','./styles/fivealive/options/orange/index.php','6.3',0),('614e2d5c4f4ed429dc8c66bc63e5a847','./styles/fivealive/options/watermelon/index.php','6.3',0),('4c995acd46862263f95cbb51d66deb47','./styles/index.php','6.3',0),('46217584886905c1feaf95ccb0519a29','./styles/integrator/index.php','6.3',0),('565af1d5927618041bb8485857694aae','./styles/jqui/index.php','6.3',0),('417e844fccc9a948492c1f81963fd121','./styles/jqui/options/excitebike/index.php','6.3',0),('6502e9901534575f66544df8b9825a8b','./styles/jqui/options/index.php','6.3',0),('417e844fccc9a948492c1f81963fd121','./styles/jqui/options/trontastic/index.php','6.3',0),('7f6b65ff0975ed292f9992c28772cdea','./styles/jqui/options/trontastic/pics/icons/index.php','6.3',0),('eb24a5576f90cae9aa21d57acca8a4b6','./styles/jqui/options/trontastic/pics/index.php','6.3',0),('46217584886905c1feaf95ccb0519a29','./styles/layout/index.php','6.3',0),('565af1d5927618041bb8485857694aae','./styles/ohia/index.php','6.3',0),('d6e60bfbd4c4aa03deca844b3ec29beb','./styles/ohia/options/index.php','6.3',0),('46217584886905c1feaf95ccb0519a29','./styles/slides/index.php','6.3',0),('46217584886905c1feaf95ccb0519a29','./styles/slideshows/index.php','6.3',0),('565af1d5927618041bb8485857694aae','./styles/snow/index.php','6.3',0),('ee35b0f90deb6f64319211d87acb836f','./styles/snow/options/index.php','6.3',0),('46217584886905c1feaf95ccb0519a29','./styles/strasa/index.php','6.3',0),('ad3398c32c387093060d8da3031906b0','./styles/strasa/options/index.php','6.3',0),('46217584886905c1feaf95ccb0519a29','./styles/strasa/options/mono/pics/icons/index.php','6.3',0),('46217584886905c1feaf95ccb0519a29','./styles/strasa/options/mono/pics/index.php','6.3',0),('46217584886905c1feaf95ccb0519a29','./styles/strasa/pics/icons/index.php','6.3',0),('46217584886905c1feaf95ccb0519a29','./styles/strasa/pics/index.php','6.3',0),('46217584886905c1feaf95ccb0519a29','./styles/thenews/index.php','6.3',0),('ad3398c32c387093060d8da3031906b0','./styles/thenews/options/index.php','6.3',0),('ad3398c32c387093060d8da3031906b0','./styles/tikinewt/options/index.php','6.3',0),('417e844fccc9a948492c1f81963fd121','./styles/tikinewt/options/shadows/index.php','6.3',0),('565af1d5927618041bb8485857694aae','./styles/twist/index.php','6.3',0),('d67d52aa517f53d0406a05ea38bb0568','./temp/cache/index.php','6.3',0),('2bdd144edbdd0e51229fe291dc3fa68c','./temp/index.php','6.3',0),('d67d52aa517f53d0406a05ea38bb0568','./temp/mail_attachs/index.php','6.3',0),('46217584886905c1feaf95ccb0519a29','./templates/debug/index.php','6.3',0),('4c995acd46862263f95cbb51d66deb47','./templates/index.php','6.3',0),('46217584886905c1feaf95ccb0519a29','./templates/mail/index.php','6.3',0),('46217584886905c1feaf95ccb0519a29','./templates/map/index.php','6.3',0),('46217584886905c1feaf95ccb0519a29','./templates/modules/index.php','6.3',0),('bb6198eec398a660f36f26574e534cc8','./templates/styles/abse/index.php','6.3',0),('4a6c674df4e874773e3919fc12d17607','./templates/styles/business/index.php','6.3',0),('b2bc6589ae0e6a2b3bd2404f94714ab2','./templates/styles/coelesce/index.php','6.3',0),('b2bc6589ae0e6a2b3bd2404f94714ab2','./templates/styles/darkroom/index.php','6.3',0),('4a6c674df4e874773e3919fc12d17607','./templates/styles/darkshine/index.php','6.3',0),('4a6c674df4e874773e3919fc12d17607','./templates/styles/eatlon/index.php','6.3',0),('b2bc6589ae0e6a2b3bd2404f94714ab2','./templates/styles/feb12/index.php','6.3',0),('bb6198eec398a660f36f26574e534cc8','./templates/styles/fivealive/index.php','6.3',0),('b2bc6589ae0e6a2b3bd2404f94714ab2','./templates/styles/index.php','6.3',0),('bb6198eec398a660f36f26574e534cc8','./templates/styles/jqui/index.php','6.3',0),('691dd4bac9a2c0e51d14ca9dcedb0e01','./templates/styles/ohia/index.php','6.3',0),('4a6c674df4e874773e3919fc12d17607','./templates/styles/skeleton/index.php','6.3',0),('4a6c674df4e874773e3919fc12d17607','./templates/styles/snow/index.php','6.3',0),('b2bc6589ae0e6a2b3bd2404f94714ab2','./templates/styles/strasa/index.php','6.3',0),('b2bc6589ae0e6a2b3bd2404f94714ab2','./templates/styles/thenews/index.php','6.3',0),('b2bc6589ae0e6a2b3bd2404f94714ab2','./templates/styles/tikinewt/index.php','6.3',0),('4a6c674df4e874773e3919fc12d17607','./templates/styles/twist/index.php','6.3',0),('cd9ff58d15c89f24c649905c25da323c','./tests/index.php','6.3',0),('3d12dcdb8d7e1bb5cf0ab94d6b36f352','./tiki-action_calendar.php','6.3',0),('fc348c778366e66e29e5ef9f9e6bab14','./tiki-admin.php','6.3',0),('d281383c480104d5e15aedc652aef022','./tiki-admin_actionlog.php','6.3',0),('f2e08a824f6fd4298e63aa389966055d','./tiki-admin_banners.php','6.3',0),('05cd3628c94ccf80104d8dd27a78e90d','./tiki-admin_banning.php','6.3',0),('12a9426c59ed3ea909b56742bbca2c42','./tiki-admin_calendars.php','6.3',0),('3f5533b124e96db35183d9d871d5c6cc','./tiki-admin_categories.php','6.3',0),('17fa00f95fd93ae5c806228cc2e43b0a','./tiki-admin_content_templates.php','6.3',0),('6237f2f1d5faf40fe0c35b94d6e8aadf','./tiki-admin_contribution.php','6.3',0),('296bc5bab0739fcc895cdfef03ef9a20','./tiki-admin_cookies.php','6.3',0),('3c570d4410c683028e85f5d2d1b4737a','./tiki-admin_credits.php','6.3',0),('43f5a2f763ed54d0950c0f674925892c','./tiki-admin_dsn.php','6.3',0),('37ccacdfae5bef085f2aad48ca316553','./tiki-admin_external_wikis.php','6.3',0),('acdbc0e721a14915cbc3f9d4901a7f7e','./tiki-admin_forums.php','6.3',0),('c7e6226aabe4006d509bf80f90d99adc','./tiki-admin_hotwords.php','6.3',0),('704a4433e917d82dab859e8d57b99e44','./tiki-admin_html_page_content.php','6.3',0),('79074549e00255ee898cb6b0d1cd3583','./tiki-admin_html_pages.php','6.3',0),('f597b4e280107791cbe8841ee246e40a','./tiki-admin_include_ads.php','6.3',0),('721bac060bed8ea03580d7574e93f526','./tiki-admin_include_blogs.php','6.3',0),('4ce15db36fa4ae5d0d85a6094e6303ee','./tiki-admin_include_calendar.php','6.3',0),('208af70de955cfdf843c40c74c0bcc53','./tiki-admin_include_category.php','6.3',0),('e6f24f168e6adb346f8baf693029d0fd','./tiki-admin_include_cms.php','6.3',0),('4af221eb5c982f582cc40571f97eae7c','./tiki-admin_include_comments.php','6.3',0),('52ffc14985bb18dd4fafee5d8833791c','./tiki-admin_include_community.php','6.3',0),('d5ffbe30e19b869bcf14d3727d3ba16c','./tiki-admin_include_connect.php','6.3',0),('515018e5b8e65bd1eab4683d5e6fdbcc','./tiki-admin_include_copyright.php','6.3',0),('3059727befc779ef69d4a4db6f83e829','./tiki-admin_include_directory.php','6.3',0),('c0b9ab400c199e1daac01ab0513ddcea','./tiki-admin_include_faqs.php','6.3',0),('3ebd84634bd474909f058698adfd6ab9','./tiki-admin_include_features.php','6.3',0),('d8297e8d5146037a0cefc1c01c38cb70','./tiki-admin_include_fgal.php','6.3',0),('bb70f0c220658d99274eb043b5961b14','./tiki-admin_include_forums.php','6.3',0),('8127e18f485237bc2f65efe9acebd851','./tiki-admin_include_freetags.php','6.3',0),('68bb5eb4cb456d1baef3ce1d004d4d98','./tiki-admin_include_gal.php','6.3',0),('c39688bf11c4ddc61978457cd7643409','./tiki-admin_include_general.php','6.3',0),('0e9520471231fd66d1f7580404b982e0','./tiki-admin_include_gmap.php','6.3',0),('a6103f5b1c658b191a4e2239c598e46c','./tiki-admin_include_i18n.php','6.3',0),('99ccec8b04691f824d9abb77b7771917','./tiki-admin_include_intertiki.php','6.3',0),('92c76cfc1469acad70059d6469cbba7f','./tiki-admin_include_login.php','6.3',0),('02fa1b6c0629204e864d996ec4bfb497','./tiki-admin_include_look.php','6.3',0),('dac02d5c71c6159f232f98b8e683a842','./tiki-admin_include_maps.php','6.3',0),('7c4e9d1d3b10ecf92f85205e98b7779d','./tiki-admin_include_messages.php','6.3',0),('3e682d6d499aa42440ca06b28ee4b71e','./tiki-admin_include_metatags.php','6.3',0),('a29e58327859cb2ca72b48eca8ed94fa','./tiki-admin_include_metrics.php','6.3',0),('cb23c5ec1aea778be34d0c93451d90e4','./tiki-admin_include_module.php','6.3',0),('c288e8dec9f57d3d3d1e68631ef6ecd8','./tiki-admin_include_payment.php','6.3',0),('d45e7cec790f3aec7e2cdd8305546872','./tiki-admin_include_performance.php','6.3',0),('c2d3e8ff4a479bca1522ea775b129485','./tiki-admin_include_polls.php','6.3',0),('c2be1ca4f8caac099dfd246f38eff1b5','./tiki-admin_include_profiles.php','6.3',0),('47df46a1816cc0f7e75c834e832f63fd','./tiki-admin_include_rating.php','6.3',0),('22a626cd2f2dc34c0a88040ab18591a3','./tiki-admin_include_rss.php','6.3',0),('c5898e647c11982cadf72e06d8a7d916','./tiki-admin_include_score.php','6.3',0),('b29f9dbca7e0e98167a49a2c62d2ae10','./tiki-admin_include_search.php','6.3',0),('8c5a64b281f15c7fee49b1ae73c93e6c','./tiki-admin_include_security.php','6.3',0),('b7805bc404e96fc5e0a261ce0d0a773e','./tiki-admin_include_sefurl.php','6.3',0),('c85a452bc10a5c55a7b10823846953a5','./tiki-admin_include_semantic.php','6.3',0),('e44a2c6dc4d29ac91ad69e755ba5b392','./tiki-admin_include_socialnetworks.php','6.3',0),('19c0e56895fcba0d284c7e44b08039ed','./tiki-admin_include_textarea.php','6.3',0),('192754311dd237322c5c0c95fd2f8ebb','./tiki-admin_include_trackers.php','6.3',0),('2bda41eb4e48d18a7c919980631940dd','./tiki-admin_include_userfiles.php','6.3',0),('3e43d44a0a0aff8790a1815d58d08fa4','./tiki-admin_include_video.php','6.3',0),('99f44f5201ae892a50dc4087ff00ba31','./tiki-admin_include_webmail.php','6.3',0),('e22b1c9274318ff35a9e843288fa663a','./tiki-admin_include_webservices.php','6.3',0),('677ef0d3c2448d7f4d8ab7f9470c5df2','./tiki-admin_include_wiki.php','6.3',0),('17c285e2e1012aa4975692f3eb1851fa','./tiki-admin_include_wikiatt.php','6.3',0),('7b8aa71e16406e309d9b57dba4457700','./tiki-admin_include_wysiwyg.php','6.3',0),('746108a301f4352c6b07a933dc595efb','./tiki-admin_integrator.php','6.3',0),('5148f87bbf422072be3141e13d88a37a','./tiki-admin_integrator_rules.php','6.3',0),('1e12969a791fce7d1f710452d07a79f2','./tiki-admin_keywords.php','6.3',0),('31ad9fb48131e900865c231b7b17ad3a','./tiki-admin_layout.php','6.3',0),('76ad97ba1c00cc11fd075c00c01eba74','./tiki-admin_links.php','6.3',0),('291d38a5dacc1ea84a8b30ccd9a9c744','./tiki-admin_mailin.php','6.3',0),('42348d1fdfeb0ef3c7bd1fe01f9b615d','./tiki-admin_menu_options.php','6.3',0),('03391db8d56f6670ad7552476243a134','./tiki-admin_menus.php','6.3',0),('8eedfaddba8458426c081dc2be0a044e','./tiki-admin_metrics.php','6.3',0),('11cff258f51f5a8bf7c6fbf2112ab907','./tiki-admin_modules.php','6.3',0),('43997e15f9cba2cda77dc92609235da1','./tiki-admin_newsletter_subscriptions.php','6.3',0),('b317dfdd7302c2e0d072b3430eeb1fee','./tiki-admin_newsletters.php','6.3',0),('00d2e1b79fe07a8cb0a5a86ad7d8396d','./tiki-admin_notifications.php','6.3',0),('1061ecd9991e8931322340d6e54767e0','./tiki-admin_poll_options.php','6.3',0),('49064443024be9c3e6dbfd6bf93a1077','./tiki-admin_polls.php','6.3',0),('869ede7ce732984d0da018aa3a728ce4','./tiki-admin_rssmodules.php','6.3',0),('1748f002f9ecda20b2cf7e58e6d75a81','./tiki-admin_security.php','6.3',0),('be16f42b30aaca92b98f195089e7f5c8','./tiki-admin_shoutbox_words.php','6.3',0),('af841be6b5fdf806b1aeadbc974f79b3','./tiki-admin_structures.php','6.3',0),('aec10b5adb80c7d946b4ebc4a311a3e1','./tiki-admin_survey_questions.php','6.3',0),('dd89c220211f8fe185bf3f90164005aa','./tiki-admin_surveys.php','6.3',0),('bd1d72006d5d9106c17dc337258bae29','./tiki-admin_system.php','6.3',0),('f46bd1bcceeffedf73f63328c0ff13f1','./tiki-admin_toolbars.php','6.3',0),('a337105abe46336583788c3eab2437c7','./tiki-admin_topics.php','6.3',0),('37622deb678e32f7c86dc8e4738ffd75','./tiki-admin_tracker_fields.php','6.3',0),('1353f2c90306026b2a457bb7f146d469','./tiki-admin_trackers.php','6.3',0),('c6ae22a99b3519accd741b2f9bad8987','./tiki-admin_transitions.php','6.3',0),('05e879773a8cc29eb6a95ebeafa255d1','./tiki-admingroups.php','6.3',0),('c9673099bf6944e6f0c5c6a42950644c','./tiki-adminusers.php','6.3',0),('558c1d2724c765d1f54e13efdfb6652a','./tiki-ajax_services.php','6.3',0),('f270c6e31fd8d827e639ca2e544af5a5','./tiki-all_languages.php','6.3',0),('242d7f8135cfb379ce8c5e779a2f990b','./tiki-approve_staging_page.php','6.3',0),('17a90d2ef25a1afa67ca517a361cb1c0','./tiki-article_types.php','6.3',0),('34e305414a95645f546c51ea11ef8cf9','./tiki-articles_rss.php','6.3',0),('81be036dcd9dbef3aeac97ed4a515463','./tiki-assignpermission.php','6.3',0),('3dd513d096c2052b8ffebc0ba0debacb','./tiki-assignuser.php','6.3',0),('47edfaedd9b3047aad72a06f63b5d590','./tiki-atom.php','6.3',0),('65612fb87e47b5304b8142680bd1e1ba','./tiki-auto_save.php','6.3',0),('0c8bec98ed725507b087d8c35a72c336','./tiki-backlinks.php','6.3',0),('0357ea4d55eee6156ac18402d5e8a392','./tiki-batch_send_newsletter.php','6.3',0),('a493e65a4640a52b37c61794278ebe11','./tiki-batch_todo.php','6.3',0),('1e78fbaa29dff5abb0d67343e5306ff6','./tiki-batch_upload.php','6.3',0),('338139fc1048a0925d0a8c7e6816d147','./tiki-batch_upload_files.php','6.3',0),('0e989c5aad04c860872fbd2743ddba00','./tiki-blog_post.php','6.3',0),('b04866f1e5fa885dc4e7e984b0361a16','./tiki-blog_rankings.php','6.3',0),('ef40cb5b54ecf348f440540e1be4d8e4','./tiki-blog_rss.php','6.3',0),('47194273de421c0bf5d1c45be103e3ae','./tiki-blogs_rss.php','6.3',0),('fd0158c72f25cbd8de9fbf97e79da6e0','./tiki-browse_categories.php','6.3',0),('a113e08614e3e4c8a7425ce0f903460c','./tiki-browse_freetags.php','6.3',0),('f84e1f241a3cecbe50a9e69de9d1767b','./tiki-browse_gallery.php','6.3',0),('2b8ff4736834352aab47f681171a7fca','./tiki-browse_image.php','6.3',0),('651448002405dca5511cd93f9471cf62','./tiki-calendar.php','6.3',0),('b520e90fa610a7b2a86ea09680605938','./tiki-calendar_edit_item.php','6.3',0),('8c87cb50e75e2265f3d9d79a5b55e028','./tiki-calendar_export_ical.php','6.3',0),('bb007274deb2ba78393510829234e1d7','./tiki-calendar_import.php','6.3',0),('858deec6a62f7204401ddb1d154648d3','./tiki-calendar_params_ical.php','6.3',0),('efd0f61c42f51860a923a04b9eb28113','./tiki-calendar_setup.php','6.3',0),('ef02b97879c4089063e994d9ee5d7be0','./tiki-calendars_rss.php','6.3',0),('9f84c94a116d9bb9fefd9798b5f6241d','./tiki-change_password.php','6.3',0),('143177f98714090d5607feccd4dd172c','./tiki-channel.php','6.3',0),('0ca8d38df622cb9b87e470b572cc6a17','./tiki-cms_rankings.php','6.3',0),('b6d6ff4c5e2fa7da95f3438cfb63f69f','./tiki-confirm_user_email.php','6.3',0),('c607927a8550b017859d96acf2f3b93c','./tiki-contact.php','6.3',0),('eb14ab6f7da02defa1e749c47fc733c0','./tiki-contacts.php','6.3',0),('bdd2a8423e730e96c820f8e7a2826417','./tiki-cookie-jar.php','6.3',0),('168fec337bf38fdcd6149600cd31ca9c','./tiki-create_multilang_pages.php','6.3',0),('0886449f1ac7a011424d9cdb8c488b84','./tiki-create_webhelp.php','6.3',0),('7deb4dd373654d445ca7220f8a8da262','./tiki-custom_home.php','6.3',0),('07ba1bef660d5c7973861b985e80efae','./tiki-directories_rss.php','6.3',0),('d2f737a693cc4d6bedf4389f07e3103d','./tiki-directory_add_site.php','6.3',0),('d16465ed9073d993bb216391ab686500','./tiki-directory_add_tiki_site.php','6.3',0),('5005b1d54dec5a170e60b39346e2d193','./tiki-directory_admin.php','6.3',0),('a42b297edbac0542377f5d446e9c7ad2','./tiki-directory_admin_categories.php','6.3',0),('35b653580d8c885c917b049c726e570d','./tiki-directory_admin_related.php','6.3',0),('493388e8cedc01e0dedbe88a6680d28b','./tiki-directory_admin_sites.php','6.3',0),('6f1ea1d307741e8bde00b5aed55756e0','./tiki-directory_browse.php','6.3',0),('fafd8a3df67736ff10cb86a932c8bfb0','./tiki-directory_ranking.php','6.3',0),('f60ae5ae3561fdb671fb5745880dc8de','./tiki-directory_redirect.php','6.3',0),('1563d3b3ce4f00fbb080ece7534cab97','./tiki-directory_rss.php','6.3',0),('34a49c4406a818f67e199982ae0b8fcf','./tiki-directory_search.php','6.3',0),('b6e1b44919be71acaa764354060192f5','./tiki-directory_validate_sites.php','6.3',0),('b6c2b5604263988db31ddaee1bafeaa7','./tiki-discount.php','6.3',0),('1bb58a78ea8fb75b328bb83045b926dd','./tiki-download_file.php','6.3',0),('21f21d3f31c1f29f83f136c3bde492b0','./tiki-download_forum_attachment.php','6.3',0),('9bbdd37ea96af727053bdb492214cc14','./tiki-download_item_attachment.php','6.3',0),('34dae78ee5d7da956f30172fa166af45','./tiki-download_userfile.php','6.3',0),('431ae82e2c274c1998200d32d3597cf0','./tiki-download_wiki_attachment.php','6.3',0),('772cd5394a9c6ed1a51cd04b0a9e8852','./tiki-edit_article.php','6.3',0),('c6634c2c28e7b9ec471ae0b7fac06874','./tiki-edit_banner.php','6.3',0),('90b190895039f7f40b4334d4bbf039e0','./tiki-edit_blog.php','6.3',0),('240d50d10ab17c93e058bde11bc2a04f','./tiki-edit_css.php','6.3',0),('ce0c6147d901bd45566a9bc2828d63bb','./tiki-edit_image.php','6.3',0),('753af74b9fb5740a74a70302fe14a28f','./tiki-edit_languages.php','6.3',0),('eeaa3efd0f45b575233d28724e3f3880','./tiki-edit_perspective.php','6.3',0),('0cef36f8048c48d980103a3d8261e6cd','./tiki-edit_programmed_content.php','6.3',0),('af5b7149a38de26c0ab73ae411f578a4','./tiki-edit_question_options.php','6.3',0),('865f8503de74a7f9c9b3102fd7f6f83c','./tiki-edit_quiz.php','6.3',0),('1253d46436726cb94d197f779243ef9a','./tiki-edit_quiz_questions.php','6.3',0),('b71a5212ed730d0ccf57c40814a46461','./tiki-edit_quiz_results.php','6.3',0),('7a8f279d98f21f7e3be3e1badadd31bd','./tiki-edit_structure.php','6.3',0),('7fad533ac931a6a22f49d5f4d749c3ed','./tiki-edit_submission.php','6.3',0),('26a63fafc9ddc7c9a4b173f64bfebf10','./tiki-edit_templates.php','6.3',0),('c6c274c0d584419d33f299f8d6dc73b7','./tiki-edit_topic.php','6.3',0),('886a33a33c28e51a716d93fcf69e93ae','./tiki-edit_translation.php','6.3',0),('d1a3e52812944523a041cf446dad32b8','./tiki-editpage.php','6.3',0),('e9c3cd188b1ef0a0f24e6a1d92bcac5b','./tiki-emulate_groups_switch.php','6.3',0),('31b07dbfb894a703b53b78a38a187502','./tiki-error_simple.php','6.3',0),('296a4702987f5dd90cd10046b1ee1f08','./tiki-export_sheet.php','6.3',0),('6e03057d79fdbbf16a73b6f72bef8faa','./tiki-export_tracker.php','6.3',0),('a78d5cef6fd7b45a78f56eae8874ef4d','./tiki-export_tracker_ajax.php','6.3',0),('bddcfd1eeacd65f3f40121c593758f7e','./tiki-export_tracker_monitor.php','6.3',0),('7affb523d9d86336402bb3d0b10e6962','./tiki-export_wiki_pages.php','6.3',0),('3978075ab42d7fbcac42ae47ccbdf910','./tiki-faq_questions.php','6.3',0),('7db22a1f575f618e0f5b9195161ff428','./tiki-featured_link.php','6.3',0),('bbef4afb8505a9ce958591527475700a','./tiki-file_archives.php','6.3',0),('008b948e19b676883352b6816e3d7384','./tiki-file_galleries_rankings.php','6.3',0),('2d008f991963ae717c6e04aa6b750e13','./tiki-file_galleries_rss.php','6.3',0),('8d20f43edf252b233a333db1d41d5df2','./tiki-file_gallery_rss.php','6.3',0),('394a280bc026213689fa8bbc305ce6df','./tiki-filter-base.php','6.3',0),('65a180aad7f14d95083deb25ed587317','./tiki-forum_import.php','6.3',0),('fecb0fcaf54ce6e43aa460d79fc8eadf','./tiki-forum_queue.php','6.3',0),('0af470aadf5f81eabfe076f81045a612','./tiki-forum_rankings.php','6.3',0),('d41bc52049573442e6b5b87408c88537','./tiki-forum_rss.php','6.3',0),('bb82365b441133b1fcc3fbe490fcb88c','./tiki-forums.php','6.3',0),('74d4f722aa44862a5356143750f4387b','./tiki-forums_reported.php','6.3',0),('f18245db6c75d379d5594918393e733b','./tiki-forums_rss.php','6.3',0),('133673d7e54e85e906bdd22492cba16b','./tiki-freetag3d_xmlrpc.php','6.3',0),('0e350f17a5f96ead761735fd68af14cd','./tiki-freetag_translate.php','6.3',0),('8bcfd1f7e1dab708f05e9c86e1c36d8f','./tiki-friends.php','6.3',0),('f1bb8f87c1bac62ea19bc90324b0805f','./tiki-galleries.php','6.3',0),('2a428999ce1baf6735271e2626953ac0','./tiki-galleries_rankings.php','6.3',0),('5851f1a36c7844c62a4e9717bc9a3c47','./tiki-gmap_locator.php','6.3',0),('802c99eae56b853e574043d39dc043c0','./tiki-gmap_usermap.php','6.3',0),('f32463c748062c97ced6b0dc82cebd7d','./tiki-graph_formula.php','6.3',0),('3ef376f7d93b18996a28ddae1ad0d797','./tiki-graph_sheet.php','6.3',0),('0d4d1cf67eca689d074d4d3f21b964bf','./tiki-history_sheets.php','6.3',0),('09e26722531caf069dadf83ba28670fc','./tiki-image_galleries_rss.php','6.3',0),('22c9c1dc6dd43cca42bfd53fc16ebc3a','./tiki-image_gallery_rss.php','6.3',0),('0679bee65b6e460a681d12a7440ce33e','./tiki-import_sheet.php','6.3',0),('063c5b34da31497f351181ea1a9d032f','./tiki-import_structuredtext.php','6.3',0),('2f8a00b6c10bcab5fbb0a2f8293bebc8','./tiki-import_tracker.php','6.3',0),('12b9817ebbcc3f984e33e363bf4ab3f7','./tiki-import_xml_zip.php','6.3',0),('8fb3c2468973daa6b4285271d60a72f0','./tiki-importer.php','6.3',0),('b14087cd555fa7fa9b1cc2655ed7fbdd','./tiki-index.php','6.3',0),('2aff2510a218be288d68153d705c58d0','./tiki-index_p.php','6.3',0),('7f3c8a2a9303a78a11f02c79cea271ab','./tiki-index_raw.php','6.3',0),('5562528b813b79383ddac97e48aef074','./tiki-information.php','6.3',0),('b86c814c245d654ba15ac5ff6ff74d3c','./tiki-install.php','6.3',0),('4174720d3b84ae450a0c2ef13d4aa5f5','./tiki-integrator.php','6.3',0),('c8b56b52b36164e3c7086d5fad4c5903','./tiki-interactive_trans.php','6.3',0),('3f33ae0124d4437f807b196a7fde7ae2','./tiki-invite.php','6.3',0),('3693dd3379618d5f67480813cbc08862','./tiki-invited.php','6.3',0),('9bcf30a4b56e50804d9e6234b17cbcf0','./tiki-jscalendar.php','6.3',0),('dd2b27371345df0340ee618708059ec3','./tiki-jsplugin.php','6.3',0),('af30467e9bf914bbe9416ab78f3a2ff6','./tiki-kaltura_upload.php','6.3',0),('3933a4bd2be78d97c5b0a6d510e74f7e','./tiki-kaltura_video.php','6.3',0),('b77c97e3afe42f15d385253b9ff49bac','./tiki-lastchanges.php','6.3',0),('69cbcbfb21525b9ae591fc21003e2280','./tiki-layout_options.php','6.3',0),('aff81321857e08da5a0a1b909660feca','./tiki-likepages.php','6.3',0),('d8968247abb40e490c487334645d772d','./tiki-list_articles.php','6.3',0),('433e198f46f3a67cb8cc1932b79898a8','./tiki-list_banners.php','6.3',0),('fde3f9e379f7a5d9b6b17d46a865d284','./tiki-list_blogs.php','6.3',0),('b3069c2031fa8b142d4cbc4bd69b9af4','./tiki-list_cache.php','6.3',0),('fdd296e2322e793137ae6415d21ba4f8','./tiki-list_comments.php','6.3',0),('57dd0cf47ae12cb73448f81997e033b9','./tiki-list_contents.php','6.3',0),('3468ba71941be0a6dddf3513472cc19a','./tiki-list_faqs.php','6.3',0),('a0c61651253f2ae43e2e06f8e99878ef','./tiki-list_file_gallery.php','6.3',0),('d5fe43d59c23eb9793082b8222a400b5','./tiki-list_gallery.php','6.3',0),('ffc715474fb92d853c0a66c6032cb157','./tiki-list_integrator_repositories.php','6.3',0),('d40fba2712405aa6eb12805d3f60889b','./tiki-list_invite.php','6.3',0),('eae3b04bf1da8e14f6a004b6f1f83515','./tiki-list_kaltura_entries.php','6.3',0),('eb90ac38a672f8b4ea258865b8deb7b6','./tiki-list_object_permissions.php','6.3',0),('c71f1e26400e87ac13e7dc4080099d51','./tiki-list_posts.php','6.3',0),('03e7d3077ef8fccf99de241125444cf7','./tiki-list_quizzes.php','6.3',0),('56007caaad645c7808cabadea6b673b9','./tiki-list_submissions.php','6.3',0),('391937856bc9395b4ce3e1e4febfe267','./tiki-list_surveys.php','6.3',0),('b0c2ca44ec3d90ca83d262e7cd78e596','./tiki-list_trackers.php','6.3',0),('d546fea55b84f222453b77ecf8a6fa20','./tiki-list_users.php','6.3',0),('83f0dc0fcfc0a83aea5c24ac1fb9e5a1','./tiki-listpages.php','6.3',0),('72d729742e60fba203c0b7def85cace0','./tiki-live_support_admin.php','6.3',0),('37d1e4b1ec4133801d7774e0cae7dee2','./tiki-live_support_chat_frame.php','6.3',0),('adf8354774fdc77834badecc7e13aa65','./tiki-live_support_chat_window.php','6.3',0),('f749fa1a500b6cf90d7ad93825ea565c','./tiki-live_support_client.php','6.3',0),('799d06080d6e4c33e4a3ba43874f2e64','./tiki-live_support_console.php','6.3',0),('1e930d29a41017265e3ba6545c8e4403','./tiki-live_support_message.php','6.3',0),('d96ff5436982c4dd8910b6aa0d2124d4','./tiki-live_support_server.php','6.3',0),('51dc63ef1e14a7fd135c5205110588e2','./tiki-live_support_transcripts.php','6.3',0),('7df1caebb2b04458d624e662eb98082d','./tiki-login.php','6.3',0),('6ba03cb01ede25074f417704e9dd54d2','./tiki-login_openid.php','6.3',0),('922489a93cbd156e4f87fa4d73e66d6a','./tiki-login_scr.php','6.3',0),('5c28081bfdb4f57de8b442586fd37286','./tiki-login_validate.php','6.3',0),('f5ab80e043a27bfc57c9c9fa1c97d768','./tiki-logout.php','6.3',0),('d1238064e32c7feaded89fef4559eb01','./tiki-mailin-code.php','6.3',0),('1a0ce198479d05d1fe7845a5fd70c6a8','./tiki-mailin.php','6.3',0),('a73fcd1135a90762331a7966f27d4b12','./tiki-map.php','6.3',0),('66f6314925db5afab1ce96c338bc0054','./tiki-map_edit.php','6.3',0),('56f8eecb10709d4e894be904c64f644c','./tiki-map_history.php','6.3',0),('f1ee69b792d4d973ef5e07ee66769d8e','./tiki-map_rss.php','6.3',0),('f01366d397df1360cb8c8eb259305a45','./tiki-map_upload.php','6.3',0),('ebfe67f001210220eb38d404d33f1867','./tiki-metrics.php','6.3',0),('ed0619aba01954f94eed6ac028f46989','./tiki-mindmap.php','6.3',0),('8e025adf1a020d4fb93be793e079690b','./tiki-minical.php','6.3',0),('3e8f57aaaff089fcfb5e5673374316f9','./tiki-minical_export.php','6.3',0),('7bd0de5e5b824c349708e83c2376bbec','./tiki-minical_prefs.php','6.3',0),('378fdb3a6d36b36eb214d18b41ef37a7','./tiki-minical_reminders.php','6.3',0),('45c1112c814e43a062b6f0c3aab4ed9c','./tiki-minichat_ajax.php','6.3',0),('24117f20c7a84881c03947c45646a81d','./tiki-mobile.php','6.3',0),('38d49e703dcd02b9cc8e97ba0383dd3c','./tiki-mods.php','6.3',0),('241e64939a125ac8c570c9066ac11dd9','./tiki-mods_admin.php','6.3',0),('df925a0d65126152c29e5bbf217366d1','./tiki-module_controls.php','6.3',0),('a8456cd56349ae93d08aec35a782d615','./tiki-modules.php','6.3',0),('dfb9f11f23f59708603cc88969da9e92','./tiki-my_tiki.php','6.3',0),('f0f085e239f1aa2437a8019f924f05b0','./tiki-mytiki_shared.php','6.3',0),('3817b616e49bee25f12c84a16d31f34c','./tiki-newsletter_archives.php','6.3',0),('52036ada2b11ac882e6843f4c6c5c6f5','./tiki-newsletters.php','6.3',0),('e2faa5e68057396c474a74511b238828','./tiki-notepad_get.php','6.3',0),('d03bd4da46e61dc7ade2546f534688d4','./tiki-notepad_list.php','6.3',0),('68a0d952273954634deaeaac122b4ae0','./tiki-notepad_read.php','6.3',0),('165672567d0d4f96cb9136af22e1cd99','./tiki-notepad_write.php','6.3',0),('cb51073472bc4d70fd7a7bdc86d1d4fd','./tiki-object_watches.php','6.3',0),('5e1eb7475ffef7d91b3c97a42401c489','./tiki-objectpermissions.php','6.3',0),('b19dfe2bc17e610c2814190a8052b68c','./tiki-old_polls.php','6.3',0),('a0c349e0df70d935276cb78e00e85f7f','./tiki-orphan_pages.php','6.3',0),('757d7b9a7e49c080f3061032aa2bb70b','./tiki-page.php','6.3',0),('bcc9418885be4dca4ef72f02f58713d7','./tiki-page_contribution.php','6.3',0),('68c22b8496fce7e8a07026ff47329f27','./tiki-page_loader.php','6.3',0),('ecd327cf3331e70e83677507022fd74f','./tiki-pagehistory.php','6.3',0),('1b238df387f2a1ea6c3e7588e4961d5a','./tiki-payment.php','6.3',0),('14426b033747d6f40cb89ca4038d4dde','./tiki-phpinfo.php','6.3',0),('2d6ed6d85144733813057b1e1508d077','./tiki-pick_avatar.php','6.3',0),('b173680832c64b9df3255ec1d35e7bb3','./tiki-plugins.php','6.3',0),('4fb2559a1f3abc7c8f73a5042de56410','./tiki-poll_form.php','6.3',0),('774061681452442387a06a1039743982','./tiki-poll_results.php','6.3',0),('fb937f3359541e4ff71d3c9cdf2a83bb','./tiki-print.php','6.3',0),('3c0812168f8baefd8e95eeb48ae6e21b','./tiki-print_article.php','6.3',0),('7ff4d15a784b54f3caac16647a892dec','./tiki-print_blog_post.php','6.3',0),('7d2ad71ba387a3164ea655a3cb75e1f8','./tiki-print_indexed.php','6.3',0),('4a2a855aeca9f0158f6ac171a3a827cf','./tiki-print_multi_pages.php','6.3',0),('33b663b5e5869eab2b229cf50cf11d94','./tiki-print_pages.php','6.3',0),('a621ba179d2b5227c3a58054ebc75d08','./tiki-pv_chart.php','6.3',0),('da26c73bf3affc66b18450292452fb32','./tiki-quiz_download_answer.php','6.3',0),('88d25cb7fd2eccdedf7972635e07b560','./tiki-quiz_edit.php','6.3',0),('fb27a518778ca37e99e59f1ff5ee20a6','./tiki-quiz_result_stats.php','6.3',0),('ecfcbea5af7669c398523e79541b14be','./tiki-quiz_stats.php','6.3',0),('587932c27180671574a7746d4494c514','./tiki-quiz_stats_quiz.php','6.3',0),('9d745e7363f08b467787a4a532642baf','./tiki-read_article.php','6.3',0),('131bfd23cb68021f45f06f8a1a4b3a93','./tiki-received_articles.php','6.3',0),('b5149c3e8cc439084ba6248002cd18fe','./tiki-received_pages.php','6.3',0),('9186e635f5892d055e8e55791d8a41cb','./tiki-referer_stats.php','6.3',0),('7e217d26a362cc59fe366524fd701f03','./tiki-register.php','6.3',0),('600460de72a49263ef365764b30907ae','./tiki-register_site.php','6.3',0),('60d562b1ef5487560e071852cfaef662','./tiki-remind_password.php','6.3',0),('6b78edcc9f1bff9a25f246d354b3ca59','./tiki-removepage.php','6.3',0),('bd6164f77ad70481df646e783f591e12','./tiki-rename_page.php','6.3',0),('9066ab2c6e5e4b4f37caa5bfb03a8808','./tiki-rollback.php','6.3',0),('fbc72d9bb22ae44a7fd843b7d9e8a954','./tiki-rss_error.php','6.3',0),('7a12ea18133036ba2e55d14360272af6','./tiki-search_replace.php','6.3',0),('e3f856974a20c0135d7b9e6fd352069e','./tiki-search_stats.php','6.3',0),('dd2d83b7a28af116fada7e3c37df4147','./tiki-searchindex.php','6.3',0),('c9fa6f55b044817923378ad533d69a61','./tiki-searchresults.php','6.3',0),('7c2670dfb231f38e2cfc374410cc0415','./tiki-section_options.php','6.3',0),('c9dbd33fdbda0bae388504e741a49325','./tiki-sefurl.php','6.3',0),('524ceb6da32adff4e9040296a462d430','./tiki-send_mail.php','6.3',0),('5309a183cfc94ca750b79881cfc46792','./tiki-send_newsletters.php','6.3',0),('64d555739d617afe797ec08ac2e24076','./tiki-send_objects.php','6.3',0),('a6c8ccb5210c2ef1ee50c2ced59d3cd1','./tiki-setup.php','6.3',0),('42f221839e0225f162ee875bab2bd924','./tiki-setup_base.php','6.3',0),('b400e366d9de22a84ed955c1d823d480','./tiki-share.php','6.3',0),('39fad75909ef2cacba13160dc666b14b','./tiki-sheets.php','6.3',0),('634808974d8b6fa99b07f57cd869b56b','./tiki-shoutbox.php','6.3',0),('565c83858b3745f092c9cc4558446ae3','./tiki-shoutbox_rss.php','6.3',0),('1118b2571d02ca83a5099a36a1b2370e','./tiki-show_all_images.php','6.3',0),('8b2527356ff7c0204b40c029d1ea65a0','./tiki-show_user_avatar.php','6.3',0),('3f60e07fe0ee47cb1c6bb29ea289f005','./tiki-slideshow.php','6.3',0),('23530b28c55816060a01df7582d9c426','./tiki-slideshow2.php','6.3',0),('ee9940d238e0c99e1bc4daee746ad409','./tiki-socialnetworks.php','6.3',0),('4cc5eaeb36c8483bb74ecd1f4ca99f99','./tiki-sqllog.php','6.3',0),('d3485bacfd4211cae70782b73aeb6e5b','./tiki-stats.php','6.3',0),('5ea4d425fb2ffcdaaebc9075c6255784','./tiki-survey_stats.php','6.3',0),('9d8054670d4681087c473b614689a62f','./tiki-survey_stats_survey.php','6.3',0),('d62f74efcf4c11caf8ac1fd24ea33d7a','./tiki-switch_lang.php','6.3',0),('450c9531a673f8e7efa344c6db257149','./tiki-switch_perspective.php','6.3',0),('6ff11c1988350f284635c49385b057ae','./tiki-switch_theme.php','6.3',0),('30b5558cf7d87b0067c5a4251bdb6549','./tiki-syslog.php','6.3',0),('94571d024c378725e76e1ec4882615d8','./tiki-take_quiz.php','6.3',0),('06e85e2611c8d3cadc2449d5dc13e539','./tiki-take_survey.php','6.3',0),('d4655cc383613608f773ea1a4ce1b423','./tiki-tc.php','6.3',0),('51e55058620ab7f9f9ec97a6c46309ac','./tiki-tell_a_friend.php','6.3',0),('6c7edefe1b977546cadcc442c0e2c334','./tiki-testGD.php','6.3',0),('9aa0ee9eea10b4f763a9c6fd3f36e2e5','./tiki-theme_control.php','6.3',0),('6391e9925e17a56eae7effa384d81b16','./tiki-theme_control_objects.php','6.3',0),('bbeca414eb29a8976b7c6dad98d11415','./tiki-theme_control_sections.php','6.3',0),('b847059780922c5aa7aa74c01a2fd62b','./tiki-tracker_http_request.php','6.3',0),('4e36555c71a508eeea7fb83e21a7f959','./tiki-tracker_rss.php','6.3',0),('c9138e5a2fb89b6e86a758c625b32682','./tiki-tracker_view_history.php','6.3',0),('be103b64453c461d8bb56b21f245361e','./tiki-upload_file.php','6.3',0),('5b69967c28406b8d4f9fd603d4c190f7','./tiki-upload_image.php','6.3',0),('2a76769f75d56b60fedb94cfdacc27bd','./tiki-usage_chart.php','6.3',0),('ad814aaa420f2f9caa7ab6eb6c925601','./tiki-user_assigned_modules.php','6.3',0),('fe1b01be16fcf9208c6ef10a108922ea','./tiki-user_bookmarks.php','6.3',0),('adc8870e1f169710b8605357e2c09af4','./tiki-user_cached_bookmark.php','6.3',0),('31b766da28b3ebb7e4f450c9a8ba086b','./tiki-user_contacts_prefs.php','6.3',0),('28645a11d80c6a3fb0150e95fbf4a2a1','./tiki-user_information.php','6.3',0),('6c0cd10b86113afdd650a9a4877e6a0e','./tiki-user_preferences.php','6.3',0),('562dbf552988d0eb276abd8e340a0f36','./tiki-user_reports.php','6.3',0),('d7a4bfa7459d40348a49597625980e17','./tiki-user_reports_send.php','6.3',0),('64f81e2aafbf61ead877f81e516491bb','./tiki-user_tasks.php','6.3',0),('6cdd375df438dd8b05bc60eb99778d6b','./tiki-user_watches.php','6.3',0),('a6b930a9debbeeaa938d1458c451e3e1','./tiki-userfiles.php','6.3',0),('0cfcac342f5f8c7a003e38e9a8592cca','./tiki-usermenu.php','6.3',0),('86c9dff8be2ab04d79b3153dac46f2f8','./tiki-users3d_xmlrpc.php','6.3',0),('05cf2b9119b813a44eecde14809a9ff0','./tiki-userversions.php','6.3',0),('0f08b437145547f3d81590a094764a98','./tiki-view_articles.php','6.3',0),('129bae751b638ce67b3c81baa37ef573','./tiki-view_banner.php','6.3',0),('c7bdeb8ef0ceab88a6df42418bb2780d','./tiki-view_blog.php','6.3',0),('771f6bcd153cd904da61fa8b0a3a2041','./tiki-view_blog_post.php','6.3',0),('f4c5318ec30b5743a9580958f40cd7a6','./tiki-view_blog_post_image.php','6.3',0),('896371523da3a8ff845b91022633bd3d','./tiki-view_cache.php','6.3',0),('cfeef5265cc3f96b0112bb1b0a1732f6','./tiki-view_faq.php','6.3',0),('5cc90d3bb414b858e7570dcbc0db33e5','./tiki-view_forum.php','6.3',0),('ddace383108aa441e973c9d6d6d708c4','./tiki-view_forum_thread.php','6.3',0),('ca446911faf5d861e1e3f96200669723','./tiki-view_minical_topic.php','6.3',0),('16a0d59db7df198d1aee655a872f8b65','./tiki-view_sheets.php','6.3',0),('8e9dc7f0176f292aaec660505907a70d','./tiki-view_tracker.php','6.3',0),('571691380b964523546901115d816a96','./tiki-view_tracker_item.php','6.3',0),('d16065a0675d5457e46610b361c252b9','./tiki-view_tracker_more_info.php','6.3',0),('51bd1dcb0ed64c934408211f8c36c2bb','./tiki-wap.php','6.3',0),('1c4d1b8da728340eb2143c4db8c22701','./tiki-watershed_service.php','6.3',0),('a2ee6140cefd6eb0e905aff9666e6373','./tiki-webdav.php','6.3',0),('2b23799967b4497c072f981a02599f0c','./tiki-webmail.php','6.3',0),('3b056cb64d223052cfa87a1e946c3f6f','./tiki-webmail_ajax.php','6.3',0),('e6badf80ea1eb84f57841a1def0990cc','./tiki-webmail_contacts.php','6.3',0),('078b3d3e824af27a9979116cd736b368','./tiki-webmail_download_attachment.php','6.3',0),('3d7880a0382831f2fb5e0beb162bb7f3','./tiki-wiki3d.php','6.3',0),('23a49547551b57b2bd2bdd75cd608057','./tiki-wiki3d_xmlrpc.php','6.3',0),('a1cdd2aad053a62badb2f526ecdb9c9d','./tiki-wiki_rankings.php','6.3',0),('03c74fb6ba67452ffda9b4d5f4566416','./tiki-wiki_rss.php','6.3',0),('145955dd831f086f37389e76fab90c1d','./tiki-wiki_rss_no_diff.php','6.3',0),('ec0521c2d19ea2efd878de1dce49dfa8','./tiki-wikiplugin_edit.php','6.3',0),('d1ee51cee40ffebc1d7e707fb4260baa','./tiki-xmlrpc_services.php','6.3',0),('244f9da452618c15dc22f715c707a47a','./tiki_tests/index.php','6.3',0),('11eee3fd6030b5cfc035048be0b54ac2','./tiki_tests/tests/index.php','6.3',0),('82694dd3612a7c0832f14406dc379fe6','./tiki_tests/tiki-tests_edit.php','6.3',0),('f242e633d7cffd7af04665c1122b996c','./tiki_tests/tiki-tests_list.php','6.3',0),('710a9d0b412c93390507b82dfe2902b4','./tiki_tests/tiki-tests_record.php','6.3',0),('7953539ccbd8d3ba936ca23ff668c8ac','./tiki_tests/tiki-tests_replay.php','6.3',0),('56ab2d2cdb4dc352fd42a5939a549c42','./tiki_tests/tiki-tests_show_xpath.php','6.3',0),('1f4afda25b8de75cae258c65a77d28e3','./tiki_tests/tikitestslib.php','6.3',0),('0beaa08d66e481e3ad68c23e4e45b527','./validate-ajax.php','6.3',0),('984ba1b844d198008b847e6de529f82a','./whelp/index.php','6.3',0),('d9d9b8ec0ed0e1f02c404af7a629ab16','./x_maps.php','6.3',0),('662545c0237642d481624bd535bbd157','./xmlrpc.php','6.3',0);
/*!40000 ALTER TABLE `tiki_secdb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_sefurl_regex_out`
--

DROP TABLE IF EXISTS `tiki_sefurl_regex_out`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_sefurl_regex_out` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `left` varchar(256) NOT NULL,
  `right` varchar(256) DEFAULT NULL,
  `type` varchar(32) DEFAULT NULL,
  `silent` char(1) DEFAULT 'n',
  `feature` varchar(256) DEFAULT NULL,
  `comment` varchar(256) DEFAULT NULL,
  `order` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `left` (`left`(128)),
  KEY `idx1` (`silent`,`type`,`feature`(30))
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_sefurl_regex_out`
--

LOCK TABLES `tiki_sefurl_regex_out` WRITE;
/*!40000 ALTER TABLE `tiki_sefurl_regex_out` DISABLE KEYS */;
INSERT INTO `tiki_sefurl_regex_out` VALUES (1,'tiki-index.php\\?page=(.+)','$1','wiki','n','feature_wiki',NULL,0),(2,'tiki-slideshow.php\\?page=(.+)','show:$1','','n','feature_wiki',NULL,0),(3,'tiki-read_article.php\\?articleId=(\\d+)','article$1','article','n','feature_articles',NULL,0),(4,'tiki-browse_categories.php\\?parentId=(\\d+)','cat$1','category','n','feature_categories',NULL,0),(5,'tiki-view_blog.php\\?blogId=(\\d+)','blog$1','blog','n','feature_blogs',NULL,0),(6,'tiki-view_blog_post.php\\?postId=(\\d+)','blogpost$1','blogpost','n','feature_blogs',NULL,0),(7,'tiki-browse_image.php\\?imageId=(\\d+)','browseimage$1','image','n','feature_galleries',NULL,0),(8,'tiki-directory_browse.php\\?parent=(\\d+)','directory$1','directory','n','feature_directory',NULL,0),(9,'tiki-view_faq.php\\?faqId=(\\d+)','faq$1','faq','n','feature_faqs',NULL,0),(10,'tiki-download_file.php\\?fileId=(\\d+)','dl$1','file','n','feature_file_galleries',NULL,10),(11,'tiki-download_file.php\\?fileId=(\\d+)&amp;thumbnail','thumbnail$1','thumbnail','n','feature_file_galleries',NULL,0),(12,'tiki-download_file.php\\?fileId=(\\d+)&amp;display','display$1','display','n','feature_file_galleries',NULL,0),(13,'tiki-download_file.php\\?fileId=(\\d+)&amp;preview','preview$1','preview','n','feature_file_galleries',NULL,0),(14,'tiki-view_forum.php\\?forumId=(\\d+)','forum$1','forum','n','feature_forums',NULL,0),(15,'tiki-browse_gallery.php\\?galleryId=(\\d+)','gallery$1','gallery','n','feature_galleries',NULL,0),(16,'show_image.php\\?id=(\\d+)','image$1','image','n','feature_galleries',NULL,0),(17,'show_image.php\\?id=(\\d+)&scalesize=(\\d+)','imagescale$1/$2','image','n','feature_galleries',NULL,0),(18,'tiki-newsletters.php\\?nlId=(\\d+)','newsletter$1','newsletter','n','feature_newsletters',NULL,0),(19,'tiki-take_quiz.php\\?quizId=(\\d+)','quiz$1','quiz','n','feature_quizzes',NULL,0),(20,'tiki-take_survey.php\\?surveyId=(\\d+)','survey$1','survey','n','feature_surveys',NULL,0),(21,'tiki-view_tracker.php\\?trackerId=(\\d+)','tracker$1','tracker','n','feature_trackers',NULL,0),(22,'tiki-integrator.php\\?repID=(\\d+)','int$1','','n','feature_integrator',NULL,0),(23,'tiki-view_sheets.php\\?sheetId=(\\d+)','sheet$1','sheet','n','feature_sheet',NULL,0),(24,'tiki-directory_redirect.php\\?siteId=(\\d+)','dirlink$1','directory','n','feature_directory',NULL,0),(25,'tiki-calendar.php\\?calIds\\[\\]=(\\d+)&calIds\\[\\]=(\\d+)&callIds\\[\\](\\d+)&callIds\\[\\](\\d+)&callIds\\[\\](\\d+)&callIds\\[\\](\\d+)&callIds\\[\\](\\d+)','cal$1,$2,$3,$4,$5,$6,$7','calendar','n','feature_calendar','7',100),(26,'tiki-calendar.php\\?calIds\\[\\]=(\\d+)&calIds\\[\\]=(\\d+)&callIds\\[\\](\\d+)&callIds\\[\\](\\d+)&callIds\\[\\](\\d+)&callIds\\[\\](\\d+)','cal$1,$2,$3,$4,$5,$6','calendar','n','feature_calendar','6',101),(27,'tiki-calendar.php\\?calIds\\[\\]=(\\d+)&calIds\\[\\]=(\\d+)&callIds\\[\\](\\d+)&callIds\\[\\](\\d+)&callIds\\[\\](\\d+)','cal$1,$2,$3,$4,$5','calendar','n','feature_calendar','5',102),(28,'tiki-calendar.php\\?calIds\\[\\]=(\\d+)&calIds\\[\\]=(\\d+)&callIds\\[\\](\\d+)&callIds\\[\\](\\d+)','cal$1,$2,$3,$4','calendar','n','feature_calendar','4',103),(29,'tiki-calendar.php\\?calIds\\[\\]=(\\d+)&calIds\\[\\]=(\\d+)&callIds\\[\\](\\d+)','cal$1,$2,$3','calendar','n','feature_calendar','3',104),(30,'tiki-calendar.php\\?calIds\\[\\]=(\\d+)&calIds\\[\\]=(\\d+)','cal$1,$2','calendar','n','feature_calendar','2',105),(31,'tiki-calendar.php\\?calIds\\[\\]=(\\d+)','cal$1','calendar','n','feature_calendar','1',106),(32,'tiki-calendar.php','calendar','calendar','n','feature_calendar',NULL,200),(33,'tiki-view_articles.php','articles','','n','feature_articles',NULL,200),(34,'tiki-list_blogs.php','blogs','','n','feature_blogs',NULL,200),(35,'tiki-browse_categories.php','categories','','n','feature_categories',NULL,200),(36,'tiki-contact.php','contact','','n','feature_contact',NULL,200),(37,'tiki-directory_browse.php','directories','','n','feature_directory',NULL,200),(38,'tiki-list_faqs.php','faqs','','n','feature_faqs',NULL,200),(39,'tiki-file_galleries.php','files','','n','feature_file_galleries',NULL,200),(40,'tiki-forums.php','forums','','n','feature_forums',NULL,200),(41,'tiki-galleries.php','galleries','','n','feature_galleries',NULL,200),(42,'tiki-login_scr.php','login','','n','',NULL,200),(43,'tiki-my_tiki.php','my','','n','',NULL,200),(44,'tiki-newsletters.php','newsletters','newsletter','n','feature_newsletters',NULL,200),(45,'tiki-list_quizzes.php','quizzes','','n','feature_quizzes',NULL,200),(46,'tiki-stats.php','stats','','n','feature_stats',NULL,200),(47,'tiki-list_surveys.php','surveys','','n','feature_surveys',NULL,200),(48,'tiki-list_trackers.php','trackers','','n','feature_trackers',NULL,200),(49,'tiki-mobile.php','mobile','','n','feature_mobile',NULL,200),(50,'tiki-sheets.php','sheets','','n','feature_sheet',NULL,200),(51,'tiki-view_tracker_item.php\\?trackerId=(\\d+)\\&itemId=(\\d+)','item$2','trackeritem','n','feature_trackers',NULL,200),(52,'tiki-view_tracker_item.php\\?itemId=(\\d+)','item$1','trackeritem','n','feature_trackers',NULL,200),(53,'tiki-list_file_gallery.php\\?galleryId=(\\d+)','file$1','file gallery','n','feature_file_galleries',NULL,200),(54,'tiki-user_information.php\\?userId=(\\d+)','user$1','','n','',NULL,200);
/*!40000 ALTER TABLE `tiki_sefurl_regex_out` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_semantic_tokens`
--

DROP TABLE IF EXISTS `tiki_semantic_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_semantic_tokens` (
  `token` varchar(15) NOT NULL,
  `label` varchar(25) NOT NULL,
  `invert_token` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`token`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_semantic_tokens`
--

LOCK TABLES `tiki_semantic_tokens` WRITE;
/*!40000 ALTER TABLE `tiki_semantic_tokens` DISABLE KEYS */;
INSERT INTO `tiki_semantic_tokens` VALUES ('alias','Page Alias',NULL),('prefixalias','Page Prefix Alias',NULL),('titlefieldid','Field Id for Page Title',NULL),('trackerid','Id of Embedded Tracker',NULL);
/*!40000 ALTER TABLE `tiki_semantic_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_semaphores`
--

DROP TABLE IF EXISTS `tiki_semaphores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_semaphores` (
  `semName` varchar(250) NOT NULL DEFAULT '',
  `objectType` varchar(20) DEFAULT 'wiki page',
  `user` varchar(200) NOT NULL DEFAULT '',
  `timestamp` int(14) DEFAULT NULL,
  PRIMARY KEY (`semName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_semaphores`
--

LOCK TABLES `tiki_semaphores` WRITE;
/*!40000 ALTER TABLE `tiki_semaphores` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_semaphores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_sent_newsletters`
--

DROP TABLE IF EXISTS `tiki_sent_newsletters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_sent_newsletters` (
  `editionId` int(12) NOT NULL AUTO_INCREMENT,
  `nlId` int(12) NOT NULL DEFAULT '0',
  `users` int(10) DEFAULT NULL,
  `sent` int(14) DEFAULT NULL,
  `subject` varchar(200) DEFAULT NULL,
  `data` longblob,
  `datatxt` longblob,
  `wysiwyg` char(1) DEFAULT NULL,
  PRIMARY KEY (`editionId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_sent_newsletters`
--

LOCK TABLES `tiki_sent_newsletters` WRITE;
/*!40000 ALTER TABLE `tiki_sent_newsletters` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_sent_newsletters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_sent_newsletters_errors`
--

DROP TABLE IF EXISTS `tiki_sent_newsletters_errors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_sent_newsletters_errors` (
  `editionId` int(12) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `login` varchar(40) DEFAULT '',
  `error` char(1) DEFAULT '',
  KEY `editionId` (`editionId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_sent_newsletters_errors`
--

LOCK TABLES `tiki_sent_newsletters_errors` WRITE;
/*!40000 ALTER TABLE `tiki_sent_newsletters_errors` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_sent_newsletters_errors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_sent_newsletters_files`
--

DROP TABLE IF EXISTS `tiki_sent_newsletters_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_sent_newsletters_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `editionId` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `type` varchar(64) NOT NULL,
  `size` int(11) NOT NULL,
  `filename` varchar(256) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `editionId` (`editionId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_sent_newsletters_files`
--

LOCK TABLES `tiki_sent_newsletters_files` WRITE;
/*!40000 ALTER TABLE `tiki_sent_newsletters_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_sent_newsletters_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_sessions`
--

DROP TABLE IF EXISTS `tiki_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_sessions` (
  `sessionId` varchar(32) NOT NULL DEFAULT '',
  `user` varchar(200) DEFAULT '',
  `timestamp` int(14) DEFAULT NULL,
  `tikihost` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`sessionId`),
  KEY `user` (`user`),
  KEY `timestamp` (`timestamp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_sessions`
--

LOCK TABLES `tiki_sessions` WRITE;
/*!40000 ALTER TABLE `tiki_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_sheet_layout`
--

DROP TABLE IF EXISTS `tiki_sheet_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_sheet_layout` (
  `sheetId` int(8) NOT NULL DEFAULT '0',
  `begin` int(10) NOT NULL DEFAULT '0',
  `end` int(10) DEFAULT NULL,
  `headerRow` int(4) NOT NULL DEFAULT '0',
  `footerRow` int(4) NOT NULL DEFAULT '0',
  `className` varchar(64) DEFAULT NULL,
  `parseValues` char(1) NOT NULL DEFAULT 'n',
  UNIQUE KEY `sheetId` (`sheetId`,`begin`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_sheet_layout`
--

LOCK TABLES `tiki_sheet_layout` WRITE;
/*!40000 ALTER TABLE `tiki_sheet_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_sheet_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_sheet_values`
--

DROP TABLE IF EXISTS `tiki_sheet_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_sheet_values` (
  `sheetId` int(8) NOT NULL DEFAULT '0',
  `begin` int(10) NOT NULL DEFAULT '0',
  `end` int(10) DEFAULT NULL,
  `rowIndex` int(4) NOT NULL DEFAULT '0',
  `columnIndex` int(4) NOT NULL DEFAULT '0',
  `value` varchar(255) DEFAULT NULL,
  `calculation` varchar(255) DEFAULT NULL,
  `width` int(4) NOT NULL DEFAULT '1',
  `height` int(4) NOT NULL DEFAULT '1',
  `format` varchar(255) DEFAULT NULL,
  `user` varchar(200) DEFAULT '',
  `style` varchar(255) DEFAULT '',
  `class` varchar(255) DEFAULT '',
  UNIQUE KEY `sheetId` (`sheetId`,`begin`,`rowIndex`,`columnIndex`),
  KEY `sheetId_2` (`sheetId`,`rowIndex`,`columnIndex`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_sheet_values`
--

LOCK TABLES `tiki_sheet_values` WRITE;
/*!40000 ALTER TABLE `tiki_sheet_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_sheet_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_sheets`
--

DROP TABLE IF EXISTS `tiki_sheets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_sheets` (
  `sheetId` int(8) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL DEFAULT '',
  `description` text,
  `author` varchar(200) NOT NULL DEFAULT '',
  `parentSheetId` int(8) DEFAULT NULL,
  PRIMARY KEY (`sheetId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_sheets`
--

LOCK TABLES `tiki_sheets` WRITE;
/*!40000 ALTER TABLE `tiki_sheets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_sheets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_shoutbox`
--

DROP TABLE IF EXISTS `tiki_shoutbox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_shoutbox` (
  `msgId` int(10) NOT NULL AUTO_INCREMENT,
  `message` varchar(255) DEFAULT NULL,
  `timestamp` int(14) DEFAULT NULL,
  `user` varchar(200) DEFAULT '',
  `hash` varchar(32) DEFAULT NULL,
  `tweetId` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`msgId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_shoutbox`
--

LOCK TABLES `tiki_shoutbox` WRITE;
/*!40000 ALTER TABLE `tiki_shoutbox` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_shoutbox` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_shoutbox_words`
--

DROP TABLE IF EXISTS `tiki_shoutbox_words`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_shoutbox_words` (
  `word` varchar(40) NOT NULL,
  `qty` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`word`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_shoutbox_words`
--

LOCK TABLES `tiki_shoutbox_words` WRITE;
/*!40000 ALTER TABLE `tiki_shoutbox_words` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_shoutbox_words` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_stats`
--

DROP TABLE IF EXISTS `tiki_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_stats` (
  `object` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(20) NOT NULL DEFAULT '',
  `day` int(14) NOT NULL DEFAULT '0',
  `hits` int(14) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object`(200),`type`,`day`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_stats`
--

LOCK TABLES `tiki_stats` WRITE;
/*!40000 ALTER TABLE `tiki_stats` DISABLE KEYS */;
INSERT INTO `tiki_stats` VALUES ('HomePage','wiki',1305410400,1);
/*!40000 ALTER TABLE `tiki_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_structure_versions`
--

DROP TABLE IF EXISTS `tiki_structure_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_structure_versions` (
  `structure_id` int(14) NOT NULL AUTO_INCREMENT,
  `version` int(14) DEFAULT NULL,
  PRIMARY KEY (`structure_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_structure_versions`
--

LOCK TABLES `tiki_structure_versions` WRITE;
/*!40000 ALTER TABLE `tiki_structure_versions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_structure_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_structures`
--

DROP TABLE IF EXISTS `tiki_structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_structures` (
  `page_ref_id` int(14) NOT NULL AUTO_INCREMENT,
  `structure_id` int(14) NOT NULL,
  `parent_id` int(14) DEFAULT NULL,
  `page_id` int(14) NOT NULL,
  `page_version` int(8) DEFAULT NULL,
  `page_alias` varchar(240) NOT NULL DEFAULT '',
  `pos` int(4) DEFAULT NULL,
  PRIMARY KEY (`page_ref_id`),
  KEY `pidpaid` (`page_id`,`parent_id`),
  KEY `page_id` (`page_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_structures`
--

LOCK TABLES `tiki_structures` WRITE;
/*!40000 ALTER TABLE `tiki_structures` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_submissions`
--

DROP TABLE IF EXISTS `tiki_submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_submissions` (
  `subId` int(8) NOT NULL AUTO_INCREMENT,
  `topline` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `linkto` varchar(255) DEFAULT NULL,
  `lang` varchar(16) DEFAULT NULL,
  `authorName` varchar(60) DEFAULT NULL,
  `topicId` int(14) DEFAULT NULL,
  `topicName` varchar(40) DEFAULT NULL,
  `size` int(12) DEFAULT NULL,
  `useImage` char(1) DEFAULT NULL,
  `image_name` varchar(80) DEFAULT NULL,
  `image_caption` text,
  `image_type` varchar(80) DEFAULT NULL,
  `image_size` int(14) DEFAULT NULL,
  `image_x` int(4) DEFAULT NULL,
  `image_y` int(4) DEFAULT NULL,
  `image_data` longblob,
  `publishDate` int(14) DEFAULT NULL,
  `expireDate` int(14) DEFAULT NULL,
  `created` int(14) DEFAULT NULL,
  `bibliographical_references` text,
  `resume` text,
  `heading` text,
  `body` text,
  `hash` varchar(32) DEFAULT NULL,
  `author` varchar(200) NOT NULL DEFAULT '',
  `nbreads` int(14) DEFAULT NULL,
  `votes` int(8) DEFAULT NULL,
  `points` int(14) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `rating` decimal(3,2) DEFAULT NULL,
  `isfloat` char(1) DEFAULT NULL,
  PRIMARY KEY (`subId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_submissions`
--

LOCK TABLES `tiki_submissions` WRITE;
/*!40000 ALTER TABLE `tiki_submissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_suggested_faq_questions`
--

DROP TABLE IF EXISTS `tiki_suggested_faq_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_suggested_faq_questions` (
  `sfqId` int(10) NOT NULL AUTO_INCREMENT,
  `faqId` int(10) NOT NULL DEFAULT '0',
  `question` text,
  `answer` text,
  `created` int(14) DEFAULT NULL,
  `user` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`sfqId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_suggested_faq_questions`
--

LOCK TABLES `tiki_suggested_faq_questions` WRITE;
/*!40000 ALTER TABLE `tiki_suggested_faq_questions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_suggested_faq_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_survey_question_options`
--

DROP TABLE IF EXISTS `tiki_survey_question_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_survey_question_options` (
  `optionId` int(12) NOT NULL AUTO_INCREMENT,
  `questionId` int(12) NOT NULL DEFAULT '0',
  `qoption` text,
  `votes` int(10) DEFAULT NULL,
  PRIMARY KEY (`optionId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_survey_question_options`
--

LOCK TABLES `tiki_survey_question_options` WRITE;
/*!40000 ALTER TABLE `tiki_survey_question_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_survey_question_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_survey_questions`
--

DROP TABLE IF EXISTS `tiki_survey_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_survey_questions` (
  `questionId` int(12) NOT NULL AUTO_INCREMENT,
  `surveyId` int(12) NOT NULL DEFAULT '0',
  `question` text,
  `options` text,
  `type` char(1) DEFAULT NULL,
  `position` int(5) DEFAULT NULL,
  `votes` int(10) DEFAULT NULL,
  `value` int(10) DEFAULT NULL,
  `average` decimal(4,2) DEFAULT NULL,
  `mandatory` char(1) NOT NULL DEFAULT 'n',
  `max_answers` int(5) NOT NULL DEFAULT '0',
  `min_answers` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`questionId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_survey_questions`
--

LOCK TABLES `tiki_survey_questions` WRITE;
/*!40000 ALTER TABLE `tiki_survey_questions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_survey_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_surveys`
--

DROP TABLE IF EXISTS `tiki_surveys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_surveys` (
  `surveyId` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `description` text,
  `taken` int(10) DEFAULT NULL,
  `lastTaken` int(14) DEFAULT NULL,
  `created` int(14) DEFAULT NULL,
  `status` char(1) DEFAULT NULL,
  PRIMARY KEY (`surveyId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_surveys`
--

LOCK TABLES `tiki_surveys` WRITE;
/*!40000 ALTER TABLE `tiki_surveys` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_surveys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_tags`
--

DROP TABLE IF EXISTS `tiki_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_tags` (
  `tagName` varchar(80) NOT NULL DEFAULT '',
  `pageName` varchar(160) NOT NULL DEFAULT '',
  `hits` int(8) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `data` longblob,
  `lastModif` int(14) DEFAULT NULL,
  `comment` varchar(200) DEFAULT NULL,
  `version` int(8) NOT NULL DEFAULT '0',
  `user` varchar(200) NOT NULL DEFAULT '',
  `ip` varchar(15) DEFAULT NULL,
  `flag` char(1) DEFAULT NULL,
  PRIMARY KEY (`tagName`,`pageName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_tags`
--

LOCK TABLES `tiki_tags` WRITE;
/*!40000 ALTER TABLE `tiki_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_theme_control_categs`
--

DROP TABLE IF EXISTS `tiki_theme_control_categs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_theme_control_categs` (
  `categId` int(12) NOT NULL DEFAULT '0',
  `theme` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`categId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_theme_control_categs`
--

LOCK TABLES `tiki_theme_control_categs` WRITE;
/*!40000 ALTER TABLE `tiki_theme_control_categs` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_theme_control_categs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_theme_control_objects`
--

DROP TABLE IF EXISTS `tiki_theme_control_objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_theme_control_objects` (
  `objId` varchar(250) NOT NULL DEFAULT '',
  `type` varchar(250) NOT NULL DEFAULT '',
  `name` varchar(250) NOT NULL DEFAULT '',
  `theme` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`objId`(100),`type`(100))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_theme_control_objects`
--

LOCK TABLES `tiki_theme_control_objects` WRITE;
/*!40000 ALTER TABLE `tiki_theme_control_objects` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_theme_control_objects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_theme_control_sections`
--

DROP TABLE IF EXISTS `tiki_theme_control_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_theme_control_sections` (
  `section` varchar(250) NOT NULL DEFAULT '',
  `theme` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`section`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_theme_control_sections`
--

LOCK TABLES `tiki_theme_control_sections` WRITE;
/*!40000 ALTER TABLE `tiki_theme_control_sections` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_theme_control_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_todo`
--

DROP TABLE IF EXISTS `tiki_todo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_todo` (
  `todoId` int(12) NOT NULL AUTO_INCREMENT,
  `after` int(12) NOT NULL,
  `event` varchar(50) NOT NULL,
  `objectType` varchar(50) DEFAULT NULL,
  `objectId` varchar(255) DEFAULT NULL,
  `from` varchar(255) DEFAULT NULL,
  `to` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`todoId`),
  KEY `what` (`objectType`,`objectId`),
  KEY `after` (`after`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_todo`
--

LOCK TABLES `tiki_todo` WRITE;
/*!40000 ALTER TABLE `tiki_todo` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_todo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_todo_notif`
--

DROP TABLE IF EXISTS `tiki_todo_notif`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_todo_notif` (
  `todoId` int(12) NOT NULL,
  `objectType` varchar(50) DEFAULT NULL,
  `objectId` varchar(255) DEFAULT NULL,
  KEY `todoId` (`todoId`),
  KEY `objectId` (`objectId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_todo_notif`
--

LOCK TABLES `tiki_todo_notif` WRITE;
/*!40000 ALTER TABLE `tiki_todo_notif` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_todo_notif` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_topics`
--

DROP TABLE IF EXISTS `tiki_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_topics` (
  `topicId` int(14) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) DEFAULT NULL,
  `image_name` varchar(80) DEFAULT NULL,
  `image_type` varchar(80) DEFAULT NULL,
  `image_size` int(14) DEFAULT NULL,
  `image_data` longblob,
  `active` char(1) DEFAULT NULL,
  `created` int(14) DEFAULT NULL,
  PRIMARY KEY (`topicId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_topics`
--

LOCK TABLES `tiki_topics` WRITE;
/*!40000 ALTER TABLE `tiki_topics` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_tracker_fields`
--

DROP TABLE IF EXISTS `tiki_tracker_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_tracker_fields` (
  `fieldId` int(12) NOT NULL AUTO_INCREMENT,
  `trackerId` int(12) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `options` text,
  `type` varchar(15) DEFAULT NULL,
  `isMain` char(1) DEFAULT NULL,
  `isTblVisible` char(1) DEFAULT NULL,
  `position` int(4) DEFAULT NULL,
  `isSearchable` char(1) NOT NULL DEFAULT 'y',
  `isPublic` char(1) NOT NULL DEFAULT 'n',
  `isHidden` char(1) NOT NULL DEFAULT 'n',
  `isMandatory` char(1) NOT NULL DEFAULT 'n',
  `description` text,
  `isMultilingual` char(1) DEFAULT 'n',
  `itemChoices` text,
  `errorMsg` text,
  `visibleBy` text,
  `editableBy` text,
  `descriptionIsParsed` char(1) DEFAULT 'n',
  `validation` varchar(255) DEFAULT '',
  `validationParam` varchar(255) DEFAULT '',
  `validationMessage` varchar(255) DEFAULT '',
  PRIMARY KEY (`fieldId`),
  KEY `trackerId` (`trackerId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_tracker_fields`
--

LOCK TABLES `tiki_tracker_fields` WRITE;
/*!40000 ALTER TABLE `tiki_tracker_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_tracker_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_tracker_item_attachments`
--

DROP TABLE IF EXISTS `tiki_tracker_item_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_tracker_item_attachments` (
  `attId` int(12) NOT NULL AUTO_INCREMENT,
  `itemId` int(12) NOT NULL DEFAULT '0',
  `filename` varchar(80) DEFAULT NULL,
  `filetype` varchar(80) DEFAULT NULL,
  `filesize` int(14) DEFAULT NULL,
  `user` varchar(200) DEFAULT NULL,
  `data` longblob,
  `path` varchar(255) DEFAULT NULL,
  `hits` int(10) DEFAULT NULL,
  `created` int(14) DEFAULT NULL,
  `comment` varchar(250) DEFAULT NULL,
  `longdesc` blob,
  `version` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`attId`),
  KEY `itemId` (`itemId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_tracker_item_attachments`
--

LOCK TABLES `tiki_tracker_item_attachments` WRITE;
/*!40000 ALTER TABLE `tiki_tracker_item_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_tracker_item_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_tracker_item_comments`
--

DROP TABLE IF EXISTS `tiki_tracker_item_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_tracker_item_comments` (
  `commentId` int(12) NOT NULL AUTO_INCREMENT,
  `itemId` int(12) NOT NULL DEFAULT '0',
  `user` varchar(200) DEFAULT NULL,
  `data` text,
  `title` varchar(200) DEFAULT NULL,
  `posted` int(14) DEFAULT NULL,
  PRIMARY KEY (`commentId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_tracker_item_comments`
--

LOCK TABLES `tiki_tracker_item_comments` WRITE;
/*!40000 ALTER TABLE `tiki_tracker_item_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_tracker_item_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_tracker_item_field_logs`
--

DROP TABLE IF EXISTS `tiki_tracker_item_field_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_tracker_item_field_logs` (
  `version` int(12) NOT NULL,
  `itemId` int(12) NOT NULL DEFAULT '0',
  `fieldId` int(12) NOT NULL DEFAULT '0',
  `value` text,
  `lang` char(16) DEFAULT NULL,
  KEY `version` (`version`),
  KEY `itemId` (`itemId`),
  KEY `fieldId` (`itemId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_tracker_item_field_logs`
--

LOCK TABLES `tiki_tracker_item_field_logs` WRITE;
/*!40000 ALTER TABLE `tiki_tracker_item_field_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_tracker_item_field_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_tracker_item_fields`
--

DROP TABLE IF EXISTS `tiki_tracker_item_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_tracker_item_fields` (
  `itemId` int(12) NOT NULL DEFAULT '0',
  `fieldId` int(12) NOT NULL DEFAULT '0',
  `value` text,
  `lang` char(16) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemId`,`fieldId`,`lang`),
  KEY `fieldId` (`fieldId`),
  KEY `value` (`value`(250)),
  KEY `lang` (`lang`),
  FULLTEXT KEY `ft` (`value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_tracker_item_fields`
--

LOCK TABLES `tiki_tracker_item_fields` WRITE;
/*!40000 ALTER TABLE `tiki_tracker_item_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_tracker_item_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_tracker_items`
--

DROP TABLE IF EXISTS `tiki_tracker_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_tracker_items` (
  `itemId` int(12) NOT NULL AUTO_INCREMENT,
  `trackerId` int(12) NOT NULL DEFAULT '0',
  `created` int(14) DEFAULT NULL,
  `createdBy` varchar(200) DEFAULT NULL,
  `status` char(1) DEFAULT NULL,
  `lastModif` int(14) DEFAULT NULL,
  `lastModifBy` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`itemId`),
  KEY `trackerId` (`trackerId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_tracker_items`
--

LOCK TABLES `tiki_tracker_items` WRITE;
/*!40000 ALTER TABLE `tiki_tracker_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_tracker_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_tracker_options`
--

DROP TABLE IF EXISTS `tiki_tracker_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_tracker_options` (
  `trackerId` int(12) NOT NULL DEFAULT '0',
  `name` varchar(80) NOT NULL DEFAULT '',
  `value` text,
  PRIMARY KEY (`trackerId`,`name`(30))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_tracker_options`
--

LOCK TABLES `tiki_tracker_options` WRITE;
/*!40000 ALTER TABLE `tiki_tracker_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_tracker_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_trackers`
--

DROP TABLE IF EXISTS `tiki_trackers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_trackers` (
  `trackerId` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `descriptionIsParsed` varchar(1) DEFAULT '0',
  `created` int(14) DEFAULT NULL,
  `lastModif` int(14) DEFAULT NULL,
  `showCreated` char(1) DEFAULT NULL,
  `showStatus` char(1) DEFAULT NULL,
  `showLastModif` char(1) DEFAULT NULL,
  `useComments` char(1) DEFAULT NULL,
  `useAttachments` char(1) DEFAULT NULL,
  `showAttachments` char(1) DEFAULT NULL,
  `items` int(10) DEFAULT NULL,
  `showComments` char(1) DEFAULT NULL,
  `orderAttachments` varchar(255) NOT NULL DEFAULT 'filename,created,filesize,hits,desc',
  PRIMARY KEY (`trackerId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_trackers`
--

LOCK TABLES `tiki_trackers` WRITE;
/*!40000 ALTER TABLE `tiki_trackers` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_trackers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_transitions`
--

DROP TABLE IF EXISTS `tiki_transitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_transitions` (
  `transitionId` int(11) NOT NULL AUTO_INCREMENT,
  `preserve` int(1) NOT NULL DEFAULT '0',
  `name` varchar(50) DEFAULT NULL,
  `type` varchar(20) NOT NULL,
  `from` varchar(255) NOT NULL,
  `to` varchar(255) NOT NULL,
  `guards` text,
  PRIMARY KEY (`transitionId`),
  KEY `transition_lookup` (`type`,`from`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_transitions`
--

LOCK TABLES `tiki_transitions` WRITE;
/*!40000 ALTER TABLE `tiki_transitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_transitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_translated_objects`
--

DROP TABLE IF EXISTS `tiki_translated_objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_translated_objects` (
  `traId` int(14) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `objId` varchar(255) NOT NULL,
  `lang` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`type`,`objId`),
  KEY `traId` (`traId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_translated_objects`
--

LOCK TABLES `tiki_translated_objects` WRITE;
/*!40000 ALTER TABLE `tiki_translated_objects` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_translated_objects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_translations_in_progress`
--

DROP TABLE IF EXISTS `tiki_translations_in_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_translations_in_progress` (
  `page_id` int(14) NOT NULL,
  `language` char(2) NOT NULL,
  UNIQUE KEY `page_id_2` (`page_id`,`language`),
  KEY `page_id` (`page_id`),
  KEY `language` (`language`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_translations_in_progress`
--

LOCK TABLES `tiki_translations_in_progress` WRITE;
/*!40000 ALTER TABLE `tiki_translations_in_progress` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_translations_in_progress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_untranslated`
--

DROP TABLE IF EXISTS `tiki_untranslated`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_untranslated` (
  `id` int(14) NOT NULL AUTO_INCREMENT,
  `source` tinyblob NOT NULL,
  `lang` char(16) NOT NULL DEFAULT '',
  PRIMARY KEY (`source`(255),`lang`),
  UNIQUE KEY `id` (`id`),
  KEY `id_2` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_untranslated`
--

LOCK TABLES `tiki_untranslated` WRITE;
/*!40000 ALTER TABLE `tiki_untranslated` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_untranslated` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_url_shortener`
--

DROP TABLE IF EXISTS `tiki_url_shortener`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_url_shortener` (
  `urlId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` varchar(200) NOT NULL,
  `longurl` tinytext NOT NULL,
  `longurl_hash` varchar(32) NOT NULL,
  `service` varchar(32) NOT NULL,
  `shorturl` varchar(63) NOT NULL,
  PRIMARY KEY (`urlId`),
  UNIQUE KEY `shorturl` (`shorturl`),
  KEY `longurl_hash` (`longurl_hash`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_url_shortener`
--

LOCK TABLES `tiki_url_shortener` WRITE;
/*!40000 ALTER TABLE `tiki_url_shortener` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_url_shortener` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_user_answers`
--

DROP TABLE IF EXISTS `tiki_user_answers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_user_answers` (
  `userResultId` int(10) NOT NULL DEFAULT '0',
  `quizId` int(10) NOT NULL DEFAULT '0',
  `questionId` int(10) NOT NULL DEFAULT '0',
  `optionId` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`userResultId`,`quizId`,`questionId`,`optionId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_user_answers`
--

LOCK TABLES `tiki_user_answers` WRITE;
/*!40000 ALTER TABLE `tiki_user_answers` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_user_answers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_user_answers_uploads`
--

DROP TABLE IF EXISTS `tiki_user_answers_uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_user_answers_uploads` (
  `answerUploadId` int(4) NOT NULL AUTO_INCREMENT,
  `userResultId` int(11) NOT NULL DEFAULT '0',
  `questionId` int(11) NOT NULL DEFAULT '0',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `filetype` varchar(64) NOT NULL DEFAULT '',
  `filesize` varchar(255) NOT NULL DEFAULT '',
  `filecontent` longblob NOT NULL,
  PRIMARY KEY (`answerUploadId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_user_answers_uploads`
--

LOCK TABLES `tiki_user_answers_uploads` WRITE;
/*!40000 ALTER TABLE `tiki_user_answers_uploads` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_user_answers_uploads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_user_assigned_modules`
--

DROP TABLE IF EXISTS `tiki_user_assigned_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_user_assigned_modules` (
  `moduleId` int(8) NOT NULL,
  `name` varchar(200) NOT NULL DEFAULT '',
  `position` char(1) NOT NULL DEFAULT '',
  `ord` int(4) NOT NULL DEFAULT '0',
  `type` char(1) DEFAULT NULL,
  `user` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`name`(30),`user`,`position`,`ord`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_user_assigned_modules`
--

LOCK TABLES `tiki_user_assigned_modules` WRITE;
/*!40000 ALTER TABLE `tiki_user_assigned_modules` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_user_assigned_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_user_bookmarks_folders`
--

DROP TABLE IF EXISTS `tiki_user_bookmarks_folders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_user_bookmarks_folders` (
  `folderId` int(12) NOT NULL AUTO_INCREMENT,
  `parentId` int(12) DEFAULT NULL,
  `user` varchar(200) NOT NULL DEFAULT '',
  `name` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`user`,`folderId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_user_bookmarks_folders`
--

LOCK TABLES `tiki_user_bookmarks_folders` WRITE;
/*!40000 ALTER TABLE `tiki_user_bookmarks_folders` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_user_bookmarks_folders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_user_bookmarks_urls`
--

DROP TABLE IF EXISTS `tiki_user_bookmarks_urls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_user_bookmarks_urls` (
  `urlId` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `url` varchar(250) DEFAULT NULL,
  `data` longblob,
  `lastUpdated` int(14) DEFAULT NULL,
  `folderId` int(12) NOT NULL DEFAULT '0',
  `user` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`urlId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_user_bookmarks_urls`
--

LOCK TABLES `tiki_user_bookmarks_urls` WRITE;
/*!40000 ALTER TABLE `tiki_user_bookmarks_urls` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_user_bookmarks_urls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_user_login_cookies`
--

DROP TABLE IF EXISTS `tiki_user_login_cookies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_user_login_cookies` (
  `userId` int(11) NOT NULL,
  `secret` char(64) NOT NULL,
  `expiration` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`userId`,`secret`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_user_login_cookies`
--

LOCK TABLES `tiki_user_login_cookies` WRITE;
/*!40000 ALTER TABLE `tiki_user_login_cookies` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_user_login_cookies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_user_mail_accounts`
--

DROP TABLE IF EXISTS `tiki_user_mail_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_user_mail_accounts` (
  `accountId` int(12) NOT NULL AUTO_INCREMENT,
  `user` varchar(200) NOT NULL DEFAULT '',
  `account` varchar(50) NOT NULL DEFAULT '',
  `pop` varchar(255) DEFAULT NULL,
  `current` char(1) DEFAULT NULL,
  `port` int(4) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `pass` varchar(100) DEFAULT NULL,
  `msgs` int(4) DEFAULT NULL,
  `smtp` varchar(255) DEFAULT NULL,
  `useAuth` char(1) DEFAULT NULL,
  `smtpPort` int(4) DEFAULT NULL,
  `flagsPublic` char(1) DEFAULT 'n',
  `autoRefresh` int(4) NOT NULL DEFAULT '0',
  `imap` varchar(255) DEFAULT NULL,
  `mbox` varchar(255) DEFAULT NULL,
  `maildir` varchar(255) DEFAULT NULL,
  `useSSL` char(1) NOT NULL DEFAULT 'n',
  `fromEmail` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`accountId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_user_mail_accounts`
--

LOCK TABLES `tiki_user_mail_accounts` WRITE;
/*!40000 ALTER TABLE `tiki_user_mail_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_user_mail_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_user_menus`
--

DROP TABLE IF EXISTS `tiki_user_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_user_menus` (
  `user` varchar(200) NOT NULL DEFAULT '',
  `menuId` int(12) NOT NULL AUTO_INCREMENT,
  `url` varchar(250) DEFAULT NULL,
  `name` varchar(40) DEFAULT NULL,
  `position` int(4) DEFAULT NULL,
  `mode` char(1) DEFAULT NULL,
  PRIMARY KEY (`menuId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_user_menus`
--

LOCK TABLES `tiki_user_menus` WRITE;
/*!40000 ALTER TABLE `tiki_user_menus` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_user_menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_user_modules`
--

DROP TABLE IF EXISTS `tiki_user_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_user_modules` (
  `name` varchar(200) NOT NULL DEFAULT '',
  `title` varchar(40) DEFAULT NULL,
  `data` longblob,
  `parse` char(1) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_user_modules`
--

LOCK TABLES `tiki_user_modules` WRITE;
/*!40000 ALTER TABLE `tiki_user_modules` DISABLE KEYS */;
INSERT INTO `tiki_user_modules` VALUES ('Application Menu','Menu','{menu id=42 css=y type=vert}','n');
/*!40000 ALTER TABLE `tiki_user_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_user_notes`
--

DROP TABLE IF EXISTS `tiki_user_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_user_notes` (
  `user` varchar(200) NOT NULL DEFAULT '',
  `noteId` int(12) NOT NULL AUTO_INCREMENT,
  `created` int(14) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `lastModif` int(14) DEFAULT NULL,
  `data` text,
  `size` int(14) DEFAULT NULL,
  `parse_mode` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`noteId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_user_notes`
--

LOCK TABLES `tiki_user_notes` WRITE;
/*!40000 ALTER TABLE `tiki_user_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_user_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_user_postings`
--

DROP TABLE IF EXISTS `tiki_user_postings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_user_postings` (
  `user` varchar(200) NOT NULL DEFAULT '',
  `posts` int(12) DEFAULT NULL,
  `last` int(14) DEFAULT NULL,
  `first` int(14) DEFAULT NULL,
  `level` int(8) DEFAULT NULL,
  PRIMARY KEY (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_user_postings`
--

LOCK TABLES `tiki_user_postings` WRITE;
/*!40000 ALTER TABLE `tiki_user_postings` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_user_postings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_user_preferences`
--

DROP TABLE IF EXISTS `tiki_user_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_user_preferences` (
  `user` varchar(200) NOT NULL DEFAULT '',
  `prefName` varchar(40) NOT NULL DEFAULT '',
  `value` text,
  PRIMARY KEY (`user`,`prefName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_user_preferences`
--

LOCK TABLES `tiki_user_preferences` WRITE;
/*!40000 ALTER TABLE `tiki_user_preferences` DISABLE KEYS */;
INSERT INTO `tiki_user_preferences` VALUES ('admin','realName','System Administrator');
/*!40000 ALTER TABLE `tiki_user_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_user_quizzes`
--

DROP TABLE IF EXISTS `tiki_user_quizzes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_user_quizzes` (
  `user` varchar(200) DEFAULT '',
  `quizId` int(10) DEFAULT NULL,
  `timestamp` int(14) DEFAULT NULL,
  `timeTaken` int(14) DEFAULT NULL,
  `points` int(12) DEFAULT NULL,
  `maxPoints` int(12) DEFAULT NULL,
  `resultId` int(10) DEFAULT NULL,
  `userResultId` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`userResultId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_user_quizzes`
--

LOCK TABLES `tiki_user_quizzes` WRITE;
/*!40000 ALTER TABLE `tiki_user_quizzes` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_user_quizzes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_user_reports`
--

DROP TABLE IF EXISTS `tiki_user_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_user_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(200) NOT NULL,
  `interval` varchar(20) NOT NULL,
  `view` varchar(8) NOT NULL,
  `type` varchar(5) NOT NULL,
  `time_to_send` datetime DEFAULT '0000-00-00 00:00:00',
  `always_email` tinyint(1) NOT NULL,
  `last_report` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_user_reports`
--

LOCK TABLES `tiki_user_reports` WRITE;
/*!40000 ALTER TABLE `tiki_user_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_user_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_user_reports_cache`
--

DROP TABLE IF EXISTS `tiki_user_reports_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_user_reports_cache` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(200) NOT NULL,
  `event` varchar(200) NOT NULL,
  `data` text NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_user_reports_cache`
--

LOCK TABLES `tiki_user_reports_cache` WRITE;
/*!40000 ALTER TABLE `tiki_user_reports_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_user_reports_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_user_taken_quizzes`
--

DROP TABLE IF EXISTS `tiki_user_taken_quizzes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_user_taken_quizzes` (
  `user` varchar(200) NOT NULL DEFAULT '',
  `quizId` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`user`,`quizId`(50))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_user_taken_quizzes`
--

LOCK TABLES `tiki_user_taken_quizzes` WRITE;
/*!40000 ALTER TABLE `tiki_user_taken_quizzes` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_user_taken_quizzes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_user_tasks`
--

DROP TABLE IF EXISTS `tiki_user_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_user_tasks` (
  `taskId` int(14) NOT NULL AUTO_INCREMENT,
  `last_version` int(4) NOT NULL DEFAULT '0',
  `user` varchar(200) NOT NULL DEFAULT '',
  `creator` varchar(200) NOT NULL,
  `public_for_group` varchar(30) DEFAULT NULL,
  `rights_by_creator` char(1) DEFAULT NULL,
  `created` int(14) NOT NULL,
  `status` char(1) DEFAULT NULL,
  `priority` int(2) DEFAULT NULL,
  `completed` int(14) DEFAULT NULL,
  `percentage` int(4) DEFAULT NULL,
  PRIMARY KEY (`taskId`),
  UNIQUE KEY `creator` (`creator`,`created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_user_tasks`
--

LOCK TABLES `tiki_user_tasks` WRITE;
/*!40000 ALTER TABLE `tiki_user_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_user_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_user_tasks_history`
--

DROP TABLE IF EXISTS `tiki_user_tasks_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_user_tasks_history` (
  `belongs_to` int(14) NOT NULL,
  `task_version` int(4) NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL,
  `description` text,
  `start` int(14) DEFAULT NULL,
  `end` int(14) DEFAULT NULL,
  `lasteditor` varchar(200) NOT NULL,
  `lastchanges` int(14) NOT NULL,
  `priority` int(2) NOT NULL DEFAULT '3',
  `completed` int(14) DEFAULT NULL,
  `deleted` int(14) DEFAULT NULL,
  `status` char(1) DEFAULT NULL,
  `percentage` int(4) DEFAULT NULL,
  `accepted_creator` char(1) DEFAULT NULL,
  `accepted_user` char(1) DEFAULT NULL,
  PRIMARY KEY (`belongs_to`,`task_version`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_user_tasks_history`
--

LOCK TABLES `tiki_user_tasks_history` WRITE;
/*!40000 ALTER TABLE `tiki_user_tasks_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_user_tasks_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_user_votings`
--

DROP TABLE IF EXISTS `tiki_user_votings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_user_votings` (
  `user` varchar(200) NOT NULL DEFAULT '',
  `ip` varchar(15) DEFAULT NULL,
  `id` varchar(255) NOT NULL DEFAULT '',
  `optionId` int(10) NOT NULL DEFAULT '0',
  `time` int(14) NOT NULL DEFAULT '0',
  KEY `user` (`user`(100),`id`(100)),
  KEY `ip` (`ip`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_user_votings`
--

LOCK TABLES `tiki_user_votings` WRITE;
/*!40000 ALTER TABLE `tiki_user_votings` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_user_votings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_user_watches`
--

DROP TABLE IF EXISTS `tiki_user_watches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_user_watches` (
  `watchId` int(12) NOT NULL AUTO_INCREMENT,
  `user` varchar(200) NOT NULL DEFAULT '',
  `event` varchar(40) NOT NULL DEFAULT '',
  `object` varchar(200) NOT NULL DEFAULT '',
  `title` varchar(250) DEFAULT NULL,
  `type` varchar(200) DEFAULT NULL,
  `url` varchar(250) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`watchId`),
  KEY `event-object-user` (`event`,`object`(100),`user`(50))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_user_watches`
--

LOCK TABLES `tiki_user_watches` WRITE;
/*!40000 ALTER TABLE `tiki_user_watches` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_user_watches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_userfiles`
--

DROP TABLE IF EXISTS `tiki_userfiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_userfiles` (
  `user` varchar(200) NOT NULL DEFAULT '',
  `fileId` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `filename` varchar(200) DEFAULT NULL,
  `filetype` varchar(200) DEFAULT NULL,
  `filesize` varchar(200) DEFAULT NULL,
  `data` longblob,
  `hits` int(8) DEFAULT NULL,
  `isFile` char(1) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `created` int(14) DEFAULT NULL,
  PRIMARY KEY (`fileId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_userfiles`
--

LOCK TABLES `tiki_userfiles` WRITE;
/*!40000 ALTER TABLE `tiki_userfiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_userfiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_userpoints`
--

DROP TABLE IF EXISTS `tiki_userpoints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_userpoints` (
  `user` varchar(200) NOT NULL DEFAULT '',
  `points` decimal(8,2) DEFAULT NULL,
  `voted` int(8) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_userpoints`
--

LOCK TABLES `tiki_userpoints` WRITE;
/*!40000 ALTER TABLE `tiki_userpoints` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_userpoints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_users_score`
--

DROP TABLE IF EXISTS `tiki_users_score`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_users_score` (
  `user` char(200) NOT NULL DEFAULT '',
  `event_id` char(200) NOT NULL DEFAULT '',
  `expire` int(14) NOT NULL DEFAULT '0',
  `tstamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user`(110),`event_id`(110)),
  KEY `user` (`user`(110),`event_id`(110),`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_users_score`
--

LOCK TABLES `tiki_users_score` WRITE;
/*!40000 ALTER TABLE `tiki_users_score` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_users_score` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_webmail_contacts`
--

DROP TABLE IF EXISTS `tiki_webmail_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_webmail_contacts` (
  `contactId` int(12) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(80) DEFAULT NULL,
  `lastName` varchar(80) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `nickname` varchar(200) DEFAULT NULL,
  `user` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`contactId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_webmail_contacts`
--

LOCK TABLES `tiki_webmail_contacts` WRITE;
/*!40000 ALTER TABLE `tiki_webmail_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_webmail_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_webmail_contacts_ext`
--

DROP TABLE IF EXISTS `tiki_webmail_contacts_ext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_webmail_contacts_ext` (
  `contactId` int(11) NOT NULL,
  `value` varchar(255) NOT NULL,
  `hidden` tinyint(1) NOT NULL,
  `fieldId` int(10) unsigned NOT NULL,
  KEY `contactId` (`contactId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_webmail_contacts_ext`
--

LOCK TABLES `tiki_webmail_contacts_ext` WRITE;
/*!40000 ALTER TABLE `tiki_webmail_contacts_ext` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_webmail_contacts_ext` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_webmail_contacts_fields`
--

DROP TABLE IF EXISTS `tiki_webmail_contacts_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_webmail_contacts_fields` (
  `user` varchar(200) NOT NULL,
  `fieldname` varchar(255) NOT NULL,
  `order` int(2) NOT NULL DEFAULT '0',
  `show` char(1) NOT NULL DEFAULT 'n',
  `fieldId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `flagsPublic` char(1) NOT NULL DEFAULT 'n',
  PRIMARY KEY (`fieldId`),
  KEY `user` (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_webmail_contacts_fields`
--

LOCK TABLES `tiki_webmail_contacts_fields` WRITE;
/*!40000 ALTER TABLE `tiki_webmail_contacts_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_webmail_contacts_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_webmail_contacts_groups`
--

DROP TABLE IF EXISTS `tiki_webmail_contacts_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_webmail_contacts_groups` (
  `contactId` int(12) NOT NULL,
  `groupName` varchar(255) NOT NULL,
  PRIMARY KEY (`contactId`,`groupName`(200))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_webmail_contacts_groups`
--

LOCK TABLES `tiki_webmail_contacts_groups` WRITE;
/*!40000 ALTER TABLE `tiki_webmail_contacts_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_webmail_contacts_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_webmail_messages`
--

DROP TABLE IF EXISTS `tiki_webmail_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_webmail_messages` (
  `accountId` int(12) NOT NULL DEFAULT '0',
  `mailId` varchar(255) NOT NULL DEFAULT '',
  `user` varchar(200) NOT NULL DEFAULT '',
  `isRead` char(1) DEFAULT NULL,
  `isReplied` char(1) DEFAULT NULL,
  `isFlagged` char(1) DEFAULT NULL,
  `flaggedMsg` varchar(50) DEFAULT '',
  PRIMARY KEY (`accountId`,`mailId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_webmail_messages`
--

LOCK TABLES `tiki_webmail_messages` WRITE;
/*!40000 ALTER TABLE `tiki_webmail_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_webmail_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_webservice`
--

DROP TABLE IF EXISTS `tiki_webservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_webservice` (
  `service` varchar(25) NOT NULL,
  `url` varchar(250) DEFAULT NULL,
  `body` text,
  `schema_version` varchar(5) DEFAULT NULL,
  `schema_documentation` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`service`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_webservice`
--

LOCK TABLES `tiki_webservice` WRITE;
/*!40000 ALTER TABLE `tiki_webservice` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_webservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_webservice_template`
--

DROP TABLE IF EXISTS `tiki_webservice_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_webservice_template` (
  `service` varchar(25) NOT NULL,
  `template` varchar(25) NOT NULL,
  `engine` varchar(15) NOT NULL,
  `output` varchar(15) NOT NULL,
  `content` text NOT NULL,
  `last_modif` int(11) DEFAULT NULL,
  PRIMARY KEY (`service`,`template`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_webservice_template`
--

LOCK TABLES `tiki_webservice_template` WRITE;
/*!40000 ALTER TABLE `tiki_webservice_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_webservice_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_wiki_attachments`
--

DROP TABLE IF EXISTS `tiki_wiki_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_wiki_attachments` (
  `attId` int(12) NOT NULL AUTO_INCREMENT,
  `page` varchar(200) NOT NULL DEFAULT '',
  `filename` varchar(255) DEFAULT NULL,
  `filetype` varchar(80) DEFAULT NULL,
  `filesize` int(14) DEFAULT NULL,
  `user` varchar(200) NOT NULL DEFAULT '',
  `data` longblob,
  `path` varchar(255) DEFAULT NULL,
  `hits` int(10) DEFAULT NULL,
  `created` int(14) DEFAULT NULL,
  `comment` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`attId`),
  KEY `page` (`page`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_wiki_attachments`
--

LOCK TABLES `tiki_wiki_attachments` WRITE;
/*!40000 ALTER TABLE `tiki_wiki_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_wiki_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tiki_zones`
--

DROP TABLE IF EXISTS `tiki_zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tiki_zones` (
  `zone` varchar(40) NOT NULL DEFAULT '',
  PRIMARY KEY (`zone`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiki_zones`
--

LOCK TABLES `tiki_zones` WRITE;
/*!40000 ALTER TABLE `tiki_zones` DISABLE KEYS */;
/*!40000 ALTER TABLE `tiki_zones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_grouppermissions`
--

DROP TABLE IF EXISTS `users_grouppermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_grouppermissions` (
  `groupName` varchar(255) NOT NULL DEFAULT '',
  `permName` varchar(40) NOT NULL DEFAULT '',
  `value` char(1) DEFAULT '',
  PRIMARY KEY (`groupName`(30),`permName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_grouppermissions`
--

LOCK TABLES `users_grouppermissions` WRITE;
/*!40000 ALTER TABLE `users_grouppermissions` DISABLE KEYS */;
INSERT INTO `users_grouppermissions` VALUES ('Anonymous','tiki_p_view',''),('Admins','tiki_p_admin','');
/*!40000 ALTER TABLE `users_grouppermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_groups`
--

DROP TABLE IF EXISTS `users_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupName` varchar(255) NOT NULL DEFAULT '',
  `groupDesc` varchar(255) DEFAULT NULL,
  `groupHome` varchar(255) DEFAULT NULL,
  `usersTrackerId` int(11) DEFAULT NULL,
  `groupTrackerId` int(11) DEFAULT NULL,
  `usersFieldId` int(11) DEFAULT NULL,
  `groupFieldId` int(11) DEFAULT NULL,
  `registrationChoice` char(1) DEFAULT NULL,
  `registrationUsersFieldIds` text,
  `userChoice` char(1) DEFAULT NULL,
  `groupDefCat` int(12) DEFAULT '0',
  `groupTheme` varchar(255) DEFAULT '',
  `isExternal` char(1) DEFAULT 'n',
  `expireAfter` int(14) DEFAULT '0',
  `emailPattern` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `groupName` (`groupName`),
  KEY `expireAfter` (`expireAfter`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_groups`
--

LOCK TABLES `users_groups` WRITE;
/*!40000 ALTER TABLE `users_groups` DISABLE KEYS */;
INSERT INTO `users_groups` VALUES (1,'Anonymous','Public users not logged',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'','n',0,''),(2,'Registered','Users logged into the system',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'','n',0,''),(3,'Admins','Administrator and accounts managers.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'','n',0,'');
/*!40000 ALTER TABLE `users_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_objectpermissions`
--

DROP TABLE IF EXISTS `users_objectpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_objectpermissions` (
  `groupName` varchar(255) NOT NULL DEFAULT '',
  `permName` varchar(40) NOT NULL DEFAULT '',
  `objectType` varchar(20) NOT NULL DEFAULT '',
  `objectId` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`objectId`,`objectType`,`groupName`(30),`permName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_objectpermissions`
--

LOCK TABLES `users_objectpermissions` WRITE;
/*!40000 ALTER TABLE `users_objectpermissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_objectpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_permissions`
--

DROP TABLE IF EXISTS `users_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_permissions` (
  `permName` varchar(40) NOT NULL DEFAULT '',
  `permDesc` varchar(250) DEFAULT NULL,
  `level` varchar(80) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `admin` varchar(1) DEFAULT NULL,
  `feature_check` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`permName`),
  KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_permissions`
--

LOCK TABLES `users_permissions` WRITE;
/*!40000 ALTER TABLE `users_permissions` DISABLE KEYS */;
INSERT INTO `users_permissions` VALUES ('tiki_p_admin_calendar','Can create/admin calendars','admin','calendar','y','feature_calendar'),('tiki_p_add_events','Can add events in the calendar','registered','calendar',NULL,'feature_calendar'),('tiki_p_change_events','Can change events in the calendar','registered','calendar',NULL,'feature_calendar'),('tiki_p_view_calendar','Can browse the calendar','basic','calendar',NULL,'feature_calendar'),('tiki_p_view_events','Can view events details','registered','calendar',NULL,'feature_calendar'),('tiki_p_calendar_add_my_particip','Can add own user to the participants','registered','calendar',NULL,'feature_calendar'),('tiki_p_calendar_add_guest_particip','Can add guest to the participants','registered','calendar',NULL,'feature_calendar'),('tiki_p_view_tiki_calendar','Can view Tiki tools calendar','basic','calendar',NULL,'feature_calendar'),('tiki_p_admin_chat','Administrator, can create channels remove channels etc','editors','chat','y','feature_minichat,feature_live_support'),('tiki_p_chat','Can use the chat system','registered','chat',NULL,'feature_minichat,feature_live_support'),('tiki_p_admin_cms','Can admin the articles','editors','cms','y','feature_articles'),('tiki_p_approve_submission','Can approve submissions','editors','cms',NULL,'feature_articles'),('tiki_p_articles_admin_topics','Can admin article topics','editors','cms',NULL,'feature_articles'),('tiki_p_articles_admin_types','Can admin article types','editors','cms',NULL,'feature_articles'),('tiki_p_articles_read_heading','Can read article headings','basic','cms',NULL,'feature_articles'),('tiki_p_autoapprove_submission','Submitted articles automatically approved','editors','cms',NULL,'feature_articles'),('tiki_p_edit_article','Can edit articles','editors','cms',NULL,'feature_articles'),('tiki_p_edit_submission','Can edit submissions','editors','cms',NULL,'feature_articles'),('tiki_p_read_article','Can read articles','basic','cms',NULL,'feature_articles'),('tiki_p_remove_article','Can remove articles','editors','cms',NULL,'feature_articles'),('tiki_p_remove_submission','Can remove submissions','editors','cms',NULL,'feature_articles'),('tiki_p_submit_article','Can submit articles','basic','cms',NULL,'feature_articles'),('tiki_p_rate_article','Can rate articles','basic','cms',NULL,'feature_articles'),('tiki_p_topic_read','Can read a topic (Applies only to individual topic perms)','basic','cms',NULL,'feature_articles'),('tiki_p_admin_contribution','Can admin contributions','admin','contribution','y','feature_contribution'),('tiki_p_admin_directory','Can admin the directory','editors','directory','y','feature_directory'),('tiki_p_admin_directory_cats','Can admin directory categories','editors','directory',NULL,'feature_directory'),('tiki_p_admin_directory_sites','Can admin directory sites','editors','directory',NULL,'feature_directory'),('tiki_p_autosubmit_link','Submitted links are valid','editors','directory',NULL,'feature_directory'),('tiki_p_submit_link','Can submit sites to the directory','basic','directory',NULL,'feature_directory'),('tiki_p_validate_links','Can validate submitted links','editors','directory',NULL,'feature_directory'),('tiki_p_view_directory','Can use the directory','basic','directory',NULL,'feature_directory'),('tiki_p_admin_faqs','Can admin faqs','editors','faqs','y','feature_faqs'),('tiki_p_suggest_faq','Can suggest faq questions','basic','faqs',NULL,'feature_faqs'),('tiki_p_view_faqs','Can view faqs','basic','faqs',NULL,'feature_faqs'),('tiki_p_admin','Administrator, can manage users groups and permissions, and all features','admin','tiki','y',NULL),('tiki_p_admin_users','Can admin users','admin','tiki',NULL,NULL),('tiki_p_access_closed_site','Can access site when closed','admin','tiki',NULL,NULL),('tiki_p_admin_banners','Administrator, can admin banners','admin','tiki',NULL,NULL),('tiki_p_admin_banning','Can ban users or ips','admin','tiki',NULL,NULL),('tiki_p_admin_dynamic','Can admin the dynamic content system','editors','tiki',NULL,NULL),('tiki_p_admin_integrator','Can admin integrator repositories and rules','admin','tiki',NULL,NULL),('tiki_p_admin_mailin','Can admin mail-in accounts','admin','tiki',NULL,NULL),('tiki_p_admin_objects','Can edit object permissions','admin','tiki',NULL,NULL),('tiki_p_admin_rssmodules','Can admin external feeds','admin','tiki',NULL,NULL),('tiki_p_clean_cache','Can clean cache','editors','tiki',NULL,NULL),('tiki_p_create_css','Can create new css suffixed with -user','registered','tiki',NULL,NULL),('tiki_p_detach_translation','Can remove association between two pages in a translation set','registered','tiki',NULL,NULL),('tiki_p_edit_cookies','Can admin cookies','editors','tiki',NULL,NULL),('tiki_p_edit_languages','Can edit translations and create new languages','editors','tiki',NULL,NULL),('tiki_p_edit_menu','Can edit menu','admin','tiki',NULL,NULL),('tiki_p_edit_menu_option','Can edit menu option','admin','tiki',NULL,NULL),('tiki_p_edit_templates','Can edit site templates','admin','tiki',NULL,NULL),('tiki_p_search','Can search','basic','tiki',NULL,NULL),('tiki_p_site_report','Can report a link to the webmaster','basic','tiki',NULL,NULL),('tiki_p_subscribe_groups','Can subscribe to groups','registered','tiki',NULL,NULL),('tiki_p_tell_a_friend','Can send a link to a friend','Basic','tiki',NULL,NULL),('tiki_p_share','Can share a page (email, twitter, facebook, message, forums)','Basic','tiki',NULL,NULL),('tiki_p_use_HTML','Can use HTML in pages','editors','tiki',NULL,NULL),('tiki_p_view_actionlog','Can view action log','registered','tiki',NULL,NULL),('tiki_p_view_actionlog_owngroups','Can view action log for users of his own groups','registered','tiki',NULL,NULL),('tiki_p_view_integrator','Can view integrated repositories','basic','tiki',NULL,NULL),('tiki_p_view_referer_stats','Can view referrer stats','editors','tiki',NULL,NULL),('tiki_p_view_stats','Can view site stats','basic','tiki',NULL,NULL),('tiki_p_view_templates','Can view site templates','admin','tiki',NULL,NULL),('tiki_p_blog_admin','Can admin blogs','editors','blogs','y','feature_blogs'),('tiki_p_assign_perm_blog','Can assign perms to blog','admin','blogs',NULL,'feature_blogs'),('tiki_p_blog_post','Can post to a blog','registered','blogs',NULL,'feature_blogs'),('tiki_p_create_blogs','Can create a blog','editors','blogs',NULL,'feature_blogs'),('tiki_p_read_blog','Can read blogs','basic','blogs',NULL,'feature_blogs'),('tiki_p_blog_post_view_ref','Can view in module and feed the blog posts','basic','blogs',NULL,'feature_blogs'),('tiki_p_blog_view_ref','Can view in module and feed the blog','basic','blogs',NULL,'feature_blogs'),('tiki_p_admin_file_galleries','Can admin file galleries','editors','file galleries','y','feature_file_galleries'),('tiki_p_assign_perm_file_gallery','Can assign perms to file gallery','admin','file galleries',NULL,'feature_file_galleries'),('tiki_p_batch_upload_file_dir','Can use Directory Batch Load','editors','file galleries',NULL,'feature_file_galleries'),('tiki_p_batch_upload_files','Can upload zip files with files','editors','file galleries',NULL,'feature_file_galleries'),('tiki_p_create_file_galleries','Can create file galleries','editors','file galleries',NULL,'feature_file_galleries'),('tiki_p_download_files','Can download files','basic','file galleries',NULL,'feature_file_galleries'),('tiki_p_edit_gallery_file','Can edit a gallery file','editors','file galleries',NULL,'feature_file_galleries'),('tiki_p_list_file_galleries','Can list file galleries','basic','file galleries',NULL,'feature_file_galleries'),('tiki_p_upload_files','Can upload files','registered','file galleries',NULL,'feature_file_galleries'),('tiki_p_view_fgal_explorer','Can view file galleries explorer','basic','file galleries',NULL,'feature_file_galleries'),('tiki_p_view_fgal_path','Can view file galleries path','basic','file galleries',NULL,'feature_file_galleries'),('tiki_p_view_file_gallery','Can view file galleries','basic','file galleries',NULL,'feature_file_galleries'),('tiki_p_admin_forum','Can admin forums','editors','forums','y','feature_forums'),('tiki_p_forum_attach','Can attach to forum posts','registered','forums',NULL,'feature_forums'),('tiki_p_forum_autoapp','Auto approve forum posts','editors','forums',NULL,'feature_forums'),('tiki_p_forum_edit_own_posts','Can edit own forum posts','registered','forums',NULL,'feature_forums'),('tiki_p_forum_post','Can post in forums','registered','forums',NULL,'feature_forums'),('tiki_p_forum_post_topic','Can start threads in forums','registered','forums',NULL,'feature_forums'),('tiki_p_forum_read','Can read forums','basic','forums',NULL,'feature_forums'),('tiki_p_forums_report','Can report posts to moderator','registered','forums',NULL,'feature_forums'),('tiki_p_forum_vote','Can vote comments in forums','registered','forums',NULL,'feature_forums'),('tiki_p_admin_freetags','Can admin freetags','admin','freetags','y','feature_freetags'),('tiki_p_admin_galleries','Can admin Image Galleries','editors','image galleries','y','feature_galleries'),('tiki_p_assign_perm_image_gallery','Can assign perms to image gallery','admin','image galleries',NULL,'feature_galleries'),('tiki_p_batch_upload_image_dir','Can use Directory Batch Load','editors','image galleries',NULL,'feature_galleries'),('tiki_p_batch_upload_images','Can upload zip files with images','editors','image galleries',NULL,'feature_galleries'),('tiki_p_create_galleries','Can create image galleries','editors','image galleries',NULL,'feature_galleries'),('tiki_p_freetags_tag','Can tag objects','registered','freetags',NULL,'feature_freetags'),('tiki_p_list_image_galleries','Can list image galleries','basic','image galleries',NULL,'feature_galleries'),('tiki_p_unassign_freetags','Can unassign tags from an object','basic','freetags',NULL,'feature_freetags'),('tiki_p_upload_images','Can upload images','registered','image galleries',NULL,'feature_galleries'),('tiki_p_view_freetags','Can browse freetags','basic','freetags',NULL,'feature_freetags'),('tiki_p_view_image_gallery','Can view image galleries','basic','image galleries',NULL,'feature_galleries'),('tiki_p_admin_newsletters','Can admin newsletters','admin','newsletters','y','feature_newsletters'),('tiki_p_batch_subscribe_email','Can subscribe many e-mails at once (requires tiki_p_subscribe email)','editors','newsletters',NULL,'feature_newsletters'),('tiki_p_send_newsletters','Can send newsletters','editors','newsletters',NULL,'feature_newsletters'),('tiki_p_subscribe_email','Can subscribe any email to newsletters','editors','newsletters',NULL,'feature_newsletters'),('tiki_p_subscribe_newsletters','Can subscribe to newsletters','basic','newsletters',NULL,'feature_newsletters'),('tiki_p_view_newsletter','Can view the archive of a newsletters','basic','newsletters',NULL,'feature_newsletters'),('tiki_p_list_newsletters','Can list newsletters','basic','newsletters',NULL,'feature_newsletters'),('tiki_p_admin_polls','Can admin polls','admin','polls','y','feature_polls'),('tiki_p_view_poll_results','Can view poll results','basic','polls',NULL,'feature_polls'),('tiki_p_vote_poll','Can vote polls','basic','polls',NULL,'feature_polls'),('tiki_p_view_poll_voters','Can view poll voters','basic','polls',NULL,'feature_polls'),('tiki_p_admin_toolbars','Can admin toolbars','admin','tiki',NULL,NULL),('tiki_p_admin_quizzes','Can admin quizzes','editors','quizzes','y','feature_quizzes'),('tiki_p_take_quiz','Can take quizzes','basic','quizzes',NULL,'feature_quizzes'),('tiki_p_view_quiz_stats','Can view quiz stats','basic','quizzes',NULL,'feature_quizzes'),('tiki_p_view_user_results','Can view user quiz results','editors','quizzes',NULL,'feature_quizzes'),('tiki_p_admin_sheet','Can admin sheet','admin','sheet','y','feature_sheet'),('tiki_p_edit_sheet','Can create and edit sheets','editors','sheet',NULL,'feature_sheet'),('tiki_p_view_sheet','Can view sheet','basic','sheet',NULL,'feature_sheet'),('tiki_p_view_sheet_history','Can view sheet history','admin','sheet',NULL,'feature_sheet'),('tiki_p_admin_shoutbox','Can admin shoutbox (Edit/remove messages)','editors','shoutbox','y','feature_shoutbox'),('tiki_p_post_shoutbox','Can post messages in shoutbox','basic','shoutbox',NULL,'feature_shoutbox'),('tiki_p_view_shoutbox','Can view shoutbox','basic','shoutbox',NULL,'feature_shoutbox'),('tiki_p_admin_surveys','Can admin surveys','editors','surveys','y','feature_surveys'),('tiki_p_take_survey','Can take surveys','basic','surveys',NULL,'feature_surveys'),('tiki_p_view_survey_stats','Can view survey stats','basic','surveys',NULL,'feature_surveys'),('tiki_p_admin_trackers','Can admin trackers','editors','trackers','y','feature_trackers'),('tiki_p_attach_trackers','Can attach files to tracker items','registered','trackers',NULL,'feature_trackers'),('tiki_p_comment_tracker_items','Can insert comments for tracker items','basic','trackers',NULL,'feature_trackers'),('tiki_p_tracker_view_comments','Can view tracker items comments','basic','trackers',NULL,'feature_trackers'),('tiki_p_create_tracker_items','Can create new items for trackers','registered','trackers',NULL,'feature_trackers'),('tiki_p_list_trackers','Can list trackers','basic','trackers',NULL,'feature_trackers'),('tiki_p_modify_tracker_items','Can change tracker items','registered','trackers',NULL,'feature_trackers'),('tiki_p_modify_tracker_items_pending','Can change pending tracker items','registered','trackers',NULL,'feature_trackers'),('tiki_p_modify_tracker_items_closed','Can change closed tracker items','registered','trackers',NULL,'feature_trackers'),('tiki_p_tracker_view_ratings','Can view rating result for tracker items','basic','trackers',NULL,'feature_trackers'),('tiki_p_tracker_vote_ratings','Can vote a rating for tracker items','registered','trackers',NULL,'feature_trackers'),('tiki_p_tracker_revote_ratings','Can re-vote a rating for tracker items','registered','trackers',NULL,'feature_trackers'),('tiki_p_view_trackers','Can view trackers','basic','trackers',NULL,'feature_trackers'),('tiki_p_view_trackers_closed','Can view closed trackers items','registered','trackers',NULL,'feature_trackers'),('tiki_p_view_trackers_pending','Can view pending trackers items','editors','trackers',NULL,'feature_trackers'),('tiki_p_watch_trackers','Can watch tracker','registered','trackers',NULL,'feature_trackers'),('tiki_p_export_tracker','Can export tracker items','registered','trackers',NULL,'feature_trackers'),('tiki_p_admin_wiki','Can admin the wiki','editors','wiki','y','feature_wiki'),('tiki_p_assign_perm_wiki_page','Can assign perms to wiki pages','admin','wiki',NULL,'feature_wiki'),('tiki_p_edit','Can edit pages','registered','wiki',NULL,'feature_wiki'),('tiki_p_edit_copyrights','Can edit copyright notices','editors','wiki',NULL,'wiki_feature_copyrights'),('tiki_p_edit_dynvar','Can edit dynamic variables','editors','wiki',NULL,'feature_wiki'),('tiki_p_edit_structures','Can create and edit structures','editors','wiki',NULL,'feature_wiki_structure'),('tiki_p_export_wiki','Can export wiki pages using the export feature','admin','wiki',NULL,'feature_wiki_export'),('tiki_p_lock','Can lock pages','editors','wiki',NULL,'feature_wiki'),('tiki_p_minor','Can save as minor edit','registered','wiki',NULL,'feature_wiki'),('tiki_p_remove','Can remove','editors','wiki',NULL,'feature_wiki'),('tiki_p_rename','Can rename pages','editors','wiki',NULL,'feature_wiki'),('tiki_p_rollback','Can rollback pages','editors','wiki',NULL,'feature_wiki'),('tiki_p_upload_picture','Can upload pictures to wiki pages','registered','wiki',NULL,'feature_wiki_pictures'),('tiki_p_use_as_template','Can use the page as a tracker template','basic','wiki',NULL,'feature_wiki'),('tiki_p_view','Can view page/pages','basic','wiki',NULL,'feature_wiki'),('tiki_p_wiki_view_ref','Can view in module and feed the wiki pages reference','basic','wiki',NULL,'feature_wiki'),('tiki_p_watch_structure','Can watch structure','registered','wiki',NULL,'feature_wiki_structure'),('tiki_p_wiki_admin_attachments','Can admin attachments on wiki pages','editors','wiki',NULL,'feature_wiki_attachments'),('tiki_p_wiki_admin_ratings','Can add and change ratings on wiki pages','admin','wiki',NULL,'feature_wiki_ratings'),('tiki_p_wiki_attach_files','Can attach files to wiki pages','registered','wiki',NULL,'feature_wiki_attachments'),('tiki_p_wiki_view_attachments','Can view wiki attachments and download','registered','wiki',NULL,'feature_wiki_attachments'),('tiki_p_wiki_view_comments','Can view wiki comments','basic','wiki',NULL,'feature_wiki_comments'),('tiki_p_wiki_view_history','Can view wiki history','basic','wiki',NULL,'feature_history'),('tiki_p_wiki_view_ratings','Can view rating of wiki pages','basic','wiki',NULL,'feature_wiki_ratings'),('tiki_p_wiki_view_source','Can view source of wiki pages','basic','wiki',NULL,'feature_source'),('tiki_p_wiki_vote_ratings','Can participate to rating of wiki pages','registered','wiki',NULL,'feature_wiki_ratings'),('tiki_p_wiki_view_similar','Can view similar wiki pages','registered','wiki',NULL,'feature_wiki'),('tiki_p_admin_received_articles','Can admin received articles','editors','comm',NULL,'feature_comm'),('tiki_p_admin_received_pages','Can admin received pages','editors','comm',NULL,'feature_comm'),('tiki_p_send_articles','Can send articles to other sites','editors','comm',NULL,'feature_comm'),('tiki_p_sendme_articles','Can send articles to this site','registered','comm',NULL,'feature_comm'),('tiki_p_sendme_pages','Can send pages to this site','registered','comm',NULL,'feature_comm'),('tiki_p_send_pages','Can send pages to other sites','registered','comm',NULL,'feature_comm'),('tiki_p_admin_tikitests','Can admin the TikiTests','admin','tikitests',NULL,'feature_tikitests'),('tiki_p_edit_tikitests','Can edit TikiTests','editors','tikitests',NULL,'feature_tikitests'),('tiki_p_play_tikitests','Can replay the TikiTests','registered','tikitests',NULL,'feature_tikitests'),('tiki_p_cache_bookmarks','Can cache user bookmarks','admin','user',NULL,'feature_user_bookmarks'),('tiki_p_configure_modules','Can configure modules','registered','user',NULL,'feature_modulecontrols'),('tiki_p_create_bookmarks','Can create user bookmarks','registered','user',NULL,'feature_user_bookmarks'),('tiki_p_minical','Can use the mini event calendar','registered','user',NULL,'feature_minical'),('tiki_p_notepad','Can use the notepad','registered','user',NULL,'feature_notepad'),('tiki_p_tasks_admin','Can admin public tasks','admin','user',NULL,'feature_tasks'),('tiki_p_tasks','Can use tasks','registered','user',NULL,'feature_tasks'),('tiki_p_tasks_receive','Can receive tasks from other users','registered','user',NULL,'feature_tasks'),('tiki_p_tasks_send','Can send tasks to other users','registered','user',NULL,'feature_tasks'),('tiki_p_userfiles','Can upload personal files','registered','user',NULL,'feature_userfiles'),('tiki_p_usermenu','Can create items in personal menu','registered','user',NULL,'feature_usermenu'),('tiki_p_broadcast_all','Can broadcast messages to all user','admin','messu',NULL,'feature_messages'),('tiki_p_broadcast','Can broadcast messages to groups','admin','messu',NULL,'feature_messages'),('tiki_p_messages','Can use the messaging system','registered','messu',NULL,'feature_messages'),('tiki_p_admin_comments','Can admin comments','admin','comments','y','feature_wiki_comments,feature_blogposts_comments,feature_file_galleries_comments,feature_image_galleries_comments,feature_article_comments,feature_faq_comments,feature_poll_comments,map_comments'),('tiki_p_edit_comments','Can edit all comments','editors','comments',NULL,'feature_wiki_comments,feature_blogposts_comments,feature_file_galleries_comments,feature_image_galleries_comments,feature_article_comments,feature_faq_comments,feature_poll_comments,map_comments'),('tiki_p_post_comments','Can post new comments','registered','comments',NULL,'feature_wiki_comments,feature_blogposts_comments,feature_file_galleries_comments,feature_image_galleries_comments,feature_article_comments,feature_faq_comments,feature_poll_comments,map_comments'),('tiki_p_read_comments','Can read comments','basic','comments',NULL,'feature_wiki_comments,feature_blogposts_comments,feature_file_galleries_comments,feature_image_galleries_comments,feature_article_comments,feature_faq_comments,feature_poll_comments,map_comments'),('tiki_p_remove_comments','Can delete comments','editors','comments',NULL,'feature_wiki_comments,feature_blogposts_comments,feature_file_galleries_comments,feature_image_galleries_comments,feature_article_comments,feature_faq_comments,feature_poll_comments,map_comments'),('tiki_p_vote_comments','Can vote comments','registered','comments',NULL,'feature_wiki_comments,feature_blogposts_comments,feature_file_galleries_comments,feature_image_galleries_comments,feature_article_comments,feature_faq_comments,feature_poll_comments,map_comments'),('tiki_p_admin_content_templates','Can admin content templates','admin','content templates','y','feature_wiki_templates,feature_cms_templates'),('tiki_p_edit_content_templates','Can edit content templates','editors','content templates',NULL,'feature_wiki_templates,feature_cms_templates'),('tiki_p_use_content_templates','Can use content templates','registered','content templates',NULL,'feature_wiki_templates,feature_cms_templates'),('tiki_p_edit_html_pages','Can edit HTML pages','editors','html pages',NULL,'feature_html_pages'),('tiki_p_view_html_pages','Can view HTML pages','basic','html pages',NULL,'feature_html_pages'),('tiki_p_list_users','Can list registered users','registered','user',NULL,'feature_friends'),('tiki_p_live_support_admin','Admin live support system','admin','support','y','feature_live_support'),('tiki_p_live_support','Can use live support system','basic','support',NULL,'feature_live_support'),('tiki_p_map_create','Can create new mapfile','admin','maps',NULL,'feature_maps'),('tiki_p_map_delete','Can delete mapfiles','admin','maps',NULL,'feature_maps'),('tiki_p_map_edit','Can edit mapfiles','editors','maps',NULL,'feature_maps'),('tiki_p_map_view','Can view mapfiles','basic','maps',NULL,'feature_maps'),('tiki_p_map_view_mapfiles','Can view contents of mapfiles','registered','maps',NULL,'feature_maps'),('tiki_p_use_webmail','Can use webmail','registered','webmail',NULL,'feature_webmail,feature_contacts'),('tiki_p_use_group_webmail','Can use group webmail','registered','webmail',NULL,'feature_webmail,feature_contacts'),('tiki_p_admin_group_webmail','Can admin group webmail accounts','registered','webmail',NULL,'feature_webmail,feature_contacts'),('tiki_p_use_personal_webmail','Can use personal webmail accounts','registered','webmail',NULL,'feature_webmail,feature_contacts'),('tiki_p_admin_personal_webmail','Can admin personal webmail accounts','registered','webmail',NULL,'feature_webmail,feature_contacts'),('tiki_p_plugin_viewdetail','Can view unapproved plugin details','registered','wiki',NULL,'feature_wiki'),('tiki_p_plugin_preview','Can execute unapproved plugin','registered','wiki',NULL,'feature_wiki'),('tiki_p_plugin_approve','Can approve plugin execution','editors','wiki',NULL,'feature_wiki'),('tiki_p_trust_input','Trust all user inputs including plugins (no security checks)','admin','tiki',NULL,NULL),('tiki_p_view_backlink','View page backlinks','basic','wiki',NULL,'feature_wiki'),('tiki_p_admin_notifications','Can admin mail notifications','editors','tiki',NULL,NULL),('tiki_p_invite_to_my_groups','Can invite user to my groups','editors','tiki',NULL,NULL),('tiki_p_delete_account','Can delete his/her own account','admin','tiki',NULL,NULL),('tiki_p_admin_importer','Can use the importer','admin','tiki',NULL,NULL),('tiki_p_admin_categories','Can admin categories','editors','category','y','feature_categories'),('tiki_p_view_category','Can see the category in a listing','basic','category',NULL,'feature_categories'),('tiki_p_modify_object_categories','Can change the categories of the object','editors','tiki',NULL,NULL),('tiki_p_add_object','Can add objects to the category','editors','category',NULL,'feature_categories'),('tiki_p_remove_object','Can remove objects from the category','editors','category',NULL,'feature_categories'),('tiki_p_create_category','Can create new categories','admin','category',NULL,'feature_categories'),('tiki_p_perspective_view','Can view the perspective','basic','perspective',NULL,'feature_perspective'),('tiki_p_perspective_edit','Can edit the perspective','basic','perspective',NULL,'feature_perspective'),('tiki_p_perspective_create','Can create a perspective','basic','perspective',NULL,'feature_perspective'),('tiki_p_perspective_admin','Can admin perspectives','admin','perspective','y','feature_perspective'),('tiki_p_group_view','Can view the group','basic','group',NULL,NULL),('tiki_p_group_view_members','Can view the group members','basic','group',NULL,NULL),('tiki_p_group_add_member','Can add group members','admin','group',NULL,NULL),('tiki_p_group_remove_member','Can remove group members','admin','group',NULL,NULL),('tiki_p_group_join','Can join or leave the group','admin','group',NULL,NULL),('tiki_p_trigger_transition','Can trigger the transition between two states','admin','transition',NULL,'feature_group_transition,feature_category_transition'),('tiki_p_admin_kaltura','Can admin kaltura feature','admin','kaltura','y','feature_kaltura'),('tiki_p_upload_videos','Can upload video on kaltura server','editors','kaltura',NULL,'feature_kaltura'),('tiki_p_edit_videos','Can edit information of kaltura entry','editors','kaltura',NULL,'feature_kaltura'),('tiki_p_remix_videos','Can create kaltura remix video','editors','kaltura',NULL,'feature_kaltura'),('tiki_p_delete_videos','Can delete kaltura entry','editors','kaltura',NULL,'feature_kaltura'),('tiki_p_download_videos','Can download kaltura entry','registered','kaltura',NULL,'feature_kaltura'),('tiki_p_list_videos','Can list kaltura entries','basic','kaltura',NULL,'feature_kaltura'),('tiki_p_view_videos','Can view kaltura entry','basic','kaltura',NULL,'feature_kaltura'),('tiki_p_dsn_query','Can execute arbitrary queries on a given DSN','admin','dsn',NULL,NULL),('tiki_p_payment_admin','Can administer payments','admin','payment','y','payment_feature'),('tiki_p_payment_view','Can view payment requests and details','admin','payment',NULL,'payment_feature'),('tiki_p_payment_manual','Can enter manual payments','admin','payment',NULL,'payment_feature'),('tiki_p_payment_request','Can request a payment','admin','payment',NULL,'payment_feature'),('tiki_p_admin_modules','User can administer modules','registered','tiki',NULL,NULL),('tiki_p_tracker_dump','Can save a .CSV backup of entire trackers','admin','trackers',NULL,'feature_trackers'),('tiki_p_bigbluebutton_join','Can join a meeting','basic','bigbluebutton',NULL,'bigbluebutton_feature'),('tiki_p_bigbluebutton_moderate','Can moderate a meeting','admin','bigbluebutton',NULL,'bigbluebutton_feature'),('tiki_p_bigbluebutton_create','Can create a meeting','admin','bigbluebutton',NULL,'bigbluebutton_feature'),('tiki_p_socialnetworks','user can use social network integration','registered','socialnetworks',NULL,'feature_socialnetworks'),('tiki_p_admin_socialnetworks','user can register this site with social networks','admin','socialnetworks','y','feature_socialnetworks'),('tiki_p_page_contribution_view','Can view contributions to a page','basic','wiki',NULL,'feature_wiki'),('tiki_p_invite','Can invite users by email, and include them in groups','registered','tiki',NULL,'feature_invite');
/*!40000 ALTER TABLE `users_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_usergroups`
--

DROP TABLE IF EXISTS `users_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_usergroups` (
  `userId` int(8) NOT NULL DEFAULT '0',
  `groupName` varchar(255) NOT NULL DEFAULT '',
  `created` int(14) DEFAULT NULL,
  `expire` int(14) DEFAULT NULL,
  PRIMARY KEY (`userId`,`groupName`(30))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_usergroups`
--

LOCK TABLES `users_usergroups` WRITE;
/*!40000 ALTER TABLE `users_usergroups` DISABLE KEYS */;
INSERT INTO `users_usergroups` VALUES (1,'Admins',NULL,NULL);
/*!40000 ALTER TABLE `users_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_users`
--

DROP TABLE IF EXISTS `users_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_users` (
  `userId` int(8) NOT NULL AUTO_INCREMENT,
  `email` varchar(200) DEFAULT NULL,
  `login` varchar(200) NOT NULL DEFAULT '',
  `password` varchar(30) DEFAULT '',
  `provpass` varchar(30) DEFAULT NULL,
  `default_group` varchar(255) DEFAULT NULL,
  `lastLogin` int(14) DEFAULT NULL,
  `currentLogin` int(14) DEFAULT NULL,
  `registrationDate` int(14) DEFAULT NULL,
  `challenge` varchar(32) DEFAULT NULL,
  `pass_confirm` int(14) DEFAULT NULL,
  `email_confirm` int(14) DEFAULT NULL,
  `hash` varchar(34) DEFAULT NULL,
  `created` int(14) DEFAULT NULL,
  `avatarName` varchar(80) DEFAULT NULL,
  `avatarSize` int(14) DEFAULT NULL,
  `avatarFileType` varchar(250) DEFAULT NULL,
  `avatarData` longblob,
  `avatarLibName` varchar(200) DEFAULT NULL,
  `avatarType` char(1) DEFAULT NULL,
  `score` int(11) NOT NULL DEFAULT '0',
  `valid` varchar(32) DEFAULT NULL,
  `unsuccessful_logins` int(14) DEFAULT '0',
  `openid_url` varchar(255) DEFAULT NULL,
  `waiting` char(1) DEFAULT NULL,
  PRIMARY KEY (`userId`),
  KEY `score` (`score`),
  KEY `login` (`login`),
  KEY `registrationDate` (`registrationDate`),
  KEY `openid_url` (`openid_url`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_users`
--

LOCK TABLES `users_users` WRITE;
/*!40000 ALTER TABLE `users_users` DISABLE KEYS */;
INSERT INTO `users_users` VALUES (1,'admin@switchedonpbx.org','admin','','',NULL,1305469960,1305469960,NULL,NULL,1305469960,NULL,'$1$s/dh8hFi$AyXpIF.YahJZJyjyLd8m6.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `users_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-05-15 10:46:16
