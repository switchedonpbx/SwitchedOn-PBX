<?php
// (c) Copyright 2002-2010 by authors of the Tiki Wiki/CMS/Groupware Project
// 
// All Rights Reserved. See copyright.txt for details and a complete list of authors.
// Licensed under the GNU LESSER GENERAL PUBLIC LICENSE. See license.txt for details.
// $Id: index.php 25258 2010-02-16 13:22:48Z changi67 $

// This redirects to the sites root to prevent directory browsing
header ("location: ../index.php");
die;
