The .pdf and .doc versions of the docs have been removed from the official
Tiki sources distribution since they were too big. You can download them
as a separate package from SourceForge.

Our SourceForge project URL is https://sourceforge.net/projects/tikiwiki. We
also have a Tiki site for the documentation which is available for reference
at http://doc.tiki.org

It is highly recommended to read the docs to understand all the Tiki features
and how to configure them.

Thanks !

Tiki Community
